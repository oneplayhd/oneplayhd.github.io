ADDON_ID = "script.limpeza.oneplay"
VERSION = "1.2.1"
