# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

import json

import xbmc


def execute(method, params=None, executor=None):
    request = {
        "jsonrpc": "2.0",
        "id": "script.limpeza.oneplay",
        "method": method,
    }
    if params is not None:
        request["params"] = params
    raw = (executor or xbmc.executeJSONRPC)(
        json.dumps(request, ensure_ascii=False)
    )
    try:
        response = json.loads(raw)
    except (TypeError, ValueError):
        raise RuntimeError("Resposta JSON-RPC inválida em %s" % method)
    if not isinstance(response, dict):
        raise RuntimeError("Resposta JSON-RPC inesperada em %s" % method)
    if response.get("error"):
        error = response["error"]
        message = error.get("message", "erro desconhecido") if isinstance(error, dict) else str(error)
        raise RuntimeError("%s: %s" % (method, message))
    return response.get("result")
