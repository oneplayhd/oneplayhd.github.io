# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

import os

import xbmc
import xbmcaddon
import xbmcvfs

from . import ADDON_ID


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def translate(path):
    return os.path.abspath(xbmcvfs.translatePath(path))


def profile_path(*parts):
    root = translate(addon().getAddonInfo("profile"))
    if not os.path.isdir(root):
        try:
            os.makedirs(root)
        except OSError:
            pass
    return os.path.join(root, *parts)


def setting_bool(key, default=False):
    value = addon().getSetting(key)
    if value == "":
        return bool(default)
    return value.strip().lower() in ("true", "1", "yes", "on")


def setting_int(key, default=0, minimum=None, maximum=None):
    try:
        value = int(addon().getSetting(key))
    except (TypeError, ValueError):
        value = int(default)
    if minimum is not None:
        value = max(minimum, value)
    if maximum is not None:
        value = min(maximum, value)
    return value


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[%s] %s" % (ADDON_ID, message), level)


def is_playing():
    try:
        return bool(xbmc.Player().isPlaying())
    except Exception:
        return False
