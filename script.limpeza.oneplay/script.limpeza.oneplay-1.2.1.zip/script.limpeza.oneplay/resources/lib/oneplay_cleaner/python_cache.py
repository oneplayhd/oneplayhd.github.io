# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

import os

from .models import Candidate, Report
from .platform import translate
from .safety import assert_safe_target, canonical, is_within


BYTECODE_EXTENSIONS = (".pyc", ".pyo")
PYTHON_CACHE_DIR = "__pycache__"


def _root_path(root=None):
    return canonical(root or translate("special://home/addons"))


def is_python_cache_file(path, root):
    path = canonical(path)
    root = canonical(root)
    if not is_within(path, root):
        return False
    if os.path.islink(path):
        return False
    relative = os.path.relpath(path, root)
    parts = relative.replace("\\", "/").split("/")
    if PYTHON_CACHE_DIR not in [part.lower() for part in parts[:-1]]:
        return False
    return parts[-1].lower().endswith(BYTECODE_EXTENSIONS)


def scan_python_cache(cancel=None, root=None):
    root = _root_path(root)
    report = Report()
    candidates = []
    if not os.path.isdir(root):
        return candidates, report

    for current, dirs, files in os.walk(root, topdown=True, followlinks=False):
        dirs[:] = [name for name in dirs if not os.path.islink(os.path.join(current, name))]
        if os.path.basename(current).lower() != PYTHON_CACHE_DIR:
            continue

        # Não percorre estruturas inesperadas dentro de __pycache__.
        dirs[:] = []
        for name in files:
            if cancel and cancel():
                report.cancelled = True
                return candidates, report
            path = os.path.join(current, name)
            if not is_python_cache_file(path, root):
                continue
            try:
                size = os.path.getsize(path)
            except OSError:
                size = 0
            candidates.append(Candidate(path, size, "python_cache"))
            report.add_candidate(size)

    return candidates, report


def delete_python_cache(candidates, cancel=None, on_progress=None, root=None):
    root = _root_path(root)
    report = Report()
    parents = set()
    total = len(candidates)

    for index, item in enumerate(candidates):
        if cancel and cancel():
            report.cancelled = True
            break
        try:
            path = assert_safe_target(item.path, root)
            if not is_python_cache_file(path, root):
                raise ValueError("Arquivo fora de uma pasta __pycache__ autorizada")
            os.unlink(path)
            parents.add(os.path.dirname(path))
            report.deleted += 1
            report.deleted_bytes += item.size
        except (OSError, ValueError) as exc:
            report.failed += 1
            if len(report.errors) < 20:
                report.errors.append("%s: %s" % (item.path, exc))
        if on_progress:
            on_progress(index + 1, total, item)

    # Remove somente a própria pasta __pycache__ quando ela ficou vazia.
    for folder in sorted(parents, key=len, reverse=True):
        try:
            if os.path.basename(folder).lower() != PYTHON_CACHE_DIR:
                continue
            assert_safe_target(folder, root)
            if not os.listdir(folder):
                os.rmdir(folder)
        except (OSError, ValueError):
            pass

    return report
