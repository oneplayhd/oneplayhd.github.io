# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

import os

try:
    from urllib.parse import unquote
except ImportError:  # pragma: no cover - Kodi usa Python 3
    from urllib import unquote

from .core import iter_files
from .jsonrpc import execute
from .models import Candidate, Report
from .platform import translate
from .safety import canonical, is_within


TEXTURE_PROPERTIES = ("url", "cachedurl", "imagehash", "lasthashcheck")


def texture_records(executor=None):
    result = execute(
        "Textures.GetTextures",
        {"properties": list(TEXTURE_PROPERTIES)},
        executor,
    )
    if not isinstance(result, dict):
        raise RuntimeError("Textures.GetTextures não retornou uma coleção")
    records = result.get("textures", [])
    if not isinstance(records, list):
        raise RuntimeError("Textures.GetTextures retornou dados incompatíveis")
    return records


def _normalized_url(value):
    value = unquote(str(value or "")).replace("\\", "/").lower()
    while value.endswith("/"):
        value = value[:-1]
    return value


def is_addon_texture(record):
    url = _normalized_url(record.get("url"))
    return (
        "/addons/" in url
        or url.startswith("special://home/addons/")
        or url.startswith("resource://")
    )


def _cached_file(record, root):
    cached_url = _normalized_url(record.get("cachedurl"))
    if not cached_url:
        return None
    path = canonical(os.path.join(root, *cached_url.split("/")))
    if not is_within(path, root):
        return None
    return path


def _record_size(record, root):
    path = _cached_file(record, root)
    if not path:
        return 0
    try:
        return max(0, int(os.path.getsize(path)))
    except OSError:
        return 0


def _remove_texture(texture_id, executor=None):
    result = execute(
        "Textures.RemoveTexture",
        {"textureid": int(texture_id)},
        executor,
    )
    if result != "OK":
        raise RuntimeError("Textures.RemoveTexture não confirmou a exclusão")


def scan_orphan_thumbnails(cancel=None, executor=None, root=None):
    report = Report()
    root = root or translate("special://thumbnails")
    if not os.path.isdir(root):
        return [], report
    records = texture_records(executor)
    references = set(
        _normalized_url(item.get("cachedurl"))
        for item in records
        if item.get("cachedurl")
    )
    candidates = []
    for item in iter_files(root, cancel=cancel) or ():
        relative = os.path.relpath(item.path, root).replace("\\", "/").lower()
        if relative not in references:
            candidates.append(Candidate(item.path, item.size, "thumbnails"))
            report.add_candidate(item.size)
    if cancel and cancel():
        report.cancelled = True
    return candidates, report


def refresh_cached_textures(scope="all", cancel=None, on_progress=None, executor=None, root=None):
    if scope not in ("all", "addons"):
        raise ValueError("Escopo de texturas desconhecido")
    root = root or translate("special://thumbnails")
    records = texture_records(executor)
    selected = records if scope == "all" else [item for item in records if is_addon_texture(item)]
    report = Report()
    report.scanned = len(records)
    report.candidates = len(selected)
    report.candidate_bytes = sum(_record_size(item, root) for item in selected)
    total = len(selected)
    for index, record in enumerate(selected):
        if cancel and cancel():
            report.cancelled = True
            break
        size = _record_size(record, root)
        try:
            texture_id = int(record.get("textureid"))
            _remove_texture(texture_id, executor)
            report.deleted += 1
            report.deleted_bytes += size
        except (RuntimeError, TypeError, ValueError) as exc:
            report.failed += 1
            if len(report.errors) < 20:
                report.errors.append("%s: %s" % (record.get("url", "?"), exc))
        if on_progress:
            on_progress(index + 1, total, record)
    return report


def clean_stale_texture_rows(cancel=None, on_progress=None, executor=None, root=None):
    root = root or translate("special://thumbnails")
    records = texture_records(executor)
    stale = []
    for item in records:
        if not item.get("cachedurl"):
            continue
        path = _cached_file(item, root)
        if path and not os.path.isfile(path):
            stale.append(item)
    report = Report()
    report.scanned = len(records)
    report.candidates = len(stale)
    total = len(stale)
    for index, record in enumerate(stale):
        if cancel and cancel():
            report.cancelled = True
            break
        try:
            _remove_texture(int(record.get("textureid")), executor)
            report.deleted += 1
        except (RuntimeError, TypeError, ValueError) as exc:
            report.failed += 1
            if len(report.errors) < 20:
                report.errors.append("%s: %s" % (record.get("url", "?"), exc))
        if on_progress:
            on_progress(index + 1, total, record)
    return report
