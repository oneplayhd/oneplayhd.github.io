# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

import sys

try:
    from urllib.parse import parse_qs, urlencode
except ImportError:  # pragma: no cover - Kodi uses Python 3
    from urlparse import parse_qs
    from urllib import urlencode

import xbmc
import xbmcgui
import xbmcplugin

from .engine import category_label, clean, scan
from .maintenance import clean_library
from .models import Report, format_bytes
from .platform import addon, is_playing, log, setting_bool
from .safety import RunLock
from .textures import clean_stale_texture_rows, refresh_cached_textures


SAFE_CATEGORIES = ("cache", "packages")
ALL_CATEGORIES = SAFE_CATEGORIES + ("python_cache", "thumbnails")


def _handle():
    try:
        return int(sys.argv[1])
    except (IndexError, TypeError, ValueError):
        return -1


def _base_url():
    try:
        return sys.argv[0]
    except IndexError:
        return "plugin://script.limpeza.oneplay/"


def _params():
    try:
        query = sys.argv[2].lstrip("?")
    except IndexError:
        query = ""
    return dict((key, values[-1]) for key, values in parse_qs(query).items())


def _url(**params):
    return "%s?%s" % (_base_url(), urlencode(params))


def _add_item(label, action, icon, folder=False, description=""):
    item = xbmcgui.ListItem(label=label)
    item.setArt({"icon": icon, "thumb": icon})
    if description:
        try:
            info = item.getVideoInfoTag()
            info.setTitle(label)
            info.setPlot(description)
        except (AttributeError, RuntimeError):
            item.setInfo("video", {"title": label, "plot": description})
    xbmcplugin.addDirectoryItem(_handle(), _url(action=action), item, isFolder=folder)


def _legacy_matrix_installed():
    try:
        return bool(xbmc.getCondVisibility("System.HasAddon(script.limpeza.Matrix)"))
    except Exception:
        return False


def show_menu():
    addon_path = addon().getAddonInfo("path")
    media = addon_path.rstrip("/\\") + "/resources/media/"
    if _legacy_matrix_installed():
        _add_item(
            "[B][COLOR red]AVISO: Script Limpeza Matrix antigo instalado[/COLOR][/B]",
            "legacy_warning",
            media + "database.png",
            description="Desative ou remova o addon antigo para não executar a limpeza errada.",
        )
    _add_item("[B]Analisar espaço recuperável[/B]", "analyze", media + "analyze.png", description="Somente analisa; não exclui nada.")
    _add_item("[B][COLOR green]Limpeza segura[/COLOR][/B]", "clean_safe", media + "safe.png", description="Cache/temporários vencidos e pacotes ZIP antigos. Deduplica caminhos e preserva logs, configurações e bancos.")
    _add_item("Limpar cache e temporários do Kodi", "clean_cache", media + "temp.png", description="Une special://temp e home/cache sem contar ou excluir o mesmo arquivo duas vezes.")
    _add_item("Remover pacotes ZIP antigos", "clean_packages", media + "packages.png")
    _add_item("Limpar cache Python dos addons", "clean_python_cache", media + "python.png", description="Remove somente arquivos .pyc/.pyo dentro de pastas __pycache__.")
    _add_item("[COLOR yellow]Remover miniaturas órfãs (espaço)[/COLOR]", "clean_thumbnails", media + "thumbnails.png", description="Remove arquivos sem referência. Não força o download de artes novas.")
    _add_item("[COLOR cyan]Atualizar artes dos addons[/COLOR]", "refresh_addon_art", media + "safe.png", description="Invalida pelo Kodi os ícones e fanarts em cache após atualizações de addons.")
    _add_item("[COLOR orange]Reconstruir todo o cache visual[/COLOR]", "refresh_all_art", media + "cache.png", description="Remove todas as texturas pela API oficial. As imagens voltam sob demanda.")
    _add_item("[COLOR yellow]Reparar índice de miniaturas[/COLOR]", "repair_textures", media + "database.png", description="Remove pela API do Kodi somente registros cujo arquivo físico não existe.")
    _add_item("[COLOR white]Limpar biblioteca de vídeos[/COLOR]", "clean_video_library", media + "database.png", description="Pede ao Kodi para remover do catálogo vídeos que não existem mais. Não apaga arquivos de mídia.")
    _add_item("[COLOR white]Limpar biblioteca de músicas[/COLOR]", "clean_audio_library", media + "database.png", description="Pede ao Kodi para remover do catálogo músicas que não existem mais. Não apaga arquivos de mídia.")
    _add_item("Configurações", "settings", media + "settings.png")
    xbmcplugin.setContent(_handle(), "files")
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


class Progress(object):
    def __init__(self, heading):
        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create(heading, "Preparando...")

    def cancelled(self):
        try:
            return self.dialog.iscanceled()
        except Exception:
            return False

    def update(self, current, total, message):
        percent = int((float(current) / max(1, total)) * 100)
        self.dialog.update(min(100, percent), message)

    def close(self):
        try:
            self.dialog.close()
        except Exception:
            pass


def _summary(report, analyzed=False):
    if analyzed:
        return "Itens encontrados: %d\nEspaço recuperável: %s" % (
            report.candidates, format_bytes(report.candidate_bytes))
    status = "interrompida" if report.cancelled else "concluída"
    text = "Limpeza %s.\n\nArquivos removidos: %d\nEspaço liberado: %s" % (
        status, report.deleted, format_bytes(report.deleted_bytes))
    if report.failed:
        text += "\nFalhas: %d" % report.failed
    return text


def _scan_with_progress(categories):
    progress = Progress("Script Limpeza OnePlay")
    try:
        all_candidates = {}
        total_report = Report()
        total = len(categories)
        for index, category in enumerate(categories):
            if progress.cancelled():
                total_report.cancelled = True
                break
            progress.update(index, total, "Analisando %s..." % category_label(category))
            candidates, report = scan(category, progress.cancelled)
            all_candidates[category] = candidates
            total_report.merge(report)
        progress.update(total, total, "Análise concluída")
        return all_candidates, total_report
    finally:
        progress.close()


def analyze():
    candidates, report = _scan_with_progress(ALL_CATEGORIES)
    lines = []
    for category in ALL_CATEGORIES:
        size = sum(item.size for item in candidates.get(category, ()))
        lines.append("%s: %d itens — %s" % (category_label(category), len(candidates.get(category, ())), format_bytes(size)))
    lines.append("")
    lines.append(_summary(report, analyzed=True))
    xbmcgui.Dialog().textviewer("Análise de limpeza", "\n".join(lines))


def _ensure_idle():
    if setting_bool("skip_while_playing", True) and is_playing():
        xbmcgui.Dialog().ok("Script Limpeza OnePlay", "Há uma reprodução em andamento. Pare o vídeo ou áudio antes de limpar.")
        return False
    return True


def clean_categories(categories, manual=True):
    if manual and not _ensure_idle():
        return Report()
    log("Limpeza iniciada: categorias=%s manual=%s" % (",".join(categories), manual))
    with RunLock():
        candidates, analyzed = _scan_with_progress(categories)
        log(
            "Análise concluída: categorias=%s candidatos=%d bytes=%d cancelada=%s" % (
                ",".join(categories), analyzed.candidates, analyzed.candidate_bytes, analyzed.cancelled
            )
        )
        if analyzed.cancelled:
            return analyzed
        if not analyzed.candidates:
            if manual:
                if tuple(categories) == ("cache",):
                    message = (
                        "Nenhum cache ou temporário vencido foi encontrado.\n\n"
                        "Isso é normal: o Kodi gerencia essas pastas e a limpeza respeita a idade mínima configurada."
                    )
                else:
                    message = "Nada seguro para remover com as regras atuais."
                xbmcgui.Dialog().ok("Script Limpeza OnePlay", message)
            return analyzed
        if manual and setting_bool("confirm_actions", True):
            message = "Excluir %d arquivo(s) e liberar aproximadamente %s?" % (
                analyzed.candidates, format_bytes(analyzed.candidate_bytes))
            if not xbmcgui.Dialog().yesno("Confirmar limpeza", message):
                analyzed.cancelled = True
                return analyzed
        progress = Progress("Limpando com segurança")
        deleted = Report()
        total = analyzed.candidates
        completed = [0]
        try:
            for category in categories:
                if progress.cancelled():
                    deleted.cancelled = True
                    break
                def on_progress(current, category_total, item):
                    overall = completed[0] + current
                    progress.update(overall, total, "Limpando %s..." % category_label(category))
                current = clean(category, candidates.get(category, ()), progress.cancelled, on_progress)
                deleted.merge(current)
                completed[0] += len(candidates.get(category, ()))
        finally:
            progress.close()
        if manual:
            xbmcgui.Dialog().ok("Script Limpeza OnePlay", _summary(deleted))
        log(
            "Limpeza concluída: categorias=%s removidos=%d bytes=%d falhas=%d cancelada=%s" % (
                ",".join(categories), deleted.deleted, deleted.deleted_bytes, deleted.failed, deleted.cancelled
            )
        )
        return deleted


def maintain_library(kind):
    if not _ensure_idle():
        return
    scanning_condition = "Library.IsScanningVideo" if kind == "video" else "Library.IsScanningMusic"
    if xbmc.getCondVisibility(scanning_condition):
        xbmcgui.Dialog().ok(
            "Script Limpeza OnePlay",
            "O Kodi está atualizando essa biblioteca. Aguarde a atualização terminar antes de limpar.",
        )
        return
    label = "vídeos" if kind == "video" else "músicas"
    question = (
        "Solicitar ao Kodi a limpeza da biblioteca de %s?\n\n"
        "Itens cujos arquivos não existem mais ou cujas fontes estejam indisponíveis poderão sair do catálogo. "
        "Nenhum arquivo de mídia será apagado."
    ) % label
    if not xbmcgui.Dialog().yesno("Limpar biblioteca de %s" % label, question):
        return
    with RunLock():
        clean_library(kind)
    log("Manutenção oficial da biblioteca solicitada: %s" % kind)


def repair_textures():
    if not _ensure_idle():
        return
    if not xbmcgui.Dialog().yesno("Reparar índice", "Remover do banco de texturas somente registros cujo arquivo não existe?"):
        return
    progress = Progress("Reparando índice de miniaturas")
    try:
        with RunLock():
            report = clean_stale_texture_rows(
                progress.cancelled,
                lambda current, total, item: progress.update(current, total, "Removendo registro inválido..."),
            )
    finally:
        progress.close()
    if report.failed:
        message = "O banco estava ocupado ou não pôde ser reparado. Nenhuma limpeza forçada foi feita."
    else:
        message = "Registros analisados: %d\nRegistros órfãos removidos: %d" % (report.scanned, report.deleted)
    xbmcgui.Dialog().ok("Script Limpeza OnePlay", message)
    log(
        "Reparo de texturas concluído: analisadas=%d removidas=%d falhas=%d cancelada=%s" % (
            report.scanned, report.deleted, report.failed, report.cancelled
        )
    )


def refresh_art(scope):
    if not _ensure_idle():
        return Report()
    if scope == "addons":
        title = "Atualizar artes dos addons"
        question = (
            "Invalidar os ícones e fanarts de addons armazenados pelo Kodi?\n\n"
            "As versões atuais serão recriadas automaticamente quando aparecerem na tela."
        )
    else:
        title = "Reconstruir cache visual"
        question = (
            "Remover todas as imagens do cache visual do Kodi?\n\n"
            "Pôsteres, fanarts e ícones serão baixados novamente sob demanda. "
            "A primeira navegação poderá ficar mais lenta e fontes remotas indisponíveis podem não voltar."
        )
    if not xbmcgui.Dialog().yesno(title, question):
        report = Report()
        report.cancelled = True
        return report
    progress = Progress(title)
    try:
        with RunLock():
            report = refresh_cached_textures(
                scope,
                progress.cancelled,
                lambda current, total, item: progress.update(current, total, "Invalidando imagens pelo Kodi..."),
            )
    finally:
        progress.close()
    message = (
        "Registros analisados: %d\n"
        "Imagens invalidadas: %d\n"
        "Falhas: %d\n\n"
        "As imagens atuais serão recriadas conforme o Kodi precisar."
    ) % (report.scanned, report.deleted, report.failed)
    xbmcgui.Dialog().ok("Script Limpeza OnePlay", message)
    log(
        "Atualização de artes concluída: escopo=%s analisadas=%d removidas=%d falhas=%d cancelada=%s" % (
            scope, report.scanned, report.deleted, report.failed, report.cancelled
        )
    )
    if report.deleted:
        xbmc.executebuiltin("Container.Refresh")
        xbmc.sleep(250)
        xbmc.executebuiltin("ReloadSkin()")
    return report


def run():
    action = _params().get("action", "menu")
    log("Ação solicitada: %s" % action)
    try:
        if action == "menu":
            show_menu()
        elif action == "legacy_warning":
            xbmcgui.Dialog().ok(
                "Conflito de addons de limpeza",
                "O script.limpeza.Matrix antigo também está instalado.\n\n"
                "O log periciado mostrou que ele, e não o OnePlay, executou a limpeza anterior. "
                "Desative ou remova o Matrix antes do próximo teste.",
            )
        elif action == "analyze":
            analyze()
        elif action == "clean_safe":
            clean_categories(SAFE_CATEGORIES)
        elif action == "clean_video_library":
            maintain_library("video")
        elif action == "clean_audio_library":
            maintain_library("audio")
        elif action.startswith("clean_"):
            category = action[len("clean_"):]
            if category not in ALL_CATEGORIES:
                raise ValueError("Categoria desconhecida")
            clean_categories((category,))
        elif action == "repair_textures":
            repair_textures()
        elif action == "refresh_addon_art":
            refresh_art("addons")
        elif action == "refresh_all_art":
            refresh_art("all")
        elif action == "settings":
            addon().openSettings()
        else:
            raise ValueError("Ação desconhecida")
    except RuntimeError as exc:
        xbmcgui.Dialog().ok("Script Limpeza OnePlay", str(exc))
    except Exception as exc:
        log("Falha na ação %s: %s" % (action, exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Script Limpeza OnePlay", "A operação foi interrompida com segurança. Consulte o log do Kodi.")
    finally:
        if action != "menu" and _handle() >= 0:
            try:
                xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
            except Exception:
                pass
