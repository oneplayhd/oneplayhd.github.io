# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

import os

from .core import delete_candidates, scan_root
from .models import Report
from .platform import setting_int, translate
from .python_cache import delete_python_cache, scan_python_cache
from .safety import canonical, is_within
from .textures import scan_orphan_thumbnails


CATEGORIES = {
    "cache": {
        "label": "Cache e temporários do Kodi",
        "roots": ("special://temp", "special://home/cache"),
        "age_setting": "kodi_cache_age_hours",
        "default_age": 24,
        "extensions": None,
        "protect_logs": True,
    },
    "packages": {
        "label": "Pacotes antigos",
        "roots": ("special://home/addons/packages",),
        "age_setting": "packages_age_days",
        "default_age": 7,
        "extensions": (".zip",),
        "protect_logs": False,
    },
}


def _protected_temp_file(path):
    name = os.path.basename(path).lower()
    return name in ("kodi.log", "kodi.old.log") or name.startswith("kodi_crashlog")


def category_roots(category):
    roots = []
    for value in CATEGORIES[category]["roots"]:
        root = canonical(translate(value))
        if root not in roots:
            roots.append(root)
    return roots


def category_label(category):
    if category == "thumbnails":
        return "Miniaturas órfãs"
    if category == "python_cache":
        return "Cache Python dos addons"
    return CATEGORIES[category]["label"]


def scan(category, cancel=None):
    if category == "thumbnails":
        return scan_orphan_thumbnails(cancel)
    if category == "python_cache":
        return scan_python_cache(cancel)
    config = CATEGORIES[category]
    amount = setting_int(config["age_setting"], config["default_age"], 0, 365)
    multiplier = 86400 if config["age_setting"].endswith("_days") else 3600
    candidates = []
    report = Report()
    seen = set()
    for root in category_roots(category):
        current, scanned = scan_root(
            root,
            category,
            minimum_age_seconds=amount * multiplier,
            extensions=config["extensions"],
            cancel=cancel,
            exclude=_protected_temp_file if config.get("protect_logs") else None,
        )
        for item in current:
            key = canonical(item.path)
            if key in seen:
                continue
            seen.add(key)
            candidates.append(item)
            report.add_candidate(item.size)
        if scanned.cancelled:
            report.cancelled = True
            break
    return candidates, report


def clean(category, candidates, cancel=None, on_progress=None):
    if category == "thumbnails":
        return delete_candidates(candidates, translate("special://thumbnails"), cancel, on_progress)
    if category == "python_cache":
        return delete_python_cache(candidates, cancel, on_progress)

    roots = category_roots(category)
    grouped = dict((root, []) for root in roots)
    report = Report()
    for item in candidates:
        target_root = next((root for root in roots if is_within(item.path, root)), None)
        if target_root is None:
            report.failed += 1
            if len(report.errors) < 20:
                report.errors.append("%s: fora das raízes autorizadas" % item.path)
            continue
        grouped[target_root].append(item)

    completed = 0
    total = len(candidates)
    for root in roots:
        items = grouped[root]
        if not items:
            continue
        offset = completed

        def root_progress(current, root_total, item, base=offset):
            if on_progress:
                on_progress(base + current, total, item)

        current = delete_candidates(items, root, cancel, root_progress)
        report.merge(current)
        completed += len(items)
        if current.cancelled:
            break
    return report
