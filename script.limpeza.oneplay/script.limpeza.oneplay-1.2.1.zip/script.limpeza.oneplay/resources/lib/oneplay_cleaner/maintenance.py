# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

from .jsonrpc import execute


LIBRARY_METHODS = {
    "video": "VideoLibrary.Clean",
    "audio": "AudioLibrary.Clean",
}


def clean_library(kind, executor=None):
    try:
        method = LIBRARY_METHODS[kind]
    except KeyError:
        raise ValueError("Biblioteca desconhecida")
    result = execute(method, {"showdialogs": True}, executor)
    if result != "OK":
        raise RuntimeError("%s não confirmou o início da manutenção" % method)
    return result
