# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

import errno
import json
import os
import time

from .platform import profile_path, translate


ALLOWED_ROOTS = (
    "special://home/cache",
    "special://temp",
    "special://home/addons/packages",
    "special://thumbnails",
    "special://home/addons",
)

FORBIDDEN_ROOTS = (
    "special://home",
    "special://profile",
    "special://userdata",
    "special://database",
    "special://masterprofile",
)


def canonical(path):
    return os.path.normcase(os.path.realpath(os.path.abspath(path)))


def allowed_roots():
    return tuple(canonical(translate(item)) for item in ALLOWED_ROOTS)


def forbidden_roots():
    return tuple(canonical(translate(item)) for item in FORBIDDEN_ROOTS)


def is_within(path, root):
    path = canonical(path)
    root = canonical(root)
    try:
        return os.path.commonpath((path, root)) == root
    except (AttributeError, ValueError):
        root_prefix = root.rstrip(os.sep) + os.sep
        return path == root or path.startswith(root_prefix)


def assert_safe_target(path, expected_root):
    target = canonical(path)
    root = canonical(expected_root)
    if target == root:
        raise ValueError("A raiz protegida não pode ser apagada")
    if not is_within(target, root):
        raise ValueError("Destino fora da raiz permitida")
    if root not in allowed_roots():
        raise ValueError("Raiz não autorizada")
    if target in forbidden_roots():
        raise ValueError("Destino protegido")
    return target


class RunLock(object):
    def __init__(self, stale_seconds=7200):
        self.path = profile_path("cleaner.lock")
        self.stale_seconds = int(stale_seconds)
        self.owned = False

    def acquire(self):
        now = int(time.time())
        try:
            if os.path.exists(self.path) and now - int(os.path.getmtime(self.path)) > self.stale_seconds:
                os.unlink(self.path)
        except (OSError, ValueError):
            pass
        flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
        try:
            descriptor = os.open(self.path, flags)
        except OSError as exc:
            if exc.errno == errno.EEXIST:
                return False
            raise
        payload = json.dumps({"pid": os.getpid(), "time": now}).encode("utf-8")
        try:
            os.write(descriptor, payload)
        finally:
            os.close(descriptor)
        self.owned = True
        return True

    def release(self):
        if self.owned:
            try:
                os.unlink(self.path)
            except OSError:
                pass
            self.owned = False

    def __enter__(self):
        if not self.acquire():
            raise RuntimeError("Já existe uma limpeza em andamento")
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.release()
