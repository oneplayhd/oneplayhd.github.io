# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

import time

import xbmc
import xbmcgui

from .engine import clean, scan
from .models import Report, format_bytes
from .platform import addon, is_playing, log, setting_bool, setting_int
from .safety import RunLock


def _selected_categories():
    result = []
    for category in ("cache", "packages"):
        if setting_bool("auto_" + category, True):
            result.append(category)
    return result


def _due(now):
    last_run = setting_int("last_auto_run", 0, 0)
    interval_days = setting_int("auto_interval", 7, 1, 30)
    return not last_run or now - last_run >= interval_days * 86400


def _automatic_clean(cancel=None):
    result = Report()
    with RunLock():
        for category in _selected_categories():
            if cancel and cancel():
                result.cancelled = True
                break
            candidates, scanned = scan(category, cancel)
            result.merge(scanned)
            if scanned.cancelled:
                break
            result.merge(clean(category, candidates, cancel))
    return result


def run_service():
    monitor = xbmc.Monitor()
    startup_delay_done = False
    log("Serviço iniciado")
    while not monitor.abortRequested():
        if not setting_bool("auto_enabled", False):
            startup_delay_done = False
            if monitor.waitForAbort(60):
                break
            continue
        if not startup_delay_done:
            delay = setting_int("auto_delay_minutes", 5, 0, 60)
            if monitor.waitForAbort(delay * 60):
                break
            startup_delay_done = True
        now = int(time.time())
        if not _due(now):
            if monitor.waitForAbort(300):
                break
            continue
        if setting_bool("skip_while_playing", True) and is_playing():
            log("Limpeza automática adiada: reprodução ativa")
            if monitor.waitForAbort(300):
                break
            continue
        try:
            report = _automatic_clean(monitor.abortRequested)
            if report.cancelled:
                log("Limpeza automática interrompida pelo encerramento do Kodi")
                break
            addon().setSetting("last_auto_run", str(int(time.time())))
            log(
                "Limpeza automática concluída: candidatos=%d removidos=%d bytes=%d falhas=%d" % (
                    report.candidates, report.deleted, report.deleted_bytes, report.failed
                )
            )
            if report.deleted:
                xbmcgui.Dialog().notification(
                    "Script Limpeza OnePlay",
                    "%d arquivo(s), %s liberados" % (report.deleted, format_bytes(report.deleted_bytes)),
                    addon().getAddonInfo("icon"),
                    5000,
                    False,
                )
        except RuntimeError:
            log("Limpeza automática adiada: outra limpeza está em andamento")
        except Exception as exc:
            log("Falha segura na limpeza automática: %s" % exc, xbmc.LOGERROR)
        if monitor.waitForAbort(300):
            break
    log("Serviço encerrado")
