# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals


class Candidate(object):
    __slots__ = ("path", "size", "category")

    def __init__(self, path, size, category):
        self.path = path
        self.size = max(0, int(size or 0))
        self.category = category


class Report(object):
    def __init__(self):
        self.scanned = 0
        self.candidates = 0
        self.candidate_bytes = 0
        self.deleted = 0
        self.deleted_bytes = 0
        self.failed = 0
        self.skipped = 0
        self.cancelled = False
        self.errors = []

    def add_candidate(self, size):
        self.scanned += 1
        self.candidates += 1
        self.candidate_bytes += max(0, int(size or 0))

    def merge(self, other):
        for key in ("scanned", "candidates", "candidate_bytes", "deleted",
                    "deleted_bytes", "failed", "skipped"):
            setattr(self, key, getattr(self, key) + getattr(other, key))
        self.cancelled = self.cancelled or other.cancelled
        self.errors.extend(other.errors)
        return self


def format_bytes(value):
    value = float(max(0, value or 0))
    units = ("B", "KB", "MB", "GB", "TB")
    index = 0
    while value >= 1024.0 and index < len(units) - 1:
        value /= 1024.0
        index += 1
    if index == 0:
        return "%d %s" % (int(value), units[index])
    return "%.2f %s" % (value, units[index])
