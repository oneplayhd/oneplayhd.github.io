# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

from resources.lib.oneplay_cleaner.router import run


if __name__ == "__main__":
    run()
