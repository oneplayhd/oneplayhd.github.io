# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

from resources.lib.oneplay_cleaner.scheduler import run_service


if __name__ == "__main__":
    run_service()
