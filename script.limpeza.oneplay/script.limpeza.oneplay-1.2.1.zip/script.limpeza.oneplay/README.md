# Script Limpeza OnePlay 1.2.1

Addon de limpeza e manutenção para Kodi 19–21.x, com foco em segurança,
baixo consumo e compatibilidade com Windows, Linux, Android e TV Box.

## Funções

- Analisa o espaço recuperável sem excluir arquivos.
- Une `special://temp` e `special://home/cache`, elimina raízes duplicadas e
  limpa cada arquivo físico no máximo uma vez, preservando `kodi.log`,
  `kodi.old.log` e relatórios `kodi_crashlog*`.
- Remove somente pacotes `.zip` antigos de `special://home/addons/packages`.
- Remove `.pyc`/`.pyo` somente dentro de pastas `__pycache__` dos addons.
- O cache e os temporários participam da limpeza segura e, opcionalmente, da
  automação com retenção padrão conservadora de 24 horas.
- Remove somente miniaturas físicas sem referência no índice de texturas.
- Atualiza artes de addons e reconstrói o cache visual por
  `Textures.GetTextures` e `Textures.RemoveTexture`.
- Repara referências de texturas cujo arquivo físico não existe, sem escrever
  diretamente no banco `Textures*.db`.
- Solicita ao próprio Kodi a limpeza das bibliotecas de vídeo e música por
  `VideoLibrary.Clean` e `AudioLibrary.Clean`.

## Política de segurança

- A limpeza automática vem desativada e alcança somente cache/temporários
  vencidos e pacotes ZIP antigos.
- Toda exclusão manual é analisada e confirmada antes da execução.
- Por padrão, nenhuma limpeza ocorre durante reprodução.
- Configurações, perfis, bancos, fontes, favoritos e `addon_data` são protegidos.
- Nenhuma raiz é apagada; somente arquivos internos a raízes autorizadas.
- Links simbólicos não são seguidos.
- Não há caminhos personalizados nem comandos de sistema.
- Bibliotecas e texturas são mantidas exclusivamente pelas APIs do Kodi.
- A reconstrução visual completa é manual e alerta sobre o novo download das artes.

## Observações

O Kodi pode mapear `special://temp` e `special://home/cache` para a mesma pasta,
como ocorre no Windows/Kodi 21.3 periciado. O addon resolve os caminhos reais,
deduplica a raiz e não conta nem exclui o mesmo arquivo duas vezes. Se não houver
itens com mais de 24 horas, a mensagem de nenhum cache encontrado é correta.
O cache Python permanece como ação manual porque é recompilado pelo próprio Kodi
logo após os módulos voltarem a ser importados.
O cache do aplicativo Android exibido nas configurações do sistema operacional
não é apagado por este addon.

## Instalação

Abra **Add-ons → Instalar de um arquivo ZIP** e selecione o pacote. O addon
aparecerá em **Add-ons de programas**.
