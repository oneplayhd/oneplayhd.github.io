# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

from .core import delete_candidates, scan_root
from .models import Report
from .platform import setting_int, translate
from .python_cache import delete_python_cache, scan_python_cache
from .textures import scan_orphan_thumbnails


CATEGORIES = {
    "cache": {
        "label": "Cache do Kodi",
        "root": "special://home/cache",
        "age_setting": "cache_age_hours",
        "default_age": 1,
        "extensions": None,
    },
    "temp": {
        "label": "Arquivos temporários",
        "root": "special://temp",
        "age_setting": "temp_age_hours",
        "default_age": 2,
        "extensions": None,
    },
    "packages": {
        "label": "Pacotes antigos",
        "root": "special://home/addons/packages",
        "age_setting": "packages_age_days",
        "default_age": 7,
        "extensions": (".zip",),
    },
}


def category_label(category):
    if category == "thumbnails":
        return "Miniaturas órfãs"
    if category == "python_cache":
        return "Cache Python dos addons"
    return CATEGORIES[category]["label"]


def scan(category, cancel=None):
    if category == "thumbnails":
        return scan_orphan_thumbnails(cancel)
    if category == "python_cache":
        return scan_python_cache(cancel)
    config = CATEGORIES[category]
    amount = setting_int(config["age_setting"], config["default_age"], 0, 365)
    multiplier = 86400 if config["age_setting"].endswith("_days") else 3600
    return scan_root(
        translate(config["root"]),
        category,
        minimum_age_seconds=amount * multiplier,
        extensions=config["extensions"],
        cancel=cancel,
    )


def clean(category, candidates, cancel=None, on_progress=None):
    if category == "thumbnails":
        root = translate("special://thumbnails")
    elif category == "python_cache":
        return delete_python_cache(candidates, cancel, on_progress)
    else:
        root = translate(CATEGORIES[category]["root"])
    return delete_candidates(candidates, root, cancel, on_progress)


def scan_many(categories, cancel=None):
    result = {}
    report = Report()
    for category in categories:
        if cancel and cancel():
            report.cancelled = True
            break
        candidates, current = scan(category, cancel)
        result[category] = candidates
        report.merge(current)
    return result, report
