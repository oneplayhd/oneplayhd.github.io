ADDON_ID = "script.limpeza.oneplay"
VERSION = "1.1.0"
