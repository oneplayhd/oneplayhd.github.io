# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

import os
import time

from .models import Candidate, Report
from .safety import assert_safe_target, canonical, is_within


def iter_files(root, minimum_age_seconds=0, extensions=None, cancel=None):
    root = canonical(root)
    now = time.time()
    normalized_extensions = None
    if extensions:
        normalized_extensions = tuple(item.lower() for item in extensions)
    if not os.path.isdir(root):
        return
    for current, dirs, files in os.walk(root, topdown=True, followlinks=False):
        dirs[:] = [name for name in dirs if not os.path.islink(os.path.join(current, name))]
        for name in files:
            if cancel and cancel():
                return
            path = os.path.join(current, name)
            if os.path.islink(path) or not is_within(path, root):
                continue
            if normalized_extensions and not name.lower().endswith(normalized_extensions):
                continue
            try:
                stat = os.stat(path)
            except OSError:
                continue
            if minimum_age_seconds and now - stat.st_mtime < minimum_age_seconds:
                continue
            yield Candidate(path, stat.st_size, "")


def scan_root(root, category, minimum_age_seconds=0, extensions=None, cancel=None):
    report = Report()
    candidates = []
    for item in iter_files(root, minimum_age_seconds, extensions, cancel) or ():
        item.category = category
        candidates.append(item)
        report.add_candidate(item.size)
    if cancel and cancel():
        report.cancelled = True
    return candidates, report


def delete_candidates(candidates, root, cancel=None, on_progress=None):
    report = Report()
    total = len(candidates)
    for index, item in enumerate(candidates):
        if cancel and cancel():
            report.cancelled = True
            break
        try:
            safe_path = assert_safe_target(item.path, root)
            os.unlink(safe_path)
            report.deleted += 1
            report.deleted_bytes += item.size
        except (OSError, ValueError) as exc:
            report.failed += 1
            if len(report.errors) < 20:
                report.errors.append("%s: %s" % (item.path, exc))
        if on_progress:
            on_progress(index + 1, total, item)
    prune_empty_directories(root)
    return report


def prune_empty_directories(root):
    root = canonical(root)
    if not os.path.isdir(root):
        return
    for current, dirs, files in os.walk(root, topdown=False, followlinks=False):
        if canonical(current) == root:
            continue
        if os.path.islink(current):
            continue
        try:
            if not os.listdir(current):
                assert_safe_target(current, root)
                os.rmdir(current)
        except (OSError, ValueError):
            pass
