# Script Limpeza OnePlay 1.1.0

Addon de manutenção para Kodi 19–21.x, reconstruído com foco em segurança,
baixo consumo e compatibilidade com Windows, Linux, Android e TV Box.

## Política de segurança

- A limpeza automática vem desativada.
- A limpeza segura atua apenas em cache, temporários e pacotes ZIP antigos.
- O cache Python remove somente `.pyc`/`.pyo` dentro de pastas `__pycache__`
  dos addons instalados, incluindo arquivos `cpython-38.opt-1`.
- Miniaturas são removidas somente quando não estão referenciadas no banco.
- Nenhuma pasta `addon_data` é apagada automaticamente.
- Nenhum caminho personalizado é aceito.
- Nenhuma raiz do Kodi é removida; somente arquivos internos a raízes permitidas.
- Links simbólicos não são seguidos.
- Toda limpeza manual é analisada e confirmada antes da exclusão.
- A execução é bloqueada durante reprodução por padrão.

## Instalação

No Kodi, abra **Add-ons → Instalar de um arquivo ZIP** e selecione o pacote.
O addon aparece em **Add-ons de programas**.

## Versão 1.1.0

- Adicionada atualização direcionada das artes de addons pelo JSON-RPC oficial
  `Textures.GetTextures` e `Textures.RemoveTexture`.
- Adicionada reconstrução manual e confirmada de todo o cache visual.
- O reparo do índice não escreve mais diretamente em `Textures13.db` enquanto
  o Kodi está aberto; a exclusão coordenada fica sob responsabilidade do Kodi.
- A limpeza de miniaturas órfãs permanece separada da atualização de imagens.
- Após a invalidação, o container e a skin são recarregados para solicitar as
  artes atuais sob demanda.
- Logs agora identificam a ação solicitada e o resultado da atualização visual.
- Novo ícone temático com sujeira e vassoura, preservando o logo oficial.

## Versão 1.0.4

- Ícone principal refeito com um único logotipo oficial, fundo limpo e margem segura.
- Fanart, pictogramas internos e lógica de limpeza preservados sem alteração.

## Versão 1.0.3

- Novo ícone, nova fanart e nove pictogramas internos alinhados à identidade visual oficial OnePlay.
- Menus de análise, cache, banco, pacotes, Python, segurança, configurações,
  temporários e miniaturas agora possuem símbolos próprios e consistentes.
- Nenhuma alteração na lógica de limpeza já periciada na versão 1.0.2.
