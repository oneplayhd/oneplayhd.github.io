# -*- coding: utf-8 -*-

WEBSITE = 'OVERFLIX'

try:
    from resources.lib.ClientScraper import cfscraper, USER_AGENT
except ImportError:
    from ClientScraper import cfscraper, USER_AGENT

import requests
from bs4 import BeautifulSoup
from urllib.parse import quote_plus, urlparse, urljoin
import os
import sys
import re
import difflib
from urllib.parse import urlparse

try:
    from resources.lib.autotranslate import AutoTranslate
    portuguese = AutoTranslate.language('Portuguese')
    english = AutoTranslate.language('English')
    select_option_name = AutoTranslate.language('select_option')
except ImportError:
    portuguese = 'DUBLADO'
    english = 'LEGENDADO'
    select_option_name = 'SELECIONE UMA OPÇÃO ABAIXO:'

try:
    from kodi_helper import myAddon
    addonId = re.search('plugin\://(.+?)/', str(sys.argv[0])).group(1)
    addon = myAddon(addonId)
    select = addon.select
except ImportError:
    local_path = os.path.dirname(os.path.realpath(__file__))
    lib_path = local_path.replace('scrapers', '')
    sys.path.append(lib_path)

try:
    from resources.lib import resolveurl
except ImportError:
    local_path = os.path.dirname(os.path.realpath(__file__))
    lib_path = local_path.replace('scrapers', '')
    sys.path.append(lib_path)
    from resolvers import resolveurl


class source:
    __site_url__ = ['https://overflixtv.bond/']

    @classmethod
    def find_title(cls, imdb):
        url = f'https://m.imdb.com/pt/title/{imdb}'
        try:
            r = cfscraper.get(url)
            if not r or r.status_code != 200:
                return '', '', ''
            soup = BeautifulSoup(r.text, 'html.parser')
            title_el = soup.find('h1', {'data-testid': 'hero__pageTitle'})
            title = title_el.find('span').get_text(strip=True) if title_el else ''
            orig_el = soup.find('div', class_='sc-cb6a22b2-1')
            original = orig_el.get_text(strip=True).replace('Título original:', '').strip() if orig_el else ''
            year = ''
            for sel in ['a[class*="titleYear"]', 'a[data-testid*="release"]', 'li[data-testid*="releaseyear"]']:
                el = soup.select_one(sel)
                if el:
                    m = re.search(r'\d{4}', el.get_text())
                    if m:
                        year = m.group(0)
                        break
            return title, original, year
        except:
            return '', '', ''

    @classmethod
    def _extract_all_embeds(cls, html, page_url):
        embeds = []
        soup = BeautifulSoup(html, 'html.parser')

        token = 'xief4dkvetrronx'
        m = re.search(r'token\s*=\s*["\']([^"\']+)["\']', html)
        if m:
            token = m.group(1)

        base_match = re.search(r'src="([^"]+?/e/getembed\.php)', html)
        embed_base = base_match.group(1).rsplit('/', 1)[0] if base_match else "https://etv-embed.cfd"

        legendado_ids = {}
        js = re.search(r'function NewAudio\(\)\{([^}]+)\}', html, re.DOTALL)
        if js:
            block = js.group(1)
            for srv in ['filemoon', 'doodstream', 'mixdrop', 'streamtape']:
                m = re.search(fr"id=([0-9]+)&.*?{srv}", block)
                if m:
                    legendado_ids[srv] = m.group(1)

        visible_ids = {}
        for div in soup.find_all('div', class_='item', onclick=re.compile(r'GetIframe')):
            m = re.search(r"GetIframe\('(\d+)','(\w+)'\)", div.get('onclick', ''))
            if m:
                vid, srv = m.groups()
                visible_ids[srv] = vid

        servers = {}
        for srv in ['filemoon', 'doodstream', 'mixdrop', 'streamtape']:
            dub = visible_ids.get(srv)
            leg = legendado_ids.get(srv, dub)
            if dub:
                servers[srv] = {'dub': dub, 'leg': leg}

        for srv, ids in servers.items():
            for lang, pid in [('dub', ids['dub']), ('leg', ids['leg'])]:
                if not pid:
                    continue
                label = portuguese if lang == 'dub' else english
                name = f"{srv.upper()} - {label}"
                getembed = f"{embed_base}/e/getembed.php?sv={srv}&id={pid}&site=overflix&token={token}"
                video = cls._get_play_url(page_url, getembed, {'id': pid, 'sv': srv, 'token': token})
                if video:
                    embeds.append((name, video))
        return embeds

    @classmethod
    def _get_play_url(cls, referer_url, getembed_url, meta):
        base = '/'.join(getembed_url.split('/')[:3])
        play_url = f"{base}/e/getplay.php?id={meta['id']}&sv={meta['sv']}"
        headers = {'User-Agent': USER_AGENT, 'Referer': getembed_url}
        try:
            r = requests.get(play_url, headers=headers, allow_redirects=True)
            if r.history:
                return r.url
            for pat in [
                r'window\.location\.href\s*=\s*["\']([^"\']+)["\']',
                r'<iframe[^>]+src=["\']([^"\']+)["\']',
                r'var\s+videoUrl\s*=\s*["\']([^"\']+)["\']'
            ]:
                m = re.search(pat, r.text, re.I)
                if m and any(h in m.group(1) for h in ['filemoon.', 'dood.', 'mixdrop.', 'streamtape.']):
                    return m.group(1)
            return None
        except:
            return None

    @classmethod
    def search_movies(cls, imdb, year):
        title, original_title, imdb_year = cls.find_title(imdb)
        if not title:
            return []

        query = quote_plus(title)
        search_url = cls.__site_url__[-1].rstrip('/') + '/pesquisar/?p=' + query
        r = cfscraper.get(search_url)
        if not r or r.status_code != 200 or "captcha" in r.text.lower():
            return []

        soup = BeautifulSoup(r.text, 'html.parser')
        results = soup.find_all('a', href=re.compile(r'/assistir-.*-\d{4}-[^/]+'))

        movie_urls = {}

        for item in results:
            href = urljoin(cls.__site_url__[-1], item['href'])

            # Título exibido no resultado da busca
            found_title = item.get_text(strip=True)
            found_title_cleaned = re.sub(r'(?i)(dublado|legendado|\d{4}\d+min$)', '', found_title).strip()

            # Extrai ano da URL
            y_match = re.search(r'-(\d{4})-([^/]+)/?$', href)
            found_year = y_match.group(1) if y_match else None

            # Similaridade (igual ao original que funcionava)
            title_sim = difflib.SequenceMatcher(None, title.lower(), found_title_cleaned.lower()).ratio() * 100
            orig_sim = difflib.SequenceMatcher(None, original_title.lower(), found_title_cleaned.lower()).ratio() * 100 if original_title else 0
            max_similarity = max(title_sim, orig_sim)

            # Filtro exatamente como no original: >= 50% + ano tem que bater
            if max_similarity >= 50 and found_year and int(year) == int(found_year):
                href_l = href.lower()
                if 'dublado' in href_l:
                    movie_urls['dublado'] = href
                elif 'legendado' in href_l:
                    movie_urls['legendado'] = href
                else:
                    movie_urls.setdefault('dublado', href)

        if not movie_urls:
            return []

        main_url = movie_urls.get('dublado') or movie_urls.get('legendado')
        if 'area=online' not in main_url:
            main_url += ('&' if '?' in main_url else '?') + 'area=online'

        r = cfscraper.get(main_url, headers={'Referer': cls.__site_url__[-1]})
        if not r or r.status_code != 200:
            return []

        return cls._extract_all_embeds(r.text, main_url)

    @classmethod
    def search_tvshows(cls, imdb, year, season, episode):
        try:
            season = int(season)
            episode = int(episode)
        except:
            return []

        title, original_title, imdb_year = cls.find_title(imdb)
        if not title:
            return []

        query = quote_plus(title)
        search_url = cls.__site_url__[-1].rstrip('/') + '/pesquisar/?p=' + query
        r = cfscraper.get(search_url)
        if not r or r.status_code != 200:
            return []

        soup = BeautifulSoup(r.text, 'html.parser')
        results = soup.find_all('a', href=re.compile(r'/assistir-.*-\d{4}-[^/]+'))

        series_urls = {}

        for item in results:
            href = urljoin(cls.__site_url__[-1], item['href'])
            found_title = item.get_text(strip=True)
            found_title_cleaned = re.sub(r'(?i)(dublado|legendado|\d{4}\d+min$)', '', found_title).strip()

            y_match = re.search(r'-(\d{4})-([^/]+)/?$', href)
            found_year = y_match.group(1) if y_match else None

            title_sim = difflib.SequenceMatcher(None, title.lower(), found_title_cleaned.lower()).ratio() * 100
            orig_sim = difflib.SequenceMatcher(None, original_title.lower(), found_title_cleaned.lower()).ratio() * 100 if original_title else 0
            max_similarity = max(title_sim, orig_sim)

            if max_similarity >= 50 and found_year and int(year) == int(found_year):
                href_l = href.lower()
                if 'dublado' in href_l:
                    series_urls['dublado'] = href
                elif 'legendado' in href_l:
                    series_urls['legendado'] = href
                else:
                    series_urls.setdefault('dublado', href)

        if not series_urls:
            return []

        base_url = series_urls.get('dublado') or series_urls.get('legendado')

        r = cfscraper.get(base_url, headers={'Referer': cls.__site_url__[-1]})
        if not r or r.status_code != 200:
            return []

        soup = BeautifulSoup(r.text, 'html.parser')
        ep_links = soup.find_all('a', href=re.compile(r'/assistir-.*-(\d+)x(\d+)-'))

        episode_url = None
        for item in ep_links:
            href = urljoin(cls.__site_url__[-1], item['href'])
            m = re.search(r'-(\d+)x(\d+)-', href)
            if m and int(m.group(1)) == season and int(m.group(2)) == episode:
                episode_url = href
                break

        if not episode_url:
            season_url = f"{base_url.rstrip('/')}?temporada={season}"
            r2 = cfscraper.get(season_url, headers={'Referer': cls.__site_url__[-1]})
            if r2 and r2.status_code == 200:
                soup2 = BeautifulSoup(r2.text, 'html.parser')
                for item in soup2.find_all('a', href=re.compile(r'/assistir-.*-(\d+)x(\d+)-')):
                    href = urljoin(cls.__site_url__[-1], item['href'])
                    m = re.search(r'-(\d+)x(\d+)-', href)
                    if m and int(m.group(1)) == season and int(m.group(2)) == episode:
                        episode_url = href
                        break

        if not episode_url:
            return []

        r = cfscraper.get(episode_url, headers={'Referer': cls.__site_url__[-1]})
        if not r or r.status_code != 200:
            return []

        return cls._extract_all_embeds(r.text, episode_url)

    @classmethod
    def resolve_movies(cls, url):
        streams = []
        if not url:
            return streams
        try:
            resolved, sub = resolveurl(url, referer=None)
            if resolved:
                streams.append((resolved, sub or '', USER_AGENT))
        except:
            pass
        return streams

    @classmethod
    def resolve_tvshows(cls, url):
        return cls.resolve_movies(url)
