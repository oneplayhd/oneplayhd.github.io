# -*- coding: utf-8 -*-

WEBSITE = 'MEOMEO'

import re
import os
import sys
try:
    from kodi_helper import quote_plus
except ImportError:
    from urllib.parse import quote_plus
try:
    from resources.lib.autotranslate import AutoTranslate
    english = AutoTranslate.language('English')
except ImportError:
    english = 'LEGENDADO'
try:
    from resources.lib.unblock import unblock as requests
except ImportError:
    local_path = os.path.dirname(os.path.realpath(__file__))
    lib_path = local_path.replace('scrapers', '')
    sys.path.append(lib_path)
    from unblock import unblock as requests   

class source:
    __headers__ = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0', 'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3'}

    @classmethod
    def search_movies(cls,imdb,year):
        links = []
        url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x6d\x65\x6f\x6d\x65\x6f\x2e\x70\x77\x2f\x66\x61\x73\x74\x6d\x65\x64\x69\x61\x2f' + str(imdb)
        name = 'MEOMEO - ' + english
        links.append((name,url))
        return links

    @classmethod
    def resolve_movies(cls,url):
        streams = []
        if '\x65\x6d\x62\x65\x64\x2e\x6d\x65\x6f\x6d\x65\x6f' in url:
            origin = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x6d\x65\x6f\x6d\x65\x6f\x2e\x70\x77'
            referer = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x6d\x65\x6f\x6d\x65\x6f\x2e\x70\x77\x2f'
            try:
                referer = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x76\x75\x6d\x6f\x6f\x2e\x74\x6f\x2f'
                headers = cls.__headers__
                headers.update({'Referer': referer})
                r = requests.get(url,headers=headers)
                src = r.text
                links = re.findall(r'file":"(.*?)"',src)
                try:
                    pattern1 = r'"file":"(.*?)","kind":"captions","label":"por","default":false'
                    pattern2 = r'{"file":"(.*?).vtt'
                    code = re.findall(pattern1,src)[-1]
                    sub = re.findall(pattern2,code)[-1] + '.vtt'
                    if sub.startswith('//'):
                        sub = 'https:' + sub
                except:
                    sub = ''
                if links:
                    for i in links:
                        if '.m3u8' in i or '.mp4' in i:
                            if i.startswith('//'):
                                stream = 'https:' + i
                            else:
                                stream = i
                            user_agent = quote_plus(cls.__headers__['User-Agent'])
                            origin = quote_plus(origin)
                            referer = quote_plus(referer)
                            stream = stream + '|User-Agent=' + user_agent + '&Origin=' + origin + '&Referer=' + referer
                            streams.append((stream,sub))
                            break
            except:
                pass
        return streams
    
    @classmethod
    def search_tvshows(cls,imdb,year,season,episode):
        links = []
        url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x6d\x65\x6f\x6d\x65\x6f\x2e\x70\x77\x2f\x66\x61\x73\x74\x6d\x65\x64\x69\x61\x2f' + str(imdb) + '-' + str(season) + '-' + str(episode)
        name = 'MEOMEO - ' + english
        links.append((name,url))
        return links
    
    @classmethod
    def resolve_tvshows(cls,url):
        return cls.resolve_movies(url)




        