# -*- coding: utf-8 -*-

WEBSITE = 'FLIX'

try:
    from kodi_helper import requests as requests2, BeautifulSoup, quote_plus, unquote_plus, urlparse
except ImportError:
    import requests as requests2
    from bs4 import BeautifulSoup
    from urllib.parse import quote_plus, unquote_plus, urlparse
import os
import sys
import re
try:
    from resources.lib.autotranslate import AutoTranslate
    portuguese = AutoTranslate.language('Portuguese')
    english = AutoTranslate.language('English')
    select_option_name = AutoTranslate.language('select_option')
except ImportError:
    portuguese = 'DUBLADO'
    english = 'LEGENDADO'
    select_option_name = 'SELECIONE UMA OPÇÃO ABAIXO:'
try:
    from kodi_helper import myAddon
    from resources.lib.unblock import unblock as requests
    addonId = re.search('plugin\://(.+?)/',str(sys.argv[0])).group(1)
    addon = myAddon(addonId)
    select = addon.select
except ImportError:
    local_path = os.path.dirname(os.path.realpath(__file__))
    lib_path = local_path.replace('scrapers', '')
    sys.path.append(lib_path)
    from unblock import unblock as requests   

class source:
    __headers__ = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0', 'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3'}
    __site_url__ = ['\x68\x74\x74\x70\x73\x3a\x2f\x2f\x74\x6f\x70\x66\x6c\x69\x78\x2e\x66\x6d\x2f']
    @classmethod
    def find_title(cls, imdb):
        url = 'https://www.imdb.com/title/{0}'.format(imdb)
        try:
            r = requests2.get(url,headers=cls.__headers__)
            src = r.text
            soup = BeautifulSoup(src, 'html.parser')
            title = soup.find('h1',{'data-testid': 'hero__pageTitle'}).find('span').text
            return title
        except:
            return ''

    @classmethod
    def find_title2(cls, imdb):
        url = 'https://www.imdb.com/title/{0}/reference'.format(imdb)
        try:
            r = requests2.get(url,headers=cls.__headers__)
            src = r.text
            soup = BeautifulSoup(src, 'html.parser')
            title = soup.find('meta', {'property': 'og:title'}).get('content')
            try:
                title = title.split(' (')[0]
            except:
                pass
            return title
        except:
            return ''
        
    @classmethod
    def search_movies(cls, imdb, year):
        links = []
        title = cls.find_title(imdb)
        if title: 
            name_opt = WEBSITE
            try:
                headers = cls.__headers__
                headers.update({'Referer': cls.__site_url__[-1]})
                data = {
                    'do': 'search',
                    'subaction': 'search',
                    'story': quote_plus(title)
                }
                r = requests.post(cls.__site_url__[-1],headers=headers,data=data)
                src = r.text
                soup = BeautifulSoup(src, 'html.parser')
                div = soup.find('div', {'id': 'dle-content'})
                div_default_poster = div.find_all('div', class_=lambda x: x and x.startswith('default poster'))
                if div_default_poster:
                    for i in div_default_poster:
                        post_desc = i.find('div', {'class': 'poster__desc'})
                        poster_title = post_desc.find('h3', {'class': 'poster__title'}).find('a')
                        link = poster_title.get('href', '')
                        name = poster_title.text
                        y = post_desc.find('div', {'class': 'bslide__meta'}).find('span').text
                        y = y.replace(' ', '').replace('-', '')
                        name = name.lower().strip()
                        name2 = name.replace(':', '')
                        title = title.lower().strip()
                        title2 = title.replace(':', '')
                        title3 = title2.replace('um', '1').replace('dois', '2').replace('três', '3').replace('quatro', '4').replace('cinco', '5').replace('seis', '6')
                        name3 = name2.replace('um', '1').replace('dois', '2').replace('três', '3').replace('quatro', '4').replace('cinco', '5').replace('seis', '6')
                        if link:
                            if 'filmes' in link:
                                if title in name and int(year) == int(y):
                                    links.append((name_opt,link))
                                    break
                                elif title in name2 and int(year) == int(y):
                                    links.append((name_opt,link))
                                    break
                                elif title2 in name and int(year) == int(y): 
                                    links.append((name_opt,link))
                                    break
                                elif title2 in name2 and int(year) == int(y):  
                                    links.append((name_opt,link))
                                    break
                                elif title3 in name3 and int(year) == int(y): 
                                    links.append((name_opt,link))
                                    break
                                                                              

            except:
                pass
        return links
    
    @classmethod
    def resolve_movies(cls,url):
        parse = urlparse(url)
        protocol = parse.scheme
        host = parse.netloc
        site = '{0}://{1}/'.format(protocol,host)
        streams = []
        if site in cls.__site_url__:
            headers = cls.__headers__
            headers.update({'Referer': cls.__site_url__[-1]})
            try:
                r = requests.get(url,headers=headers)
                src = r.text
                season = re.findall(r'let playerCurrSeason = (.*?);', src)[-1]
                series = re.findall(r'let playerCurrSeries = (.*?);', src)[-1]
                base_api = re.findall(r'const VideoBalancerUrl="(.*?)";', src)
                base = ''
                if base_api:
                    for i in base_api:
                        if not '127.0.0.1' in i:
                            base += i
                            break                   
                video_id = re.findall(r'playerLoader\.setAttribute\("src",.+?"(.*?)&version=', src)[-1]                
                url_api = base + video_id
                url_dublado = url_api + '&version=0' + '&season=' + str(season) + '&series=' + str(series) + '&a=false'
                url_legendado = url_api + '&version=1' + '&season=' + str(season) + '&series=' + str(series) + '&a=false'
                sub = ''
                stream_dublado = ''
                stream_legendado = ''
                opts = []
                allowed_url = base + 'allowed'
                try:
                    r = requests.get(allowed_url,headers={'User-Agent': headers['User-Agent'], 'Origin': headers['Referer'][:-1], 'Referer': headers['Referer']})
                    src = r.text
                except:
                    pass
                try:
                    r = requests.get(url_dublado,headers=headers)
                    src = r.text
                    pattern = r"flixPlayer\('(.*?)'"
                    stream_dublado += re.findall(pattern,src)[0] + '|User-Agent=' + quote_plus(headers['User-Agent']) + '&Referer=' + quote_plus(headers['Referer'])
                except:
                    pass
                try:
                    r = requests.get(url_legendado,headers=headers)
                    src = r.text
                    pattern = r"flixPlayer\('(.*?)'"
                    pattern2 = r"flixPlayer\('.+?',.+?'(.*?)'"
                    try:
                        sub += cls.__site_url__[-1][:-1] + re.findall(pattern2,src)[0]
                    except:
                        pass
                    stream_legendado += re.findall(pattern,src)[0] + '|User-Agent=' + quote_plus(headers['User-Agent']) + '&Referer=' + quote_plus(headers['Referer'])
                except:
                    pass
                if stream_dublado:
                    opts.append((portuguese, stream_dublado, ''))
                if stream_legendado:
                    opts.append((english, stream_legendado, sub))
                if opts:
                    items_options = [name for name,stream_link, sub_link in opts]
                    try:
                        op = select(name=select_option_name,items=items_options)
                    except:
                        op = 0
                    if op >= 0:
                        stream_link = opts[op][1]
                        sub_link = opts[op][2]
                        streams.append((stream_link,sub_link))
            except:
                pass               
        return streams
    
    @classmethod
    def search_tvshows(cls,imdb,year,season,episode):
        links = []
        title = cls.find_title(imdb)
        if title:
            name_opt = WEBSITE
            page = []
            headers = cls.__headers__
            try:
                headers.update({'Referer': cls.__site_url__[-1]})
                data = {
                    'do': 'search',
                    'subaction': 'search',
                    'story': quote_plus(title)
                }
                r = requests.post(cls.__site_url__[-1],headers=headers,data=data)
                src = r.text
                soup = BeautifulSoup(src, 'html.parser')
                div = soup.find('div', {'id': 'dle-content'})
                div_default_poster = div.find_all('div', class_=lambda x: x and x.startswith('default poster'))
                if div_default_poster:
                    for i in div_default_poster:
                        post_desc = i.find('div', {'class': 'poster__desc'})
                        poster_title = post_desc.find('h3', {'class': 'poster__title'}).find('a')
                        link = poster_title.get('href', '')
                        name = poster_title.text
                        y = post_desc.find('div', {'class': 'bslide__meta'}).find('span').text
                        y = y.replace(' ', '').replace('-', '')
                        name = name.lower()
                        name2 = name.replace(':', '')
                        title = title.lower()
                        title2 = title.replace(':', '')
                        title3 = title2.replace('um', '1').replace('dois', '2').replace('três', '3').replace('quatro', '4').replace('cinco', '5').replace('seis', '6')
                        name3 = name2.replace('um', '1').replace('dois', '2').replace('três', '3').replace('quatro', '4').replace('cinco', '5').replace('seis', '6')
                        if link:
                            if 'series' in link:
                                if title in name and int(year) == int(y):
                                    page.append(link)
                                    break
                                elif title in name2 and int(year) == int(y):
                                    page.append(link)
                                    break
                                elif title2 in name and int(year) == int(y): 
                                    page.append(link)
                                    break
                                elif title2 in name2 and int(year) == int(y):  
                                    page.append(link)
                                    break
                                elif title3 in name3 and int(year) == int(y): 
                                    page.append(link)
                                    break
                if page:
                    part = '|season=' + str(season) + '&episode=' + str(episode)
                    final = page[0] + quote_plus(part)
                    links.append((name_opt,final))
            except:
                pass         
            try:
                if not page:
                    title2 = cls.find_title2(imdb)
                    data = {
                            'do': 'search',
                            'subaction': 'search',
                            'story': quote_plus(title2)
                        }
                    r = requests.post(cls.__site_url__[-1],headers=headers,data=data)
                    src = r.text
                    soup = BeautifulSoup(src, 'html.parser')
                    div = soup.find('div', {'id': 'dle-content'})
                    div_default_poster = div.find_all('div', class_=lambda x: x and x.startswith('default poster'))
                    if div_default_poster:
                        for i in div_default_poster:
                            post_desc = i.find('div', {'class': 'poster__desc'})
                            poster_title = post_desc.find('h3', {'class': 'poster__title'}).find('a')
                            link = poster_title.get('href', '')
                            name = poster_title.text
                            y = post_desc.find('div', {'class': 'bslide__meta'}).find('span').text
                            y = y.replace(' ', '').replace('-', '')
                            name = name.lower().strip()
                            name2 = name.replace(':', '')
                            title = title.lower().strip()
                            title2 = title.replace(':', '')
                            title3 = title2.replace('um', '1').replace('dois', '2').replace('três', '3').replace('quatro', '4').replace('cinco', '5').replace('seis', '6')
                            name3 = name2.replace('um', '1').replace('dois', '2').replace('três', '3').replace('quatro', '4').replace('cinco', '5').replace('seis', '6')
                            if link:
                                if 'series' in link:
                                    if title in name and int(year) == int(y):
                                        page.append(link)
                                        break
                                    elif title in name2 and int(year) == int(y):
                                        page.append(link)
                                        break
                                    elif title2 in name and int(year) == int(y): 
                                        page.append(link)
                                        break
                                    elif title2 in name2 and int(year) == int(y):  
                                        page.append(link)
                                        break
                                    elif title3 in name3 and int(year) == int(y): 
                                        page.append(link)
                                        break
                    if page:
                        part = '|season=' + str(season) + '&episode=' + str(episode)
                        final = page[0] + quote_plus(part)
                        links.append((name_opt,final))                          

            except:
                pass
        return links

    @classmethod
    def resolve_tvshows(cls,url):
        url = unquote_plus(url)
        try:
            parts = url.split('|')
            url = parts[0]
        except:
            url = ''
            parts = []
        parse = urlparse(url)
        protocol = parse.scheme
        host = parse.netloc
        site = '{0}://{1}/'.format(protocol,host)
        streams = []
        if site in cls.__site_url__:
            headers = cls.__headers__
            headers.update({'Referer': cls.__site_url__[-1]})        
            try:
                season, episode = re.findall(r'season=(\d+)&episode=(\d+)', parts[1])[0]
                season = str(int(season) - 1)
                episode = str(int(episode) - 1)
                r = requests.get(url,headers=headers)
                src = r.text
                # season = re.findall(r'let playerCurrSeason = (.*?);', src)[0]
                # series = re.findall(r'let playerCurrSeries = (.*?);', src)[0]
                base_api = re.findall(r'const VideoBalancerUrl="(.*?)";', src)
                base = ''
                if base_api:
                    for i in base_api:
                        if not '127.0.0.1' in i:
                            base += i
                            break                    
                video_id = re.findall(r'playerLoader\.setAttribute\("src",.+?"(.*?)&version=', src)[-1]                
                url_api = base + video_id
                url_dublado = url_api + '&version=0' + '&season=' + str(season) + '&series=' + str(episode) + '&a=false'
                url_legendado = url_api + '&version=1' + '&season=' + str(season) + '&series=' + str(episode) + '&a=false'
                sub = ''
                stream_dublado = ''
                stream_legendado = ''
                opts = []
                allowed_url = base + 'allowed'
                try:
                    r = requests.get(allowed_url,headers={'User-Agent': headers['User-Agent'], 'Origin': headers['Referer'][:-1], 'Referer': headers['Referer']})
                    src = r.text
                except:
                    pass                
                try:
                    r = requests.get(url_dublado,headers=headers)
                    src = r.text
                    pattern = r"flixPlayer\('(.*?)'"
                    stream_dublado += re.findall(pattern,src)[0] + '|User-Agent=' + quote_plus(headers['User-Agent']) + '&Referer=' + quote_plus(headers['Referer'])
                except:
                    pass
                try:
                    r = requests.get(url_legendado,headers=headers)
                    src = r.text
                    pattern = r"flixPlayer\('(.*?)'"
                    pattern2 = r"flixPlayer\('.+?',.+?'(.*?)'"
                    try:
                        sub += cls.__site_url__[-1][:-1] + re.findall(pattern2,src)[0]
                    except:
                        pass
                    stream_legendado += re.findall(pattern,src)[0] + '|User-Agent=' + quote_plus(headers['User-Agent']) + '&Referer=' + quote_plus(headers['Referer'])
                except:
                    pass
                if stream_dublado:
                    opts.append((portuguese, stream_dublado, ''))
                if stream_legendado:
                    opts.append((english, stream_legendado, sub))
                if opts:
                    items_options = [name for name,stream_link, sub_link in opts]
                    try:
                        op = select(name=select_option_name,items=items_options)
                    except:
                        op = 0
                    if op >= 0:
                        stream_link = opts[op][1]
                        sub_link = opts[op][2]
                        streams.append((stream_link,sub_link))
            except:
                pass                 


        return streams                
                               
