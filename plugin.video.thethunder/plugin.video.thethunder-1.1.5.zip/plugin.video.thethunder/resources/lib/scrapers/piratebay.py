# -*- coding: utf-8 -*-

WEBSITE = 'PIRATEBAY'

import sys
import os
import time
import re
try:
    from kodi_helper import requests as requests2, BeautifulSoup, quote_plus, unquote_plus, json
except ImportError:
    import requests as requests2
    from bs4 import BeautifulSoup
    from urllib.parse import quote_plus, unquote_plus
    import json
try:
    from resources.lib.autotranslate import AutoTranslate
    portuguese = AutoTranslate.language('Portuguese')
    portuguese2 = AutoTranslate.language('Portuguese2')
    english = AutoTranslate.language('English')
    english2 = AutoTranslate.language('English2')
    select_option_name = AutoTranslate.language('select_option')
    direct = AutoTranslate.language('direct')
    select_player = AutoTranslate.language('select_player')
    load_torrent = AutoTranslate.language('load_torrent')
    select_torrent = AutoTranslate.language('select_torrent')
    preparing = AutoTranslate.language('preparing')
    ready = AutoTranslate.language('ready')
except ImportError:
    portuguese = 'DUBLADO'
    portuguese2 = 'Dublado'
    english = 'LEGENDADO'
    english2 = 'Legendado'
    select_option_name = 'SELECIONE UMA OPÇÃO ABAIXO:'
    direct = 'Direto'
    select_player = 'SELECIONE UM REPRODUTOR:'
    load_torrent = 'carregando torrent...'
    select_torrent = 'SELECIONE UM TORRENT ABAIXO:'
    preparing = 'preparando reproducao...'
    ready = 'Pronto pra reproducao'
try:
    from kodi_helper import myAddon
    from resources.lib.unblock import unblock as requests
    from resources.lib import streamtorrent
    addonId = re.search('plugin\://(.+?)/',str(sys.argv[0])).group(1)
    addon = myAddon(addonId)
    select = addon.select
    progressBG = addon.progressBG_six
    translate = addon.translate
    elementum = True if addon.exists(translate('special://home/addons/plugin.video.elementum/')) else False
except ImportError:
    local_path = os.path.dirname(os.path.realpath(__file__))
    lib_path = local_path.replace('scrapers', '')
    sys.path.append(lib_path)
    import streamtorrent
    from unblock import unblock as requests
    elementum = False
try:
    from kodi_helper import quote
except ImportError:
    from urllib.parse import quote

class source:
    __headers__ = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0', 'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3'}
    @classmethod
    def find_title(cls, imdb):
        url = 'https://www.imdb.com/title/{0}'.format(imdb)
        try:
            r = requests2.get(url,headers=cls.__headers__)
            src = r.text
            soup = BeautifulSoup(src, 'html.parser')
            script_content = soup.find('script', {'type': 'application/ld+json'}).string
            data = json.loads(script_content)
            title = data.get('name', '')
            return title
        except:
            return ''



    @classmethod
    def search_movies(cls,imdb,year):
        links = []
        title = cls.find_title(imdb)
        search_term = title + ' ' + str(year)
        search_term = search_term.replace(' ', '%20')
        search_term = search_term.lower()
        url_search = 'https://thepiratebay10.org/search/{0}/1/99/0'.format(search_term)
        try:
            r = requests2.get(url_search,cls.__headers__)
            src = r.text
            soup = BeautifulSoup(src, 'html.parser')
            itens = soup.find('table', {'id': 'searchResult'}).find_all('tr')
            for n, i in enumerate(itens):
                if n > 0:            
                    try:
                        name = i.find_all('a')[1].text
                        try:
                            magnet = ''
                            links_ = i.find_all('a')
                            for a in links_:
                                href = a.get('href', '')
                                if 'magnet' in href:
                                    magnet += href
                        except:
                            magnet = ''
                        try:
                            name2 = re.findall(r'dn=(.*?)&', unquote_plus(magnet))[0]
                        except:
                            name2 = ''
                        name_filter = title + '(' + str(year) + ')'
                        title2 = title.replace(' ', '.')
                        name_filter2 = title2 + '.' + str(year)
                        if name_filter in name or name_filter in name2 or name_filter2 in name or name_filter2 in name2:
                            link_append = '#piratebay#{0}#{1}#'.format(str(imdb),str(year))
                            links.append(('PIRATEBAY', link_append))
                            break
                    except:
                        pass
        except:
            pass
        return links

    @classmethod
    def resolve_movies(cls,url):
        streams = []
        if 'piratebay' in url:
            result = []                     
            try:
                _, imdb, year = re.findall(r'#(.*?)#(.*?)#(.*?)#', url)[0] 
                title = cls.find_title(imdb)
                search_term = title + ' ' + str(year)
                search_term = search_term.replace(' ', '%20')
                search_term = search_term.lower()
                url_search = 'https://thepiratebay10.org/search/{0}/1/99/0'.format(search_term)                  
                r = requests2.get(url_search,cls.__headers__)
                src = r.text
                soup = BeautifulSoup(src, 'html.parser')
                itens = soup.find('table', {'id': 'searchResult'}).find_all('tr')
                for n, i in enumerate(itens):
                    if n > 0:            
                        try:
                            name = i.find_all('a')[1].text
                            try:
                                magnet = ''
                                links_ = i.find_all('a')
                                for a in links_:
                                    href = a.get('href', '')
                                    if 'magnet' in href:
                                        magnet += href
                            except:
                                magnet = ''
                            try:
                                name2 = re.findall(r'dn=(.*?)&', unquote_plus(magnet))[0]
                            except:
                                name2 = ''
                            name_filter = title + '(' + str(year) + ')'
                            title2 = title.replace(' ', '.')
                            name_filter2 = title2 + '.' + str(year)
                            if magnet:
                                if name_filter in name or name_filter in name2 or name_filter2 in name or name_filter2 in name2:
                                    name_torrent = name2 if name2 else name
                                    result.append((name_torrent,magnet))
                        except:
                            pass
            except:
                pass
            if result:
                try:
                    items_options = [name for name,magnet in result]
                    try:
                        op = select(name=select_option_name,items=items_options)
                    except:
                        op = 0
                    if op >= 0:
                        magnet_link = result[op][1]
                        try:
                            players = ['StreamTorrent ({0})'.format(direct), 'Elementum']
                            op = select(name=select_player,items=players)
                        except:
                            op = 0
                        if op >= 0:
                            if op == 0:                                                             
                                try:
                                    bg = progressBG()
                                    bg.create('StreamTorrent', load_torrent)
                                except:
                                    pass
                                client = streamtorrent.Torrent(magnet_link)
                                files_list = client.files
                                if files_list:
                                    items_options = [name for name,stream_link in files_list]
                                    try:
                                        op = select(name=select_torrent,items=items_options)
                                    except:
                                        op = 0
                                    if op >= 0:
                                        stream_link = files_list[op][1]
                                        try:
                                            bg.update(1, preparing)
                                        except:
                                            pass
                                        streams.append((client.check_stream(stream_link),''))
                                        try:
                                            bg.update(100, ready)
                                        except:
                                            pass
                            # elementum
                            elif op == 1:
                                if not elementum:
                                    try:
                                        addon.executebuiltin("UpdateAddonRepos()", wait=True)  
                                        addon.executebuiltin("UpdateLocalAddons()", wait=True)
                                    except:
                                        pass
                                    try:                            
                                        addon.executebuiltin('InstallAddon(repository.elementumorg)', wait=True)
                                        #xbmc.executebuiltin('SendClick(11)')
                                    except:
                                        pass
                                    time.sleep(3) 
                                    try:
                                        addon.executebuiltin("UpdateAddonRepos()", wait=True)  
                                        addon.executebuiltin("UpdateLocalAddons()", wait=True)
                                    except:
                                        pass
                                    time.sleep(5)                                                       
                                    try:
                                        addon.executebuiltin('InstallAddon(script.elementum.burst)', wait=True)
                                        #xbmc.executebuiltin('SendClick(11)')
                                    except:
                                        pass                              
                                    try:
                                        addon.executebuiltin('InstallAddon(plugin.video.elementum)', wait=True)
                                        #xbmc.executebuiltin('SendClick(11)')
                                    except:
                                        pass
                                    time.sleep(3)
                                if elementum:                                                               
                                    stream_link = 'plugin://plugin.video.elementum/play?uri=' + magnet_link
                                    streams.append((stream_link,''))

                except:
                    pass
        return streams

    @classmethod
    def search_tvshows(cls,imdb,year,season,episode):
        links = []
        if int(season) < 10:
            season = '0' + str(season)
        title = cls.find_title(imdb)
        search_term = title + ' ' + str(year) + ' s' + str(season)
        search_term = search_term.replace(' ', '%20')
        search_term = search_term.lower()
        url_search = 'https://thepiratebay10.org/search/{0}/1/99/0'.format(search_term)
        try:
            r = requests2.get(url_search,cls.__headers__)
            src = r.text
            soup = BeautifulSoup(src, 'html.parser')
            itens = soup.find('table', {'id': 'searchResult'}).find_all('tr')
            for n, i in enumerate(itens):
                if n > 0:            
                    try:
                        name = i.find_all('a')[1].text
                        try:
                            magnet = ''
                            links_ = i.find_all('a')
                            for a in links_:
                                href = a.get('href', '')
                                if 'magnet' in href:
                                    magnet += href
                        except:
                            magnet = ''
                        try:
                            name2 = re.findall(r'dn=(.*?)&', unquote_plus(magnet))[0]
                        except:
                            name2 = ''
                        name_filter = title + '(' + str(year) + ')'
                        title2 = title.replace(' ', '.')
                        name_filter2 = title2 + '.' + str(year)
                        if name_filter in name or name_filter in name2 or name_filter2 in name or name_filter2 in name2:
                            name_torrent = name2 if name2 else name
                            name_filter_final = 'S' + str(season)
                            if name_filter_final in name_torrent:
                                link_append = '#piratebay#{0}#{1}#{2}#'.format(str(imdb),str(year),str(season))
                                links.append(('PIRATEBAY', link_append))
                                break
                    except:
                        pass
        except:
            pass        
        return links

    @classmethod
    def resolve_tvshows(cls,url):
        streams = []
        if 'piratebay' in url:
            result = [] 
            try:
                _, imdb, year, season = re.findall(r'#(.*?)#(.*?)#(.*?)#(.*?)#', url)[0]
                title = cls.find_title(imdb)
                search_term = title + ' ' + str(year) + ' s' + str(season)
                search_term = search_term.replace(' ', '%20')
                search_term = search_term.lower()
                url_search = 'https://thepiratebay10.org/search/{0}/1/99/0'.format(search_term)
                try:
                    r = requests2.get(url_search,cls.__headers__)
                    src = r.text
                    soup = BeautifulSoup(src, 'html.parser')
                    itens = soup.find('table', {'id': 'searchResult'}).find_all('tr')
                    for n, i in enumerate(itens):
                        if n > 0:            
                            try:
                                name = i.find_all('a')[1].text
                                try:
                                    magnet = ''
                                    links_ = i.find_all('a')
                                    for a in links_:
                                        href = a.get('href', '')
                                        if 'magnet' in href:
                                            magnet += href
                                except:
                                    magnet = ''
                                try:
                                    name2 = re.findall(r'dn=(.*?)&', unquote_plus(magnet))[0]
                                except:
                                    name2 = ''
                                name_filter = title + '(' + str(year) + ')'
                                title2 = title.replace(' ', '.')
                                name_filter2 = title2 + '.' + str(year)
                                if name_filter in name or name_filter in name2 or name_filter2 in name or name_filter2 in name2:
                                    name_torrent = name2 if name2 else name
                                    name_filter_final = 'S' + str(season)
                                    if name_filter_final in name_torrent:
                                        result.append((name_torrent,magnet))
                            except:
                                pass
                except:
                    pass
                if result:
                    try:
                        items_options = [name for name,magnet in result]
                        try:
                            op = select(name=select_option_name,items=items_options)
                        except:
                            op = 0
                        if op >= 0:
                            magnet_link = result[op][1]
                            try:
                                players = ['StreamTorrent ({0})'.format(direct), 'Elementum']
                                op = select(name=select_player,items=players)
                            except:
                                op = 0
                            if op >= 0:
                                if op == 0:                                                             
                                    try:
                                        bg = progressBG()
                                        bg.create('StreamTorrent', load_torrent)
                                    except:
                                        pass
                                    client = streamtorrent.Torrent(magnet_link)
                                    files_list = client.files
                                    if files_list:
                                        items_options = [name for name,stream_link in files_list]
                                        try:
                                            op = select(name=select_torrent,items=items_options)
                                        except:
                                            op = 0
                                        if op >= 0:
                                            stream_link = files_list[op][1]
                                            try:
                                                bg.update(1, preparing)
                                            except:
                                                pass
                                            streams.append((client.check_stream(stream_link),''))
                                            try:
                                                bg.update(100, ready)
                                            except:
                                                pass
                                # elementum
                                elif op == 1:
                                    if not elementum:
                                        try:
                                            addon.executebuiltin("UpdateAddonRepos()", wait=True)  
                                            addon.executebuiltin("UpdateLocalAddons()", wait=True)
                                        except:
                                            pass
                                        try:                            
                                            addon.executebuiltin('InstallAddon(repository.elementumorg)', wait=True)
                                            #xbmc.executebuiltin('SendClick(11)')
                                        except:
                                            pass
                                        time.sleep(3) 
                                        try:
                                            addon.executebuiltin("UpdateAddonRepos()", wait=True)  
                                            addon.executebuiltin("UpdateLocalAddons()", wait=True)
                                        except:
                                            pass
                                        time.sleep(5)                                                       
                                        try:
                                            addon.executebuiltin('InstallAddon(script.elementum.burst)', wait=True)
                                            #xbmc.executebuiltin('SendClick(11)')
                                        except:
                                            pass                              
                                        try:
                                            addon.executebuiltin('InstallAddon(plugin.video.elementum)', wait=True)
                                            #xbmc.executebuiltin('SendClick(11)')
                                        except:
                                            pass
                                        time.sleep(3)
                                    if elementum:                                                               
                                        stream_link = 'plugin://plugin.video.elementum/play?uri=' + magnet_link
                                        streams.append((stream_link,''))
                    except:
                        pass

            except:
                pass
        return streams               
