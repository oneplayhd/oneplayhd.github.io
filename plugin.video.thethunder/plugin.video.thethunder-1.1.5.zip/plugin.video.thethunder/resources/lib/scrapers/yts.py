# -*- coding: utf-8 -*-

WEBSITE = 'YTS'

import sys
import os
import time
import re
try:
    from resources.lib.autotranslate import AutoTranslate
    portuguese = AutoTranslate.language('Portuguese')
    portuguese2 = AutoTranslate.language('Portuguese2')
    english = AutoTranslate.language('English')
    english2 = AutoTranslate.language('English2')
    select_option_name = AutoTranslate.language('select_option')
    direct = AutoTranslate.language('direct')
    select_player = AutoTranslate.language('select_player')
    load_torrent = AutoTranslate.language('load_torrent')
    select_torrent = AutoTranslate.language('select_torrent')
    preparing = AutoTranslate.language('preparing')
    ready = AutoTranslate.language('ready')
except ImportError:
    portuguese = 'DUBLADO'
    portuguese2 = 'Dublado'
    english = 'LEGENDADO'
    english2 = 'Legendado'
    select_option_name = 'SELECIONE UMA OPÇÃO ABAIXO:'
    direct = 'Direto'
    select_player = 'SELECIONE UM REPRODUTOR:'
    load_torrent = 'carregando torrent...'
    select_torrent = 'SELECIONE UM TORRENT ABAIXO:'
    preparing = 'preparando reproducao...'
    ready = 'Pronto pra reproducao'
try:
    from kodi_helper import myAddon
    from resources.lib.unblock import unblock as requests
    from resources.lib import streamtorrent
    addonId = re.search('plugin\://(.+?)/',str(sys.argv[0])).group(1)
    addon = myAddon(addonId)
    select = addon.select
    progressBG = addon.progressBG_six
    translate = addon.translate
    elementum = True if addon.exists(translate('special://home/addons/plugin.video.elementum/')) else False
except ImportError:
    local_path = os.path.dirname(os.path.realpath(__file__))
    lib_path = local_path.replace('scrapers', '')
    sys.path.append(lib_path)
    import streamtorrent
    from unblock import unblock as requests
    elementum = False
try:
    from kodi_helper import quote
except ImportError:
    from urllib.parse import quote

class source:
    __headers__ = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0', 'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3'}

    @classmethod
    def search_movies(cls,imdb,year):
        links = []
        try:
            api = 'https://yts.mx/api/v2/movie_details.json?imdb_id=' + str(imdb)
            r = requests.get(api)
            src = r.json()
            data = src.get('data', {})
            if data:
                movie = data.get('movie', {})
                if movie:
                    torrents = movie.get('torrents', [])
                    if len(torrents) > 0:
                        links.append(('YTS (TORRENT) - LEGENDADO', api))
        except:
            pass
        return links

    @classmethod
    def resolve_movies(cls,url):
        streams = []
        if 'yts.mx' in url:
            result = []
            try:
                r = requests.get(url)
                src = r.json()
                data = src.get('data', {})
                if data:
                    movie = data.get('movie', {})
                    if movie:
                        title = movie.get('title', '')
                        torrents = movie.get('torrents', [])
                        if len(torrents) > 0:
                            for i in torrents:
                                hash_ = i.get('hash', '')
                                quality = i.get('quality', '')
                                if quality and hash_:
                                    trackers = ['udp://tracker.opentrackr.org:1337/announce', 
                                                'udp://open.tracker.cl:1337/announce', 
                                                'udp://p4p.arenabg.com:1337/announce',
                                                'udp://tracker.torrent.eu.org:451/announce',
                                                'udp://tracker.dler.org:6969/announce',
                                                'http://track.one:1234/announce',
                                                'udp://track.two:80',
                                                'udp://glotorrents.pw:6969/announce',
                                                'udp://torrent.gresille.org:80/announce',
                                                'udp://tracker.openbittorrent.com:80',
                                                'udp://tracker.coppersurfer.tk:6969',
                                                'udp://tracker.leechers-paradise.org:6969',
                                                'udp://tracker.internetwarriors.net:1337']
                                    encoded_trackers = [quote(tracker, safe='') for tracker in trackers]
                                    trackers_string = '&amp;'.join('tr={0}'.format(tracker) for tracker in encoded_trackers)
                                    title_quote = quote(title)
                                    name = '{0} - {1}'.format(quality,english2)
                                    magnet = 'magnet:?xt=urn:btih:{0}&dn={1}&amp;{2}'.format(hash_.lower(),title_quote,trackers_string)
                                    result.append((name,magnet))
            except:
                pass
            if result:
                try:
                    items_options = [name for name,magnet in result]
                    try:
                        op = select(name=select_option_name,items=items_options)
                    except:
                        op = 0
                    if op >= 0:
                        magnet_link = result[op][1]
                        try:
                            players = ['StreamTorrent ({0})'.format(direct), 'Elementum']
                            op = select(name=select_player,items=players)
                        except:
                            op = 0
                        if op >= 0:
                            if op == 0:                                
                                try:
                                    bg = progressBG()
                                    bg.create('StreamTorrent', load_torrent)
                                except:
                                    pass
                                client = streamtorrent.Torrent(magnet_link)
                                files_list = client.files
                                if files_list:
                                    items_options = [name for name,stream_link in files_list]
                                    try:
                                        op = select(name=select_torrent,items=items_options)
                                    except:
                                        op = 0
                                    if op >= 0:
                                        stream_link = files_list[op][1]
                                        try:
                                            bg.update(1, preparing)
                                        except:
                                            pass
                                        streams.append((client.check_stream(stream_link),''))
                                        try:
                                            bg.update(100, ready)
                                        except:
                                            pass
                            # elementum
                            elif op == 1:
                                if not elementum:
                                    try:
                                        addon.executebuiltin("UpdateAddonRepos()", wait=True)  
                                        addon.executebuiltin("UpdateLocalAddons()", wait=True)
                                    except:
                                        pass
                                    try:                            
                                        addon.executebuiltin('InstallAddon(repository.elementumorg)', wait=True)
                                        #xbmc.executebuiltin('SendClick(11)')
                                    except:
                                        pass
                                    time.sleep(3) 
                                    try:
                                        addon.executebuiltin("UpdateAddonRepos()", wait=True)  
                                        addon.executebuiltin("UpdateLocalAddons()", wait=True)
                                    except:
                                        pass
                                    time.sleep(5)                                                       
                                    try:
                                        addon.executebuiltin('InstallAddon(script.elementum.burst)', wait=True)
                                        #xbmc.executebuiltin('SendClick(11)')
                                    except:
                                        pass                              
                                    try:
                                        addon.executebuiltin('InstallAddon(plugin.video.elementum)', wait=True)
                                        #xbmc.executebuiltin('SendClick(11)')
                                    except:
                                        pass
                                    time.sleep(3)
                                if elementum:                                                               
                                    stream_link = 'plugin://plugin.video.elementum/play?uri=' + magnet_link
                                    streams.append((stream_link,''))

                except:
                    pass
        return streams

    @classmethod
    def search_tvshows(cls,imdb,year,season,episode):
        return []

    @classmethod
    def resolve_tvshows(cls,url):
        return []                                       

