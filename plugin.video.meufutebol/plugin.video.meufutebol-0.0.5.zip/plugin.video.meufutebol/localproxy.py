# -*- coding: utf-8 -*-
# import xbmc
# import xbmcgui
from helpers import *
import threading
import socket
import requests
import re
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
#from urllib.parse import urlparse, parse_qs

HOST = "127.0.0.1"
PORT = 9098
URL_PROXY = "http://{}:{}/?url=".format(HOST, PORT)

WINDOW = xbmcgui.Window(10000)
PROPERTY_NAME = "meufutebol.proxy.running"

_proxy_instance = None


# ==========================================
# Server multi-thread (melhor para HLS)
# ==========================================

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


# ==========================================
# Verifica porta
# ==========================================

def is_port_in_use(port, host="127.0.0.1"):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        return s.connect_ex((host, port)) == 0


# ==========================================
# Handler
# ==========================================

class M3UProxyHandler(BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        return

    def do_GET(self):
        query = parse_qs(urlparse(self.path).query)
        target_url = query.get("url", [None])[0]
        target_url = unquote_plus(target_url) if target_url else None
        UPSTREAM_PROXY = target_url.split("Proxy=")[-1].split("&")[0] if target_url and "Proxy=" in target_url else None


        if not target_url:
            self.send_error(400)
            return

        try:
            headers = {
                "User-Agent": target_url.split("User-Agent=")[-1].split("&")[0] if "User-Agent=" in target_url else "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Referer": target_url.split("Referer=")[-1].split("&")[0] if "Referer=" in target_url else target_url.split("|")[0] if "|" in target_url else '',
                "Origin": target_url.split("Origin=")[-1].split("&")[0] if "Origin=" in target_url else target_url.split("|")[0] if "|" in target_url else '',
            }

            proxies = None
            if UPSTREAM_PROXY:
                proxies = {
                    "http": UPSTREAM_PROXY,
                    "https": UPSTREAM_PROXY
                }

            url = target_url.split("|")[0] if "|" in target_url else target_url

            r = requests.get(
                url,
                headers=headers,
                proxies=proxies,
                timeout=10,
                verify=False
            )

            r.raise_for_status()
            content = r.text

            parsed = urlparse(target_url)
            base_url = f"{parsed.scheme}://{parsed.netloc}"

            # Reescreve segmentos relativos
            content = re.sub(
                r"^/uploads/[a-zA-Z0-9]+$",
                lambda m: base_url + m.group(0),
                content,
                flags=re.MULTILINE
            )

            self.send_response(200)
            self.send_header("Content-Type", "application/vnd.apple.mpegurl")
            self.end_headers()
            self.wfile.write(content.encode("utf-8"))

        except Exception as e:
            xbmc.log("[PROXY ERROR] " + str(e), xbmc.LOGERROR)
            self.send_error(500)


# ==========================================
# Thread Proxy
# ==========================================
class ProxyServer(threading.Thread):

    def __init__(self):
        super().__init__(daemon=True)
        self.server = None
        self.monitor = xbmc.Monitor()

    def run(self):
        try:
            ThreadedHTTPServer.allow_reuse_address = True
            self.server = ThreadedHTTPServer((HOST, PORT), M3UProxyHandler)

            xbmc.log(f"[PROXY] Rodando em http://{HOST}:{PORT}", xbmc.LOGINFO)

            # roda servidor em thread interna
            threading.Thread(
                target=self.server.serve_forever,
                daemon=True
            ).start()

            # monitora Kodi
            while not self.monitor.abortRequested():
                self.monitor.waitForAbort(1)

            # Kodi está fechando → encerra proxy
            self.stop()

        except OSError:
            xbmc.log("[PROXY] Porta ocupada.", xbmc.LOGINFO)

    def stop(self):
        if self.server:
            xbmc.log("[PROXY] Encerrando...", xbmc.LOGINFO)
            self.server.shutdown()
            self.server.server_close()
            self.server = None



# ==========================================
# Controle público (ANTI DUPLICAÇÃO REAL)
# ==========================================

def start():
    global _proxy_instance

    # Se já existe propriedade ativa → não inicia de novo
    if WINDOW.getProperty(PROPERTY_NAME) == "true":
        xbmc.log("[PROXY] Já marcado como ativo.", xbmc.LOGINFO)
        return

    # Se porta já estiver aberta → apenas marca como ativo
    if is_port_in_use(PORT, HOST):
        WINDOW.setProperty(PROPERTY_NAME, "true")
        xbmc.log("[PROXY] Porta já estava ativa.", xbmc.LOGINFO)
        return

    _proxy_instance = ProxyServer()
    _proxy_instance.start()

    WINDOW.setProperty(PROPERTY_NAME, "true")
    xbmc.log("[PROXY] Iniciado com sucesso.", xbmc.LOGINFO)


def stop():
    global _proxy_instance

    if _proxy_instance:
        _proxy_instance.stop()
        _proxy_instance = None

    WINDOW.clearProperty(PROPERTY_NAME)
    xbmc.log("[PROXY] Finalizado.", xbmc.LOGINFO)
