# -*- coding: utf-8 -*-
import os
import sys
try:
    import xbmc
    import xbmcvfs
    import xbmcaddon
    import xbmcgui
    import xbmcplugin
    try:
        from xbmcvfs import translatePath
    except (ImportError, AttributeError):
        from xbmc import translatePath    
except:
    pass
import requests
from bs4 import BeautifulSoup
import zipfile
from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode #python 3
import shutil


try:
    plugin = sys.argv[0]
    handle = int(sys.argv[1])
    __addon__      = xbmcaddon.Addon()
    __addonname__ = __addon__.getAddonInfo('name')
    __version__    = __addon__.getAddonInfo('version') # Module version
    __profile__    = translatePath(__addon__.getAddonInfo('profile'))
    __temp__       = translatePath(os.path.join(__profile__,'temp',''))    
except:
    __addonname__ = 'Debug tester'

__headers__ = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'}
__website__ = 'https://legendei.net/'

def log(module, msg):
    xbmc.log((u"### [%s] - %s" % (module,msg,)),level=xbmc.LOGDEBUG)

class Download:
    def __init__(self,url,dest):
        log('Download', 'url: %s'%url)
        with open(dest, 'wb') as f:
            res = requests.get(url,headers=__headers__,stream=True)
            for chunk in res.iter_content(chunk_size=1024):
                f.write(chunk)

class ExtractZip:
    def __init__(self,path,dest):
        log('Extract zip', 'source: %s'%path)
        special_packages = 'special://home/addons/packages'
        packages = translatePath(special_packages)
        path2 = os.path.join(packages, 'legendei.zip')
        shutil.copy2(path, path2)         
        try:
            zin = zipfile.ZipFile(path2, 'r')
            zin.extractall(dest)
        except Exception as e:
            pass
        try:
            os.remove(path2)
        except:
            pass        


class ExtractRAR:
    def __init__(self,path,dest):
        log('Extract RAR', 'path: %s'%path)
        special_packages = 'special://home/addons/packages'
        packages = translatePath(special_packages)
        path2 = os.path.join(packages, 'legendei.rar')   
        shutil.copy2(path, path2)   
        self.unzip_rar(path2,dest)
        try:
            os.remove(path2)
        except:
            pass
    def unzip_rar(self,path, dest, format='rar'):
        path = quote_plus(path)
        root = format + '://' + path + '/'
        dirs, files = xbmcvfs.listdir(root)
        if dirs:
            self.unzip_recursive(root, dirs, dest)
        for file in files:
            self.unzip_file(os.path.join(root, file), os.path.join(dest, file))

    def unzip_recursive(self, path, dirs, dest):
        for directory in dirs:
            dirs_dir = os.path.join(path, directory)
            dest_dir = os.path.join(dest, directory)          
            xbmcvfs.mkdir(dest_dir)

            dirs2, files = xbmcvfs.listdir(dirs_dir)

            if dirs2:
                self.unzip_recursive(dirs_dir, dirs2, dest_dir)
            for file in files:
                self.unzip_file(os.path.join(dirs_dir, file), os.path.join(dest_dir, file)) 

    def unzip_file(self, path, dest):
        ''' Unzip specific file. Path should start with zip://
        '''
        xbmcvfs.copy(path, dest)


def subitem(params):
    url = '%s?%s'%(plugin, urlencode(params))
    language = params.get("language")
    subname = params.get("subname") 
    rating = params.get("rating")
    flag = params.get("flag")
    sub = params.get("sub")
    if language and subname and rating and flag:
        li=xbmcgui.ListItem(label=language,label2=subname)
        li.setArt({"icon": rating, "thumb": flag})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    elif sub:
        li=xbmcgui.ListItem(label2=os.path.basename(sub))
        xbmcplugin.addDirectoryItem(handle=handle, url=sub, listitem=li, isFolder=False)

def originaltitle_imdb(imdb):
    url = 'https://www.imdb.com/title/%s/reference'%imdb
    try:
        r = requests.get(url,headers=__headers__)
        src = r.text
        soup = BeautifulSoup(src, 'html.parser')
        originaltitle = soup.find('meta', {'property': 'og:title'}).get('content')
        try:
            originaltitle = originaltitle.split(' (')[0]
        except:
            pass
    except:
        originaltitle = False
    return originaltitle

def infoDialog(message, heading=__addonname__, iconimage='', time=3000, sound=False):
    if iconimage == '':
        iconimage = ''
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR
    xbmcgui.Dialog().notification(heading, message, iconimage, time, sound=sound)


def detect_info():
    tag = xbmc.Player().getVideoInfoTag()
    imdb = tag.getIMDBNumber()
    if imdb !='-1' and imdb !=False and imdb !=-1 and imdb !=None and imdb !='':
        originaltitle = originaltitle_imdb(imdb)
        search = originaltitle
    else:
        search = False
        infoDialog('Without imdb', iconimage='INFO')
    try:
        season = tag.getSeason()
    except:
        season = False
    try:
        episode = tag.getEpisode()
    except:
        episode = False
    return search, season, episode

def legendei(sch):
    sch = unquote_plus(sch)
    sch = sch.replace(' ', '+')
    link = '%s?s=%s'%(__website__,sch)
    src = ''
    try:
        r = requests.get(link,headers=__headers__)
        src += r.text
        soup = BeautifulSoup(src, 'html.parser')
        try:
            next_link = soup.find('a', {'class': 'sfwppa-pages sfwppa-link sfwppa-link-next'}).get('href', '')
        except:
            next_link = False
        if next_link:
            count = 0
            while next_link:
                count += 1
                r = requests.get(next_link,headers=__headers__)
                src_base = r.text
                src += src_base
                soup = BeautifulSoup(src_base, 'html.parser')
                try:
                    next_link = soup.find('a', {'class': 'sfwppa-pages sfwppa-link sfwppa-link-next'}).get('href', False)
                except:
                    next_link = False
                if next_link == False or count == 12:
                    break
    except:
        pass
    itens = []
    if src:
        try:
            soup = BeautifulSoup(src, 'html.parser')
            grid = soup.find_all('div', {'class': 'simple-grid-posts-content'})
            for g in grid:
                i_ = g.find('div', {'class': 'simple-grid-posts simple-grid-posts-grid'}).find_all('div', id=lambda x: x and x.startswith('simple-grid-post'))
                for i in i_:
                    div = i.find('div', {'class': 'simple-grid-grid-post-inside'}).find('div', {'class': 'simple-grid-grid-post-thumbnail simple-grid-grid-post-block'})
                    link = div.find('a').get('href', '')
                    details = div.find('div', {'class': 'simple-grid-grid-post-details simple-grid-grid-post-block'}).find('h3', {'class': 'simple-grid-grid-post-title'})
                    name = details.find('a').text
                    itens.append((name,link))
        except:
            pass
    if itens:
        for name, link in itens:
            # try:
            #     name = name.encode('utf-8', 'ignore')
            # except:
            #     pass
            try:
                subitem({'language': 'Portuguese (Brasil)', 'subname': name, 'rating': '5', 'flag': 'pb', 'action': 'download', 'sub_download': link})
            except:
                pass
        try:
            xbmcplugin.endOfDirectory(handle)
        except:
            pass

def subtitle_clear():
    for r, d, f in os.walk(__temp__):
        for file in f:
            if file.endswith(".srt"):
                try:
                    os.remove(os.path.join(r, file))
                except:
                    pass
            if file.endswith(".url"):
                try:
                    os.remove(os.path.join(r, file))
                except:
                    pass 
            if file.endswith(".rar"):
                try:
                    os.remove(os.path.join(r, file))
                except:
                    pass
            if file.endswith(".zip"):
                try:
                    os.remove(os.path.join(r, file))
                except:
                    pass
    for name in os.listdir(__temp__):
        try:
            os.rmdir(os.path.join(__temp__, name))
        except:
            pass

def subs_site(lang,manualsearch=False):
    if lang == 'pt':
        if manualsearch:
            sch = quote(manualsearch)
            legendei(sch)
        else:
            search, season, episode = detect_info()
            if season !='-1' and season !=False and season !=-1:
                season = season
            else:
                season = False
            if episode !='-1' and episode !=False and episode !=-1:
                episode = episode
            else:
                episode = False
            if search and season:
                if int(season) < 10:
                    sdesc = '0%s'%str(season)
                else:
                    sdesc = str(season)            
                sch = '%s S%s'%(search,sdesc)
                sch = quote(sch)
            elif search:
                sch = quote(search)
            else:
                sch = False            
            if sch:
                legendei(sch)
            else:
                pass

def search_subtitle(default_subtitle,manualsearch=False):
    subtitle_clear()
    # try:
    #     xbmc.executebuiltin('InstallAddon(vfs.rar)', wait=True)
    # except:
    #     pass  
    if 'Portuguese' in default_subtitle:
        lang = 'pt'
    else:
        lang = 'pt'
    if manualsearch:
        subs_site(lang,manualsearch)
    else:
        subs_site(lang)

def list_subtitle():
    names = []
    links = []
    for r, d, f in os.walk(__temp__):
        for file in f:
            if file.endswith(".rar"):
                try:
                    ExtractRAR(os.path.join(r, file),__temp__)
                except:
                    pass
    for r, d, f in os.walk(__temp__):
        for file in f:
            if file.endswith(".zip"): 
                try:
                    ExtractZip(os.path.join(r, file),__temp__)
                except:
                    pass 
    for r, d, f in os.walk(__temp__):
        for file in f:              
            if file.endswith(".srt"):
                filename = file
                link = os.path.join(r, file)
                names.append(filename)
                links.append(link) 
    if names and links:
        index = xbmcgui.Dialog().select('Select a subtitle', names)
        if index >=0:
            link = links[index]
            set_subtitle(link)
                
def download_(url):
    url = unquote_plus(url)
    subtitle_clear()
    try:
        r = requests.get(url,headers=__headers__)
        src = r.text
        soup = BeautifulSoup(src, 'html.parser')
        link = soup.find('div', {'class': 'entry-content simple-grid-clearfix'}).find('a').get('href', '')
        if link:
            link_zip = link
            special_packages = 'special://home/addons/packages'
            packages = translatePath(special_packages)
            filename = 'legendei.subpack'
            dest=os.path.join(packages, filename)
            try:
                Download(link_zip,dest)
            except:
                pass
            zip_file = dest
            extract_folder = __temp__
            try:
                ExtractRAR(zip_file,extract_folder)
            except:
                pass
            try:
                ExtractZip(zip_file,extract_folder)
            except:
                pass
            try:
                os.remove(zip_file)
            except:
                pass
            list_subtitle()
    except:
        pass


def set_subtitle(sub):
    subitem({'sub': sub})
    xbmcplugin.endOfDirectory(handle)