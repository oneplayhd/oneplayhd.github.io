# -*- coding: utf-8 -*-
import hashlib
import time
import uuid

from .constants import STATE_SCHEMA
from .storage import delete, json_schema, read_json, state_path, write_json

SESSION = state_path('session_v2.json')
PANEL = state_path('panel_v2.json')
ACTIVITY = state_path('activity_v2.json')
PREFS = state_path('preferences_v2.json')


def load_session():
    data = read_json(SESSION, {})
    if not isinstance(data, dict) or json_schema(data) != STATE_SCHEMA:
        return {}
    # Upgrade in-place: the first read after installing this build removes any
    # plaintext credentials left by an older homologated session immediately.
    if 'username' in data or 'password' in data:
        data = dict(data)
        data.pop('username', None)
        data.pop('password', None)
        try:
            write_json(SESSION, data)
        except Exception:
            # Nunca devolva uma sessão funcional deixando a cópia antiga com
            # credenciais em disco. O Device ID consegue reconstruir o vínculo
            # pelo painel, então falhar fechado aqui é seguro e recuperável.
            delete(SESSION)
            return {}
    return data


def save_session(data):
    value = dict(data or {})
    # Segurança 2.3.0 — o Device ID/painel são a autoridade do acesso. Credenciais
    # Xtream podem existir no processo Python enquanto necessárias, mas nunca são
    # persistidas em session_v2.json. Isto também migra silenciosamente sessões
    # antigas assim que forem regravadas.
    value.pop('username', None)
    value.pop('password', None)
    value['schema'] = STATE_SCHEMA
    value.setdefault('session_id', uuid.uuid4().hex)
    value['updated_at'] = int(time.time())
    write_json(SESSION, value)
    return value


def clear_session():
    delete(SESSION)
    clear_playback()


def load_panel():
    data = read_json(PANEL, {})
    if not isinstance(data, dict) or json_schema(data) != STATE_SCHEMA:
        return {}
    return data


def save_panel(data):
    value = dict(data or {})
    value['schema'] = STATE_SCHEMA
    value['updated_at'] = int(time.time())
    write_json(PANEL, value)
    return value


def load_prefs():
    data = read_json(PREFS, {})
    return data if isinstance(data, dict) else {}


def save_prefs(data):
    write_json(PREFS, dict(data or {}))


def _clear_playback_fields(data):
    for key in ('playback_url', 'playback_hash', 'playback_kind', 'playback_title', 'playback_at', 'playback_meta', 'playback_relay_session_id', 'playback_resume_at'):
        data.pop(key, None)
    return data


def mark_ui(active, route=''):
    """Mark the IBO usage session as active/inactive.

    ``session_v2.json`` is the stored authenticated access and must survive a
    normal SAIR.  ``activity_v2.json`` is the runtime usage session.  Keeping
    those concepts separate lets SAIR stop Heartbeat immediately without
    forcing the customer to type credentials again on the next launch.
    """
    now = int(time.time())
    data = load_activity()
    active = bool(active)
    data['ui_active'] = active
    data['usage_active'] = active
    data['route'] = str(route or '')
    data['at'] = now
    if active:
        if not str(data.get('usage_session_id') or '') or data.get('usage_ended_at'):
            data['usage_session_id'] = uuid.uuid4().hex
            data['usage_started_at'] = now
        data.pop('usage_ended_at', None)
    else:
        data['usage_ended_at'] = now
        _clear_playback_fields(data)
    write_json(ACTIVITY, data)
    return data


def request_exit_return():
    """Atomically end IBO usage and request restoration of Kodi history.

    The persistent service consumes this token only after the plugin's modal
    windows / DialogBusy are gone.  No target window is hard-coded: the service
    asks Kodi to go Back only while the underlying container is still this
    add-on's plugin:// root.
    """
    now = time.time()
    data = load_activity()
    data['ui_active'] = False
    data['usage_active'] = False
    data['route'] = 'exit'
    data['at'] = int(now)
    data['usage_ended_at'] = int(now)
    _clear_playback_fields(data)
    token = uuid.uuid4().hex
    data['exit_return_token'] = token
    data['exit_return_requested_at'] = now
    write_json(ACTIVITY, data)
    return token


def clear_exit_return(token=''):
    data = load_activity()
    current = str(data.get('exit_return_token') or '')
    if token and current and current != str(token):
        return False
    changed = False
    for key in ('exit_return_token', 'exit_return_requested_at'):
        if key in data:
            data.pop(key, None)
            changed = True
    if changed:
        write_json(ACTIVITY, data)
    return changed


def request_panel_sync():
    data = load_activity()
    data['panel_sync_token'] = uuid.uuid4().hex
    data['panel_sync_requested_at'] = int(time.time())
    write_json(ACTIVITY, data)
    return data['panel_sync_token']

def playback_fingerprint(url):
    raw = str(url or '').split('|', 1)[0]
    return hashlib.sha256(raw.encode('utf-8', 'ignore')).hexdigest() if raw else ''


def mark_playback(url='', kind='', title='', meta=None, relay_session_id='', resume_at=0.0):
    data = load_activity()
    data.update({'playback_hash': playback_fingerprint(url), 'playback_kind': str(kind or ''), 'playback_title': str(title or ''), 'playback_at': int(time.time())})
    relay_id = str(relay_session_id or '').strip()
    if relay_id:
        data['playback_relay_session_id'] = relay_id
    else:
        data.pop('playback_relay_session_id', None)
    try:
        resume_value = max(0.0, float(resume_at or 0.0))
    except Exception:
        resume_value = 0.0
    if str(kind or '') in ('movie', 'series') and resume_value >= 30.0:
        # Runtime-only, sem segredo: o serviço usa este alvo para não deixar
        # amostras 0.x/5.x de uma retomada ainda pendente destruírem um ponto
        # válido do histórico. _clear_playback_fields remove no Stop/fim.
        data['playback_resume_at'] = round(resume_value, 3)
    else:
        data.pop('playback_resume_at', None)
    if isinstance(meta, dict):
        # Defesa em profundidade: activity_v2 nunca recebe URL de stream,
        # usuário, senha ou qualquer campo arbitrário vindo de callers futuros.
        allowed = (
            'kind', 'stream_id', 'title', 'extension', 'art', 'plot', 'year',
            'season', 'episode', 'series_id', 'series_title', 'series_art', 'portal_id',
        )
        safe_meta = {key: meta.get(key) for key in allowed if meta.get(key) is not None}
        data['playback_meta'] = safe_meta
    else:
        data.pop('playback_meta', None)
    data.pop('playback_url', None)
    write_json(ACTIVITY, data)


def clear_playback():
    data = load_activity()
    _clear_playback_fields(data)
    write_json(ACTIVITY, data)


def load_activity():
    data = read_json(ACTIVITY, {})
    return data if isinstance(data, dict) else {}
