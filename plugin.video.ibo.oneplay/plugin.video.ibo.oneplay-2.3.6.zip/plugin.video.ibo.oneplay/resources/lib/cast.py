# -*- coding: utf-8 -*-
"""Universal Cast experimental for ONEPLAY IBO.

Pure-stdlib sender layer kept separate from the homologated Kodi player path.
Supported transports:
- DLNA/UPnP MediaRenderer: SSDP discovery + AVTransport SetAVTransportURI/Play.
- Google Cast v2: mDNS discovery + Default Media Receiver over TLS/8009.

Security contract:
- receivers get only the opaque ONEPLAY Relay LAN URL;
- Xtream DNS/user/password/upstream URL are never stored in cast state;
- starting a new cast releases the previous Relay session;
- leaving ONEPLAY stops/releases the active cast (best effort);
- discovery accepts only private-LAN IPv4 peers.
"""
from __future__ import absolute_import

import concurrent.futures
import html
import http.client
import json
import os
import random
import secrets
import socket
import ssl
import struct
import time
import urllib.error
import urllib.parse
import urllib.request
from .network_security import lan_open, _lan_connection
import xml.etree.ElementTree as ET

from .log import log
from .media_relay import release_playback, relay_session_activity
from .dlna_compat import is_lg_webos_renderer
from .storage import delete, read_json, state_path, write_json

_CAST_STATE = state_path('cast_v1.json')
_CAST_STATE_SCHEMA = 1
_CAST_DEVICE_CACHE = state_path('cast_devices_v1.json')
_CAST_DEVICE_CACHE_SCHEMA = 1
_DLNA_DEVICE_CACHE = state_path('cast_dlna_devices_v1.json')
_DLNA_DEVICE_CACHE_SCHEMA = 1
_DLNA_CACHE_MAX_AGE = 6 * 60 * 60
_DLNA_CACHE_LIMIT = 24
_DLNA_LIVE_WINDOW = 1.30
_DLNA_ST = 'urn:schemas-upnp-org:device:MediaRenderer:1'
_DLNA_AVTRANSPORT = 'urn:schemas-upnp-org:service:AVTransport:1'
_CAST_MDNS = '_googlecast._tcp.local'
_CAST_PORT = 8009
_DIAL_ST = 'urn:dial-multiscreen-org:service:dial:1'
_CAST_APP_ID = 'CC1AD845'  # Google Default Media Receiver
_NS_CONNECTION = 'urn:x-cast:com.google.cast.tp.connection'
_NS_HEARTBEAT = 'urn:x-cast:com.google.cast.tp.heartbeat'
_NS_RECEIVER = 'urn:x-cast:com.google.cast.receiver'
_NS_MEDIA = 'urn:x-cast:com.google.cast.media'
_CAST_WAKE_WINDOW = 25.0
_LG_AVT_WAKE_WINDOW = 25.0
_LG_AVT_RELAY_CONFIRM_WINDOW = 12.0


class _CastWakePending(TimeoutError):
    """Receiver endpoint is reachable but the Cast app/media channel is not ready yet."""
    pass


def _private_ipv4(value):
    raw = str(value or '').strip()
    try:
        parts = [int(x) for x in raw.split('.')]
        if len(parts) != 4 or any(x < 0 or x > 255 for x in parts):
            return False
    except Exception:
        return False
    a, b, _c, _d = parts
    return bool(a == 10 or (a == 172 and 16 <= b <= 31) or
                (a == 192 and b == 168) or (a == 100 and 64 <= b <= 127))


def _resolve_private_ipv4(host):
    raw = str(host or '').strip().strip('[]')
    if _private_ipv4(raw):
        return raw
    try:
        for _family, _socktype, _proto, _canon, addr in socket.getaddrinfo(raw, None, socket.AF_INET):
            value = str((addr or ('',))[0] or '')
            if _private_ipv4(value):
                return value
    except Exception:
        pass
    return ''


def _private_http_url(value):
    """Return a LAN-only HTTP(S) URL or an empty string.

    DLNA descriptions are network supplied.  Reject userinfo and any control
    endpoint that resolves outside the same private-IPv4 trust boundary used
    by discovery, so a renderer cannot turn ONEPLAY into a generic URL client.
    """
    raw = str(value or '').strip()
    try:
        parsed = urllib.parse.urlparse(raw)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname:
            return ''
        if parsed.username is not None or parsed.password is not None:
            return ''
        if not _resolve_private_ipv4(parsed.hostname):
            return ''
        if parsed.port is not None and not (1 <= int(parsed.port) <= 65535):
            return ''
        return raw
    except Exception:
        return ''


def _safe_label(value, fallback='Dispositivo'):
    text = ' '.join(str(value or '').replace('\x00', ' ').split()).strip()
    return text[:96] if text else fallback


def _http_headers(raw):
    headers = {}
    lines = bytes(raw or b'').decode('iso-8859-1', 'replace').replace('\r\n', '\n').split('\n')
    for line in lines[1:]:
        if ':' not in line:
            continue
        key, value = line.split(':', 1)
        headers[key.strip().lower()] = value.strip()
    return headers


def _xml_local(tag):
    return str(tag or '').split('}', 1)[-1]


def _fetch_dlna_device(location, timeout=1.2):
    try:
        safe_location = _private_http_url(location)
        if not safe_location:
            return None
        parsed = urllib.parse.urlparse(safe_location)
        host = _resolve_private_ipv4(parsed.hostname)
        req = urllib.request.Request(safe_location, headers={'User-Agent': 'ONEPLAY-IBO-Cast/1.0'})
        with lan_open(req, timeout=max(0.4, float(timeout))) as response:
            raw = response.read(512 * 1024)
        root = ET.fromstring(raw)
    except Exception:
        return None
    name = ''
    model = ''
    udn = ''
    av_control = ''
    av_service = ''
    url_base = ''
    for elem in root.iter():
        local = _xml_local(elem.tag)
        if local == 'URLBase' and not url_base:
            url_base = str(elem.text or '').strip()
        elif local == 'friendlyName' and not name:
            name = str(elem.text or '').strip()
        elif local == 'modelName' and not model:
            model = str(elem.text or '').strip()
        elif local == 'UDN' and not udn:
            udn = str(elem.text or '').strip()
        elif local == 'service':
            service_type = ''
            control_url = ''
            for child in list(elem):
                child_local = _xml_local(child.tag)
                if child_local == 'serviceType':
                    service_type = str(child.text or '').strip()
                elif child_local == 'controlURL':
                    control_url = str(child.text or '').strip()
            if 'AVTransport' in service_type and control_url and not av_control:
                av_service = service_type
                base = _private_http_url(url_base) or safe_location
                candidate_control = urllib.parse.urljoin(base, control_url)
                av_control = _private_http_url(candidate_control)
    if not av_control:
        return None
    return {
        'protocol': 'dlna', 'name': _safe_label(name, 'DLNA TV'), 'model': _safe_label(model, ''),
        'udn': str(udn or '')[:192], 'host': host, 'port': int(parsed.port or (443 if parsed.scheme == 'https' else 80)),
        'control_url': av_control, 'service_type': av_service or _DLNA_AVTRANSPORT, 'location': str(location),
    }


def _ssdp_socket(bind_ip=''):
    """Create one SSDP search socket bound to a specific private LAN interface."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
    if bind_ip and _private_ipv4(bind_ip):
        try:
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(bind_ip))
        except Exception:
            pass
        try:
            sock.bind((bind_ip, 0))
        except Exception:
            sock.bind(('', 0))
    else:
        sock.bind(('', 0))
    sock.settimeout(0.04)
    return sock


def _fetch_dlna_rows(entries, timeout=0.75, max_workers=8):
    """Resolve renderer descriptions concurrently so many receivers stay bounded."""
    items = []
    seen_locations = set()
    for entry in entries or []:
        if isinstance(entry, dict):
            location = str(entry.get('location') or '').strip()
            meta = dict(entry)
        else:
            location = str(entry or '').strip()
            meta = {'location': location}
        if not location or location in seen_locations:
            continue
        seen_locations.add(location)
        items.append((location, meta))
    if not items:
        return []

    workers = max(1, min(int(max_workers or 1), len(items), 12))
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        future_map = {
            pool.submit(_fetch_dlna_device, location, max(0.35, float(timeout))): (location, meta)
            for location, meta in items
        }
        for future, (_location, meta) in list(future_map.items()):
            try:
                row = future.result(timeout=max(0.50, float(timeout) + 0.20))
            except Exception:
                row = None
            if not row:
                continue
            if meta.get('usn') and not row.get('usn'):
                row['usn'] = str(meta.get('usn') or '')[:256]
            if meta.get('source') and not row.get('_ssdp_source'):
                row['_ssdp_source'] = str(meta.get('source') or '')
            results.append(row)
    return results


def discover_dlna(timeout=1.6):
    """Discover every reachable UPnP MediaRenderer across private IPv4 LAN NICs.

    Cache is intentionally not consulted here: this is the live-network pass.
    We search MediaRenderer v1/v2 plus ssdp:all, send on every private interface,
    repeat the multicast burst once, and keep the receive window longer than the
    advertised MX=1 so a newly-enabled renderer is not hidden by fast caches.
    """
    window = max(1.05, float(timeout))
    deadline = time.monotonic() + window
    payloads = []
    for search_target in (_DLNA_ST, 'urn:schemas-upnp-org:device:MediaRenderer:2', 'ssdp:all'):
        payloads.append(('M-SEARCH * HTTP/1.1\r\n'
                         'HOST: 239.255.255.250:1900\r\n'
                         'MAN: "ssdp:discover"\r\n'
                         'MX: 1\r\n'
                         'ST: %s\r\n\r\n' % search_target).encode('ascii'))

    local_ips = _local_private_ipv4s()
    sockets = []
    # Keep one default-route socket plus one explicit socket per private NIC.
    for bind_ip in [''] + list(local_ips or []):
        try:
            sockets.append((bind_ip, _ssdp_socket(bind_ip)))
        except Exception:
            continue
    if not sockets:
        return []

    responses = {}
    next_burst = 0.0
    burst_count = 0
    packet_count = 0
    try:
        while time.monotonic() < deadline:
            now = time.monotonic()
            if burst_count == 0 or (burst_count == 1 and now >= next_burst):
                for _bind_ip, sock in sockets:
                    for payload in payloads:
                        try:
                            sock.sendto(payload, ('239.255.255.250', 1900))
                        except Exception:
                            pass
                burst_count += 1
                if burst_count == 1:
                    next_burst = now + min(0.42, max(0.28, window * 0.30))

            progressed = False
            for _bind_ip, sock in sockets:
                try:
                    raw, addr = sock.recvfrom(64 * 1024)
                except socket.timeout:
                    continue
                except Exception:
                    continue
                progressed = True
                packet_count += 1
                headers = _http_headers(raw)
                location = str(headers.get('location') or '').strip()
                if not _private_http_url(location):
                    continue
                source = str((addr or ('',))[0] or '')
                meta = responses.setdefault(location, {'location': location, 'usn': '', 'source': ''})
                if headers.get('usn'):
                    meta['usn'] = str(headers.get('usn') or '')[:256]
                if _private_ipv4(source):
                    meta['source'] = source
            if not progressed:
                time.sleep(0.008)
    except Exception as exc:
        log('Universal Cast: descoberta DLNA indisponível (%s).' % exc.__class__.__name__, 'debug')
    finally:
        for _bind_ip, sock in sockets:
            try:
                sock.close()
            except Exception:
                pass

    rows = _fetch_dlna_rows(list(responses.values()), timeout=0.80, max_workers=10)
    results = []
    seen = set()
    for row in rows:
        identity = str(row.get('udn') or row.get('usn') or row.get('control_url') or row.get('location') or '')
        key = ('dlna', identity.casefold()) if identity else ('dlna-host', str(row.get('host') or ''), str(row.get('port') or ''))
        if key in seen:
            continue
        seen.add(key)
        results.append(row)
    log('Universal Cast: SSDP DLNA respostas=%d locations=%d renderers=%d interfaces=%d bursts=%d.' %
        (packet_count, len(responses), len(results), len(sockets), burst_count), 'debug')
    return results

def _write_dlna_cache(rows):
    """Persist only validated LAN renderer identity/control endpoints.

    Unlike Google Cast, DLNA is not trusted blindly from cache: every cached
    renderer is revalidated through its private device-description URL before
    it is offered to the user.  The cache only avoids losing a renderer that
    misses one short SSDP discovery window.
    """
    clean = []
    seen = set()
    now = int(time.time())
    for row in rows or []:
        if not isinstance(row, dict) or row.get('protocol') != 'dlna':
            continue
        host = _resolve_private_ipv4(row.get('host'))
        location = _private_http_url(row.get('location'))
        control_url = _private_http_url(row.get('control_url'))
        if not host or not location or not control_url:
            continue
        try:
            port = int(row.get('port') or 80)
        except Exception:
            port = 80
        if not (1 <= port <= 65535):
            continue
        udn = str(row.get('udn') or '')[:192]
        usn = str(row.get('usn') or '')[:256]
        key = (udn.casefold() if udn else '', usn.casefold() if usn else '', host, control_url)
        if key in seen:
            continue
        seen.add(key)
        clean.append({
            'protocol': 'dlna', 'name': _safe_label(row.get('name'), 'DLNA TV'),
            'model': _safe_label(row.get('model'), ''), 'udn': udn, 'usn': usn, 'host': host, 'port': port,
            'control_url': control_url,
            'service_type': str(row.get('service_type') or _DLNA_AVTRANSPORT)[:160],
            'location': location, 'last_seen': now,
        })
    write_json(_DLNA_DEVICE_CACHE, {
        'schema': _DLNA_DEVICE_CACHE_SCHEMA, 'updated_at': now, 'devices': clean[:_DLNA_CACHE_LIMIT],
    })


def _cached_dlna_devices(timeout=0.35, limit=None):
    """Return every still-valid cached renderer, validated concurrently."""
    data = read_json(_DLNA_DEVICE_CACHE, {})
    if not isinstance(data, dict) or int(data.get('schema') or 0) != _DLNA_DEVICE_CACHE_SCHEMA:
        return []
    devices = data.get('devices') if isinstance(data.get('devices'), list) else []
    now = int(time.time())
    cap = _DLNA_CACHE_LIMIT if limit is None else max(1, min(int(limit or 1), _DLNA_CACHE_LIMIT))
    candidates = []
    for row in devices[:cap]:
        if not isinstance(row, dict):
            continue
        try:
            last_seen = int(row.get('last_seen') or data.get('updated_at') or 0)
        except Exception:
            last_seen = 0
        if last_seen and now - last_seen > _DLNA_CACHE_MAX_AGE:
            continue
        location = _private_http_url(row.get('location'))
        if not location:
            continue
        candidates.append({'location': location, 'usn': row.get('usn') or '', 'source': 'cache'})

    results = _fetch_dlna_rows(candidates, timeout=max(0.30, float(timeout)), max_workers=10)
    for fresh in results:
        fresh['_discovery_source'] = 'cache_validated'
    # Preserve the old safety contract: dead/expired endpoints are forgotten.
    _write_dlna_cache(results)
    return results

def _merge_cast_devices(google, dlna):
    """Merge all receivers without collapsing independent DLNA renderers.

    Google Cast is preferred over DLNA only when both resolve to the same host
    (the common case for a single TV exposing both stacks).  DLNA-vs-DLNA uses
    UDN/USN/control endpoint identity, so separate renderers remain separate.
    """
    merged = []
    seen_google = set()
    google_hosts = set()
    for row in list(google or []):
        if not isinstance(row, dict):
            continue
        host = str(row.get('host') or '')
        identity = str(row.get('uuid') or '').strip().casefold()
        key = ('google-uuid', identity) if identity else ('google-endpoint', host, int(row.get('port') or _CAST_PORT))
        if key in seen_google:
            continue
        seen_google.add(key)
        if host:
            google_hosts.add(host)
        merged.append(row)

    seen_dlna = set()
    for row in list(dlna or []):
        if not isinstance(row, dict):
            continue
        host = str(row.get('host') or '')
        # Same physical host already has a working Google Cast stack: show one
        # receiver entry for that TV, but never use host-only dedupe DLNA-to-DLNA.
        if host and host in google_hosts:
            continue
        udn = str(row.get('udn') or '').strip().casefold()
        usn = str(row.get('usn') or '').strip().casefold()
        control = str(row.get('control_url') or '').strip().casefold()
        location = str(row.get('location') or '').strip().casefold()
        if udn:
            key = ('dlna-udn', udn)
        elif usn:
            key = ('dlna-usn', usn)
        elif control:
            key = ('dlna-control', control)
        elif location:
            key = ('dlna-location', location)
        else:
            key = ('dlna-fallback', host, str(row.get('port') or ''), str(row.get('name') or '').casefold())
        if key in seen_dlna:
            continue
        seen_dlna.add(key)
        merged.append(row)

    merged.sort(key=lambda r: (str(r.get('name') or '').casefold(), 0 if r.get('protocol') == 'googlecast' else 1,
                               str(r.get('host') or '')))
    return merged


# ---- Minimal mDNS parser (PTR/SRV/TXT/A) ----
def _dns_name(data, offset, depth=0):
    if depth > 12:
        raise ValueError('dns compression loop')
    labels = []
    pos = int(offset)
    end = pos
    jumped = False
    while pos < len(data):
        length = data[pos]
        if length == 0:
            pos += 1
            if not jumped:
                end = pos
            break
        if length & 0xC0 == 0xC0:
            if pos + 1 >= len(data):
                raise ValueError('dns pointer truncated')
            ptr = ((length & 0x3F) << 8) | data[pos + 1]
            suffix, _ = _dns_name(data, ptr, depth + 1)
            if suffix:
                labels.append(suffix)
            pos += 2
            if not jumped:
                end = pos
            jumped = True
            break
        pos += 1
        if pos + length > len(data):
            raise ValueError('dns label truncated')
        labels.append(data[pos:pos + length].decode('utf-8', 'replace'))
        pos += length
        if not jumped:
            end = pos
    return '.'.join([x for x in labels if x]), end


def _dns_question(name, qtype=12, qclass=1):
    out = bytearray()
    for label in str(name).rstrip('.').split('.'):
        raw = label.encode('utf-8')
        out.append(len(raw))
        out.extend(raw)
    out.append(0)
    out.extend(struct.pack('!HH', int(qtype), int(qclass)))
    return bytes(out)


def _parse_mdns(data):
    data = bytes(data or b'')
    if len(data) < 12:
        return []
    _ident, _flags, qd, an, ns, ar = struct.unpack('!HHHHHH', data[:12])
    pos = 12
    try:
        for _ in range(qd):
            _name, pos = _dns_name(data, pos)
            pos += 4
        records = []
        for _ in range(an + ns + ar):
            name, pos = _dns_name(data, pos)
            if pos + 10 > len(data):
                break
            rtype, rclass, ttl, rdlen = struct.unpack('!HHIH', data[pos:pos + 10])
            pos += 10
            rstart = pos
            rend = pos + rdlen
            if rend > len(data):
                break
            value = None
            if rtype == 1 and rdlen == 4:
                value = socket.inet_ntoa(data[rstart:rend])
            elif rtype == 12:
                value, _ = _dns_name(data, rstart)
            elif rtype == 33 and rdlen >= 6:
                priority, weight, port = struct.unpack('!HHH', data[rstart:rstart + 6])
                target, _ = _dns_name(data, rstart + 6)
                value = {'priority': priority, 'weight': weight, 'port': port, 'target': target}
            elif rtype == 16:
                txt = {}
                idx = rstart
                while idx < rend:
                    ln = data[idx]
                    idx += 1
                    chunk = data[idx:min(rend, idx + ln)].decode('utf-8', 'replace')
                    idx += ln
                    if '=' in chunk:
                        k, v = chunk.split('=', 1)
                        txt[k] = v
                value = txt
            records.append({'name': name, 'type': rtype, 'class': rclass, 'ttl': ttl, 'value': value})
            pos = rend
        return records
    except Exception:
        return []


def _local_private_ipv4s():
    """Return private IPv4 addresses usable as multicast egress interfaces."""
    found = []

    def add(value):
        value = str(value or '').strip()
        if _private_ipv4(value) and value not in found:
            found.append(value)

    # Route-derived address is the most useful on Windows with more than one NIC.
    probe = None
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.connect(('8.8.8.8', 53))
        add(probe.getsockname()[0])
    except Exception:
        pass
    finally:
        try:
            if probe is not None:
                probe.close()
        except Exception:
            pass
    try:
        for _family, _socktype, _proto, _canon, addr in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            add((addr or ('',))[0])
    except Exception:
        pass
    try:
        _host, _aliases, addresses = socket.gethostbyname_ex(socket.gethostname())
        for value in addresses or []:
            add(value)
    except Exception:
        pass
    return found


def _mdns_socket(bind_ip='', canonical=False):
    """Create one bounded IPv4 mDNS socket.

    Canonical mode listens on 5353 for multicast replies.  Ephemeral mode asks
    for QU/unicast replies and is important on Windows when Bonjour or another
    service owns 5353.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
    if bind_ip and _private_ipv4(bind_ip):
        try:
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(bind_ip))
        except Exception:
            pass
    if canonical:
        sock.bind(('', 5353))
        try:
            interface = socket.inet_aton(bind_ip) if _private_ipv4(bind_ip) else socket.inet_aton('0.0.0.0')
            membership = socket.inet_aton('224.0.0.251') + interface
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, membership)
        except Exception:
            pass
    else:
        sock.bind((bind_ip if _private_ipv4(bind_ip) else '', 0))
    sock.settimeout(0.12)
    return sock


def _mdns_query_packet(name, qtype, unicast=False):
    ident = random.randint(1, 65535) if unicast else 0
    qclass = 0x8001 if unicast else 1
    return struct.pack('!HHHHHH', ident, 0, 1, 0, 0, 0) + _dns_question(name, qtype, qclass=qclass)


def _collect_mdns_queries(sockets, questions, deadline):
    """Send mDNS questions and retain the packet source on parsed records."""
    records = []
    packets = 0
    for sock, is_unicast in sockets:
        for name, qtype in questions:
            try:
                sock.sendto(_mdns_query_packet(name, qtype, unicast=is_unicast), ('224.0.0.251', 5353))
            except Exception:
                continue
    while time.monotonic() < deadline:
        progressed = False
        for sock, _is_unicast in sockets:
            try:
                raw, addr = sock.recvfrom(64 * 1024)
            except socket.timeout:
                continue
            except Exception:
                continue
            progressed = True
            packets += 1
            source = str((addr or ('',))[0] or '')
            for row in _parse_mdns(raw):
                item = dict(row)
                if _private_ipv4(source):
                    item['_src'] = source
                records.append(item)
        if not progressed:
            time.sleep(0.01)
    return records, packets


def _google_devices_from_records(all_records):
    """Resolve Google Cast devices from mDNS records with source-IP fallback."""
    ptr_instances = []
    ptr_sources = {}
    for row in all_records:
        if row.get('type') != 12 or str(row.get('name') or '').rstrip('.').casefold() != _CAST_MDNS.casefold():
            continue
        instance = str(row.get('value') or '').rstrip('.')
        if not instance:
            continue
        if instance not in ptr_instances:
            ptr_instances.append(instance)
        source = str(row.get('_src') or '')
        if _private_ipv4(source) and instance not in ptr_sources:
            ptr_sources[instance] = source

    results = []
    seen = set()
    for instance in ptr_instances:
        srv_row = next((r for r in all_records if r.get('type') == 33 and str(r.get('name') or '').rstrip('.') == instance), None)
        srv = (srv_row or {}).get('value')
        txt = next((r.get('value') for r in all_records if r.get('type') == 16 and str(r.get('name') or '').rstrip('.') == instance), {}) or {}
        if not isinstance(txt, dict):
            txt = {}

        host = ''
        port = _CAST_PORT
        if isinstance(srv, dict):
            target = str(srv.get('target') or '').rstrip('.')
            port = int(srv.get('port') or _CAST_PORT)
            host = next((str(r.get('value') or '') for r in all_records
                         if r.get('type') == 1 and str(r.get('name') or '').rstrip('.') == target
                         and _private_ipv4(r.get('value'))), '')
            if not host:
                host = _resolve_private_ipv4(target)
            if not host:
                source = str((srv_row or {}).get('_src') or '')
                if _private_ipv4(source):
                    host = source

        # Some Chromecast built-in implementations reply with PTR/SRV but omit
        # the A record from the first response.  The source IP is authoritative
        # enough for the LAN-only trust boundary and avoids relying on Windows
        # being able to resolve .local names through normal DNS.
        if not host:
            host = ptr_sources.get(instance, '')
        if not _private_ipv4(host):
            continue
        if not (1 <= int(port) <= 65535):
            port = _CAST_PORT
        key = ('googlecast', host, int(port))
        if key in seen:
            continue
        seen.add(key)
        fallback = instance.split('._googlecast._tcp', 1)[0]
        results.append({
            'protocol': 'googlecast', 'name': _safe_label(txt.get('fn'), fallback),
            'model': _safe_label(txt.get('md'), 'Google Cast'), 'host': host, 'port': int(port),
            'uuid': str(txt.get('id') or ''),
        })
    return results


def _discover_google_cast_dial(timeout=0.7):
    """Last-resort Chromecast built-in discovery through DIAL/SSDP.

    DIAL does not replace Cast v2; it only supplies a private-LAN host when
    mDNS data is incomplete.  We accept the host only when Cast TLS/8009 is
    reachable, preventing generic DIAL devices from being mislabeled.
    """
    deadline = time.monotonic() + max(0.25, float(timeout))
    payloads = []
    for search_target in (_DIAL_ST, 'ssdp:all'):
        payloads.append(('M-SEARCH * HTTP/1.1\r\n'
                         'HOST: 239.255.255.250:1900\r\n'
                         'MAN: "ssdp:discover"\r\n'
                         'MX: 1\r\n'
                         'ST: %s\r\n\r\n' % search_target).encode('ascii'))
    hosts = []
    sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
        sock.settimeout(0.12)
        for payload in payloads:
            try:
                sock.sendto(payload, ('239.255.255.250', 1900))
            except Exception:
                pass
        while time.monotonic() < deadline:
            try:
                raw, addr = sock.recvfrom(64 * 1024)
            except socket.timeout:
                continue
            except Exception:
                break
            source = str((addr or ('',))[0] or '')
            headers = _http_headers(raw)
            location = str(headers.get('location') or '').strip()
            location_host = ''
            try:
                if location:
                    location_host = _resolve_private_ipv4(urllib.parse.urlparse(location).hostname)
            except Exception:
                pass
            host = location_host or (source if _private_ipv4(source) else '')
            if host and host not in hosts:
                hosts.append(host)
    except Exception as exc:
        log('Universal Cast: fallback DIAL indisponível (%s).' % exc.__class__.__name__, 'debug')
    finally:
        try:
            if sock is not None:
                sock.close()
        except Exception:
            pass

    results = []
    for host in hosts[:12]:
        candidate = {
            'protocol': 'googlecast', 'name': 'Google Cast %s' % host,
            'model': 'Chromecast built-in', 'host': host, 'port': _CAST_PORT, 'uuid': '',
        }
        try:
            if _probe_google_cast_device(candidate, timeout=0.65):
                results.append(candidate)
        except Exception:
            continue
    return results


def _remember_google_devices(rows):
    """Persist only non-secret receiver identity for wake/reconnect fallback."""
    clean = []
    seen = set()
    for row in rows or []:
        if not isinstance(row, dict) or row.get('protocol') != 'googlecast':
            continue
        host = _resolve_private_ipv4(row.get('host'))
        if not host:
            continue
        try:
            port = int(row.get('port') or _CAST_PORT)
        except Exception:
            port = _CAST_PORT
        if not (1 <= port <= 65535):
            continue
        key = (host, port)
        if key in seen:
            continue
        seen.add(key)
        clean.append({
            'protocol': 'googlecast', 'name': _safe_label(row.get('name'), 'Google Cast'),
            'model': _safe_label(row.get('model'), 'Google Cast'), 'host': host, 'port': port,
            'uuid': str(row.get('uuid') or '')[:96],
        })
    if not clean:
        return
    write_json(_CAST_DEVICE_CACHE, {
        'schema': _CAST_DEVICE_CACHE_SCHEMA, 'updated_at': int(time.time()), 'devices': clean[:8],
    })


def _cached_google_devices(timeout=0.75, limit=8):
    """Probe previously discovered Cast endpoints when the TV is not advertising."""
    data = read_json(_CAST_DEVICE_CACHE, {})
    if not isinstance(data, dict) or int(data.get('schema') or 0) != _CAST_DEVICE_CACHE_SCHEMA:
        return []
    devices = data.get('devices') if isinstance(data.get('devices'), list) else []
    results = []
    for row in devices[:max(1, int(limit or 1))]:
        if not isinstance(row, dict):
            continue
        host = _resolve_private_ipv4(row.get('host'))
        if not host:
            continue
        candidate = dict(row)
        candidate['host'] = host
        candidate['protocol'] = 'googlecast'
        try:
            if _probe_google_cast_device(candidate, timeout=max(0.25, float(timeout))):
                results.append(candidate)
        except Exception:
            continue
    return results


def discover_google_cast(timeout=1.8):
    """Discover Google Cast receivers with a fast known-endpoint path first."""
    total = max(0.8, float(timeout))
    # After one proven discovery, a direct TLS/8009 probe is both more reliable
    # and much faster than waiting for a dormant Android TV to advertise mDNS.
    # If the remembered endpoint is stale we immediately fall back to the full
    # mDNS/SSDP discovery below.
    cached_fast = _cached_google_devices(timeout=min(0.42, total * 0.28), limit=2)
    if cached_fast:
        for row in cached_fast:
            row['_discovery_source'] = 'cache_fast'
        _remember_google_devices(cached_fast)
        log('Universal Cast: Google discovery respostas=0 registros=0 dispositivos=%d interfaces=%d fonte=cache_fast.' %
            (len(cached_fast), len(_local_private_ipv4s())), 'debug')
        return cached_fast
    local_ips = _local_private_ipv4s()
    sockets = []
    packet_count = 0
    all_records = []
    try:
        # Canonical 5353 receiver first.  On Windows a bind can succeed even
        # when another mDNS service already owns delivery, so we ALSO create a
        # QU/unicast socket per private interface instead of treating bind
        # success as proof that multicast replies will reach this process.
        try:
            sockets.append((_mdns_socket(local_ips[0] if local_ips else '', canonical=True), False))
        except Exception:
            pass
        for ip in (local_ips or ['']):
            try:
                sockets.append((_mdns_socket(ip, canonical=False), True))
            except Exception:
                continue
        if not sockets:
            return []

        first_deadline = time.monotonic() + min(0.72, total * 0.55)
        rows, count = _collect_mdns_queries(sockets, [(_CAST_MDNS, 12)], first_deadline)
        all_records.extend(rows)
        packet_count += count

        # mDNS responders may split PTR, SRV, TXT and A over several packets.
        # Ask explicitly for missing service details rather than requiring all
        # records to be present in the first response.
        instances = []
        for row in all_records:
            if row.get('type') == 12 and str(row.get('name') or '').rstrip('.').casefold() == _CAST_MDNS.casefold():
                value = str(row.get('value') or '').rstrip('.')
                if value and value not in instances:
                    instances.append(value)
        if instances and time.monotonic() < (first_deadline + total):
            questions = []
            for instance in instances[:16]:
                questions.extend([(instance, 33), (instance, 16)])
            second_deadline = time.monotonic() + min(0.42, total * 0.30)
            rows, count = _collect_mdns_queries(sockets, questions, second_deadline)
            all_records.extend(rows)
            packet_count += count

            targets = []
            for row in all_records:
                if row.get('type') == 33 and isinstance(row.get('value'), dict):
                    target = str(row.get('value', {}).get('target') or '').rstrip('.')
                    if target and target not in targets:
                        targets.append(target)
            if targets:
                third_deadline = time.monotonic() + min(0.24, total * 0.18)
                rows, count = _collect_mdns_queries(sockets, [(target, 1) for target in targets[:16]], third_deadline)
                all_records.extend(rows)
                packet_count += count
    except Exception as exc:
        log('Universal Cast: descoberta Google Cast indisponível (%s).' % exc.__class__.__name__, 'debug')
    finally:
        for sock, _flag in sockets:
            try:
                sock.close()
            except Exception:
                pass

    results = _google_devices_from_records(all_records)
    source = 'mdns' if results else ''
    if not results:
        # Keep the total interaction bounded while giving Chromecast built-in
        # models one independent discovery/wake route through SSDP/DIAL.
        results = _discover_google_cast_dial(timeout=min(0.65, total * 0.40))
        source = 'ssdp' if results else ''
    if not results:
        # Once a receiver has been discovered successfully, remember only its
        # private endpoint so a dormant TCL/Android TV can be probed directly on
        # a later session without depending on another phone to wake mDNS first.
        results = _cached_google_devices(timeout=0.55, limit=4)
        source = 'cache' if results else ''
    if results:
        _remember_google_devices(results)
    log('Universal Cast: Google discovery respostas=%d registros=%d dispositivos=%d interfaces=%d fonte=%s.' %
        (packet_count, len(all_records), len(results), len(local_ips), source or 'nenhuma'), 'debug')
    return results


def discover_devices(timeout=2.2):
    """Discover all available receivers; caches accelerate but never replace LAN scan."""
    total = max(1.0, float(timeout))
    google = discover_google_cast(timeout=min(1.5, total * 0.60))
    google_fast = bool(google and all(str(row.get('_discovery_source') or '') == 'cache_fast' for row in google))

    # Validate every remembered DLNA endpoint in parallel.  Cache only speeds up
    # known renderers; it never suppresses the mandatory live SSDP scan below.
    dlna_cached = _cached_dlna_devices(timeout=min(0.45, max(0.32, total * 0.18)), limit=_DLNA_CACHE_LIMIT)

    # MX=1 permits receivers to delay their response for up to ~1 second.  Keep
    # the live window above that even when Google Cast was returned instantly.
    # This is intentionally a network-completeness tradeoff: ~1.3s is still
    # bounded, but newly-enabled Kodi/TV renderers are no longer frozen out.
    dlna_live_timeout = min(1.45, max(_DLNA_LIVE_WINDOW, total * 0.58))
    dlna_live = discover_dlna(timeout=dlna_live_timeout)

    dlna = _merge_cast_devices([], dlna_cached + dlna_live)
    _write_dlna_cache(dlna)

    final = _merge_cast_devices(google, dlna)
    log('Universal Cast: DLNA discovery cache_validos=%d ao_vivo=%d total_dlna=%d total_receivers=%d modo=rede_completa.' %
        (len(dlna_cached), len(dlna_live), len(dlna), len(final)), 'debug')
    return final


# ---- DLNA AVTransport ----
def _soap(control_url, service, action, body, timeout=2.5):
    envelope = ('<?xml version="1.0" encoding="utf-8"?>'
                '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
                's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">'
                '<s:Body><u:%s xmlns:u="%s">%s</u:%s></s:Body></s:Envelope>' %
                (action, service, body, action)).encode('utf-8')
    req = urllib.request.Request(str(control_url), data=envelope, method='POST')
    req.add_header('Content-Type', 'text/xml; charset="utf-8"')
    req.add_header('SOAPAction', '"%s#%s"' % (service, action))
    req.add_header('Connection', 'close')
    with lan_open(req, timeout=max(0.8, float(timeout))) as response:
        response.read(256 * 1024)
        return int(getattr(response, 'status', 200) or 200)


def _didl(title, url, mime):
    protocol = 'http-get:*:%s:*' % str(mime or 'application/octet-stream')
    return ('<DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" '
            'xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/">'
            '<item id="0" parentID="-1" restricted="1">'
            '<dc:title>%s</dc:title><upnp:class>object.item.videoItem</upnp:class>'
            '<res protocolInfo="%s">%s</res></item></DIDL-Lite>' %
            (html.escape(str(title or 'ONEPLAY'), quote=False), html.escape(protocol, quote=True),
             html.escape(str(url), quote=False)))


def dlna_play(device, url, mime, title='ONEPLAY'):
    control = str((device or {}).get('control_url') or '')
    if not control:
        raise ValueError('AVTransport ausente')
    metadata = _didl(title, url, mime)
    body = '<InstanceID>0</InstanceID><CurrentURI>%s</CurrentURI><CurrentURIMetaData>%s</CurrentURIMetaData>' % (
        html.escape(str(url), quote=False), html.escape(metadata, quote=False))
    service = str((device or {}).get('service_type') or _DLNA_AVTRANSPORT)
    _soap(control, service, 'SetAVTransportURI', body, timeout=3.0)
    _soap(control, service, 'Play', '<InstanceID>0</InstanceID><Speed>1</Speed>', timeout=2.5)
    return True


def _lg_ts_didl(title, url):
    """Conservative DIDL profile used only after a strict LG rejects V11 TS metadata."""
    protocol = (
        'http-get:*:video/mp2t:'
        'DLNA.ORG_OP=00;DLNA.ORG_FLAGS=01700000000000000000000000000000'
    )
    return ('<DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" '
            'xmlns:dlna="urn:schemas-dlna-org:metadata-1-0/" '
            'xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/">'
            '<item id="0" parentID="" restricted="1">'
            '<dc:title>%s</dc:title><upnp:class>object.item.videoItem</upnp:class>'
            '<res protocolInfo="%s">%s</res></item></DIDL-Lite>' %
            (html.escape(str(title or 'ONEPLAY'), quote=False), html.escape(protocol, quote=True),
             html.escape(str(url), quote=False)))


def _lg_ts_set_uri(control, service, url, metadata, timeout=3.0):
    body = '<InstanceID>0</InstanceID><CurrentURI>%s</CurrentURI><CurrentURIMetaData>%s</CurrentURIMetaData>' % (
        html.escape(str(url), quote=False), html.escape(str(metadata or ''), quote=False))
    return _soap(control, service, 'SetAVTransportURI', body, timeout=timeout)


def _lg_retry_set_uri_until_ready(setter, control, service, url, metadata, label, last_exc):
    """Bounded LG/webOS AVTransport readiness recovery after explicit HTTP 500.

    SSDP/device-description reachability only proves that the renderer service is
    published on the LAN.  Field logs show LG can still return HTTP 500 for every
    SetAVTransportURI profile, then accept the identical V11 request later.  Use
    the canonical SetURI itself as the readiness probe: retry only HTTP 500 inside
    a 25 s window, never loop indefinitely, and never hide non-500 rejections.

    A transport timeout remains ambiguous (the TV may have processed SetURI while
    delaying the SOAP reply), so callers may send their existing one-way PLAY and
    let Relay served_count arbitrate actual success.
    """
    deadline = time.monotonic() + _LG_AVT_WAKE_WINDOW
    attempt = 0
    announced = False
    current_exc = last_exc
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0.0:
            break
        attempt += 1
        if not announced:
            log('Universal Cast: LG/webOS AVTransport ainda não pronto após HTTP 500; aguardando readiness bounded (máximo 25s).', 'debug')
            announced = True
        delay = min(2.0, 0.85 + (0.25 * min(attempt, 5)))
        time.sleep(min(delay, max(0.05, remaining)))
        try:
            setter(control, service, url, metadata, timeout=3.0)
            log('Universal Cast: LG/webOS AVTransport ficou pronto; SetURI V11 aceito na recuperação (%s, tentativa=%d).' %
                (str(label or 'media'), attempt), 'debug')
            return service, False
        except urllib.error.HTTPError as exc:
            current_exc = exc
            code = int(getattr(exc, 'code', 0) or 0)
            if code != 500:
                log('Universal Cast: LG/webOS readiness interrompido por rejeição não transitória HTTP %s.' % code, 'debug')
                raise
            if attempt in (1, 3, 6, 10):
                log('Universal Cast: LG/webOS AVTransport ainda retornando HTTP 500; wake/readiness em andamento.', 'debug')
        except (socket.timeout, TimeoutError, urllib.error.URLError) as exc:
            log('Universal Cast: LG/webOS readiness SetURI sem resposta (%s); estado será validado pelo Relay.' %
                exc.__class__.__name__, 'debug')
            return service, True

    log('Universal Cast: LG/webOS AVTransport não ficou pronto dentro da janela bounded de 25s.', 'debug')
    raise current_exc


def _dlna_play_lg_ts(device, url, title='ONEPLAY'):
    """Start direct TS on LG/webOS with bounded AVTransport readiness recovery.

    The proven V11 SetURI remains first.  Interoperability metadata fallbacks are
    preserved.  Only when every explicit rejection is HTTP 500 do we treat the
    LG AVTransport as potentially published-but-not-ready and repeat canonical
    V11 inside a bounded wake window.  PLAY remains one-way and Relay activity is
    still the sole success authority in start_cast().
    """
    control = str((device or {}).get('control_url') or '')
    if not control:
        raise ValueError('AVTransport ausente')
    service = str((device or {}).get('service_type') or _DLNA_AVTRANSPORT)
    standard = _didl(title, url, 'video/mp2t')
    ambiguous_seturi = False
    try:
        _lg_ts_set_uri(control, service, url, standard, timeout=3.0)
        accepted_service = service
        log('Universal Cast: LG/webOS aceitou SetURI TS no perfil V11.', 'debug')
    except urllib.error.HTTPError as first_exc:
        first_code = int(getattr(first_exc, 'code', 0) or 0)
        log('Universal Cast: LG/webOS recusou SetURI TS padrão (HTTP %s); tentando perfil TS conservador.' %
            first_code, 'debug')
        accepted_service = ''
        compat = _lg_ts_didl(title, url)
        attempts = [(service, compat, 'ts-compat')]
        if service != _DLNA_AVTRANSPORT:
            attempts.append((_DLNA_AVTRANSPORT, compat, 'ts-compat-avt1'))
        attempts.append((_DLNA_AVTRANSPORT, '', 'uri-sem-metadata'))
        last_exc = first_exc
        rejection_codes = [first_code]
        for candidate_service, candidate_meta, label in attempts:
            try:
                _lg_ts_set_uri(control, candidate_service, url, candidate_meta, timeout=3.2)
                accepted_service = candidate_service
                log('Universal Cast: LG/webOS SetURI aceito (%s).' % label, 'debug')
                break
            except urllib.error.HTTPError as exc:
                last_exc = exc
                code = int(getattr(exc, 'code', 0) or 0)
                rejection_codes.append(code)
                log('Universal Cast: LG/webOS perfil %s recusado (HTTP %s).' % (label, code), 'debug')
        if not accepted_service:
            all_http_500 = bool(rejection_codes) and all(code == 500 for code in rejection_codes)
            if all_http_500:
                accepted_service, ambiguous_seturi = _lg_retry_set_uri_until_ready(
                    _lg_ts_set_uri, control, service, url, standard, 'live-ts', last_exc,
                )
            else:
                raise last_exc

    _soap_oneway(
        control, accepted_service or service, 'Play',
        '<InstanceID>0</InstanceID><Speed>1</Speed>', timeout=0.45,
    )
    log('Universal Cast: LG/webOS PLAY TS enviado em modo one-way%s; confirmação ficará a cargo do Relay.' %
        (' após SetURI ambíguo' if ambiguous_seturi else ''), 'debug')
    return True





def _lg_vod_didl(title, url, mime, generic=False):
    """Seekable VOD DIDL for LG/webOS, isolated from the V11 generic path.

    LG field tests on V15 proved Live direct-TS, while Movie attempts failed
    before the renderer fetched Relay media.  This profile is therefore used
    only for LG/webOS VOD after (or around) the original V11 SetURI contract.
    It advertises byte seek because Relay V5 already supports Range/206 for
    movie/series roots.  ``generic=True`` mirrors tolerant DLNA controllers by
    advertising application/octet-stream without changing the actual Relay
    response MIME or upstream media bytes.
    """
    advertised = 'application/octet-stream' if generic else str(mime or 'application/octet-stream')
    protocol = (
        'http-get:*:%s:'
        'DLNA.ORG_OP=01;DLNA.ORG_FLAGS=21700000000000000000000000000000'
    ) % advertised
    return ('<DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" '
            'xmlns:dlna="urn:schemas-dlna-org:metadata-1-0/" '
            'xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/">'
            '<item id="0" parentID="" restricted="1">'
            '<dc:title>%s</dc:title><upnp:class>object.item.videoItem</upnp:class>'
            '<res protocolInfo="%s">%s</res></item></DIDL-Lite>' %
            (html.escape(str(title or 'ONEPLAY'), quote=False), html.escape(protocol, quote=True),
             html.escape(str(url), quote=False)))


def _lg_vod_set_uri(control, service, url, metadata, timeout=3.0):
    body = '<InstanceID>0</InstanceID><CurrentURI>%s</CurrentURI><CurrentURIMetaData>%s</CurrentURIMetaData>' % (
        html.escape(str(url), quote=False), html.escape(str(metadata or ''), quote=False))
    return _soap(control, service, 'SetAVTransportURI', body, timeout=timeout)


def _dlna_play_lg_vod(device, url, mime, title='ONEPLAY'):
    """Start LG/webOS VOD with profile fallbacks plus bounded readiness recovery.

    V11 and all existing interoperability profiles remain intact.  A synchronous
    timeout is still ambiguous and is never followed by stacked SetURI variants.
    When every explicit profile rejection is HTTP 500, canonical V11 becomes the
    bounded readiness probe for up to 25 s, matching the real LG pattern where
    the same media is accepted after the renderer/webOS transport settles.
    """
    control = str((device or {}).get('control_url') or '')
    if not control:
        raise ValueError('AVTransport ausente')
    service = str((device or {}).get('service_type') or _DLNA_AVTRANSPORT)
    real_mime = str(mime or 'application/octet-stream')
    standard = _didl(title, url, real_mime)
    accepted_service = service
    ambiguous_seturi = False

    try:
        _lg_vod_set_uri(control, service, url, standard, timeout=3.0)
        log('Universal Cast: LG/webOS VOD aceitou SetURI no perfil V11 (mime=%s).' % real_mime, 'debug')
    except urllib.error.HTTPError as first_exc:
        first_code = int(getattr(first_exc, 'code', 0) or 0)
        log('Universal Cast: LG/webOS VOD recusou SetURI padrão (HTTP %s); tentando interoperabilidade VOD.' %
            first_code, 'debug')
        attempts = [
            (service, _lg_vod_didl(title, url, real_mime, generic=False), 'vod-seek'),
            (service, _lg_vod_didl(title, url, real_mime, generic=True), 'vod-generic'),
        ]
        if service != _DLNA_AVTRANSPORT:
            attempts.append((_DLNA_AVTRANSPORT, _lg_vod_didl(title, url, real_mime, generic=True), 'vod-generic-avt1'))
        attempts.append((_DLNA_AVTRANSPORT, '', 'uri-sem-metadata'))
        last_exc = first_exc
        rejection_codes = [first_code]
        accepted_service = ''
        for candidate_service, metadata, label in attempts:
            try:
                _lg_vod_set_uri(control, candidate_service, url, metadata, timeout=3.2)
                accepted_service = candidate_service
                log('Universal Cast: LG/webOS VOD SetURI aceito (%s; mime=%s).' % (label, real_mime), 'debug')
                break
            except urllib.error.HTTPError as exc:
                last_exc = exc
                code = int(getattr(exc, 'code', 0) or 0)
                rejection_codes.append(code)
                log('Universal Cast: LG/webOS VOD perfil %s recusado (HTTP %s).' % (label, code), 'debug')
            except (socket.timeout, TimeoutError, urllib.error.URLError) as exc:
                accepted_service = candidate_service
                ambiguous_seturi = True
                log('Universal Cast: LG/webOS VOD SetURI %s sem resposta (%s); estado será validado pelo Relay.' %
                    (label, exc.__class__.__name__), 'debug')
                break
        if not accepted_service:
            all_http_500 = bool(rejection_codes) and all(code == 500 for code in rejection_codes)
            if all_http_500:
                accepted_service, ambiguous_seturi = _lg_retry_set_uri_until_ready(
                    _lg_vod_set_uri, control, service, url, standard, 'vod', last_exc,
                )
            else:
                raise last_exc
    except (socket.timeout, TimeoutError, urllib.error.URLError) as exc:
        ambiguous_seturi = True
        accepted_service = service
        log('Universal Cast: LG/webOS VOD SetURI padrão sem resposta (%s); tentando PLAY bounded e validando pelo Relay.' %
            exc.__class__.__name__, 'debug')

    _soap_oneway(
        control, accepted_service or service, 'Play',
        '<InstanceID>0</InstanceID><Speed>1</Speed>', timeout=0.45,
    )
    log('Universal Cast: LG/webOS PLAY VOD enviado em modo one-way%s; confirmação ficará a cargo do Relay.' %
        (' após SetURI ambíguo' if ambiguous_seturi else ''), 'debug')
    return True




def _soap_oneway(control_url, service, action, body, timeout=0.35):
    """Send a LAN SOAP command without waiting for the HTTP response.

    Used only for user-initiated DLNA STOP.  Android field tests showed that
    waiting synchronously for the renderer response can stall the sender UI and
    in some devices destabilize Kodi during teardown.  Once the complete HTTP
    request body has been sent, the MediaRenderer has everything required to
    process Stop; the response is informational for this best-effort operation.
    """
    parsed = urllib.parse.urlparse(str(control_url or ''))
    host = _resolve_private_ipv4(parsed.hostname)
    if parsed.scheme != 'http' or not host:
        raise ValueError('controle DLNA one-way inválido')
    port = int(parsed.port or 80)
    path = str(parsed.path or '/')
    if parsed.query:
        path += '?' + str(parsed.query)
    envelope = ('<?xml version="1.0" encoding="utf-8"?>'
                '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
                's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">'
                '<s:Body><u:%s xmlns:u="%s">%s</u:%s></s:Body></s:Envelope>' %
                (action, service, body, action)).encode('utf-8')
    conn = http.client.HTTPConnection(host, port, timeout=max(0.15, min(0.65, float(timeout))))
    try:
        conn.request('POST', path, body=envelope, headers={
            'Content-Type': 'text/xml; charset="utf-8"',
            'SOAPAction': '"%s#%s"' % (service, action),
            'Content-Length': str(len(envelope)),
            'Connection': 'close',
        })
        # Deliberately do not call getresponse(): receiver-side processing does
        # not require us to wait for the HTTP reply, and Android UI must remain
        # bounded even if the renderer delays its response.
        return True
    finally:
        try:
            conn.close()
        except Exception:
            pass


def dlna_stop(device, fast=False):
    control = str((device or {}).get('control_url') or '')
    if not control:
        return False
    try:
        service = str((device or {}).get('service_type') or _DLNA_AVTRANSPORT)
        if fast:
            return bool(_soap_oneway(
                control, service, 'Stop', '<InstanceID>0</InstanceID>', timeout=0.35,
            ))
        _soap(control, service, 'Stop', '<InstanceID>0</InstanceID>', timeout=1.8)
        return True
    except Exception:
        return False


# ---- Minimal Google Cast v2 channel (protobuf CastMessage without protobuf dep) ----
def _varint(number):
    value = int(number)
    out = bytearray()
    while True:
        b = value & 0x7F
        value >>= 7
        out.append(b | (0x80 if value else 0))
        if not value:
            return bytes(out)


def _field_varint(number, value):
    return _varint((int(number) << 3) | 0) + _varint(value)


def _field_bytes(number, value):
    raw = value.encode('utf-8') if isinstance(value, str) else bytes(value)
    return _varint((int(number) << 3) | 2) + _varint(len(raw)) + raw


def _read_varint(data, pos):
    result = 0
    shift = 0
    while pos < len(data) and shift < 64:
        b = data[pos]
        pos += 1
        result |= (b & 0x7F) << shift
        if not (b & 0x80):
            return result, pos
        shift += 7
    raise ValueError('varint inválido')


def _cast_message(source, destination, namespace, payload):
    text = json.dumps(payload, separators=(',', ':'), ensure_ascii=False)
    # protocol_version=0 (CASTV2_1_0), payload_type=0 (STRING)
    return (b''.join([
        _field_varint(1, 0), _field_bytes(2, source), _field_bytes(3, destination),
        _field_bytes(4, namespace), _field_varint(5, 0), _field_bytes(6, text),
    ]))


def _parse_cast_message(raw):
    data = bytes(raw or b'')
    pos = 0
    fields = {}
    while pos < len(data):
        key, pos = _read_varint(data, pos)
        field = key >> 3
        wire = key & 7
        if wire == 0:
            value, pos = _read_varint(data, pos)
        elif wire == 2:
            ln, pos = _read_varint(data, pos)
            value = data[pos:pos + ln]
            pos += ln
        else:
            raise ValueError('wire type não suportado')
        fields[field] = value
    def text(n):
        value = fields.get(n, b'')
        return value.decode('utf-8', 'replace') if isinstance(value, (bytes, bytearray)) else str(value or '')
    payload = {}
    if text(6):
        try:
            payload = json.loads(text(6))
        except Exception:
            payload = {}
    return {'source': text(2), 'destination': text(3), 'namespace': text(4), 'payload': payload}


class _CastChannel(object):
    def __init__(self, host, port=8009, timeout=3.0):
        self.host = str(host)
        self.port = int(port or 8009)
        self.timeout = max(1.0, float(timeout))
        self.sock = None
        self.source = 'sender-0'
        self._receive_buffer = bytearray()
        self._receive_length = None
        self.request_id = random.randint(1000, 900000)

    def __enter__(self):
        raw = _lan_connection((self.host, self.port), timeout=self.timeout)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        try:
            self.sock = context.wrap_socket(raw, server_hostname=self.host)
        except Exception:
            raw.close()
            raise
        self.sock.settimeout(0.45)
        return self

    def __exit__(self, _type, _value, _tb):
        try:
            if self.sock is not None:
                self.sock.close()
        except Exception:
            pass
        self.sock = None

    def next_request(self):
        self.request_id += 1
        return self.request_id

    def send(self, destination, namespace, payload):
        msg = _cast_message(self.source, str(destination), str(namespace), payload)
        self.sock.sendall(struct.pack('!I', len(msg)) + msg)

    def _recv_exact(self, length):
        # Preserve partial data when wait_payload retries after a timeout.
        out = self._receive_buffer
        while len(out) < length:
            chunk = self.sock.recv(length - len(out))
            if not chunk:
                raise OSError('cast socket encerrado')
            out.extend(chunk)
        result = bytes(out)
        out.clear()
        return result

    def recv(self):
        if self._receive_length is None:
            header = self._recv_exact(4)
            length = struct.unpack('!I', header)[0]
            if length <= 0 or length > 2 * 1024 * 1024:
                raise ValueError('cast frame inválido')
            self._receive_length = length
        raw = self._recv_exact(self._receive_length)
        self._receive_length = None
        return _parse_cast_message(raw)

    def wait_payload(self, types, timeout=4.0, request_id=None):
        wanted = set(types if isinstance(types, (list, tuple, set)) else [types])
        deadline = time.monotonic() + max(0.5, float(timeout))
        while time.monotonic() < deadline:
            try:
                msg = self.recv()
            except socket.timeout:
                continue
            payload = msg.get('payload') if isinstance(msg.get('payload'), dict) else {}
            if msg.get('namespace') == _NS_HEARTBEAT and payload.get('type') == 'PING':
                self.send(msg.get('source') or 'receiver-0', _NS_HEARTBEAT, {'type': 'PONG'})
                continue
            if payload.get('type') in wanted:
                # Cast receivers commonly broadcast RECEIVER_STATUS/MEDIA_STATUS
                # with requestId=0 (or without requestId) even when a sender is
                # waiting for a concrete request.  Treat those status broadcasts
                # as valid observations; request-bound error replies still retain
                # their requestId and are handled by the caller.
                observed_request = payload.get('requestId')
                if request_id is None or observed_request in (None, 0, request_id):
                    return payload
        raise TimeoutError('resposta Google Cast não recebida')


def _receiver_application(status):
    root = (status or {}).get('status') if isinstance(status, dict) else {}
    if not isinstance(root, dict):
        root = {}
    apps = root.get('applications') or []
    if not isinstance(apps, list):
        apps = []
    return next((app for app in apps if isinstance(app, dict) and app.get('appId') == _CAST_APP_ID), None)


def _media_status_row(payload):
    rows = (payload or {}).get('status') or []
    if not isinstance(rows, list):
        rows = []
    return next((item for item in rows if isinstance(item, dict)), {})


def _media_status_detail(payload):
    row = _media_status_row(payload)
    state = str(row.get('playerState') or '').upper()
    idle = str(row.get('idleReason') or '').upper()
    return state, idle


def _media_status_identity(payload):
    row = _media_status_row(payload)
    media = row.get('media') if isinstance(row.get('media'), dict) else {}
    return (
        str(row.get('mediaSessionId') or ''),
        str(media.get('contentId') or ''),
    )


def _relay_has_media(session_id):
    status = relay_session_activity(session_id)
    return bool(
        status.get('found') and int(status.get('served_count') or 0) > 0 and not status.get('released')
    )


def _wait_relay_media(session_id, timeout=5.0):
    deadline = time.monotonic() + max(0.5, float(timeout))
    while time.monotonic() < deadline:
        if _relay_has_media(session_id):
            return True
        time.sleep(0.10)
    return _relay_has_media(session_id)



def _cast_connect_payload():
    """Sender identity compatible with Cast v2 platform/app channels."""
    return {
        'type': 'CONNECT', 'origin': {}, 'userAgent': 'ONEPLAY IBO',
        'senderInfo': {
            'sdkType': 2, 'version': '2.3.4', 'browserVersion': 'Kodi',
            'platform': 4, 'systemVersion': 'Kodi', 'connectionType': 1,
        },
    }


def _probe_google_cast_device(device, timeout=1.0):
    """Prove that an endpoint speaks Cast v2; a TCP-open port alone is insufficient."""
    host = _resolve_private_ipv4((device or {}).get('host'))
    if not host:
        return False
    try:
        port = int((device or {}).get('port') or _CAST_PORT)
        with _CastChannel(host, port, timeout=max(0.7, float(timeout))) as channel:
            channel.send('receiver-0', _NS_CONNECTION, _cast_connect_payload())
            rid = channel.next_request()
            channel.send('receiver-0', _NS_RECEIVER, {'type': 'GET_STATUS', 'requestId': rid})
            status = channel.wait_payload('RECEIVER_STATUS', timeout=max(0.7, float(timeout)), request_id=rid)
            return isinstance(status, dict) and status.get('type') == 'RECEIVER_STATUS'
    except Exception:
        return False


def _receiver_status_with_wake(channel, total_timeout=None):
    """Get receiver status with one heartbeat-assisted retry for dormant TVs.

    ``total_timeout`` is used only by the cold-wake state machine.  Existing
    callers keep the V5 timings unchanged.
    """
    if total_timeout is None:
        waits = (2.2, 2.8)
    else:
        budget = max(1.4, float(total_timeout))
        first = min(2.0, max(0.7, budget * 0.44))
        second = min(2.6, max(0.7, budget - first))
        waits = (first, second)
    last_error = None
    for attempt in range(2):
        rid = channel.next_request()
        channel.send('receiver-0', _NS_RECEIVER, {'type': 'GET_STATUS', 'requestId': rid})
        try:
            return channel.wait_payload('RECEIVER_STATUS', timeout=waits[attempt], request_id=rid)
        except Exception as exc:
            last_error = exc
            if attempt == 0:
                try:
                    channel.send('receiver-0', _NS_HEARTBEAT, {'type': 'PING'})
                    channel.wait_payload('PONG', timeout=min(0.8, max(0.35, waits[1] * 0.35)))
                except Exception:
                    pass
                channel.send('receiver-0', _NS_CONNECTION, _cast_connect_payload())
    raise last_error or TimeoutError('receiver Google Cast não respondeu')


def _receiver_app_stable(channel, app, timeout=3.6):
    """Wait for a newly launched Cast app to expose a stable session/transport."""
    expected = (str((app or {}).get('sessionId') or ''), str((app or {}).get('transportId') or ''))
    if not all(expected):
        return app
    deadline = time.monotonic() + max(1.2, float(timeout))
    stable = 0
    last = app
    while time.monotonic() < deadline:
        rid = channel.next_request()
        channel.send('receiver-0', _NS_RECEIVER, {'type': 'GET_STATUS', 'requestId': rid})
        try:
            status = channel.wait_payload('RECEIVER_STATUS', timeout=min(1.25, max(0.5, deadline - time.monotonic())), request_id=rid)
        except Exception:
            try:
                channel.send('receiver-0', _NS_HEARTBEAT, {'type': 'PING'})
            except Exception:
                pass
            time.sleep(0.20)
            continue
        current = _receiver_application(status)
        ident = (str((current or {}).get('sessionId') or ''), str((current or {}).get('transportId') or ''))
        if current and ident == expected:
            last = current
            stable += 1
            if stable >= 2:
                return last
        else:
            stable = 0
            if current and all(ident):
                expected = ident
                last = current
        time.sleep(0.25)
    return last


def _receiver_app_stateful_ready(channel, app, timeout=4.0):
    """Return the app only after sessionId/transportId are stable twice.

    Unlike the legacy settling helper, timeout is reported as ``None`` so the
    cold-wake state machine can reconnect and keep waiting instead of sending
    LOAD into a half-awake Android TV.
    """
    expected = (str((app or {}).get('sessionId') or ''), str((app or {}).get('transportId') or ''))
    if not all(expected):
        return None
    deadline = time.monotonic() + max(1.0, float(timeout))
    stable = 0
    while time.monotonic() < deadline:
        rid = channel.next_request()
        channel.send('receiver-0', _NS_RECEIVER, {'type': 'GET_STATUS', 'requestId': rid})
        try:
            status = channel.wait_payload(
                'RECEIVER_STATUS', timeout=min(1.15, max(0.45, deadline - time.monotonic())), request_id=rid,
            )
        except Exception:
            try:
                channel.send('receiver-0', _NS_HEARTBEAT, {'type': 'PING'})
            except Exception:
                pass
            time.sleep(0.16)
            continue
        current = _receiver_application(status)
        ident = (str((current or {}).get('sessionId') or ''), str((current or {}).get('transportId') or ''))
        if current and all(ident) and ident == expected:
            stable += 1
            if stable >= 2:
                return current
        elif current and all(ident):
            expected = ident
            stable = 1
        else:
            stable = 0
        time.sleep(0.18)
    return None


def _media_namespace_ready(channel, transport, session_id, timeout=2.8):
    """Synchronize the media namespace before LOAD, especially after a cold launch."""
    deadline = time.monotonic() + max(1.0, float(timeout))
    while time.monotonic() < deadline:
        rid = channel.next_request()
        channel.send(transport, _NS_MEDIA, {
            'type': 'GET_STATUS', 'requestId': rid, 'sessionId': session_id,
        })
        try:
            payload = channel.wait_payload('MEDIA_STATUS', timeout=min(1.0, max(0.5, deadline - time.monotonic())), request_id=rid)
            if isinstance(payload, dict):
                return payload
        except Exception:
            try:
                channel.send('receiver-0', _NS_HEARTBEAT, {'type': 'PING'})
            except Exception:
                pass
        time.sleep(0.25)
    return None


def _google_cast_play_once(device, url, mime, title='ONEPLAY', kind='live', relay_session_id='', settle_launch=True, strict_wake=False, wake_deadline=None):
    host = _resolve_private_ipv4((device or {}).get('host'))
    if not host:
        raise ValueError('IP Google Cast inválido')
    if not str(relay_session_id or '').strip():
        raise ValueError('sessão Relay ausente para Google Cast')
    port = int((device or {}).get('port') or _CAST_PORT)
    with _CastChannel(host, port, timeout=3.0) as channel:
        channel.send('receiver-0', _NS_CONNECTION, _cast_connect_payload())
        remaining = None
        if strict_wake and wake_deadline is not None:
            remaining = max(1.4, float(wake_deadline) - time.monotonic())
        try:
            status = _receiver_status_with_wake(
                channel, total_timeout=min(4.6, remaining) if remaining is not None else None,
            )
        except (TimeoutError, OSError, ssl.SSLError) as exc:
            if strict_wake:
                raise _CastWakePending('receiver Google Cast ainda acordando')
            raise
        app = _receiver_application(status)
        launched_now = False
        if not app:
            rid = channel.next_request()
            channel.send('receiver-0', _NS_RECEIVER, {'type': 'LAUNCH', 'appId': _CAST_APP_ID, 'requestId': rid})
            launch_wait = 8.5
            if strict_wake and wake_deadline is not None:
                launch_wait = min(launch_wait, max(1.0, float(wake_deadline) - time.monotonic()))
            deadline = time.monotonic() + launch_wait
            while time.monotonic() < deadline:
                try:
                    status = channel.wait_payload(
                        ['RECEIVER_STATUS', 'LAUNCH_ERROR'],
                        timeout=min(2.2, max(0.45, deadline - time.monotonic())),
                    )
                except TimeoutError:
                    try:
                        channel.send('receiver-0', _NS_HEARTBEAT, {'type': 'PING'})
                    except Exception:
                        pass
                    continue
                if status.get('type') == 'LAUNCH_ERROR':
                    raise RuntimeError('receiver Google Cast recusou o lançamento')
                app = _receiver_application(status)
                if app:
                    launched_now = True
                    break
            if not app:
                if strict_wake:
                    raise _CastWakePending('Default Media Receiver ainda iniciando')
                raise TimeoutError('Default Media Receiver não iniciou')

        if strict_wake:
            settle_budget = 4.2
            if wake_deadline is not None:
                settle_budget = min(settle_budget, max(1.0, float(wake_deadline) - time.monotonic()))
            app = _receiver_app_stateful_ready(channel, app, timeout=settle_budget)
            if not app:
                raise _CastWakePending('receiver Google Cast ainda estabilizando sessão')
        elif launched_now and settle_launch:
            app = _receiver_app_stable(channel, app, timeout=4.0)

        transport = str((app or {}).get('transportId') or '')
        session_id = str((app or {}).get('sessionId') or '')
        if not transport:
            if strict_wake:
                raise _CastWakePending('transportId Google Cast ainda indisponível')
            raise RuntimeError('transportId Google Cast ausente')
        if not session_id:
            if strict_wake:
                raise _CastWakePending('sessionId Google Cast ainda indisponível')
            raise RuntimeError('sessionId Google Cast ausente')
        channel.send(transport, _NS_CONNECTION, _cast_connect_payload())

        warm_timeout = 3.4 if launched_now else 1.5
        if strict_wake:
            warm_timeout = 3.8
            if wake_deadline is not None:
                warm_timeout = min(warm_timeout, max(1.0, float(wake_deadline) - time.monotonic()))
        warm = _media_namespace_ready(channel, transport, session_id, timeout=warm_timeout)
        if strict_wake and warm is None:
            raise _CastWakePending('receiver Google Cast ainda inicializando o canal de mídia')
        if launched_now and warm is None:
            raise TimeoutError('receiver Google Cast ainda inicializando o canal de mídia')

        if isinstance(warm, dict):
            warm_state, _warm_idle = _media_status_detail(warm)
            _warm_msid, warm_content = _media_status_identity(warm)
            if warm_content == str(url) and warm_state in ('PLAYING', 'BUFFERING') and _relay_has_media(relay_session_id):
                log('Universal Cast: Google media confirmado após estabilização do receiver (estado=%s; relay_media=sim).' % warm_state, 'debug')
                return True

        load_rid = channel.next_request()
        media = {
            'contentId': str(url), 'streamType': 'LIVE' if str(kind) == 'live' else 'BUFFERED',
            'contentType': str(mime or 'application/octet-stream'),
            'metadata': {'metadataType': 0, 'title': str(title or 'ONEPLAY')},
        }
        channel.send(transport, _NS_MEDIA, {
            'type': 'LOAD', 'requestId': load_rid, 'sessionId': session_id,
            'media': media, 'autoplay': True, 'currentTime': 0, 'customData': {},
        })

        deadline = time.monotonic() + 13.0
        load_sent_at = time.monotonic()
        transition_grace = load_sent_at + 2.2
        last_state = ''
        last_idle = ''
        target_media_session = ''
        active = False
        relay_seen = False
        next_status_query = 0.0
        next_heartbeat = time.monotonic() + 3.5
        first = True
        stale_interrupted_logged = False
        while time.monotonic() < deadline:
            now = time.monotonic()
            if now >= next_heartbeat:
                try:
                    channel.send('receiver-0', _NS_HEARTBEAT, {'type': 'PING'})
                except Exception:
                    pass
                next_heartbeat = now + 3.5
            result = None
            requested_id = load_rid if first else None
            try:
                if first:
                    result = channel.wait_payload(
                        ['MEDIA_STATUS', 'LOAD_FAILED', 'LOAD_CANCELLED', 'INVALID_REQUEST'],
                        timeout=min(2.8, max(0.5, deadline - now)),
                        request_id=load_rid,
                    )
                    first = False
                elif now >= next_status_query:
                    rid = channel.next_request()
                    requested_id = rid
                    channel.send(transport, _NS_MEDIA, {
                        'type': 'GET_STATUS', 'requestId': rid, 'sessionId': session_id,
                    })
                    result = channel.wait_payload(
                        ['MEDIA_STATUS', 'LOAD_FAILED', 'LOAD_CANCELLED', 'INVALID_REQUEST'],
                        timeout=min(1.35, max(0.5, deadline - now)),
                        request_id=rid,
                    )
                    next_status_query = time.monotonic() + 0.55
            except TimeoutError:
                first = False
                next_status_query = time.monotonic() + 0.25

            if not relay_seen:
                relay_seen = _relay_has_media(relay_session_id)

            if isinstance(result, dict):
                msg_type = str(result.get('type') or '')
                if msg_type in ('LOAD_FAILED', 'LOAD_CANCELLED', 'INVALID_REQUEST'):
                    raise RuntimeError('Google Cast não aceitou a mídia (%s)' % msg_type)
                if msg_type == 'MEDIA_STATUS':
                    state, idle = _media_status_detail(result)
                    media_session, content_id = _media_status_identity(result)
                    observed_request = result.get('requestId')
                    request_bound = requested_id is not None and observed_request == requested_id
                    content_bound = bool(content_id and content_id == str(url))
                    session_bound = bool(target_media_session and media_session and media_session == target_media_session)
                    active_bound = bool(relay_seen and state in ('PLAYING', 'BUFFERING'))
                    belongs_to_target = request_bound or content_bound or session_bound or active_bound

                    # A direct GET_STATUS can also return the OLD media's final
                    # INTERRUPTED while the new LOAD is taking over.  Until the new
                    # content/session/Relay is actually bound, treat that state as
                    # transition noise even if it came as the reply to our query.
                    if (state == 'IDLE' and idle == 'INTERRUPTED' and
                            not content_bound and not session_bound and
                            time.monotonic() <= transition_grace):
                        if not stale_interrupted_logged:
                            log('Universal Cast: INTERRUPTED da mídia anterior ignorado durante handoff.', 'debug')
                            stale_interrupted_logged = True
                        continue

                    if belongs_to_target:
                        last_state, last_idle = state, idle
                        if media_session and (content_bound or active_bound or
                                (request_bound and not (state == 'IDLE' and idle == 'INTERRUPTED'))):
                            target_media_session = media_session
                        if last_state in ('PLAYING', 'BUFFERING'):
                            active = True
                        elif last_state == 'IDLE' and last_idle in ('ERROR', 'CANCELLED', 'INTERRUPTED'):
                            if last_idle == 'INTERRUPTED' and not (target_media_session or relay_seen) and time.monotonic() <= transition_grace:
                                if not stale_interrupted_logged:
                                    log('Universal Cast: INTERRUPTED transitório ignorado antes da nova mídia ficar ativa.', 'debug')
                                    stale_interrupted_logged = True
                            else:
                                raise RuntimeError('Google Cast encerrou a carga da mídia (%s)' % last_idle)

            if active and relay_seen:
                log('Universal Cast: Google media confirmado (estado=%s; relay_media=sim).' %
                    (last_state or 'ATIVO'), 'debug')
                return True
            time.sleep(0.08)

        if not relay_seen:
            raise TimeoutError('receiver Google Cast não recebeu mídia válida do Relay')
        raise TimeoutError('receiver Google Cast não confirmou reprodução (estado=%s)' % (last_state or 'SEM_STATUS'))


def google_cast_play(device, url, mime, title='ONEPLAY', kind='live', relay_session_id='', handoff=False):
    """Play media through Google Cast.

    Same-receiver handoff keeps the proven V5 path unchanged.  A cold/dormant
    receiver instead gets a bounded stateful wake window: reconnect/status/
    launch/session/media-namespace readiness are retried until the TV is truly
    ready, and LOAD is not sent before that point.
    """
    if handoff:
        # Preserve the V5 handoff timing and behavior that field logs proved.
        last_error = None
        for attempt in range(2):
            try:
                return _google_cast_play_once(
                    device, url, mime, title=title, kind=kind,
                    relay_session_id=relay_session_id, settle_launch=True,
                )
            except (TimeoutError, OSError) as exc:
                last_error = exc
            except RuntimeError as exc:
                text = str(exc or '')
                recoverable = any(marker in text for marker in (
                    'ainda inicializando', 'Default Media Receiver não iniciou',
                    'resposta Google Cast não recebida', 'não confirmou reprodução',
                    'encerrou a carga da mídia (INTERRUPTED)',
                ))
                if not recoverable:
                    raise
                last_error = exc
            if attempt == 0:
                log('Universal Cast: receiver ainda acordando; aguardando estabilização para nova tentativa automática.', 'debug')
                time.sleep(1.35)
        raise last_error or TimeoutError('receiver Google Cast não respondeu')

    wake_deadline = time.monotonic() + _CAST_WAKE_WINDOW
    attempt = 0
    last_error = None
    announced = False
    while True:
        attempt += 1
        try:
            return _google_cast_play_once(
                device, url, mime, title=title, kind=kind,
                relay_session_id=relay_session_id, settle_launch=True,
                strict_wake=True, wake_deadline=wake_deadline,
            )
        except _CastWakePending as exc:
            last_error = exc
        except (OSError, ssl.SSLError) as exc:
            last_error = exc
        # Once LOAD has been sent, media/Relay failures are not wake failures.
        # Let those propagate instead of hiding a bad stream behind 25 s of retries.
        except (TimeoutError, RuntimeError):
            raise

        remaining = wake_deadline - time.monotonic()
        if remaining <= 0.0:
            break
        if not announced:
            log('Universal Cast: receiver ainda acordando; aguardando estado Cast pronto (janela máxima 25s).', 'debug')
            announced = True
        elif attempt in (2, 4, 6):
            log('Universal Cast: wake em andamento; receiver ainda não expôs sessão de mídia estável.', 'debug')
        # Adaptive bounded backoff: fast receivers are not penalized, while a TCL
        # that needs 10-20 s gets enough time without a busy loop.
        delay = min(1.45, 0.55 + (0.18 * min(attempt, 5)))
        time.sleep(min(delay, max(0.05, remaining)))

    detail = str(last_error or '').strip()
    if detail:
        log('Universal Cast: janela de wake esgotada; último estado=%s.' % detail, 'debug')
    raise TimeoutError('receiver Google Cast não ficou pronto após despertar')


def google_cast_stop(device):
    host = _resolve_private_ipv4((device or {}).get('host'))
    if not host:
        return False
    try:
        with _CastChannel(host, int((device or {}).get('port') or _CAST_PORT), timeout=2.0) as channel:
            channel.send('receiver-0', _NS_CONNECTION, _cast_connect_payload())
            rid = channel.next_request()
            channel.send('receiver-0', _NS_RECEIVER, {'type': 'GET_STATUS', 'requestId': rid})
            status = channel.wait_payload('RECEIVER_STATUS', timeout=2.0, request_id=rid)
            app = _receiver_application(status)
            if not app or not app.get('sessionId'):
                return True
            rid = channel.next_request()
            channel.send('receiver-0', _NS_RECEIVER, {'type': 'STOP', 'sessionId': app.get('sessionId'), 'requestId': rid})
            try:
                channel.wait_payload('RECEIVER_STATUS', timeout=2.0, request_id=rid)
            except Exception:
                pass
            return True
    except Exception:
        return False


def _public_device(row):
    row = row if isinstance(row, dict) else {}
    allowed = ('protocol', 'name', 'model', 'host', 'port', 'control_url', 'service_type', 'location', 'uuid')
    return {key: row.get(key) for key in allowed if row.get(key) not in (None, '')}


def load_cast_state():
    data = read_json(_CAST_STATE, {})
    if not isinstance(data, dict) or int(data.get('schema') or 0) != _CAST_STATE_SCHEMA:
        return {}
    return data


def cast_active():
    data = load_cast_state()
    return bool(data.get('relay_session_id') and data.get('device'))


def _save_active(device, relay_session_id, title, kind):
    write_json(_CAST_STATE, {
        'schema': _CAST_STATE_SCHEMA, 'started_at': int(time.time()),
        'device': _public_device(device), 'relay_session_id': str(relay_session_id or ''),
        'title': _safe_label(title, 'ONEPLAY'), 'kind': str(kind or ''),
    })


def start_cast(device, relay_url, relay_session_id, mime, title='ONEPLAY', kind='live'):
    # One external receiver at a time.  If the user is sending a new item to the
    # SAME Google Cast endpoint, keep the already-running Default Media Receiver
    # alive and replace only the media.  Field evidence showed that STOPping the
    # receiver app between attempts made TCL immediately lose the next handshake.
    previous = load_cast_state()
    previous_device = previous.get('device') if isinstance(previous.get('device'), dict) else {}
    protocol = str((device or {}).get('protocol') or '')
    same_google = bool(
        protocol == 'googlecast' and str(previous_device.get('protocol') or '') == 'googlecast' and
        str(previous_device.get('host') or '') == str((device or {}).get('host') or '') and
        int(previous_device.get('port') or _CAST_PORT) == int((device or {}).get('port') or _CAST_PORT)
    )
    old_relay = str(previous.get('relay_session_id') or '') if same_google else ''
    if same_google:
        log('Universal Cast: handoff para o mesmo receiver; mídia anterior preservada até confirmação da nova.', 'debug')
    else:
        stop_active_cast(notify_device=True)
    try:
        if protocol == 'googlecast':
            google_cast_play(
                device, relay_url, mime, title=title, kind=kind, relay_session_id=relay_session_id,
                handoff=same_google,
            )
        elif protocol == 'dlna':
            lg_renderer = is_lg_webos_renderer(device)
            if str(kind or '') == 'live' and str(mime or '').lower() == 'video/mp2t' and lg_renderer:
                _dlna_play_lg_ts(device, relay_url, title=title)
            elif str(kind or '') in ('movie', 'series') and lg_renderer:
                _dlna_play_lg_vod(device, relay_url, mime, title=title)
            else:
                dlna_play(device, relay_url, mime, title=title)
            wait_timeout = _LG_AVT_RELAY_CONFIRM_WINDOW if lg_renderer else 6.0
            if not _wait_relay_media(relay_session_id, timeout=wait_timeout):
                if lg_renderer:
                    activity = relay_session_activity(relay_session_id) or {}
                    log('Universal Cast: LG/webOS sem confirmação do Relay (tipo=%s head=%d get=%d served=%d; janela=%.0fs).' % (
                        str(kind or ''), int(activity.get('head_count') or 0), int(activity.get('get_count') or 0),
                        int(activity.get('served_count') or 0), _LG_AVT_RELAY_CONFIRM_WINDOW), 'debug')
                raise TimeoutError('receiver DLNA não recebeu mídia válida do Relay')
            log('Universal Cast: DLNA confirmado pela primeira resposta de mídia do Relay.', 'debug')
        else:
            raise ValueError('protocolo de transmissão não suportado')
    except Exception:
        if protocol == 'dlna':
            try:
                dlna_stop(device)
            except Exception:
                pass
        release_playback(relay_session_id)
        if same_google and old_relay:
            log('Universal Cast: handoff não confirmado; Relay anterior mantido para evitar corte antecipado.', 'debug')
        raise
    if same_google and old_relay and old_relay != str(relay_session_id or ''):
        try:
            release_playback(old_relay)
        except Exception:
            pass
        log('Universal Cast: handoff confirmado; Relay anterior liberado após nova mídia ativa.', 'debug')
    _save_active(device, relay_session_id, title, kind)
    log('Universal Cast: transmissão iniciada em %s via %s.' % (_safe_label((device or {}).get('name')), protocol), 'info')
    return True


def stop_active_cast(notify_device=True, ui_fast=False):
    data = load_cast_state()
    device = data.get('device') if isinstance(data.get('device'), dict) else {}
    relay_id = str(data.get('relay_session_id') or '')
    protocol = str(device.get('protocol') or '') if device else ''
    stopped = False
    started = time.monotonic()

    # For an explicit UI stop of a DLNA receiver, detach the public cast state
    # first so the ONEPLAY UI becomes responsive immediately and a repeated
    # action cannot re-enter the same session.  Internal handoff/shutdown paths
    # keep the original synchronous ordering.
    if ui_fast and protocol == 'dlna' and data:
        try:
            delete(_CAST_STATE)
        except Exception:
            pass

    if notify_device and device:
        if protocol == 'googlecast':
            stopped = google_cast_stop(device)
        elif protocol == 'dlna':
            stopped = dlna_stop(device, fast=bool(ui_fast))
    if relay_id:
        try:
            release_playback(relay_id, timeout=0.35 if ui_fast and protocol == 'dlna' else 0.7)
        except Exception:
            pass
    if not (ui_fast and protocol == 'dlna'):
        delete(_CAST_STATE)
    if data:
        elapsed_ms = int(max(0.0, time.monotonic() - started) * 1000.0)
        if ui_fast and protocol == 'dlna':
            log('Universal Cast: STOP DLNA rápido concluído em %dms (one-way=%s).' % (elapsed_ms, 'sim' if stopped else 'não'), 'debug')
        log('Universal Cast: sessão externa encerrada%s.' % (' e receiver notificado' if stopped else ''), 'debug')
    return bool(data)
