# -*- coding: utf-8 -*-
"""Credential-safe local/LAN media relay for ONEPLAY IBO.

Security and transport contract:
- Kodi/VideoPlayer sees only opaque Relay URLs; when a private LAN IPv4 is
  available the media URL uses that device IP so a cast receiver can fetch it.
- If no safe LAN IPv4 is discovered, media URLs fall back to 127.0.0.1.
- Control/register/release requests remain restricted to loopback.
- Xtream credentials/upstream URLs live only in Python memory.
- Redirects are followed inside the relay and never exposed to Kodi.
- HLS manifests are recursively rewritten (variants, segments, keys, maps, media).
- VOD/TS is streamed incrementally; Range/206 is passed through.
- HEAD/Stat is answered locally and never blocks on an upstream server.
- Stop scrubs upstream URLs/credentials immediately but leaves a short metadata
  tombstone so Kodi's post-stop CSaveFileState::Stat returns instantly.
"""
import http.client
import http.cookiejar
import json
import os
import re
import secrets
import socket
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

try:
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
except ImportError:  # pragma: no cover
    BaseHTTPRequestHandler = None
    ThreadingHTTPServer = None

from .constants import XTREAM_USER_AGENT
from .log import log
from .network_security import HTTPOnlyRedirect
from .storage import delete, read_json, state_path, write_json

_RELAY_STATE = state_path('media_relay_v1.json')
_RELAY_VERSION = 5
_CONTROL_PATH = '/_ibo/register'
_RELEASE_PATH = '/_ibo/release'
_STATUS_PATH = '/_ibo/status'
_MAX_CONTROL_BODY = 64 * 1024
_MAX_MANIFEST_BYTES = 2 * 1024 * 1024
_COPY_CHUNK = 128 * 1024
_LIVE_TS_COPY_CHUNK = 16 * 1024
_RESOURCE_COPY_CHUNK = 64 * 1024
_VOD_RESUME_ATTEMPTS = 2

# Live TS Guard V1: keep the LG-facing HTTP body continuous while finite or
# transient upstream TS connections are replaced internally. No transcoding,
# timestamp/PCR rewriting or permanent latency buffer is introduced.
_LIVE_TS_PACKET_SIZE = 188
_LIVE_TS_SYNC_MIN_PACKETS = 5
_LIVE_TS_SYNC_PROBE_MAX = 4 * 1024
_LIVE_TS_RECONNECT_ATTEMPTS = 3
_LIVE_TS_RECONNECT_TIMEOUT = 4.0
_LIVE_TS_RECONNECT_BACKOFFS = (0.15, 0.35, 0.75)
_LIVE_TS_PSI_GATE_MAX = 512 * 1024
_LIVE_TS_PSI_GATE_TIMEOUT = 1.25

_FASTSTART_MAX_MOOV = 8 * 1024 * 1024
_FASTSTART_PREP_TIMEOUT = 4.0
_ENTRY_TTL = 6 * 60 * 60
_RELEASE_TOMBSTONE_TTL = 45.0
_MAX_ENTRIES = 8192
_URI_QUOTED_RE = re.compile(r'(?i)(URI\s*=\s*)(["\'])(.*?)(\2)')
_URI_BARE_RE = re.compile(r'(?i)(URI\s*=\s*)([^,\s]+)')



def _ts_packet_pid(packet):
    data = bytes(packet or b'')
    if len(data) != _LIVE_TS_PACKET_SIZE or data[0] != 0x47:
        return -1
    return ((data[1] & 0x1F) << 8) | data[2]


def _ts_payload_offset(packet):
    data = bytes(packet or b'')
    if len(data) != _LIVE_TS_PACKET_SIZE or data[0] != 0x47:
        return None
    adaptation = (data[3] >> 4) & 0x03
    if adaptation in (0, 2):
        return None
    offset = 4
    if adaptation == 3:
        if offset >= len(data):
            return None
        offset = 5 + int(data[4])
    if offset < 4 or offset >= len(data):
        return None
    return offset


def _ts_section_start(packet, expected_table_id=None):
    data = bytes(packet or b'')
    if len(data) != _LIVE_TS_PACKET_SIZE or data[0] != 0x47 or not (data[1] & 0x40):
        return None
    offset = _ts_payload_offset(data)
    if offset is None or offset >= len(data):
        return None
    pointer = int(data[offset])
    start = offset + 1 + pointer
    if start + 3 > len(data):
        return None
    if expected_table_id is not None and int(data[start]) != int(expected_table_id):
        return None
    section_length = ((data[start + 1] & 0x0F) << 8) | data[start + 2]
    end = start + 3 + int(section_length)
    if end > len(data) or section_length < 4:
        # Conservative parser: never reconstruct a PSI section spanning packets.
        return None
    return start, end


def _ts_pat_pmt_pids(packet):
    if _ts_packet_pid(packet) != 0:
        return set()
    span = _ts_section_start(packet, 0x00)
    if not span:
        return set()
    data = bytes(packet)
    start, end = span
    # PAT fixed header is 8 bytes from table_id through last_section_number;
    # final four section bytes are CRC32. Each program record is four bytes.
    cursor = start + 8
    limit = max(cursor, end - 4)
    result = set()
    while cursor + 4 <= limit:
        program = (data[cursor] << 8) | data[cursor + 1]
        pid = ((data[cursor + 2] & 0x1F) << 8) | data[cursor + 3]
        if program != 0 and 0 <= pid <= 0x1FFE:
            result.add(pid)
        cursor += 4
    return result


def _ts_is_pmt_packet(packet, pmt_pids):
    pid = _ts_packet_pid(packet)
    if pid < 0 or pid not in set(pmt_pids or ()):
        return False
    return bool(_ts_section_start(packet, 0x02))


def _ts_find_sync_offset(data):
    raw = bytes(data or b'')
    needed = _LIVE_TS_PACKET_SIZE * _LIVE_TS_SYNC_MIN_PACKETS
    if len(raw) < needed:
        return None
    max_offset = min(_LIVE_TS_PACKET_SIZE - 1, max(0, len(raw) - needed))
    for offset in range(max_offset + 1):
        ok = True
        for index in range(_LIVE_TS_SYNC_MIN_PACKETS):
            pos = offset + index * _LIVE_TS_PACKET_SIZE
            if pos >= len(raw) or raw[pos] != 0x47:
                ok = False
                break
        if ok:
            return offset
    return None


class _LiveTSFramer(object):
    """Conservative 188-byte TS alignment with raw fallback."""
    def __init__(self):
        self.buffer = bytearray()
        self.mode = 'unknown'
        self.discarded = 0

    def feed(self, data):
        raw = bytes(data or b'')
        if not raw:
            return b''
        if self.mode == 'raw':
            return raw
        self.buffer.extend(raw)
        if self.mode == 'unknown':
            offset = _ts_find_sync_offset(self.buffer)
            if offset is None:
                if len(self.buffer) < _LIVE_TS_SYNC_PROBE_MAX:
                    return b''
                self.mode = 'raw'
                out = bytes(self.buffer)
                self.buffer.clear()
                return out
            if offset:
                del self.buffer[:offset]
                self.discarded += int(offset)
            self.mode = 'ts188'
        complete = (len(self.buffer) // _LIVE_TS_PACKET_SIZE) * _LIVE_TS_PACKET_SIZE
        if complete <= 0:
            return b''
        out = bytes(self.buffer[:complete])
        del self.buffer[:complete]
        return out

    def finish(self):
        if self.mode == 'unknown' and self.buffer:
            self.mode = 'raw'
            out = bytes(self.buffer)
            self.buffer.clear()
            return out
        # In proven TS mode an incomplete tail is deliberately dropped; forwarding
        # half a packet across a reconnect is worse than losing at most 187 bytes.
        if self.mode == 'raw' and self.buffer:
            out = bytes(self.buffer)
            self.buffer.clear()
            return out
        self.buffer.clear()
        return b''


class _LiveTSPsiGate(object):
    """After reconnect, prefer restarting output at a fresh PAT+PMT boundary."""
    def __init__(self):
        self.buffer = bytearray()
        self.started = time.monotonic()
        self.pat_offset = None
        self.pmt_pids = set()

    def feed(self, data):
        raw = bytes(data or b'')
        if raw:
            self.buffer.extend(raw)
        limit = (len(self.buffer) // _LIVE_TS_PACKET_SIZE) * _LIVE_TS_PACKET_SIZE
        if limit > 0:
            for offset in range(0, limit, _LIVE_TS_PACKET_SIZE):
                packet = self.buffer[offset:offset + _LIVE_TS_PACKET_SIZE]
                if self.pat_offset is None:
                    pids = _ts_pat_pmt_pids(packet)
                    if pids:
                        self.pat_offset = offset
                        self.pmt_pids = set(pids)
                        continue
                elif offset >= self.pat_offset and _ts_is_pmt_packet(packet, self.pmt_pids):
                    out = bytes(self.buffer[self.pat_offset:limit])
                    self.buffer.clear()
                    return out, True, 'pat+pmt'
        expired = (time.monotonic() - self.started) >= _LIVE_TS_PSI_GATE_TIMEOUT
        overflow = len(self.buffer) >= _LIVE_TS_PSI_GATE_MAX
        if expired or overflow:
            start = int(self.pat_offset or 0)
            out = bytes(self.buffer[start:limit]) if limit > start else b''
            # preserve only an incomplete packet tail for the caller to append later
            tail = bytes(self.buffer[limit:])
            self.buffer.clear()
            self.buffer.extend(tail)
            return out, True, 'pat' if self.pat_offset is not None else 'fallback'
        return b'', False, 'aguardando'

    def finish(self):
        limit = (len(self.buffer) // _LIVE_TS_PACKET_SIZE) * _LIVE_TS_PACKET_SIZE
        start = int(self.pat_offset or 0)
        out = bytes(self.buffer[start:limit]) if limit > start else b''
        self.buffer.clear()
        return out, ('pat' if self.pat_offset is not None else 'fallback')


def _is_private_lan_ipv4(value):
    """Accept RFC1918/CGNAT IPv4 only; never advertise loopback/public addresses."""
    raw = str(value or '').strip()
    try:
        packed = socket.inet_aton(raw)
        if len(packed) != 4:
            return False
        parts = [int(x) for x in raw.split('.')]
        if len(parts) != 4 or any(x < 0 or x > 255 for x in parts):
            return False
    except Exception:
        return False
    a, b, _c, _d = parts
    return bool(
        a == 10 or
        (a == 172 and 16 <= b <= 31) or
        (a == 192 and b == 168) or
        (a == 100 and 64 <= b <= 127)
    )


def _discover_lan_ipv4():
    """Best-effort device LAN IPv4 discovery with conservative private-only output."""
    candidates = []
    probe = None
    try:
        # UDP connect selects the active route without sending application data.
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.settimeout(0.25)
        probe.connect(('8.8.8.8', 80))
        candidates.append(str(probe.getsockname()[0] or ''))
    except Exception:
        pass
    finally:
        try:
            if probe is not None:
                probe.close()
        except Exception:
            pass
    try:
        _name, _aliases, addresses = socket.gethostbyname_ex(socket.gethostname())
        candidates.extend(addresses or [])
    except Exception:
        pass
    for candidate in candidates:
        if _is_private_lan_ipv4(candidate):
            return str(candidate)
    return ''


def _safe_relay_host(value):
    raw = str(value or '').strip()
    if raw == '127.0.0.1' or _is_private_lan_ipv4(raw):
        return raw
    return '127.0.0.1'


def _safe_kind(value):
    kind = str(value or '').strip().lower()
    return kind if kind in ('live', 'movie', 'series', 'hls', 'resource') else 'resource'


def _valid_upstream(url):
    try:
        parsed = urllib.parse.urlparse(str(url or '').strip())
    except Exception:
        return False
    return parsed.scheme in ('http', 'https') and bool(parsed.netloc)


def _suffix_for(url, kind=''):
    try:
        path = (urllib.parse.urlparse(str(url or '')).path or '').lower()
    except Exception:
        path = ''
    for suffix in ('.m3u8', '.mp4', '.mkv', '.ts', '.m4s', '.aac', '.key', '.vtt', '.webvtt'):
        if path.endswith(suffix):
            return suffix
    if str(kind) == 'live':
        return '.m3u8'
    if str(kind) in ('movie', 'series'):
        return '.mp4'
    return '.bin'


def _mime_for(url='', kind=''):
    suffix = _suffix_for(url, kind)
    return {
        '.m3u8': 'application/vnd.apple.mpegurl',
        '.mp4': 'video/mp4',
        '.mkv': 'video/x-matroska',
        '.ts': 'video/mp2t',
        '.m4s': 'video/iso.segment',
        '.aac': 'audio/aac',
        '.vtt': 'text/vtt',
        '.webvtt': 'text/vtt',
        '.key': 'application/octet-stream',
    }.get(suffix, 'application/octet-stream')


def _blob_box_header(buf, offset, limit):
    """Parse one ISO BMFF box from an in-memory byte buffer."""
    offset = int(offset)
    limit = int(limit)
    if offset < 0 or offset + 8 > limit:
        return None
    size32 = int.from_bytes(buf[offset:offset + 4], 'big')
    btype = bytes(buf[offset + 4:offset + 8])
    header = 8
    if size32 == 1:
        if offset + 16 > limit:
            return None
        size = int.from_bytes(buf[offset + 8:offset + 16], 'big')
        header = 16
    elif size32 == 0:
        size = limit - offset
    else:
        size = int(size32)
    if size < header or offset + size > limit:
        return None
    return {'type': btype, 'offset': offset, 'size': size, 'header': header, 'end': offset + size}


def _patch_moov_chunk_offsets(raw_moov, delta):
    """Return a moov relocated by ``delta`` with stco/co64 offsets adjusted.

    This is intentionally narrower than a general MP4 rewriter.  V21 only
    accepts classic non-fragmented files whose media lives in one contiguous
    mdat immediately before the final moov.  In that shape, relocating moov
    before mdat shifts every media chunk by exactly ``delta == moov_size``.
    """
    buf = bytearray(raw_moov or b'')
    root = _blob_box_header(buf, 0, len(buf))
    if not root or root.get('type') != b'moov' or int(root.get('end') or 0) != len(buf):
        raise ValueError('moov inválido')
    containers = {b'moov', b'trak', b'mdia', b'minf', b'stbl', b'edts', b'dinf'}
    stats = {'stco': 0, 'co64': 0}

    def walk(start, end, depth=0):
        if depth > 12:
            raise ValueError('profundidade MP4 excessiva')
        pos = int(start)
        end = int(end)
        boxes = 0
        while pos + 8 <= end:
            box = _blob_box_header(buf, pos, end)
            if not box:
                raise ValueError('box MP4 truncado')
            boxes += 1
            if boxes > 256:
                raise ValueError('boxes MP4 excessivos')
            btype = box['type']
            payload = int(box['offset']) + int(box['header'])
            bend = int(box['end'])
            if btype == b'stco':
                if payload + 8 > bend:
                    raise ValueError('stco truncado')
                count = int.from_bytes(buf[payload + 4:payload + 8], 'big')
                cursor = payload + 8
                if count < 1 or cursor + count * 4 > bend:
                    raise ValueError('stco inválido')
                for _idx in range(count):
                    old = int.from_bytes(buf[cursor:cursor + 4], 'big')
                    new = int(old) + int(delta)
                    if new < 0 or new > 0xffffffff:
                        raise OverflowError('stco excede 32 bits')
                    buf[cursor:cursor + 4] = int(new).to_bytes(4, 'big')
                    cursor += 4
                    stats['stco'] += 1
            elif btype == b'co64':
                if payload + 8 > bend:
                    raise ValueError('co64 truncado')
                count = int.from_bytes(buf[payload + 4:payload + 8], 'big')
                cursor = payload + 8
                if count < 1 or cursor + count * 8 > bend:
                    raise ValueError('co64 inválido')
                for _idx in range(count):
                    old = int.from_bytes(buf[cursor:cursor + 8], 'big')
                    new = int(old) + int(delta)
                    if new < 0 or new > 0xffffffffffffffff:
                        raise OverflowError('co64 excede 64 bits')
                    buf[cursor:cursor + 8] = int(new).to_bytes(8, 'big')
                    cursor += 8
                    stats['co64'] += 1
            elif btype in containers:
                walk(payload, bend, depth + 1)
            pos = bend
        if pos != end:
            raise ValueError('alinhamento MP4 inválido')

    walk(int(root['header']), int(root['end']), 0)
    if int(stats['stco']) + int(stats['co64']) <= 0:
        raise ValueError('moov sem tabela de chunks')
    return bytes(buf), stats


def _validate_faststart_prefix(raw, mdat_offset, moov_offset):
    """Re-prove inert prefix boxes and one mdat ending exactly at moov."""
    buf = bytes(raw or b'')
    mdat_offset = int(mdat_offset)
    moov_offset = int(moov_offset)
    if mdat_offset <= 0 or len(buf) < mdat_offset + 8:
        raise ValueError('prefixo MP4 insuficiente')
    pos = 0
    while pos < mdat_offset:
        box = _blob_box_header(buf, pos, len(buf))
        if not box or int(box['end']) > mdat_offset:
            raise ValueError('prefixo MP4 inválido')
        if box.get('type') not in (b'ftyp', b'free', b'skip', b'wide'):
            raise ValueError('box de prefixo não permitido')
        pos = int(box['end'])
    if pos != mdat_offset:
        raise ValueError('mdat desalinhado')
    if len(buf) < mdat_offset + 16:
        raise ValueError('header mdat incompleto')
    size32 = int.from_bytes(buf[mdat_offset:mdat_offset + 4], 'big')
    btype = bytes(buf[mdat_offset + 4:mdat_offset + 8])
    if btype != b'mdat':
        raise ValueError('mdat ausente')
    if size32 == 1:
        mdat_size = int.from_bytes(buf[mdat_offset + 8:mdat_offset + 16], 'big')
        header = 16
    elif size32 == 0:
        raise ValueError('mdat aberto não elegível')
    else:
        mdat_size = int(size32)
        header = 8
    if mdat_size < header or mdat_offset + mdat_size != moov_offset:
        raise ValueError('mdat não termina no moov')
    return True


def _prepare_faststart_metadata(context, url, kind, metadata):
    """Prepare a bounded virtual-faststart plan, otherwise return V20 metadata.

    No media payload is downloaded here: only the final moov (<=8 MiB).  The
    source has already been structurally proven by the V19/V20 probe; this
    second validation deliberately re-checks all offsets inside the Relay
    process before enabling the virtual representation.
    """
    source = dict(metadata or {})
    if not (source.get('lg_faststart_candidate') and kind in ('movie', 'series')
            and str(source.get('content_type') or '').lower() == 'video/mp4'):
        return source
    try:
        total = int(source.get('content_length') or 0)
        moov_offset = int(source.get('moov_offset') or 0)
        moov_size = int(source.get('moov_size') or 0)
        mdat_offset = int(source.get('mdat_offset') or 0)
        if not (total > 0 and 0 < mdat_offset <= (192 * 1024) and moov_offset > mdat_offset and
                8 <= moov_size <= _FASTSTART_MAX_MOOV and moov_offset + moov_size == total):
            raise ValueError('geometria não elegível')
        # Re-check the beginning independently inside Relay: only inert
        # branding/padding boxes may precede one mdat whose declared end is
        # exactly the final moov offset.
        prefix_response = None
        try:
            prefix_end = mdat_offset + 15
            prefix_response = context.open_upstream(
                url, method='GET', headers={'Range': 'bytes=0-%d' % int(prefix_end)},
                timeout=_FASTSTART_PREP_TIMEOUT,
            )
            pstatus = int(getattr(prefix_response, 'status', prefix_response.getcode()) or 0)
            pcr = str(prefix_response.headers.get('Content-Range') or '').strip()
            pmatch = re.match(r'(?i)^bytes\s+(\d+)-(\d+)/(\d+)$', pcr)
            if not (pstatus == 206 and pmatch and int(pmatch.group(1)) == 0 and
                    int(pmatch.group(2)) == prefix_end and int(pmatch.group(3)) == total):
                raise ValueError('Range do prefixo não é exato')
            prefix = prefix_response.read(prefix_end + 2) or b''
            if len(prefix) != prefix_end + 1:
                raise ValueError('prefixo incompleto')
            _validate_faststart_prefix(prefix, mdat_offset, moov_offset)
        finally:
            try:
                if prefix_response is not None:
                    prefix_response.close()
            except Exception:
                pass

        response = None
        try:
            response = context.open_upstream(
                url, method='GET', headers={'Range': 'bytes=%d-%d' % (moov_offset, total - 1)},
                timeout=_FASTSTART_PREP_TIMEOUT,
            )
            status = int(getattr(response, 'status', response.getcode()) or 0)
            content_range = str(response.headers.get('Content-Range') or '').strip()
            match = re.match(r'(?i)^bytes\s+(\d+)-(\d+)/(\d+)$', content_range)
            if not (status == 206 and match and int(match.group(1)) == moov_offset and
                    int(match.group(2)) == total - 1 and int(match.group(3)) == total):
                raise ValueError('Range do moov não é exato')
            raw_moov = response.read(moov_size + 1) or b''
            if len(raw_moov) != moov_size:
                raise ValueError('moov incompleto')
        finally:
            try:
                if response is not None:
                    response.close()
            except Exception:
                pass
        patched, stats = _patch_moov_chunk_offsets(raw_moov, moov_size)
        source['_faststart_enabled'] = True
        source['_faststart_moov'] = patched
        source['_faststart_patch_entries'] = int(stats.get('stco') or 0) + int(stats.get('co64') or 0)
        log(
            'Relay V5 LG VOD: faststart virtual preparado (moov=%d bytes, chunks=%d).' % (
                int(moov_size), int(source['_faststart_patch_entries'])
            ),
            'debug',
        )
    except Exception as exc:
        source.pop('_faststart_enabled', None)
        source.pop('_faststart_moov', None)
        source.pop('_faststart_patch_entries', None)
        log('Relay V5 LG VOD: faststart virtual indisponível (%s); preservando V20.' % exc.__class__.__name__, 'debug')
    return source


def _parse_http_byte_range(value, total):
    """Parse one RFC7233-style bytes range. Return (status,start,end)."""
    total = int(total or 0)
    if total <= 0:
        return None
    raw = str(value or '').strip()
    if not raw:
        return 200, 0, total - 1
    match = re.match(r'(?i)^bytes=(\d*)-(\d*)$', raw)
    if not match:
        return None
    left, right = match.group(1), match.group(2)
    if left:
        start = int(left)
        end = int(right) if right else total - 1
        if start >= total or end < start:
            return None
        end = min(end, total - 1)
        return 206, start, end
    if right:
        count = int(right)
        if count <= 0:
            return None
        count = min(count, total)
        return 206, total - count, total - 1
    return None


class _Registry(object):
    def __init__(self, port, media_host='127.0.0.1'):
        self.port = int(port)
        self.media_host = _safe_relay_host(media_host)
        self._lock = threading.RLock()
        self._entries = {}
        self._reverse = {}

    def _drop_locked(self, token):
        row = self._entries.pop(token, None)
        if not row:
            return
        key = row.get('reverse_key')
        if key and self._reverse.get(key) == token:
            self._reverse.pop(key, None)

    def _cleanup_locked(self):
        now = time.monotonic()
        expired = []
        for token, row in self._entries.items():
            released_at = float(row.get('released_at') or 0.0)
            if released_at:
                if now - released_at > _RELEASE_TOMBSTONE_TTL:
                    expired.append(token)
            elif now - float(row.get('last') or row.get('created') or now) > _ENTRY_TTL:
                expired.append(token)
        for token in expired:
            self._drop_locked(token)
        overflow = len(self._entries) - _MAX_ENTRIES
        if overflow > 0:
            victims = sorted(self._entries.items(), key=lambda item: float(item[1].get('last') or 0.0))[:overflow]
            for token, _row in victims:
                self._drop_locked(token)

    def add(self, url, kind='resource', session_id='', root=False, metadata=None):
        url = str(url or '').strip()
        if not _valid_upstream(url):
            raise ValueError('upstream inválido')
        kind = _safe_kind(kind)
        metadata = metadata if isinstance(metadata, dict) else {}
        initial_type = str(metadata.get('content_type') or '').strip().lower()
        if initial_type not in ('video/mp4', 'video/x-matroska', 'video/mp2t'):
            initial_type = ''
        try:
            initial_length = int(metadata.get('content_length') or 0)
        except Exception:
            initial_length = 0
        if initial_length <= 0 or initial_length > (100 * 1024 * 1024 * 1024 * 1024):
            initial_length = 0
        initial_ranges = 'bytes' if str(metadata.get('accept_ranges') or '').strip().lower() == 'bytes' else ''
        lg_vod_proxy = bool(metadata.get('lg_vod_proxy')) and kind in ('movie', 'series')
        faststart_enabled = bool(metadata.get('_faststart_enabled')) and lg_vod_proxy and initial_type == 'video/mp4'
        faststart_moov = metadata.get('_faststart_moov') if faststart_enabled else b''
        if not isinstance(faststart_moov, (bytes, bytearray)):
            faststart_moov = b''
            faststart_enabled = False
        faststart_moov = bytes(faststart_moov)
        try:
            faststart_moov_offset = int(metadata.get('moov_offset') or 0)
            faststart_moov_size = int(metadata.get('moov_size') or 0)
            faststart_mdat_offset = int(metadata.get('mdat_offset') or 0)
            faststart_patch_entries = int(metadata.get('_faststart_patch_entries') or 0)
        except Exception:
            faststart_enabled = False
            faststart_moov_offset = faststart_moov_size = faststart_mdat_offset = faststart_patch_entries = 0
        if not (faststart_enabled and faststart_moov_size == len(faststart_moov) and
                faststart_mdat_offset > 0 and faststart_moov_offset > faststart_mdat_offset and
                faststart_moov_offset + faststart_moov_size == initial_length and faststart_patch_entries > 0):
            faststart_enabled = False
            faststart_moov = b''
        session_id = str(session_id or '').strip() or secrets.token_urlsafe(24)
        reverse_key = '%s\n%s\n%s' % (session_id, kind, url)
        now = time.monotonic()
        with self._lock:
            self._cleanup_locked()
            existing = self._reverse.get(reverse_key)
            if existing and existing in self._entries and not self._entries[existing].get('released_at'):
                row = self._entries[existing]
                row['last'] = now
                if initial_type:
                    row['content_type'] = initial_type
                if initial_length:
                    row['content_length'] = str(initial_length)
                if initial_ranges:
                    row['accept_ranges'] = initial_ranges
                if lg_vod_proxy:
                    row['lg_vod_proxy'] = True
                if faststart_enabled:
                    row['faststart_enabled'] = True
                    row['faststart_moov'] = faststart_moov
                    row['faststart_moov_offset'] = faststart_moov_offset
                    row['faststart_moov_size'] = faststart_moov_size
                    row['faststart_mdat_offset'] = faststart_mdat_offset
                    row['faststart_patch_entries'] = faststart_patch_entries
                return existing, session_id
            token = secrets.token_urlsafe(32)
            self._entries[token] = {
                'url': url,
                'kind': kind,
                'session_id': session_id,
                'root': bool(root),
                'created': now,
                'last': now,
                'released_at': 0.0,
                'reverse_key': reverse_key,
                'suffix': _suffix_for(url, kind),
                'content_type': initial_type or _mime_for(url, kind),
                'content_length': str(initial_length) if initial_length else '',
                'accept_ranges': initial_ranges or ('bytes' if kind in ('movie', 'series') else ''),
                'lg_vod_proxy': bool(lg_vod_proxy),
                'faststart_enabled': bool(faststart_enabled),
                'faststart_moov': faststart_moov if faststart_enabled else b'',
                'faststart_moov_offset': faststart_moov_offset if faststart_enabled else 0,
                'faststart_moov_size': faststart_moov_size if faststart_enabled else 0,
                'faststart_mdat_offset': faststart_mdat_offset if faststart_enabled else 0,
                'faststart_patch_entries': faststart_patch_entries if faststart_enabled else 0,
                'etag': '',
                'last_modified': '',
                'head_count': 0,
                'get_count': 0,
                'served_count': 0,
                'last_access': 0.0,
            }
            self._reverse[reverse_key] = token
            self._cleanup_locked()
            return token, session_id

    def get(self, token):
        with self._lock:
            self._cleanup_locked()
            row = self._entries.get(str(token or ''))
            if not row:
                return None
            row['last'] = time.monotonic()
            return dict(row)

    def token_active(self, token):
        token = str(token or '').strip()
        if not token:
            return False
        with self._lock:
            row = self._entries.get(token)
            return bool(row and not row.get('released_at') and row.get('url'))

    def mark_access(self, token, method):
        """Record anonymous Relay reachability without storing client identity.

        Cast verification only needs proof that the opaque media handle was
        fetched.  No remote IP, URL, token or credential is persisted here.
        """
        method = str(method or '').upper()
        if method not in ('GET', 'HEAD'):
            return False
        with self._lock:
            row = self._entries.get(str(token or ''))
            if not row or row.get('released_at') or not row.get('url'):
                return False
            key = 'get_count' if method == 'GET' else 'head_count'
            row[key] = int(row.get(key) or 0) + 1
            now = time.monotonic()
            row['last_access'] = now
            row['last'] = now
            return True

    def mark_served(self, token):
        """Record that upstream media was accepted and a response began downstream."""
        with self._lock:
            row = self._entries.get(str(token or ''))
            if not row or row.get('released_at') or not row.get('url'):
                return False
            row['served_count'] = int(row.get('served_count') or 0) + 1
            now = time.monotonic()
            row['last_access'] = now
            row['last'] = now
            return True

    def session_status(self, session_id):
        """Return non-secret aggregate access counters for one Relay session."""
        session_id = str(session_id or '').strip()
        if not session_id:
            return {'found': False, 'get_count': 0, 'head_count': 0, 'served_count': 0, 'released': False}
        found = False
        released = True
        get_count = 0
        head_count = 0
        served_count = 0
        with self._lock:
            self._cleanup_locked()
            for row in self._entries.values():
                if row.get('session_id') != session_id:
                    continue
                found = True
                get_count += int(row.get('get_count') or 0)
                head_count += int(row.get('head_count') or 0)
                served_count += int(row.get('served_count') or 0)
                if not row.get('released_at') and row.get('url'):
                    released = False
        return {
            'found': bool(found),
            'get_count': int(get_count),
            'head_count': int(head_count),
            'served_count': int(served_count),
            'released': bool(found and released),
        }

    def update_meta(self, token, headers):
        with self._lock:
            row = self._entries.get(str(token or ''))
            if not row:
                return
            content_type = str(headers.get('Content-Type') or headers.get('content-type') or '').strip()
            content_length = str(headers.get('Content-Length') or headers.get('content-length') or '').strip()
            content_range = str(headers.get('Content-Range') or headers.get('content-range') or '').strip()
            accept_ranges = str(headers.get('Accept-Ranges') or headers.get('accept-ranges') or '').strip()
            etag = str(headers.get('ETag') or headers.get('etag') or '').strip()
            last_modified = str(headers.get('Last-Modified') or headers.get('last-modified') or '').strip()
            direct_live_ts = bool(
                row.get('kind') == 'live' and str(row.get('suffix') or '').lower() == '.ts'
            )
            if content_type and not direct_live_ts:
                row['content_type'] = content_type
            elif direct_live_ts:
                row['content_type'] = 'video/mp2t'
            # Em resposta 206, Content-Length é somente o pedaço solicitado.
            # Para o HEAD sintético/Stat do Kodi precisamos guardar o tamanho
            # TOTAL indicado por Content-Range, nunca o tamanho parcial.
            total_length = ''
            match = re.search(r'/\s*(\d+)\s*$', content_range) if content_range else None
            if match:
                total_length = match.group(1)
            elif content_length.isdigit():
                total_length = content_length
            if total_length.isdigit() and not direct_live_ts:
                row['content_length'] = total_length
            if accept_ranges and not direct_live_ts:
                row['accept_ranges'] = accept_ranges
            if direct_live_ts:
                row['content_length'] = ''
                row['accept_ranges'] = ''
            if etag:
                row['etag'] = etag
            if last_modified:
                row['last_modified'] = last_modified
            row['last'] = time.monotonic()

    def retire_token(self, token):
        """Make one media handle terminal without releasing sibling resources.

        Used for a direct Live TS root after its upstream transport has ended or
        timed out. Kodi may retry a transient curl error automatically; a retired
        handle answers 410 immediately instead of reopening the same stalled
        provider connection for another 20 s retry cycle.
        """
        token = str(token or '').strip()
        if not token:
            return False
        now = time.monotonic()
        with self._lock:
            row = self._entries.get(token)
            if not row:
                return False
            key = row.get('reverse_key')
            if key and self._reverse.get(key) == token:
                self._reverse.pop(key, None)
            row['url'] = ''
            row['reverse_key'] = ''
            row['faststart_moov'] = b''
            row['faststart_enabled'] = False
            row['released_at'] = now
            row['last'] = now
            self._cleanup_locked()
            return True

    def release_session(self, session_id):
        """Scrub secrets now; retain only non-secret metadata briefly for HEAD/Stat."""
        session_id = str(session_id or '').strip()
        if not session_id:
            return 0
        now = time.monotonic()
        count = 0
        with self._lock:
            for token, row in self._entries.items():
                if row.get('session_id') != session_id:
                    continue
                key = row.get('reverse_key')
                if key and self._reverse.get(key) == token:
                    self._reverse.pop(key, None)
                # Critical: credential-bearing upstream URL leaves memory now.
                row['url'] = ''
                row['reverse_key'] = ''
                row['faststart_moov'] = b''
                row['faststart_enabled'] = False
                row['released_at'] = now
                row['last'] = now
                count += 1
            self._cleanup_locked()
        return count

    def local_url(self, token, upstream_url='', kind=''):
        return 'http://%s:%d/v1/%s/stream%s' % (
            self.media_host, self.port, str(token), _suffix_for(upstream_url, kind)
        )

    def clear(self):
        with self._lock:
            self._entries.clear()
            self._reverse.clear()


class _RelayContext(object):
    def __init__(self, port, control_token, media_host='127.0.0.1'):
        self.port = int(port)
        self.control_token = str(control_token)
        self.media_host = _safe_relay_host(media_host)
        self.registry = _Registry(port, self.media_host)
        self.cookie_jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.cookie_jar), HTTPOnlyRedirect())

    def open_upstream(self, url, method='GET', headers=None, timeout=20.0):
        hdr = {
            'User-Agent': XTREAM_USER_AGENT,
            'Accept': '*/*',
            'Accept-Encoding': 'identity',
            'Connection': 'close',
        }
        for key, value in (headers or {}).items():
            if value:
                hdr[str(key)] = str(value)
        req = urllib.request.Request(str(url), headers=hdr, method=str(method or 'GET').upper())
        # Não serialize a abertura upstream: FFmpeg/HLS faz requisições paralelas
        # de playlists/segmentos e o lock antigo transformava latência de rede em
        # fila, produzindo stalls/watchdog no aparelho real. CookieJar já protege
        # sua estrutura interna com RLock no CPython; o opener/redirect handlers
        # são usados sem estado por requisição.
        return self.opener.open(req, timeout=max(3.0, float(timeout or 0.0)))


class _RelayHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    # HLS/FFmpeg can open several loopback connections at once. A larger listen
    # backlog prevents metadata/HEAD requests from sitting behind media bursts.
    request_queue_size = 64
    block_on_close = False

    def __init__(self, *args, **kwargs):
        self._connection_slots = threading.BoundedSemaphore(32)
        super().__init__(*args, **kwargs)

    def verify_request(self, request, client_address):
        host = str(client_address[0])
        return host == '127.0.0.1' or _is_private_lan_ipv4(host)

    def get_request(self):
        request, address = super().get_request()
        # Bound idle headers, partial control bodies and stalled downstreams.
        request.settimeout(15.0)
        return request, address

    def process_request(self, request, client_address):
        if not self._connection_slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self._connection_slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._connection_slots.release()

    def handle_error(self, request, client_address):
        # Kodi routinely closes loopback sockets while stopping/seeking. Those
        # aborts are normal lifecycle, not add-on failures, and must not flood log.
        exc = sys.exc_info()[1]
        if isinstance(exc, (ConnectionResetError, ConnectionAbortedError, BrokenPipeError, socket.timeout)):
            return
        try:
            super(_RelayHTTPServer, self).handle_error(request, client_address)
        except Exception:
            pass


class _RelayHandler(BaseHTTPRequestHandler):
    # One request per local TCP connection. This deliberately avoids HTTP/1.1
    # keep-alive wait states that previously delayed Stop and generated Win10054.
    protocol_version = 'HTTP/1.0'
    server_version = 'IBORelay/5'
    sys_version = ''
    # Small loopback metadata replies should leave immediately.
    wbufsize = 0
    disable_nagle_algorithm = True

    def log_message(self, _format, *args):
        return

    @property
    def context(self):
        return self.server.relay_context

    def _begin(self, status, content_type='text/plain; charset=utf-8', content_length=None, extra=None):
        self.close_connection = True
        self.send_response(int(status))
        if content_type:
            self.send_header('Content-Type', str(content_type))
        if content_length is not None:
            self.send_header('Content-Length', str(content_length))
        self.send_header('Connection', 'close')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        # Google Cast Web Receivers fetch adaptive media (HLS/DASH) through a
        # browser/XHR media stack and therefore require CORS.  Expose CORS only
        # on opaque /v1 media-token routes; the loopback control plane never gets
        # these headers.  Echo the concrete Origin instead of using '*' because
        # Cast documentation explicitly disallows wildcard origins for protected
        # media.
        try:
            request_path = urllib.parse.urlparse(self.path).path
        except Exception:
            request_path = ''
        if request_path.startswith('/v1/'):
            origin = str(self.headers.get('Origin') or '').strip()
            if origin:
                self.send_header('Access-Control-Allow-Origin', origin)
                self.send_header('Vary', 'Origin')
            self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type, Accept-Encoding, Range, If-Range')
            self.send_header('Access-Control-Expose-Headers', 'Content-Type, Content-Length, Content-Range, Accept-Ranges')
        for name, value in (extra or {}).items():
            if value not in (None, ''):
                self.send_header(str(name), str(value))
        self.end_headers()
        try:
            self.wfile.flush()
        except Exception:
            pass

    def _plain(self, status, text=''):
        body = str(text or '').encode('utf-8')
        self._begin(status, content_length=len(body))
        if self.command != 'HEAD' and body:
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                pass

    def _json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        self._begin(status, 'application/json; charset=utf-8', len(body))
        if self.command != 'HEAD':
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                pass

    def _authorized_control(self):
        supplied = str(self.headers.get('X-IBO-Relay-Token') or '')
        expected = str(self.context.control_token or '')
        return bool(supplied and expected and supplied.isascii()
                    and secrets.compare_digest(supplied, expected))

    def do_POST(self):
        try:
            remote_ip = str((self.client_address or ('', 0))[0] or '')
        except Exception:
            remote_ip = ''
        if remote_ip != '127.0.0.1':
            return self._plain(403, 'Forbidden')
        path = urllib.parse.urlparse(self.path).path
        if path not in (_CONTROL_PATH, _RELEASE_PATH, _STATUS_PATH):
            return self._plain(404, 'Not found')
        if not self._authorized_control():
            return self._plain(403, 'Forbidden')
        try:
            length = int(self.headers.get('Content-Length') or 0)
        except Exception:
            length = 0
        if length <= 0 or length > _MAX_CONTROL_BODY:
            return self._plain(400, 'Bad request')
        try:
            payload = json.loads(self.rfile.read(length).decode('utf-8'))
        except Exception:
            return self._plain(400, 'Bad request')
        if not isinstance(payload, dict):
            return self._plain(400, 'Bad request')
        if path == _RELEASE_PATH:
            count = self.context.registry.release_session((payload or {}).get('session_id'))
            return self._json(200, {'ok': True, 'released': int(count)})
        if path == _STATUS_PATH:
            status = self.context.registry.session_status((payload or {}).get('session_id'))
            status['ok'] = True
            return self._json(200, status)
        url = str((payload or {}).get('url') or '').strip()
        kind = _safe_kind((payload or {}).get('kind'))
        if not _valid_upstream(url):
            return self._plain(400, 'Bad upstream')
        try:
            metadata = (payload or {}).get('metadata') if isinstance((payload or {}).get('metadata'), dict) else {}
            metadata = _prepare_faststart_metadata(self.context, url, kind, metadata)
            token, session_id = self.context.registry.add(url, kind=kind, root=True, metadata=metadata)
            local = self.context.registry.local_url(token, url, kind)
        except Exception:
            return self._plain(500, 'Relay registration failed')
        return self._json(200, {'ok': True, 'url': local, 'session_id': session_id})

    def do_OPTIONS(self):
        # CORS preflight is valid only for an existing opaque media token.
        # Never expose or proxy the loopback control endpoints through OPTIONS.
        token, entry = self._entry_token()
        if not token or not entry:
            return self._plain(404, 'Expired media handle')
        if entry.get('released_at') or not entry.get('url'):
            return self._plain(410, 'Released media handle')
        self._begin(204, content_type=None, content_length=0)

    def do_HEAD(self):
        self._serve_head()

    def do_GET(self):
        self._serve_get()

    def _entry_token(self):
        path = urllib.parse.urlparse(self.path).path
        parts = [part for part in path.split('/') if part]
        if len(parts) < 2 or parts[0] != 'v1':
            return '', None
        token = parts[1]
        return token, self.context.registry.get(token)

    def _forward_headers(self):
        result = {}
        for name in ('Range', 'If-Range'):
            value = self.headers.get(name)
            if value:
                result[name] = value
        return result

    def _serve_head(self):
        """Never contact upstream for Kodi Stat/GetMimeType.

        This is what removes the 20+ second post-Stop freeze seen in the real log.
        """
        token, entry = self._entry_token()
        if not entry:
            return self._plain(404, 'Expired media handle')
        self.context.registry.mark_access(token, 'HEAD')
        direct_live_ts = bool(
            entry.get('kind') == 'live' and str(entry.get('suffix') or '').lower() == '.ts'
        )
        extra = {}
        if entry.get('accept_ranges') and not direct_live_ts:
            extra['Accept-Ranges'] = entry.get('accept_ranges')
        if entry.get('etag'):
            extra['ETag'] = entry.get('etag')
        if entry.get('last_modified'):
            extra['Last-Modified'] = entry.get('last_modified')
        length = '' if direct_live_ts else entry.get('content_length')
        content_type = 'video/mp2t' if direct_live_ts else (entry.get('content_type') or _mime_for('', entry.get('kind')))
        if direct_live_ts:
            log('Relay V5 Live TS: HEAD contínuo mime=video/mp2t length=desconhecido ranges=não.', 'debug')
        if entry.get('lg_vod_proxy'):
            log(
                'Relay V5 LG VOD: HEAD status=200 mime=%s length=%s ranges=%s.' % (
                    str(content_type or 'application/octet-stream'),
                    str(length) if str(length or '').isdigit() else 'desconhecido',
                    str(entry.get('accept_ranges') or 'não'),
                ) + (' faststart=sim.' if entry.get('faststart_enabled') else ' faststart=não.'),
                'debug',
            )
        return self._begin(
            200,
            content_type,
            int(length) if str(length or '').isdigit() else None,
            extra,
        )

    def _open_exact_range(self, url, start, end, timeout=20.0):
        response = self.context.open_upstream(
            url, method='GET', headers={'Range': 'bytes=%d-%d' % (int(start), int(end))}, timeout=timeout
        )
        try:
            status = int(getattr(response, 'status', response.getcode()) or 0)
            content_range = str(response.headers.get('Content-Range') or '').strip()
            match = re.match(r'(?i)^bytes\s+(\d+)-(\d+)/(\d+|\*)$', content_range)
            if not (status == 206 and match and int(match.group(1)) == int(start) and int(match.group(2)) == int(end)):
                raise ValueError('Range upstream não exato')
            return response
        except Exception:
            try:
                response.close()
            except Exception:
                pass
            raise

    def _stream_exact_source_range(self, url, start, end, resume_state):
        """Stream one original source span, preserving the global VOD resume budget."""
        cursor = int(start)
        end = int(end)
        while cursor <= end:
            response = None
            expected = end - cursor + 1
            sent = 0
            try:
                response = self._open_exact_range(url, cursor, end, timeout=20.0)
                while sent < expected:
                    try:
                        chunk = response.read(min(_COPY_CHUNK, expected - sent))
                    except http.client.IncompleteRead as exc:
                        chunk = bytes(getattr(exc, 'partial', b'') or b'')
                    if not chunk:
                        break
                    try:
                        self.wfile.write(chunk)
                    except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                        return False
                    sent += len(chunk)
                if sent >= expected:
                    return True
            except (urllib.error.URLError, urllib.error.HTTPError, socket.timeout, TimeoutError, OSError,
                    http.client.HTTPException, ValueError):
                pass
            finally:
                # Advance even if a later read failed after successful writes.
                # Retrying the old cursor would duplicate bytes downstream.
                cursor += sent
                try:
                    if response is not None:
                        response.close()
                except Exception:
                    pass
            if cursor > end:
                return True
            if int(resume_state.get('used') or 0) >= _VOD_RESUME_ATTEMPTS:
                log(
                    'Relay V5 LG VOD: faststart upstream parcial (byte=%d, retomadas=%d).' % (
                        int(cursor), int(resume_state.get('used') or 0)
                    ),
                    'warning',
                )
                return False
            resume_state['used'] = int(resume_state.get('used') or 0) + 1
        return True

    def _serve_faststart_get(self, token, entry):
        """Serve a virtual MP4 with final moov relocated before mdat.

        Virtual layout (same total byte length):
          source prefix | patched moov | source mdat/body
        The original final moov is omitted.  stco/co64 entries in the cached
        moov were shifted during registration, so every media byte remains
        source-identical and Range requests map deterministically.
        """
        total = int(entry.get('content_length') or 0)
        mdat_offset = int(entry.get('faststart_mdat_offset') or 0)
        moov_offset = int(entry.get('faststart_moov_offset') or 0)
        moov_size = int(entry.get('faststart_moov_size') or 0)
        moov = entry.get('faststart_moov') or b''
        if not (total > 0 and mdat_offset > 0 and moov_offset > mdat_offset and
                moov_size == len(moov) and moov_offset + moov_size == total):
            entry = dict(entry)
            entry['faststart_enabled'] = False
            return None

        parsed = _parse_http_byte_range(self.headers.get('Range'), total)
        if not parsed:
            extra = {'Content-Range': 'bytes */%d' % int(total), 'Accept-Ranges': 'bytes'}
            self._begin(416, 'video/mp4', 0, extra)
            return True
        status, start, end = parsed
        extra = {'Accept-Ranges': 'bytes'}
        if int(status) == 206:
            extra['Content-Range'] = 'bytes %d-%d/%d' % (int(start), int(end), int(total))
        self._begin(int(status), 'video/mp4', int(end) - int(start) + 1, extra)
        self.context.registry.mark_served(token)

        # Virtual segments are half-open [vstart, vend), mapped either to an
        # original source span or to the locally cached/patched moov.
        virtual = [
            (0, mdat_offset, 'source', 0),
            (mdat_offset, mdat_offset + moov_size, 'moov', 0),
            (mdat_offset + moov_size, total, 'source', mdat_offset),
        ]
        resume_state = {'used': 0}
        url = str(entry.get('url') or '')
        wanted_start = int(start)
        wanted_end_exclusive = int(end) + 1
        ok = True
        for vstart, vend, stype, source_base in virtual:
            left = max(wanted_start, int(vstart))
            right = min(wanted_end_exclusive, int(vend))
            if left >= right:
                continue
            if stype == 'moov':
                local_start = left - int(vstart)
                local_end = right - int(vstart)
                try:
                    self.wfile.write(moov[local_start:local_end])
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                    ok = False
                    break
            else:
                original_start = int(source_base) + (left - int(vstart))
                original_end = int(source_base) + (right - int(vstart)) - 1
                if not self._stream_exact_source_range(url, original_start, original_end, resume_state):
                    ok = False
                    break
        log(
            'Relay V5 LG VOD: GET faststart status=%d range=%s inicio=%d length=%d total=%d moov_front=%d retomadas=%d resultado=%s.' % (
                int(status), 'sim' if self.headers.get('Range') else 'não', int(start),
                int(end) - int(start) + 1, int(total), int(mdat_offset),
                int(resume_state.get('used') or 0), 'ok' if ok else 'parcial'
            ),
            'debug',
        )
        return True

    def _is_manifest(self, upstream_url, headers, sample=b''):
        content_type = str((headers or {}).get('Content-Type') or (headers or {}).get('content-type') or '').lower()
        try:
            path = urllib.parse.urlparse(str(upstream_url or '')).path.lower()
        except Exception:
            path = ''
        return 'mpegurl' in content_type or path.endswith('.m3u8') or bytes(sample or b'').lstrip().startswith(b'#EXTM3U')

    def _rewrite_uri(self, uri, base_url, session_id):
        text = str(uri or '').strip()
        if not text or text.startswith('data:'):
            return text
        absolute = urllib.parse.urljoin(str(base_url or ''), text)
        if not _valid_upstream(absolute):
            # Never hand file://, special://, smb:// or plugin:// back to Kodi.
            raise ValueError('Unsupported manifest resource scheme')
        token, _sid = self.context.registry.add(absolute, kind='resource', session_id=session_id)
        return self.context.registry.local_url(token, absolute, 'resource')

    def _rewrite_manifest(self, raw, base_url, session_id):
        text = bytes(raw or b'').decode('utf-8-sig', 'replace')
        output = []
        for line in text.splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith('#'):
                output.append(self._rewrite_uri(stripped, base_url, session_id))
                continue
            def quoted(match):
                return '%s%s%s%s' % (
                    match.group(1), match.group(2),
                    self._rewrite_uri(match.group(3), base_url, session_id), match.group(4)
                )
            rewritten = _URI_QUOTED_RE.sub(quoted, line)
            if rewritten == line and 'URI=' in line.upper():
                def bare(match):
                    return '%s%s' % (match.group(1), self._rewrite_uri(match.group(2), base_url, session_id))
                rewritten = _URI_BARE_RE.sub(bare, line)
            output.append(rewritten)
        return ('\n'.join(output) + '\n').encode('utf-8')

    def _send_binary_headers(self, response, entry=None):
        status = int(getattr(response, 'status', response.getcode()) or 200)
        entry = entry if isinstance(entry, dict) else {}
        direct_live_ts = bool(entry.get('kind') == 'live' and str(entry.get('suffix') or '').lower() == '.ts')
        extra = {}
        for name in ('Content-Range', 'Accept-Ranges', 'Last-Modified', 'ETag', 'Expires'):
            if direct_live_ts and name in ('Content-Range', 'Accept-Ranges'):
                continue
            value = response.headers.get(name)
            if value:
                extra[name] = value
        if (not direct_live_ts) and entry.get('accept_ranges') and not extra.get('Accept-Ranges'):
            extra['Accept-Ranges'] = str(entry.get('accept_ranges'))

        upstream_type = str(response.headers.get('Content-Type') or '').strip()
        content_type = 'video/mp2t' if direct_live_ts else (upstream_type or 'application/octet-stream')
        # V20: the LG probe has already identified the actual container. Preserve
        # that proven type on the proxy even if Xtream/CDN labels the byte stream
        # as application/octet-stream or another generic Content-Type.
        if entry.get('lg_vod_proxy') and entry.get('content_type'):
            content_type = str(entry.get('content_type'))

        length_text = str(response.headers.get('Content-Length') or '').strip()
        upstream_content_length = int(length_text) if length_text.isdigit() else None
        # A direct Live TS is a virtual continuous body. Never expose the finite
        # size of one upstream HTTP segment to the renderer.
        content_length = None if direct_live_ts else upstream_content_length
        content_range = str(response.headers.get('Content-Range') or '').strip()
        match = re.match(r'(?i)^bytes\s+(\d+)-(\d+)/(\d+|\*)$', content_range)
        if status == 206 and match:
            # Never send total object size as Content-Length on a partial body.
            if content_length is None:
                content_length = max(0, int(match.group(2)) - int(match.group(1)) + 1)
        elif content_length is None and entry.get('lg_vod_proxy'):
            total_text = str(entry.get('content_length') or '').strip()
            if total_text.isdigit():
                content_length = int(total_text)

        self._begin(status, content_type, content_length, extra)

        if direct_live_ts:
            log(
                'Relay V5 Live TS: resposta contínua aberta (mime=video/mp2t, upstream_length=%s, range_cliente=%s).' % (
                    'sim' if upstream_content_length is not None else 'não',
                    'sim' if bool(str(self.headers.get('Range') or '').strip()) else 'não',
                ),
                'debug',
            )

        if entry.get('lg_vod_proxy'):
            range_header = str(self.headers.get('Range') or '').strip()
            start_byte = '0'
            requested = 'não'
            if range_header:
                requested = 'sim'
                req_match = re.match(r'(?i)^bytes=(\d+)-', range_header)
                if req_match:
                    start_byte = req_match.group(1)
            total = str(entry.get('content_length') or 'desconhecido')
            log(
                'Relay V5 LG VOD: GET status=%d range=%s inicio=%s length=%s total=%s mime=%s.' % (
                    int(status), requested, start_byte,
                    str(content_length) if content_length is not None else 'desconhecido',
                    total if total.isdigit() else 'desconhecido', str(content_type),
                ),
                'debug',
            )

    @staticmethod
    def _response_span(response):
        """Return (start, expected_body_length, end) for a binary response."""
        try:
            status = int(getattr(response, 'status', response.getcode()) or 200)
        except Exception:
            status = 200
        length_text = str(response.headers.get('Content-Length') or '').strip()
        expected = int(length_text) if length_text.isdigit() else None
        start = 0
        end = (expected - 1) if expected is not None and expected > 0 else None
        content_range = str(response.headers.get('Content-Range') or '').strip()
        match = re.match(r'(?i)^bytes\s+(\d+)-(\d+)/(?:\d+|\*)$', content_range)
        if status == 206 and match:
            start = int(match.group(1))
            end = int(match.group(2))
            if expected is None:
                expected = max(0, end - start + 1)
        return start, expected, end

    def _resume_vod_response(self, url, next_absolute, end_absolute, entry, timeout=8.0, attempt=0):
        """Resume a truncated VOD body without exposing the retry to Kodi.

        Only an exact HTTP 206 beginning at ``next_absolute`` is accepted. Some
        Xtream/CDN stacks advertise ETag/Last-Modified but answer a valid Range
        only when If-Range is omitted; in that narrow case one compatibility
        retry is allowed. Both responses are still required to prove the exact
        byte start, so duplicated or skipped bytes cannot enter Kodi's body.
        Logs intentionally contain only numeric transport metadata.
        """
        range_value = 'bytes=%d-' % int(next_absolute)
        if end_absolute is not None and int(end_absolute) >= int(next_absolute):
            range_value = 'bytes=%d-%d' % (int(next_absolute), int(end_absolute))
        if_range = str(self.headers.get('If-Range') or entry.get('etag') or entry.get('last_modified') or '').strip()

        variants = [bool(if_range)]
        if if_range:
            variants.append(False)
        for use_if_range in variants:
            headers = {'Range': range_value}
            if use_if_range:
                headers['If-Range'] = if_range
            resumed = None
            status = 0
            match = None
            try:
                resumed = self.context.open_upstream(url, method='GET', headers=headers, timeout=timeout)
                status = int(getattr(resumed, 'status', resumed.getcode()) or 0)
                content_range = str(resumed.headers.get('Content-Range') or '').strip()
                match = re.match(r'(?i)^bytes\s+(\d+)-(\d+)/(?:\d+|\*)$', content_range)
                exact = bool(status == 206 and match and int(match.group(1)) == int(next_absolute))
                if exact:
                    log(
                        'Relay V4: continuação VOD aceita (tentativa=%d, byte=%d, status=206, if_range=%s).' % (
                            int(attempt or 0), int(next_absolute), 'sim' if use_if_range else 'não'
                        ),
                        'debug',
                    )
                    return resumed
                log(
                    'Relay V4: continuação VOD rejeitada (tentativa=%d, byte=%d, status=%d, range_exato=%s, if_range=%s).' % (
                        int(attempt or 0), int(next_absolute), int(status or 0),
                        'sim' if bool(match and int(match.group(1)) == int(next_absolute)) else 'não',
                        'sim' if use_if_range else 'não',
                    ),
                    'debug',
                )
            except Exception as exc:
                log(
                    'Relay V4: continuação VOD sem resposta (tentativa=%d, byte=%d, if_range=%s, erro=%s).' % (
                        int(attempt or 0), int(next_absolute),
                        'sim' if use_if_range else 'não', exc.__class__.__name__
                    ),
                    'debug',
                )
                # A transport timeout/failure already consumed this resume try.
                # The no-If-Range compatibility retry is only for a concrete
                # HTTP response that rejected/ignored the validator.
                return None
            finally:
                if resumed is not None:
                    try:
                        # Successful exact responses are returned above and must
                        # stay open; rejected/failed variants are closed here.
                        if not (status == 206 and match and int(match.group(1)) == int(next_absolute)):
                            resumed.close()
                    except Exception:
                        pass
        return None

    def _live_token_active(self, token):
        try:
            return bool(self.context.registry.token_active(token))
        except Exception:
            return False

    def _live_backoff(self, token, seconds):
        deadline = time.monotonic() + max(0.0, float(seconds or 0.0))
        while time.monotonic() < deadline:
            if not self._live_token_active(token):
                return False
            time.sleep(min(0.05, max(0.0, deadline - time.monotonic())))
        return self._live_token_active(token)

    def _reopen_live_ts(self, url, token, attempt):
        if not self._live_token_active(token):
            return None
        index = max(1, int(attempt or 1))
        backoff = _LIVE_TS_RECONNECT_BACKOFFS[min(index - 1, len(_LIVE_TS_RECONNECT_BACKOFFS) - 1)]
        if not self._live_backoff(token, backoff):
            return None
        started = time.monotonic()
        response = None
        try:
            # Do not replay a renderer Range header on a fresh Live transport. A
            # reconnect means "current live point", not a byte seek.
            response = self.context.open_upstream(
                url, method='GET', headers={}, timeout=_LIVE_TS_RECONNECT_TIMEOUT
            )
            status = int(getattr(response, 'status', response.getcode()) or 0)
            if status < 200 or status >= 300:
                try:
                    response.close()
                except Exception:
                    pass
                response = None
                log('Relay V5 Live TS: reconexão %d rejeitada (status=%d).' % (index, status), 'debug')
                return None
            elapsed = int(max(0.0, time.monotonic() - started) * 1000.0)
            log('Relay V5 Live TS: reconexão %d upstream aceita em %dms.' % (index, elapsed), 'debug')
            return response
        except Exception as exc:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass
            elapsed = int(max(0.0, time.monotonic() - started) * 1000.0)
            log(
                'Relay V5 Live TS: reconexão %d sem resposta em %dms (erro=%s).' % (
                    index, elapsed, exc.__class__.__name__
                ),
                'debug',
            )
            return None

    def _serve_get(self):
        token, entry = self._entry_token()
        if not entry:
            return self._plain(404, 'Expired media handle')
        if entry.get('released_at') or not entry.get('url'):
            return self._plain(410, 'Released media handle')
        self.context.registry.mark_access(token, 'GET')
        if entry.get('faststart_enabled'):
            handled = self._serve_faststart_get(token, entry)
            if handled:
                return

        url = str(entry.get('url') or '')
        session_id = str(entry.get('session_id') or '')
        direct_live_ts = bool(
            entry.get('kind') == 'live' and str(entry.get('suffix') or '').lower() == '.ts'
        )
        response = None
        headers_sent = False
        try:
            # A resource entry is normally an HLS child (segment/key/variant).
            # It must fail before the player watchdog rather than keeping a
            # relay worker blocked for the generic VOD 20 s budget. VOD roots
            # retain the longer timeout because remote Range seeks can be slow.
            upstream_timeout = 8.0 if entry.get('kind') in ('resource', 'hls', 'live') else 20.0
            started_at = time.monotonic()
            forward_headers = {} if direct_live_ts else self._forward_headers()
            response = self.context.open_upstream(
                url, method='GET', headers=forward_headers, timeout=upstream_timeout
            )
            effective_url = str(getattr(response, 'geturl', lambda: url)() or url)
            self.context.registry.update_meta(token, response.headers)
            manifest = self._is_manifest(url, response.headers) or self._is_manifest(effective_url, response.headers)
            if manifest:
                raw = response.read(_MAX_MANIFEST_BYTES + 1)
                if len(raw) > _MAX_MANIFEST_BYTES:
                    return self._plain(502, 'Manifest too large')
                body = self._rewrite_manifest(raw, effective_url, session_id)
                self.context.registry.mark_served(token)
                self._begin(200, 'application/vnd.apple.mpegurl', len(body))
                headers_sent = True
                try:
                    self.wfile.write(body)
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                    pass
                return

            self._send_binary_headers(response, entry=entry)
            if not direct_live_ts:
                self.context.registry.mark_served(token)
            headers_sent = True
            span_start, expected_length, span_end = self._response_span(response)
            if direct_live_ts:
                # One upstream Content-Length represents at most one transport
                # segment. The renderer-facing body remains open-ended.
                expected_length = None
                span_end = None
            bytes_sent = 0
            resume_attempts = 0
            allow_internal_resume = entry.get('kind') in ('movie', 'series') and expected_length is not None
            live_framer = _LiveTSFramer() if direct_live_ts else None
            live_gate = None
            live_reconnect_count = 0
            live_segment = 1
            live_served_marked = False
            if direct_live_ts:
                read_size = _LIVE_TS_COPY_CHUNK
            elif entry.get('kind') in ('resource', 'hls'):
                read_size = _RESOURCE_COPY_CHUNK
            else:
                read_size = _COPY_CHUNK

            # HTTPResponse.read(128 KiB) can wait until the requested amount is
            # accumulated. That is fine for VOD, but on a low-bitrate Live TS it
            # can leave Kodi's FileCache with no localhost bytes for many seconds.
            # Prefer read1() for streaming media so currently available bytes are
            # forwarded promptly; this also makes a user Stop observable quickly
            # through the downstream socket instead of entering Curl retry loops.
            stream_reader = getattr(response, 'read1', None)
            if not callable(stream_reader) or entry.get('kind') in ('movie', 'series'):
                stream_reader = response.read

            while True:
                read_failed = False
                read_reason = 'eof'
                try:
                    chunk = stream_reader(read_size)
                except http.client.IncompleteRead as exc:
                    # Preserve every byte already received before the early EOF.
                    chunk = bytes(getattr(exc, 'partial', b'') or b'')
                    read_failed = True
                    read_reason = 'incomplete'
                except socket.timeout:
                    chunk = b''
                    read_failed = True
                    read_reason = 'timeout'
                except TimeoutError:
                    chunk = b''
                    read_failed = True
                    read_reason = 'timeout'
                except OSError:
                    chunk = b''
                    read_failed = True
                    read_reason = 'oserror'
                except http.client.HTTPException:
                    chunk = b''
                    read_failed = True
                    read_reason = 'http'

                out_chunk = chunk
                if direct_live_ts and chunk:
                    out_chunk = live_framer.feed(chunk)
                    if live_gate is not None and out_chunk:
                        if live_framer.mode != 'ts188':
                            # Unknown/non-standard transport format: preserve bytes
                            # exactly instead of forcing a 188-byte PSI parser.
                            log(
                                'Relay V5 Live TS: segmento %d em fallback raw; gate PSI desativado.' % int(live_segment),
                                'debug',
                            )
                            live_gate = None
                        else:
                            out_chunk, gate_done, gate_mode = live_gate.feed(out_chunk)
                            if gate_done:
                                log(
                                    'Relay V5 Live TS: segmento %d pronto após reconexão (alinhamento=%s, psi=%s, descartados=%d).' % (
                                        int(live_segment), str(live_framer.mode), str(gate_mode), int(live_framer.discarded)
                                    ),
                                    'debug',
                                )
                                live_gate = None

                if out_chunk:
                    try:
                        self.wfile.write(out_chunk)
                        bytes_sent += len(out_chunk)
                        if direct_live_ts and not live_served_marked:
                            self.context.registry.mark_served(token)
                            live_served_marked = True
                    except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                        if direct_live_ts:
                            log('Relay V5 Live TS: renderer encerrou a conexão.', 'debug')
                        break

                complete = expected_length is not None and bytes_sent >= int(expected_length)
                if complete:
                    break
                if chunk and not read_failed:
                    continue

                # Upstream ended early. VOD uses exact byte Range continuation.
                # Direct Live TS instead keeps the SAME renderer-facing HTTP body
                # open and swaps in a fresh current-point upstream connection.
                if direct_live_ts:
                    tail = live_framer.finish() if live_framer is not None else b''
                    if live_gate is not None:
                        if tail:
                            gated_tail, gate_done, gate_mode = live_gate.feed(tail)
                        else:
                            gated_tail, gate_done, gate_mode = b'', False, 'aguardando'
                        if not gate_done:
                            gated_tail, gate_mode = live_gate.finish()
                        tail = gated_tail
                        log(
                            'Relay V5 Live TS: segmento %d fechou durante gate PSI (resultado=%s).' % (
                                int(live_segment), str(gate_mode)
                            ),
                            'debug',
                        )
                        live_gate = None
                    if tail:
                        try:
                            self.wfile.write(tail)
                            bytes_sent += len(tail)
                            if not live_served_marked:
                                self.context.registry.mark_served(token)
                                live_served_marked = True
                        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                            log('Relay V5 Live TS: renderer encerrou a conexão durante fechamento do segmento.', 'debug')
                            break
                    log(
                        'Relay V5 Live TS: upstream interrompido (segmento=%d, motivo=%s, bytes=%d, alinhamento=%s).' % (
                            int(live_segment), str(read_reason), int(bytes_sent),
                            str(getattr(live_framer, 'mode', 'raw'))
                        ),
                        'debug',
                    )
                    try:
                        if response is not None:
                            response.close()
                    except Exception:
                        pass
                    response = None
                    reconnected = False
                    for attempt in range(1, _LIVE_TS_RECONNECT_ATTEMPTS + 1):
                        if not self._live_token_active(token):
                            break
                        resumed = self._reopen_live_ts(url, token, attempt)
                        if resumed is None:
                            continue
                        response = resumed
                        stream_reader = getattr(response, 'read1', None)
                        if not callable(stream_reader):
                            stream_reader = response.read
                        live_framer = _LiveTSFramer()
                        live_gate = _LiveTSPsiGate()
                        live_reconnect_count += 1
                        live_segment += 1
                        reconnected = True
                        break
                    if reconnected:
                        continue
                    if self._live_token_active(token):
                        self.context.registry.retire_token(token)
                        log(
                            'Relay V5 Live TS: reconexões esgotadas; encerrando após %d segmentos e %d retomadas.' % (
                                int(live_segment), int(live_reconnect_count)
                            ),
                            'warning',
                        )
                    break

                if (allow_internal_resume and resume_attempts < _VOD_RESUME_ATTEMPTS
                        and expected_length is not None and bytes_sent < int(expected_length)):
                    next_absolute = int(span_start) + int(bytes_sent)
                    try:
                        response.close()
                    except Exception:
                        pass
                    response = None
                    try:
                        resumed = self._resume_vod_response(
                            effective_url, next_absolute, span_end, entry, timeout=8.0,
                            attempt=resume_attempts + 1,
                        )
                    except Exception:
                        resumed = None
                    resume_attempts += 1
                    if resumed is not None:
                        response = resumed
                        # Critical: the previous HTTPResponse was closed above.
                        # Rebind the reader to the accepted 206 response; otherwise
                        # the loop keeps reading the dead connection and reports a
                        # false second EOF even though continuation succeeded.
                        stream_reader = response.read
                        # Do not alter bytes_sent/span_start: resumed bytes append to
                        # the original downstream body and are counted cumulatively.
                        continue
                if (allow_internal_resume and expected_length is not None
                        and bytes_sent < int(expected_length)):
                    log(
                        'Relay V4: corpo VOD terminou parcial (recebido=%d, esperado=%d, retomadas=%d).' % (
                            int(bytes_sent), int(expected_length), int(resume_attempts)
                        ),
                        'warning',
                    )
                break
        except urllib.error.HTTPError as exc:
            if not headers_sent:
                # Do not forward Location or provider body; both may contain secrets.
                log('Relay V4: upstream recusou mídia (HTTP %s, tipo=%s).' % (getattr(exc, 'code', 0) or 0, entry.get('kind') or 'resource'), 'warning')
                return self._plain(int(getattr(exc, 'code', 502) or 502), 'Upstream media error')
        except (urllib.error.URLError, socket.timeout, TimeoutError, OSError, http.client.HTTPException) as exc:
            if not headers_sent:
                try:
                    elapsed = max(0.0, time.monotonic() - started_at)
                except Exception:
                    elapsed = 0.0
                log('Relay V4: upstream sem resposta (tipo=%s, %.2fs, erro=%s).' % (entry.get('kind') or 'resource', elapsed, exc.__class__.__name__), 'warning')
                return self._plain(502, 'Upstream media unavailable')
        except Exception:
            if not headers_sent:
                return self._plain(502, 'Media relay failure')
        finally:
            try:
                if response is not None:
                    response.close()
            except Exception:
                pass



class MediaRelayService(object):
    def __init__(self):
        self.server = None
        self.thread = None
        self.control_token = ''

    def start(self):
        if self.server is not None:
            return True
        if ThreadingHTTPServer is None:
            return False
        self.control_token = secrets.token_urlsafe(48)
        media_host = _discover_lan_ipv4()
        bind_host = '0.0.0.0' if media_host else '127.0.0.1'
        server = _RelayHTTPServer((bind_host, 0), _RelayHandler)
        port = int(server.server_address[1])
        media_host = _safe_relay_host(media_host)
        server.relay_context = _RelayContext(port, self.control_token, media_host)
        self.server = server
        self.thread = threading.Thread(target=server.serve_forever, name='IBO-MediaRelay')
        self.thread.daemon = True
        self.thread.start()
        write_json(_RELAY_STATE, {
            'version': _RELAY_VERSION,
            'port': port,
            'control_token': self.control_token,
            'media_host': media_host,
            'started_at': int(time.time()),
        })
        try:
            os.chmod(_RELAY_STATE, 0o600)
        except Exception:
            pass
        log('Relay de mídia seguro V5 ativo (mídia=%s:%d; controle=loopback).' % (media_host, port), 'debug')
        return True

    def stop(self):
        delete(_RELAY_STATE)
        server = self.server
        self.server = None
        if server is not None:
            try:
                server.relay_context.registry.clear()
            except Exception:
                pass
            try:
                server.shutdown()
            except Exception:
                pass
            try:
                server.server_close()
            except Exception:
                pass
        thread = self.thread
        self.thread = None
        if thread is not None:
            try:
                thread.join(1.5)
            except Exception:
                pass


def _relay_state():
    data = read_json(_RELAY_STATE, {})
    if not isinstance(data, dict) or int(data.get('version') or 0) != _RELAY_VERSION:
        return {}
    try:
        port = int(data.get('port') or 0)
    except Exception:
        port = 0
    token = str(data.get('control_token') or '')
    media_host = _safe_relay_host(data.get('media_host'))
    if port < 1 or port > 65535 or len(token) < 32:
        return {}
    return {'port': port, 'control_token': token, 'media_host': media_host}


def relay_mime_for(url):
    """Public safe MIME helper for the plugin:// resolver route."""
    return _mime_for(str(url or ''), '')


def is_current_relay_url(url):
    """Accept only opaque media URLs served by the currently active local/LAN relay."""
    raw = str(url or '').strip().split('|', 1)[0]
    state = _relay_state()
    if not state:
        return False
    try:
        parsed = urllib.parse.urlparse(raw)
        allowed_hosts = {'127.0.0.1', _safe_relay_host(state.get('media_host'))}
        if parsed.scheme != 'http' or parsed.hostname not in allowed_hosts:
            return False
        if parsed.username is not None or parsed.password is not None:
            return False
        if int(parsed.port or 0) != int(state.get('port') or 0):
            return False
        path = str(parsed.path or '')
        parts = [part for part in path.split('/') if part]
        if len(parts) != 3 or parts[0] != 'v1' or not parts[1].strip() or not parts[2].startswith('stream.'):
            return False
        return not parsed.query and not parsed.fragment
    except Exception:
        return False


def _control_request(path, payload, timeout=1.2):
    state = _relay_state()
    if not state:
        raise RuntimeError('relay local não está ativo')
    body = json.dumps(payload, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    conn = http.client.HTTPConnection('127.0.0.1', int(state['port']), timeout=max(0.4, float(timeout)))
    try:
        conn.request('POST', path, body=body, headers={
            'Content-Type': 'application/json',
            'Content-Length': str(len(body)),
            'X-IBO-Relay-Token': state['control_token'],
            'Connection': 'close',
        })
        response = conn.getresponse()
        raw = response.read(64 * 1024)
        if int(response.status) != 200:
            raise RuntimeError('relay local recusou a operação (%s)' % int(response.status))
        data = json.loads(raw.decode('utf-8'))
        return data if isinstance(data, dict) else {}
    finally:
        try:
            conn.close()
        except Exception:
            pass


def register_playback(upstream_url, kind, wait_seconds=1.5, metadata=None):
    faststart_candidate = bool(isinstance(metadata, dict) and metadata.get('lg_faststart_candidate'))
    budget = max(0.2, float(wait_seconds or 0.0))
    if faststart_candidate:
        budget = max(budget, _FASTSTART_PREP_TIMEOUT + 1.2)
    deadline = time.monotonic() + budget
    last_error = None
    while time.monotonic() < deadline:
        try:
            payload = {'url': str(upstream_url or ''), 'kind': _safe_kind(kind)}
            if isinstance(metadata, dict) and metadata:
                payload['metadata'] = metadata
            data = _control_request(
                _CONTROL_PATH, payload,
                timeout=(_FASTSTART_PREP_TIMEOUT + 0.8) if faststart_candidate else 0.7,
            )
            local_url = str(data.get('url') or '')
            session_id = str(data.get('session_id') or '')
            if is_current_relay_url(local_url) and session_id:
                return local_url, session_id
            last_error = RuntimeError('resposta inválida do relay local')
        except Exception as exc:
            last_error = exc
        time.sleep(0.08)
    raise RuntimeError(str(last_error or 'relay local indisponível'))


def relay_session_activity(session_id):
    """Return anonymous GET/HEAD counters for one active Relay session.

    The control endpoint is loopback-only and authenticated with the per-process
    Relay token.  This intentionally exposes no media URL, upstream host, token
    or client address.
    """
    session_id = str(session_id or '').strip()
    if not session_id:
        return {'found': False, 'get_count': 0, 'head_count': 0, 'served_count': 0, 'released': False}
    try:
        data = _control_request(_STATUS_PATH, {'session_id': session_id}, timeout=0.7)
        return {
            'found': bool(data.get('found')),
            'get_count': max(0, int(data.get('get_count') or 0)),
            'head_count': max(0, int(data.get('head_count') or 0)),
            'served_count': max(0, int(data.get('served_count') or 0)),
            'released': bool(data.get('released')),
        }
    except Exception:
        return {'found': False, 'get_count': 0, 'head_count': 0, 'served_count': 0, 'released': False}


def release_playback(session_id, timeout=0.7):
    session_id = str(session_id or '').strip()
    if not session_id:
        return False
    try:
        data = _control_request(
            _RELEASE_PATH, {'session_id': session_id},
            timeout=max(0.25, min(1.5, float(timeout))),
        )
        return bool(data.get('ok'))
    except Exception:
        return False
