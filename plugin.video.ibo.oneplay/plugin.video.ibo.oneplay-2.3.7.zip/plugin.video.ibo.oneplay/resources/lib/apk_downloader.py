# -*- coding: utf-8 -*-
"""Downloader conservador dos APKs oficiais OnePlay.

Módulo adaptado do fluxo já homologado no add-on OnePlayVIP.  Mantém o escopo
isolado: seleção/transferência/validação de APK no Android, sem interferir no
player, painel IBO, autenticação, failover ou serviço Health.
"""
import base64
import os
import re
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile

from .constants import USER_AGENT
from .log import log
from .network_security import http_url, https_open
from .storage import delete, read_json, state_path, write_json

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except Exception:
    xbmc = None
    xbmcgui = None
    xbmcvfs = None


# Mesmos dois aplicativos mantidos para download. URLs ficam em Base64 apenas
# para preservar o mesmo contrato/organização do add-on modelo; isso não é
# tratado como mecanismo de segurança.
APK_ENTRIES_B64 = (
    ('OnePlay Alpha - PRINCIPAL', 'aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL09uZVBsYXlBbHBoYS5hcGs='),
    ('OnePlay Ibo - ESSENCIAL', 'aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL09uZVBsYXlJYm8uYXBr'),
)

ANDROID_DOWNLOAD_DIRS = (
    '/storage/emulated/0/Download',
    '/storage/self/primary/Download',
    '/sdcard/Download',
)

_CHUNK_SIZE = 256 * 1024
_MIN_APK_BYTES = 32 * 1024
_MAX_APK_BYTES = 512 * 1024 * 1024
_MAX_DOWNLOAD_SECONDS = 15 * 60

_APK_CLEANUP_STATE = state_path('apk_cleanup_v1.json')

# Fluxo pós-download homologado no ONEPLAY APK DOWNLOADER. DocumentsUI segue
# prioritário quando realmente aparece como aplicativo lançável para o Kodi;
# nas ROMs de TV Box, o gerenciador OEM assume o fallback.
_ANDROID_PRIMARY_HANDLER = 'com.android.documentsui'
_ANDROID_FILE_MANAGER_FALLBACKS = (
    'com.google.android.apps.nbu.files',
    'com.sec.android.app.myfiles',
    'com.mi.android.globalFileexplorer',
    'com.android.fileexplorer',
    'com.alphainventor.filemanager',
    'com.softwinner.TvdFileManager',
    'com.droidlogic.FileBrower',
    'com.droidlogic.FileBrowser',
    'com.lonelycatgames.Xplore',
    'nextapp.fx',
    'com.ghisler.android.TotalCommander',
    'pl.solidexplorer2',
    'com.mobisystems.fileman',
    'com.amaze.filemanager',
    'com.asus.filemanager',
    'com.mixplorer',
    'com.mixplorer.silver',
)
_ANDROID_APK_MIME = 'application/vnd.android.package-archive'
_FILE_MANAGER_PACKAGE_MARKERS = (
    'filemanager', 'file.manager', 'file_manager',
    'fileexplorer', 'file.explorer', 'file_explorer',
    'filebrowser', 'file.browser', 'file_browser',
    'tvdfilemanager',
)


class ApkDownloadError(Exception):
    pass


class ApkDownloadCanceled(ApkDownloadError):
    pass


def _decode_url(value):
    try:
        raw = str(value or '').strip()
        missing = len(raw) % 4
        if missing:
            raw += '=' * (4 - missing)
        return base64.b64decode(raw.encode('ascii')).decode('utf-8').strip()
    except Exception:
        return ''


def get_apk_filename_from_url(url):
    """Retorna somente basename real terminado em .apk; nunca inventa fallback."""
    try:
        path = urllib.parse.urlsplit(str(url or '')).path
        name = urllib.parse.unquote(os.path.basename(path)).strip()
    except Exception:
        return ''
    if not name or not name.lower().endswith('.apk'):
        return ''
    # Evita traversal ou nomes estranhos caso a URL seja alterada no futuro.
    if (name in ('.', '..') or '/' in name or '\\' in name or ':' in name
            or any(ord(char) < 32 or ord(char) == 127 for char in name)):
        return ''
    return name


def get_apk_entries():
    entries = []
    for label, encoded in APK_ENTRIES_B64:
        url = _decode_url(encoded)
        filename = get_apk_filename_from_url(url)
        if not url or not filename:
            continue
        entries.append({'label': str(label), 'url': url, 'filename': filename})
    return entries


def is_android():
    if xbmc is None:
        return False
    try:
        return bool(xbmc.getCondVisibility('System.Platform.Android'))
    except Exception:
        return False


def _installed_android_apps():
    """Retorna pacotes Android visíveis ao Kodi ou None se a consulta falhar."""
    if xbmcvfs is None:
        return None
    try:
        _dirs, apps = xbmcvfs.listdir('androidapp://sources/apps/')
        return [str(app) for app in (apps or []) if app]
    except Exception as exc:
        log('APK: não foi possível consultar aplicativos Android instalados: %s' % exc, 'debug')
        return None


def _find_installed_file_manager(installed):
    if not installed:
        return None
    by_lower = {package.lower(): package for package in installed}
    for package_name in _ANDROID_FILE_MANAGER_FALLBACKS:
        actual = by_lower.get(package_name.lower())
        if actual:
            return actual
    for package_name in installed:
        lowered = package_name.lower()
        if any(marker in lowered for marker in _FILE_MANAGER_PACKAGE_MARKERS):
            return package_name
    return None


def _open_handler_with_content_uri(package_name, path):
    if xbmc is None:
        return False
    safe_path = str(path or '').replace('"', '%22')
    xbmc.executebuiltin(
        'StartAndroidActivity(%s,,,"content://%s")' % (package_name, safe_path)
    )
    return True


def open_downloaded_apk(path):
    """Abre o APK no instalador/gerenciador disponível da ROM Android."""
    if not is_android() or not path:
        return False
    installed = _installed_android_apps()
    if installed is None:
        log('APK: enumeração Android indisponível; tentando DocumentsUI.', 'debug')
        return _open_handler_with_content_uri(_ANDROID_PRIMARY_HANDLER, path)

    installed_lower = {package.lower(): package for package in installed}
    primary = installed_lower.get(_ANDROID_PRIMARY_HANDLER.lower())
    if primary:
        log('APK: abrindo instalador Android pelo pacote %s.' % primary, 'debug')
        return _open_handler_with_content_uri(primary, path)

    package_name = _find_installed_file_manager(installed)
    if package_name:
        log('APK: abrindo gerenciador de arquivos %s.' % package_name, 'debug')
        return _open_handler_with_content_uri(package_name, path)

    safe_path = str(path).replace('"', '%22')
    log('APK: nenhum gerenciador detectado; usando ACTION_VIEW implícito.', 'debug')
    xbmc.executebuiltin(
        'StartAndroidActivity(,android.intent.action.VIEW,%s,"content://%s")' % (
            _ANDROID_APK_MIME, safe_path
        )
    )
    return True


def resolve_download_dir():
    """Escolhe a pasta pública Download do Android sem criar caminhos paralelos."""
    for folder in ANDROID_DOWNLOAD_DIRS:
        try:
            if os.path.isdir(folder) and os.access(folder, os.W_OK):
                return folder
        except Exception:
            pass

    # O caminho primário é o mesmo usado pelo add-on modelo. Se ainda não
    # existir, tentamos criá-lo; falha de permissão será reportada ao usuário.
    primary = ANDROID_DOWNLOAD_DIRS[0]
    try:
        os.makedirs(primary, exist_ok=True)
        if os.path.isdir(primary) and os.access(primary, os.W_OK):
            return primary
    except Exception:
        pass
    return ''


def _safe_delete(path):
    try:
        if path and os.path.exists(path):
            os.remove(path)
            return True
    except Exception:
        pass
    return False



def _official_apk_names():
    return set(
        str(row.get('filename') or '').strip()
        for row in get_apk_entries()
        if str(row.get('filename') or '').strip().lower().endswith('.apk')
    )


def _normalized_path(path):
    try:
        return os.path.normcase(os.path.realpath(os.path.abspath(str(path or ''))))
    except Exception:
        return ''


def _allowed_download_parent(path):
    parent = _normalized_path(os.path.dirname(str(path or '')))
    if not parent:
        return False
    allowed = set(_normalized_path(folder) for folder in ANDROID_DOWNLOAD_DIRS)
    return parent in allowed


def _apk_signature(path):
    try:
        stat = os.stat(path)
        mtime_ns = getattr(stat, 'st_mtime_ns', None)
        if mtime_ns is None:
            mtime_ns = int(float(stat.st_mtime) * 1000000000)
        return {'size': int(stat.st_size), 'mtime_ns': int(mtime_ns)}
    except Exception:
        return {}


def _arm_apk_cleanup(path):
    """Registra somente APK criado pelo downloader para limpeza posterior."""
    normalized = _normalized_path(path)
    filename = os.path.basename(str(path or '')).strip()
    if not normalized or filename not in _official_apk_names() or not _allowed_download_parent(normalized):
        return False
    signature = _apk_signature(normalized)
    if not signature:
        return False

    state = read_json(_APK_CLEANUP_STATE, {}) or {}
    items = list(state.get('items') or [])
    item = {
        'path': normalized,
        'filename': filename,
        'size': int(signature.get('size') or 0),
        'mtime_ns': int(signature.get('mtime_ns') or 0),
        'armed_at': int(time.time()),
    }
    items = [row for row in items if _normalized_path((row or {}).get('path')) != normalized]
    items.append(item)
    write_json(_APK_CLEANUP_STATE, {'version': 1, 'items': items})
    log('APK: limpeza automática armada para %s.' % filename, 'debug')
    return True


def cleanup_downloaded_apks():
    """Remove somente APKs ONEPLAY previamente registrados pelo downloader."""
    if not is_android():
        return {'removed': 0, 'parts': 0, 'kept': 0, 'platform': False}

    official = _official_apk_names()
    removed = 0
    parts = 0
    kept = 0
    state = read_json(_APK_CLEANUP_STATE, {}) or {}
    items = list(state.get('items') or [])

    for row in items:
        row = dict(row or {})
        path = _normalized_path(row.get('path'))
        filename = os.path.basename(path).strip() if path else ''
        if not path or filename not in official or not _allowed_download_parent(path):
            kept += 1
            continue
        if not os.path.exists(path):
            continue

        current = _apk_signature(path)
        recorded_size = int(row.get('size') or -1)
        recorded_mtime = int(row.get('mtime_ns') or -1)
        same_file = (
            bool(current) and
            int(current.get('size') or -2) == recorded_size and
            int(current.get('mtime_ns') or -2) == recorded_mtime
        )
        if not same_file:
            kept += 1
            log('APK: arquivo mudou após o download; limpeza ignorada por segurança: %s.' % filename, 'warning')
            continue
        if _safe_delete(path):
            removed += 1
            log('APK: arquivo baixado removido automaticamente: %s.' % filename, 'info')

    # O marcador é descartado depois da avaliação. Arquivo alterado fica
    # preservado e sem rastreamento para nunca ser apagado no futuro.
    delete(_APK_CLEANUP_STATE)

    # Download interrompido pode morrer antes do marcador final. Remova apenas
    # <nome-oficial>.apk.part; nunca arquivos .part genéricos.
    for folder in ANDROID_DOWNLOAD_DIRS:
        for filename in official:
            part_path = os.path.join(folder, filename + '.part')
            if _safe_delete(part_path):
                parts += 1
                log('APK: download parcial removido automaticamente: %s.part.' % filename, 'info')
        parts += _cleanup_stale_apk_parts(folder, official)

    return {'removed': removed, 'parts': parts, 'kept': kept}


def _cleanup_stale_apk_parts(folder, official):
    """Clean only the downloader's exact temporary naming convention, after
    its maximum running time plus a margin. Never follow symlinks or recurse.
    """
    removed = 0
    try:
        with os.scandir(folder) as entries:
            for entry in entries:
                if not any(re.fullmatch(re.escape(name) + r'\.[a-z0-9_]{8}\.part', entry.name)
                           for name in official):
                    continue
                try:
                    if not entry.is_file(follow_symlinks=False) or not _allowed_download_parent(entry.path):
                        continue
                    if time.time() - entry.stat(follow_symlinks=False).st_mtime <= _MAX_DOWNLOAD_SECONDS + 300:
                        continue
                    if _safe_delete(entry.path):
                        removed += 1
                except OSError:
                    continue
    except OSError:
        pass
    return removed


def validate_apk_file(path):
    """Structural check only; this does not authenticate the APK publisher."""
    try:
        if not path or not os.path.isfile(path):
            return False, 'Arquivo não foi criado.'
        if os.path.getsize(path) < _MIN_APK_BYTES:
            return False, 'Arquivo baixado é pequeno demais para ser um APK válido.'
        if not zipfile.is_zipfile(path):
            return False, 'O servidor não retornou um arquivo APK válido.'
        with zipfile.ZipFile(path, 'r') as archive:
            names = set(archive.namelist())
            if 'AndroidManifest.xml' not in names:
                return False, 'O arquivo não contém AndroidManifest.xml.'
        return True, ''
    except Exception as exc:
        return False, 'Falha ao validar APK: %s' % exc


def _progress_message(downloaded, total, started):
    elapsed = max(time.monotonic() - started, 0.001)
    speed = downloaded / elapsed
    down_mb = downloaded / float(1024 * 1024)
    if total > 0:
        total_mb = total / float(1024 * 1024)
        remain = max(total - downloaded, 0)
        eta = int(remain / speed) if speed > 0 else 0
        mins, secs = divmod(max(eta, 0), 60)
        return '%.1f MB de %.1f MB\n%.0f KB/s  •  %02d:%02d restantes' % (
            down_mb, total_mb, speed / 1024.0, mins, secs)
    return '%.1f MB baixados\n%.0f KB/s' % (down_mb, speed / 1024.0)


def download_apk(entry, download_dir=None, urlopen_func=None, progress=None, timeout=30):
    """Baixa uma entrada e retorna dict de resultado.

    ``urlopen_func`` e ``progress`` são injetáveis para permitir perícia/runtime
    sem rede real. O arquivo final só aparece após transferência + validação.
    """
    data = dict(entry or {})
    url = str(data.get('url') or '').strip()
    filename = str(data.get('filename') or get_apk_filename_from_url(url)).strip()
    try:
        http_url(url, https_only=True)
    except ValueError:
        raise ApkDownloadError('O download do APK exige uma URL HTTPS válida.')
    if not filename or filename != get_apk_filename_from_url(url):
        raise ApkDownloadError('URL de APK inválida.')

    folder = str(download_dir or resolve_download_dir() or '').strip()
    if not folder:
        raise ApkDownloadError('Não foi possível acessar a pasta Download do Android.')
    try:
        os.makedirs(folder, exist_ok=True)
    except Exception as exc:
        raise ApkDownloadError('Não foi possível preparar a pasta Download: %s' % exc)

    final_path = os.path.join(folder, filename)
    part_path = ''

    opener = urlopen_func or https_open
    req = urllib.request.Request(
        url,
        headers={
            'User-Agent': USER_AGENT,
            'Accept': 'application/vnd.android.package-archive, application/octet-stream, */*',
            'Accept-Encoding': 'identity',
            'Connection': 'close',
        },
        method='GET',
    )

    started = time.monotonic()
    downloaded = 0
    total = 0
    response = None
    try:
        response = opener(req, timeout=timeout)
        http_url(response.geturl(), https_only=True)
        try:
            status = int(getattr(response, 'status', response.getcode()))
        except Exception:
            status = 200
        if status < 200 or status >= 300:
            raise ApkDownloadError('Servidor respondeu HTTP %d.' % status)

        try:
            total = int(response.headers.get('Content-Length') or 0)
        except Exception:
            total = 0
        if total < 0 or total > _MAX_APK_BYTES:
            raise ApkDownloadError('Tamanho do APK excede o limite de 512 MB.')

        with tempfile.NamedTemporaryFile(mode='wb', dir=folder, prefix=filename + '.',
                                         suffix='.part', delete=False) as target:
            part_path = target.name
            while True:
                if time.monotonic() - started > _MAX_DOWNLOAD_SECONDS:
                    raise ApkDownloadError('Tempo máximo de download excedido.')
                if progress is not None:
                    try:
                        if progress.iscanceled():
                            raise ApkDownloadCanceled('Download cancelado pelo usuário.')
                    except AttributeError:
                        pass
                chunk = response.read(_CHUNK_SIZE)
                if not chunk:
                    break
                if downloaded + len(chunk) > _MAX_APK_BYTES:
                    raise ApkDownloadError('Tamanho do APK excede o limite de 512 MB.')
                target.write(chunk)
                downloaded += len(chunk)
                if progress is not None:
                    percent = int(min(99, (downloaded * 100 / total))) if total > 0 else 0
                    try:
                        progress.update(percent, _progress_message(downloaded, total, started))
                    except Exception:
                        pass
        try:
            response.close()
        except Exception:
            pass

        if total and downloaded != total:
            raise ApkDownloadError('Download incompleto: tamanho diferente do informado pelo servidor.')
        valid, reason = validate_apk_file(part_path)
        if not valid:
            raise ApkDownloadError(reason)

        # Somente depois da validação substituímos eventual APK anterior.
        os.replace(part_path, final_path)
        try:
            _arm_apk_cleanup(final_path)
        except Exception as exc:
            # A limpeza é conveniência de armazenamento; jamais transforma um
            # download válido em falha.
            log('APK: não foi possível armar a limpeza automática: %s' % exc, 'warning')
        if progress is not None:
            try:
                progress.update(100, 'Download concluído e APK validado.')
            except Exception:
                pass
        return {
            'ok': True,
            'path': final_path,
            'filename': filename,
            'bytes': downloaded,
            'label': str(data.get('label') or filename),
        }
    except ApkDownloadCanceled:
        _safe_delete(part_path)
        raise
    except Exception as exc:
        _safe_delete(part_path)
        if isinstance(exc, ApkDownloadError):
            raise
        raise ApkDownloadError(str(exc))
    finally:
        try:
            if response is not None:
                response.close()
        except Exception:
            pass


def show_install_help(download_path):
    if xbmcgui is None:
        return
    filename = os.path.basename(str(download_path or '')) or 'APK baixado'
    xbmcgui.Dialog().ok(
        'Como instalar o APK',
        '1. Feche ou minimize o Kodi.\n'
        '2. Abra o gerenciador de arquivos do Android.\n'
        '3. Abra [COLOR lime]Download / %s[/COLOR].\n'
        '4. Se necessário, libere [COLOR yellow]Instalar apps desconhecidos[/COLOR].\n'
        '5. Instale e abra o aplicativo.\n\n'
        '[COLOR cyan]Com a limpeza automática ativada, este APK será removido da pasta Download na próxima abertura do ONEPLAY.[/COLOR]' % filename,
    )


def show_download_apk(entry):
    """Fluxo visual usado pela tela Configurações."""
    if xbmcgui is None:
        return {'ok': False, 'error': 'Kodi GUI indisponível.'}
    if not is_android():
        xbmcgui.Dialog().ok(
            'Download de APK',
            'Este recurso está disponível no Android / Android TV / TV Box.\n'
            'O download não será iniciado neste sistema.',
        )
        return {'ok': False, 'error': 'platform'}

    folder = resolve_download_dir()
    if not folder:
        xbmcgui.Dialog().ok(
            'Download de APK',
            'Não foi possível acessar a pasta pública Download do Android.\n'
            'Verifique a permissão de arquivos do Kodi.',
        )
        return {'ok': False, 'error': 'download_dir'}

    label = str((entry or {}).get('label') or 'APK OnePlay')
    filename = str((entry or {}).get('filename') or 'APK')
    progress = xbmcgui.DialogProgress()
    progress.create('Baixando %s' % label, filename)
    try:
        result = download_apk(entry, download_dir=folder, progress=progress)
    except ApkDownloadCanceled:
        log('Download de APK cancelado pelo usuário.', 'info')
        try:
            xbmcgui.Dialog().notification('Download de APK', 'Download cancelado.', time=2500)
        except Exception:
            pass
        return {'ok': False, 'error': 'canceled'}
    except ApkDownloadError as exc:
        log('Falha no download do APK: %s' % exc, 'warning')
        xbmcgui.Dialog().ok('Download de APK', 'Não foi possível baixar o aplicativo.\n\n%s' % exc)
        return {'ok': False, 'error': str(exc)}
    finally:
        try:
            progress.close()
        except Exception:
            pass

    path = result.get('path') or ''
    xbmcgui.Dialog().ok(
        'Download concluído',
        '[COLOR yellow]APK baixado e validado com sucesso.[/COLOR]\n'
        'Arquivo salvo em:\n[COLOR lime]%s[/COLOR]\n\n'
        '[COLOR cyan]Ao fechar esta mensagem, o instalador ou gerenciador de arquivos será aberto.[/COLOR]' % path,
    )
    try:
        if not open_downloaded_apk(path):
            show_install_help(path)
    except Exception as exc:
        log('APK: falha ao abrir instalador/gerenciador Android: %s' % exc, 'warning')
        show_install_help(path)
    return result
