# -*- coding: utf-8 -*-
"""Conservative WindowXML font compatibility for third-party Kodi skins.

The ONEPLAY layouts were visually homologated on Kodi's Estuary skin. Kodi
resolves every <font> name against the *active Kodi skin*; if a requested name
is absent, Kodi falls back to ``font13``.  Several historical ONEPLAY XMLs use
names such as font16/font18/font20 which are absent from Estuary and therefore
render as Estuary's font13.  A third-party skin may define those same names at
very different sizes, unexpectedly changing the ONEPLAY layout.

For Estuary this module is a strict no-op.  For another skin it creates a small
runtime copy of the ONEPLAY WindowXML files under the add-on profile, keeping
all original media and layout geometry but translating font names to fonts in
the active skin whose declared sizes are closest to Estuary's effective
metrics.  It never writes to or edits the Kodi skin itself and never supplies
font files.
"""

import hashlib
import json
import os
import re
import shutil
import xml.etree.ElementTree as ET

from .log import log
from .storage import profile_dir, translate

try:
    import xbmc
    import xbmcvfs
except Exception:
    xbmc = None
    xbmcvfs = None


# Effective font metrics of Estuary/Omega.  Unknown font names intentionally
# map to 30 because Kodi's GUIFontManager falls back to font13, which is 30px
# in Estuary's default fontset.  Current ONEPLAY XMLs only use font12/font13/
# font14 plus names that hit this fallback, but the table keeps future aliases
# deterministic too.
_ESTUARY_FONT_SIZES = {
    'font10': 23,
    'font12': 25,
    'font13': 30,
    'font14': 33,
    'font23_narrow': 23,
    'font25_narrow': 25,
    'font27': 27,
    'font27_narrow': 27,
    'font32': 32,
    'font37': 37,
    'font45': 45,
    'font60': 60,
    'font_flag': 18,
    'font20_title': 20,
    'font25_title': 25,
    'font30_title': 30,
    'font32_title': 32,
    'font36_title': 36,
    'font40_title': 40,
    'font45_title': 45,
    'font52_title': 52,
    'font_mainmenu': 60,
    'weatherTemp': 120,
    'mono26': 26,
}
_DEFAULT_FALLBACK_SIZE = 30
_COMPAT_DIR_NAME = 'skin_compat_v1'
_COMPAT_CACHE = {}


def _jsonrpc_setting(setting, fallback=''):
    if xbmc is None:
        return fallback
    try:
        request = {
            'jsonrpc': '2.0',
            'method': 'Settings.GetSettingValue',
            'params': {'setting': str(setting)},
            'id': 1,
        }
        raw = xbmc.executeJSONRPC(json.dumps(request, separators=(',', ':')))
        data = json.loads(raw or '{}')
        return str(((data.get('result') or {}).get('value')) or fallback)
    except Exception:
        return fallback


def _active_skin_id():
    return _jsonrpc_setting('lookandfeel.skin', '').strip().lower()


def _active_fontset():
    return _jsonrpc_setting('lookandfeel.font', 'Default').strip() or 'Default'


def _skin_root():
    try:
        if xbmcvfs is not None:
            path = xbmcvfs.translatePath('special://skin/')
        else:
            path = translate('special://skin/')
        return os.path.normpath(str(path or '')) if path else ''
    except Exception:
        return ''


def _skin_resolution_info(root):
    rows_out = []
    addon_xml = os.path.join(root, 'addon.xml')
    try:
        tree = ET.parse(addon_xml)
        for ext in tree.getroot().findall('extension'):
            if str(ext.attrib.get('point') or '') != 'xbmc.gui.skin':
                continue
            rows = list(ext.findall('res'))
            rows.sort(key=lambda node: 0 if str(node.attrib.get('default') or '').lower() == 'true' else 1)
            for node in rows:
                folder = str(node.attrib.get('folder') or '').strip()
                try:
                    height = float(str(node.attrib.get('height') or '0').strip())
                except Exception:
                    height = 0.0
                if folder and not any(row[0] == folder for row in rows_out):
                    rows_out.append((folder, height if height > 0 else 1080.0))
    except Exception:
        pass
    return rows_out


def _resolution_folders(root):
    folders = [row[0] for row in _skin_resolution_info(root)]
    for fallback in ('xml', '1080i', '16x9', '720p', ''):
        if fallback not in folders:
            folders.append(fallback)
    return folders


def _skin_reference_height(root):
    rows = _skin_resolution_info(root)
    if rows:
        try:
            return max(1.0, float(rows[0][1]))
        except Exception:
            pass
    return 1080.0


def _font_xml_candidates(root):
    seen = set()
    for folder in _resolution_folders(root):
        path = os.path.join(root, folder, 'Font.xml') if folder else os.path.join(root, 'Font.xml')
        norm = os.path.normcase(os.path.normpath(path))
        if norm not in seen:
            seen.add(norm)
            yield path
    fonts_dir = os.path.join(root, 'fonts')
    try:
        for name in sorted(os.listdir(fonts_dir)):
            if not name.lower().endswith('.xml'):
                continue
            path = os.path.join(fonts_dir, name)
            norm = os.path.normcase(os.path.normpath(path))
            if norm not in seen:
                seen.add(norm)
                yield path
    except Exception:
        pass


def _parse_fontset_file(path, requested_fontset):
    try:
        root = ET.parse(path).getroot()
    except Exception:
        return None, []
    sets = list(root.findall('fontset'))
    if not sets:
        return None, []
    chosen = None
    for node in sets:
        if str(node.attrib.get('id') or '').lower() == str(requested_fontset or '').lower():
            chosen = node
            break
    if chosen is None:
        return None, []
    records = []
    for node in chosen.findall('font'):
        name = str(node.findtext('name') or '').strip()
        raw_size = str(node.findtext('size') or '').strip()
        try:
            size = float(raw_size)
        except Exception:
            continue
        if not name or size <= 0:
            continue
        style = str(node.findtext('style') or '').strip().lower()
        try:
            aspect = float(str(node.findtext('aspect') or '1').strip())
        except Exception:
            aspect = 1.0
        records.append({
            'name': name,
            'size': size,
            'style': style,
            'aspect': aspect,
        })
    return str(chosen.attrib.get('id') or requested_fontset), records


def _active_fonts(root, requested_fontset):
    first_available = None
    for path in _font_xml_candidates(root):
        try:
            doc = ET.parse(path).getroot()
            sets = list(doc.findall('fontset'))
            if sets and first_available is None:
                first_available = (path, str(sets[0].attrib.get('id') or ''))
        except Exception:
            continue
        selected, records = _parse_fontset_file(path, requested_fontset)
        if selected and records:
            return path, selected, records
    # Kodi itself falls back to the first fontset when a requested set is not
    # available. Mirror that behavior for the compatibility map.
    if first_available:
        path, first_id = first_available
        selected, records = _parse_fontset_file(path, first_id)
        if selected and records:
            return path, selected, records
    return '', '', []


def _font_score(record, target_size):
    size = float(record.get('effective_size') or record['size'])
    score = abs(size - float(target_size)) * 100.0
    name = str(record['name'] or '').lower()
    style = str(record.get('style') or '').lower()
    # ONEPLAY's homologated Estuary controls are normal/lighten. Avoid title,
    # mono, narrow and decorative aliases when an equally sized regular font
    # exists in the third-party skin.
    if 'bold' in style:
        score += 35.0
    if 'italic' in style:
        score += 35.0
    if 'title' in name:
        score += 20.0
    if 'narrow' in name:
        score += 18.0
    if 'mono' in name or 'clock' in name or 'weather' in name:
        score += 40.0
    score += abs(float(record.get('aspect') or 1.0) - 1.0) * 20.0
    # Stable tie breaker: generic-looking aliases first, then lexical order.
    if name.startswith('font'):
        score -= 0.5
    return (score, name)


def _choose_font(records, target_size):
    if not records:
        return ''
    return min(records, key=lambda row: _font_score(row, target_size))['name']


def _reference_size(font_name):
    name = str(font_name or '').strip()
    if not name:
        return _DEFAULT_FALLBACK_SIZE
    exact = _ESTUARY_FONT_SIZES.get(name)
    if exact is not None:
        return exact
    lower = name.lower()
    for key, value in _ESTUARY_FONT_SIZES.items():
        if str(key).lower() == lower:
            return value
    return _DEFAULT_FALLBACK_SIZE


def _font_map(records, source_xml_dir):
    names = set()
    try:
        for filename in os.listdir(source_xml_dir):
            if not filename.lower().endswith('.xml'):
                continue
            text = open(os.path.join(source_xml_dir, filename), 'r', encoding='utf-8').read()
            names.update(re.findall(r'<font>\s*([^<]+?)\s*</font>', text, flags=re.I))
    except Exception:
        return {}
    mapping = {}
    for name in sorted(names):
        target = _reference_size(name)
        chosen = _choose_font(records, target)
        if chosen:
            mapping[name] = chosen
    return mapping


def _replace_fonts(text, mapping):
    def repl(match):
        original = str(match.group(1) or '').strip()
        chosen = mapping.get(original)
        if not chosen:
            for key, value in mapping.items():
                if str(key).lower() == original.lower():
                    chosen = value
                    break
        return '<font>%s</font>' % (chosen or original)
    return re.sub(r'<font>\s*([^<]+?)\s*</font>', repl, text, flags=re.I)


def _file_signature(path):
    try:
        st = os.stat(path)
        return '%s:%s:%s' % (os.path.normcase(os.path.normpath(path)), st.st_size, getattr(st, 'st_mtime_ns', int(st.st_mtime * 1e9)))
    except Exception:
        return str(path or '')


def _directory_signature(path):
    """Fingerprint packaged WindowXML so compatibility copies cannot go stale."""
    rows = []
    try:
        for filename in sorted(os.listdir(path)):
            source = os.path.join(path, filename)
            if os.path.isfile(source):
                rows.append('%s=%s' % (filename, _file_signature(source)))
    except Exception:
        return str(path or '')
    return hashlib.sha256('|'.join(rows).encode('utf-8')).hexdigest()


def _copy_media(source_media, target_media):
    if os.path.isdir(target_media):
        return
    os.makedirs(os.path.dirname(target_media), exist_ok=True)
    shutil.copytree(source_media, target_media)


def _cleanup_old_roots(parent, keep):
    try:
        for name in os.listdir(parent):
            path = os.path.join(parent, name)
            if os.path.normcase(os.path.normpath(path)) == os.path.normcase(os.path.normpath(keep)):
                continue
            if os.path.isdir(path):
                shutil.rmtree(path, ignore_errors=True)
    except Exception:
        pass


def _prepare_compat(addon_path, default_skin='Default', default_res='1080i'):
    skin_id = _active_skin_id()
    # Estuary is the homologated reference: never interpose generated XMLs.
    if not skin_id or skin_id == 'skin.estuary':
        return None
    skin_root = _skin_root()
    if not skin_root or not os.path.isdir(skin_root):
        return None
    requested_fontset = _active_fontset()
    font_xml, selected_fontset, records = _active_fonts(skin_root, requested_fontset)
    reference_height = _skin_reference_height(skin_root)
    scale_to_1080 = 1080.0 / max(1.0, float(reference_height or 1080.0))
    for row in records:
        row['effective_size'] = float(row.get('size') or 0.0) * scale_to_1080
    if not records:
        log('Skin compat: Font.xml da skin ativa não pôde ser mapeado; usando XML original.', 'warning')
        return None

    source_xml_dir = os.path.join(addon_path, 'resources', 'skins', default_skin, default_res)
    source_media = os.path.join(addon_path, 'resources', 'skins', default_skin, 'media')
    if not os.path.isdir(source_xml_dir) or not os.path.isdir(source_media):
        return None
    mapping = _font_map(records, source_xml_dir)
    if not mapping:
        return None

    # A assinatura dos XMLs empacotados faz uma atualização de layout gerar
    # outra raiz. Sem isso, skins diferentes da Estuary poderiam continuar
    # reutilizando uma cópia antiga do banner após atualizar o addon.
    key_material = '|'.join((
        'v1', skin_id, selected_fontset, _file_signature(font_xml),
        hashlib.sha256(repr(sorted(mapping.items())).encode('utf-8')).hexdigest(),
        _directory_signature(source_xml_dir),
    ))
    key = hashlib.sha256(key_material.encode('utf-8')).hexdigest()[:20]
    cached = _COMPAT_CACHE.get(key)
    if cached and os.path.isdir(cached):
        return cached, mapping, skin_id, selected_fontset

    parent = os.path.join(profile_dir(), _COMPAT_DIR_NAME)
    root = os.path.join(parent, key)
    target_xml_dir = os.path.join(root, 'resources', 'skins', default_skin, default_res)
    target_media = os.path.join(root, 'resources', 'skins', default_skin, 'media')
    marker = os.path.join(root, '.ready')
    if not os.path.isfile(marker):
        tmp = root + '.tmp'
        shutil.rmtree(tmp, ignore_errors=True)
        os.makedirs(os.path.join(tmp, 'resources', 'skins', default_skin, default_res), exist_ok=True)
        tmp_xml_dir = os.path.join(tmp, 'resources', 'skins', default_skin, default_res)
        for filename in os.listdir(source_xml_dir):
            src = os.path.join(source_xml_dir, filename)
            dst = os.path.join(tmp_xml_dir, filename)
            if not os.path.isfile(src):
                continue
            if filename.lower().endswith('.xml'):
                text = open(src, 'r', encoding='utf-8').read()
                text = _replace_fonts(text, mapping)
                with open(dst, 'w', encoding='utf-8', newline='') as fh:
                    fh.write(text)
            else:
                shutil.copy2(src, dst)
        _copy_media(source_media, os.path.join(tmp, 'resources', 'skins', default_skin, 'media'))
        with open(os.path.join(tmp, '.ready'), 'w', encoding='utf-8') as fh:
            json.dump({'skin': skin_id, 'fontset': selected_fontset, 'mapping': mapping}, fh, ensure_ascii=False, sort_keys=True)
        shutil.rmtree(root, ignore_errors=True)
        os.replace(tmp, root)
        _cleanup_old_roots(parent, root)
        log('Skin compat: tipografia ONEPLAY normalizada para %s / %s.' % (skin_id, selected_fontset), 'info')

    if not os.path.isdir(target_xml_dir) or not os.path.isdir(target_media):
        return None
    _COMPAT_CACHE.clear()
    _COMPAT_CACHE[key] = root
    return root, mapping, skin_id, selected_fontset


def window_xml_args(xml_name, addon_path, default_skin='Default', default_res='1080i'):
    """Return WindowXML constructor args, with fail-open compatibility.

    On Estuary or on any parsing/copy failure, return the original add-on path.
    No caller is allowed to fail solely because compatibility could not be
    prepared.
    """
    original = (str(xml_name), str(addon_path), str(default_skin), str(default_res))
    try:
        prepared = _prepare_compat(str(addon_path), str(default_skin), str(default_res))
        if not prepared:
            return original
        root, _mapping, _skin_id, _fontset = prepared
        xml_path = os.path.join(root, 'resources', 'skins', str(default_skin), str(default_res), str(xml_name))
        if not os.path.isfile(xml_path):
            return original
        return (str(xml_name), root, str(default_skin), str(default_res))
    except Exception as exc:
        log('Skin compat: falha conservadora (%s); usando XML original.' % exc, 'warning')
        return original
