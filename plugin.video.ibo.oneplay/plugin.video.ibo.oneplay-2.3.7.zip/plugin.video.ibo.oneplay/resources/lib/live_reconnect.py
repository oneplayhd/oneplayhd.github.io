# -*- coding: utf-8 -*-
"""Pure policy for bounded and resettable Live recovery."""

RECONNECT_BACKOFFS = (1.0, 2.0, 4.0)
FALLBACK_BACKOFFS = RECONNECT_BACKOFFS
STABLE_RESET_SECONDS = 60.0
FALLBACK_MAX_CYCLES = 3


def fallback_cycles_exhausted(completed_cycles):
    """Return True only after the configured number of complete ring passes."""
    try:
        return int(completed_cycles) >= FALLBACK_MAX_CYCLES
    except (TypeError, ValueError):
        return False


def next_fallback_cycle(completed_cycles):
    """Return ``(cycle_number, delay)`` for the next complete ring pass."""
    try:
        completed = max(0, int(completed_cycles or 0))
    except (TypeError, ValueError):
        completed = 0
    if completed >= FALLBACK_MAX_CYCLES:
        return None
    return completed + 1, FALLBACK_BACKOFFS[completed]


def stable_live_recovery(outcome):
    """Recognize an unexpected Live drop after a healthy 60-second recovery."""
    outcome = outcome if isinstance(outcome, dict) else {}
    if not outcome.get('reconnectable'):
        return False
    try:
        stable_for = max(0.0, float(outcome.get('playback_seconds') or 0.0))
    except (TypeError, ValueError):
        stable_for = 0.0
    return stable_for >= STABLE_RESET_SECONDS


def authorization_denied(outcome):
    """Recognize the sanitized authorization failures returned by playback."""
    outcome = outcome if isinstance(outcome, dict) else {}
    if outcome.get('authorization_lost'):
        return True
    text = str(outcome.get('error') or '').casefold()
    return any(marker in text for marker in (
        'não autorizado', 'não autorizou', 'acesso negado',
        'conteúdo bloqueado', 'servidor negou', 'http 401', 'http 403',
    ))


def unexpected_live_termination(kind, reason):
    """Only explicit Kodi EOF/error callbacks authorize an automatic retry."""
    return str(kind or '') == 'live' and str(reason or '') in ('ended', 'error')


def next_reconnect(attempts_used, outcome):
    """Return ``(new_count, delay)`` or ``None`` when this cycle must stop.

    A playback that remained healthy for 60 seconds starts a fresh cycle.  A
    short-lived recovery consumes the remaining budget instead.
    """
    outcome = outcome if isinstance(outcome, dict) else {}
    if not outcome.get('reconnectable'):
        return None
    try:
        used = max(0, int(attempts_used or 0))
    except Exception:
        used = 0
    if stable_live_recovery(outcome):
        used = 0
    if used >= len(RECONNECT_BACKOFFS):
        return None
    return used + 1, RECONNECT_BACKOFFS[used]
