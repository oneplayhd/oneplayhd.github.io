# -*- coding: utf-8 -*-
import re
from .constants import ADDON_VERSION
try:
    import xbmc
except Exception:
    xbmc = None

_URL = re.compile(r'(?i)\b(?:https?|plugin)://[^\s<>"\']+')
_SECRET = re.compile(
    r'''(?ix)(["']?(?:password|passwd|username|authorization|token|control_token|pin|app_device_id)["']?\s*[:=]\s*)
    (?:"[^"]*"|'[^']*'|[^\s,;&}]+)''')


def redact(message):
    # Exceptions can embed upstream URLs (Xtream user/password path or query),
    # opaque relay handles and dict-like payloads. Do not send those to Kodi.
    text = _URL.sub('[URL omitida]', str(message))
    text = _SECRET.sub(lambda match: match.group(1) + '[omitido]', text)
    return text.replace('\r', ' ').replace('\n', ' ')[:4096]


def log(message, level='info'):
    text = '[IBO %s] %s' % (ADDON_VERSION, redact(message))
    if xbmc is None:
        return
    levels = {
        'debug': xbmc.LOGDEBUG,
        'warning': xbmc.LOGWARNING,
        'error': xbmc.LOGERROR,
        'info': xbmc.LOGINFO,
    }
    xbmc.log(text, levels.get(level, xbmc.LOGINFO))
