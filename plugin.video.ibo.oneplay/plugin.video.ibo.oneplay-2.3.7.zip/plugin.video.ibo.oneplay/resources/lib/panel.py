# -*- coding: utf-8 -*-
import base64
import html
import json
import re
import threading
import time
import urllib.parse

from .aes import decode_panel_envelope
from .constants import APP_VERSION_CODE, DEFAULT_PANEL_URL, DEVICE_TYPE
from .device import get_device_id, get_device_identity_source, has_verified_device_identity
from .http import HttpError, join_url, request, request_json
from .log import log
from .prefs import get_str


def panel_base_url():
    value = get_str('panel_url', DEFAULT_PANEL_URL) or DEFAULT_PANEL_URL
    value = str(value).strip()
    try:
        parsed = urllib.parse.urlsplit(value)
        invalid = (
            parsed.scheme.lower() != 'https' or
            not parsed.hostname or
            parsed.username is not None or
            parsed.password is not None or
            bool(parsed.query) or
            bool(parsed.fragment) or
            any(ord(char) < 32 or ord(char) == 127 for char in value)
        )
        # Accessing port also rejects malformed/non-numeric port values.
        _port = parsed.port
    except (TypeError, ValueError):
        invalid = True
    if invalid:
        log('URL da API de controle recusada; usando endpoint HTTPS padrão.', 'warning')
        value = DEFAULT_PANEL_URL
    return value.rstrip('/') + '/'


def api_url(path):
    return join_url(panel_base_url(), path)


def _require_auto_test_identity():
    if not has_verified_device_identity():
        raise HttpError(
            'Teste automático indisponível: não foi possível verificar a identidade '
            'deste aparelho. Solicite a ativação manual ao suporte.')


def _auth_payload(skip_auto_test=True, skip_failover=False, media_failover=False, target_portal_id=''):
    if not skip_auto_test:
        _require_auto_test_identity()
    device_id = get_device_id()
    inner = {
        'app_device_id': base64.b64encode(device_id.encode('ascii')).decode('ascii'),
        'mac_address': device_id,
        'app_version_code': APP_VERSION_CODE,
        'device_type': DEVICE_TYPE,
    }
    # Contrato Kodi: autenticação normal nunca dispara Teste Automático por
    # efeito colateral. O APK Android antigo não envia esta chave e preserva
    # seu comportamento homologado.
    if skip_auto_test:
        inner['skip_auto_test'] = 1
    if skip_failover:
        inner['skip_failover'] = 1
    # Kodi V2.0.52: compatibilidade do failover de mídia pelo auth.php.
    # V2.0.53 usa media_failover.php e não passa por este caminho pesado.
    # APKs/clientes antigos não enviam estes campos e seguem pelo contrato histórico.
    if media_failover:
        inner['media_failover'] = 1
        if str(target_portal_id or '').strip():
            inner['target_portal_id'] = str(target_portal_id).strip()
    encoded = base64.b64encode(json.dumps(inner, separators=(',', ':')).encode('utf-8')).decode('ascii')
    return {'data': encoded}


def _kodi_access_payload(target_portal_id):
    device_id = get_device_id()
    inner = {
        'app_device_id': base64.b64encode(device_id.encode('ascii')).decode('ascii'),
        'mac_address': device_id,
        'app_version_code': APP_VERSION_CODE,
        'device_type': DEVICE_TYPE,
        'client_contract': 'ibo-kodi-access-v1',
        'target_portal_id': str(target_portal_id or '').strip(),
    }
    encoded = base64.b64encode(json.dumps(inner, separators=(',', ':')).encode('utf-8')).decode('ascii')
    return {'data': encoded}


def _kodi_auto_test_payload(action='run', contract='ibo-kodi-auto-test-v2'):
    # V1 has no read-only action. Gate every route that can generate a trial,
    # including the legacy auth fallback, without changing the wire contract.
    if (str(contract or 'ibo-kodi-auto-test-v2') != 'ibo-kodi-auto-test-v2'
            or str(action or '').strip().lower() != 'state'):
        _require_auto_test_identity()
    device_id = get_device_id()
    inner = {
        'app_device_id': base64.b64encode(device_id.encode('ascii')).decode('ascii'),
        'mac_address': device_id,
        'app_version_code': APP_VERSION_CODE,
        'device_type': DEVICE_TYPE,
        'client_contract': str(contract or 'ibo-kodi-auto-test-v2'),
    }
    if inner['client_contract'] == 'ibo-kodi-auto-test-v2':
        inner['action'] = 'state' if str(action or '').strip().lower() == 'state' else 'run'
    encoded = base64.b64encode(json.dumps(inner, separators=(',', ':')).encode('utf-8')).decode('ascii')
    return {'data': encoded}




def _origin_only(value):
    """Return only scheme://host[:port], never Xtream path credentials."""
    raw = str(value or '').split('|', 1)[0].strip()
    try:
        parsed = urllib.parse.urlparse(raw)
    except Exception:
        return ''
    if parsed.scheme not in ('http', 'https') or not parsed.netloc:
        return ''
    return '%s://%s' % (parsed.scheme.lower(), parsed.netloc)

def _media_failover_payload(target_portal_id, failed_url='', excluded_urls=None):
    device_id = get_device_id()
    inner = {
        'app_device_id': base64.b64encode(device_id.encode('ascii')).decode('ascii'),
        'mac_address': device_id,
        'app_version_code': APP_VERSION_CODE,
        'device_type': DEVICE_TYPE,
        'target_portal_id': str(target_portal_id or '').strip(),
        # O endpoint usa somente a origem para excluir DNS já testada. Não
        # envie /live|movie|series/usuario/senha ao painel sem necessidade.
        'failed_url': _origin_only(failed_url)[:512],
    }
    cleaned = []
    for value in list(excluded_urls or [])[:12]:
        value = _origin_only(value)
        if value and value not in cleaned:
            cleaned.append(value[:512])
    if cleaned:
        inner['excluded_urls'] = cleaned
    encoded = base64.b64encode(json.dumps(inner, separators=(',', ':')).encode('utf-8')).decode('ascii')
    return {'data': encoded}


class PanelClient(object):
    def auth(self, failed_url='', failed_reason='', timeout=None, allow_auto_test=False, allow_failover=True, media_failover=False, target_portal_id=''):
        payload = _auth_payload(
            skip_auto_test=not bool(allow_auto_test),
            skip_failover=not bool(allow_failover),
            media_failover=bool(media_failover),
            target_portal_id=target_portal_id,
        )
        if failed_url:
            payload['failed_url'] = str(failed_url)[:512]
            payload['failed_reason'] = str(failed_reason or 'client_failure')[:80]
        _s, _h, outer = request_json(api_url('auth'), method='POST', payload=payload, timeout=timeout)
        try:
            data = decode_panel_envelope(outer)
        except Exception as exc:
            raise HttpError('Envelope IBO inválido: %s' % exc, url=api_url('auth'))
        if not isinstance(data, dict):
            raise HttpError('Resposta IBO inválida.', url=api_url('auth'))
        return data

    def kodi_access(self, target_portal_id, timeout=2.5):
        """Lê o contexto de um acesso vinculado sem passar pelo auth.php.

        O endpoint é exclusivo do Kodi e somente leitura. Assim como no
        failover de mídia, uma thread daemon funciona como fusível de tempo de
        parede para impedir que uma resposta parcial mantenha a UI bloqueada.
        """
        endpoint = api_url('kodi_access.php')
        payload = _kodi_access_payload(target_portal_id)
        total_timeout = max(0.25, float(timeout or 2.5))
        box = {}

        def _worker():
            try:
                box['value'] = request_json(
                    endpoint, method='POST', payload=payload,
                    timeout=min(total_timeout, 2.5),
                )
            except Exception as exc:
                box['error'] = exc

        worker = threading.Thread(target=_worker, name='IBOKodiAccess')
        worker.daemon = True
        worker.start()
        worker.join(total_timeout)
        if worker.is_alive():
            raise HttpError('Tempo total excedido no bootstrap de acesso.', transport=True, url=endpoint)
        if 'error' in box:
            raise box['error']
        try:
            _s, _h, outer = box['value']
        except Exception:
            raise HttpError('Resposta ausente no bootstrap de acesso.', transport=True, url=endpoint)
        try:
            data = decode_panel_envelope(outer)
        except Exception as exc:
            raise HttpError('Envelope de bootstrap de acesso inválido: %s' % exc, url=endpoint)
        if not isinstance(data, dict):
            raise HttpError('Resposta de bootstrap de acesso inválida.', url=endpoint)
        return data

    def kodi_auto_test(self, action='run', timeout=18.0, contract='ibo-kodi-auto-test-v2'):
        """Consulta/executa o contrato de Teste Automático exclusivo do Kodi.

        V2.21 separa ``state`` (somente leitura do registro em tests.php) de
        ``run`` (única ação que pode alcançar o fornecedor). O contrato V1 é
        mantido apenas para compatibilidade com o Painel V2.20.
        """
        endpoint = api_url('kodi_auto_test.php')
        payload = _kodi_auto_test_payload(action=action, contract=contract)
        total_timeout = max(1.0, min(float(timeout or 18.0), 20.0))
        box = {}

        def _worker():
            try:
                box['value'] = request_json(
                    endpoint, method='POST', payload=payload,
                    timeout=min(total_timeout, 18.0),
                )
            except Exception as exc:
                box['error'] = exc

        worker = threading.Thread(target=_worker, name='IBOKodiAutoTest-%s' % str(action or 'run'))
        worker.daemon = True
        worker.start()
        worker.join(total_timeout)
        if worker.is_alive():
            raise HttpError('Tempo total excedido no Teste Automático do Kodi.', transport=True, url=endpoint)
        if 'error' in box:
            raise box['error']
        try:
            _s, _h, outer = box['value']
        except Exception:
            raise HttpError('Resposta ausente no Teste Automático do Kodi.', transport=True, url=endpoint)
        try:
            data = decode_panel_envelope(outer)
        except Exception as exc:
            raise HttpError('Envelope do Teste Automático do Kodi inválido: %s' % exc, url=endpoint)
        if not isinstance(data, dict):
            raise HttpError('Resposta do Teste Automático do Kodi inválida.', url=endpoint)
        return data

    def media_failover_candidate(self, target_portal_id, failed_url='', excluded_urls=None, timeout=2.5):
        """Consulta o seletor mínimo de DNS com prazo total de parede.

        ``urllib`` aplica timeout às operações de socket, mas uma resposta que
        progride em pequenas etapas pode ultrapassar esse valor no relógio. Para
        uma ação interativa de reprodução isso não é aceitável. Esta chamada
        usa uma thread daemon exclusivamente como fusível de prazo total; se o
        endpoint não terminar no limite, a UI recebe falha imediatamente.
        """
        endpoint = api_url('media_failover.php')
        payload = _media_failover_payload(target_portal_id, failed_url=failed_url, excluded_urls=excluded_urls)
        total_timeout = max(0.25, float(timeout or 2.5))
        box = {}

        def _worker():
            try:
                box['value'] = request_json(
                    endpoint, method='POST', payload=payload,
                    timeout=min(total_timeout, 2.5),
                )
            except Exception as exc:
                box['error'] = exc

        worker = threading.Thread(target=_worker, name='IBOMediaFailover')
        worker.daemon = True
        worker.start()
        worker.join(total_timeout)
        if worker.is_alive():
            raise HttpError('Tempo total excedido no failover de mídia.', transport=True, url=endpoint)
        if 'error' in box:
            raise box['error']
        try:
            _s, _h, outer = box['value']
        except Exception:
            raise HttpError('Resposta ausente no failover de mídia.', transport=True, url=endpoint)
        try:
            data = decode_panel_envelope(outer)
        except Exception as exc:
            raise HttpError('Envelope de failover de mídia inválido: %s' % exc, url=endpoint)
        if not isinstance(data, dict):
            raise HttpError('Resposta de failover de mídia inválida.', url=endpoint)
        return data

    def index_state(self, timeout=None):
        endpoint = api_url('index.php') + '?' + urllib.parse.urlencode({'mac': get_device_id()})
        started = time.monotonic()
        try:
            _s, _h, outer = request_json(endpoint, timeout=timeout)
        except HttpError as exc:
            log('index.php falhou em %dms (fase=%s, status=%s, retry_after=%ss, did_source=%s).' % (
                int(getattr(exc, 'elapsed_ms', 0) or 0), str(getattr(exc, 'phase', '') or 'unknown'),
                str(getattr(exc, 'status', '') or 'rede'), int(getattr(exc, 'retry_after', 0) or 0),
                get_device_identity_source() or 'unknown'), 'warning')
            raise
        try:
            data = decode_panel_envelope(outer)
        except Exception as exc:
            raise HttpError('Estado IBO inválido: %s' % exc, url=endpoint, phase='decode', elapsed_ms=int((time.monotonic()-started)*1000))
        if isinstance(data, dict):
            server_ms = int(data.get('elapsed_ms') or 0)
            log('index.php concluído em %dms (servidor=%dms, did_source=%s).' % (
                int(max(0.0, time.monotonic()-started)*1000), server_ms, get_device_identity_source() or 'unknown'), 'debug')
            return data
        return {}

    @staticmethod
    def dns_from_state(state):
        rows = (state or {}).get('portals') or (state or {}).get('urls') or (state or {}).get('dns') or []
        out = []
        seen = set()
        for row in rows if isinstance(rows, list) else []:
            if not isinstance(row, dict):
                continue
            dns_id = str(row.get('id') or row.get('dns_id') or '').strip()
            url = str(row.get('url') or row.get('dns') or '').strip().rstrip('/')
            name = str(row.get('name') or row.get('title') or ('DNS ' + dns_id)).strip()
            marker = (dns_id, url.lower())
            if dns_id and url and marker not in seen:
                seen.add(marker)
                out.append({
                    'id': dns_id,
                    'url': url,
                    'name': name,
                    # Contrato oficial do painel/APK: somente DNSs com o mesmo
                    # failover_group são espelhos entre si. A prioridade menor
                    # é tentada primeiro dentro do grupo.
                    'failover_group': str(row.get('failover_group') or '').strip(),
                    'failover_priority': row.get('failover_priority'),
                })
        return out

    @staticmethod
    def accesses_from_state(state):
        rows = (state or {}).get('accesses') or []
        out = []
        seen = set()
        for row in rows if isinstance(rows, list) else []:
            if not isinstance(row, dict):
                continue
            dns_id = str(row.get('id') or row.get('dns_id') or '').strip()
            if not dns_id or dns_id in seen:
                continue
            seen.add(dns_id)
            out.append({
                'id': dns_id,
                'name': str(row.get('name') or row.get('title') or ('DNS ' + dns_id)).strip(),
                'is_protected': '1' if str(row.get('is_protected') or '').lower() in ('1','true','yes','on') else '0',
            })
        return out

    def list_dns(self, timeout=None):
        state = self.index_state(timeout=timeout)
        out = self.dns_from_state(state)
        log('index.php retornou %d DNS.' % len(out))
        return out

    def add_access(self, dns_id, username, password, timeout=None):
        payload = {
            'dns_id': str(dns_id),
            'username': str(username),
            'password': str(password),
            'device_id': get_device_id(),
        }
        _s, _h, data = request_json(api_url('add.php'), method='POST', payload=payload, timeout=timeout)
        return data if isinstance(data, dict) else {}

    def delete_access(self, dns_id, timeout=None):
        payload = {'device_id': get_device_id(), 'dns_id': str(dns_id), 'delete': 1}
        _s, _h, data = request_json(api_url('update.php'), method='POST', payload=payload, timeout=timeout)
        return data if isinstance(data, dict) else {}

    def update_parental_pin(self, pin, timeout=None):
        """Atualiza o PIN parental central do dispositivo no painel.

        Contrato existente do ``update.php``/APK: ``device_id`` identifica o
        aparelho e ``parent_control`` contém o novo PIN. O painel aplica o
        valor às playlists vinculadas ao mesmo dispositivo e o devolve na
        resposta. Nenhum PIN paralelo é persistido pelo add-on.
        """
        value = str(pin or '').strip()
        if len(value) != 4 or not value.isdigit():
            raise ValueError('O PIN deve conter exatamente 4 dígitos.')
        payload = {'device_id': get_device_id(), 'parent_control': value}
        _s, _h, data = request_json(api_url('update.php'), method='POST', payload=payload, timeout=timeout)
        return data if isinstance(data, dict) else {}

    def health(self, username, server_url, max_connections, timeout=None):
        payload = {
            'device_id': get_device_id(),
            'username': str(username or ''),
            'server_url': str(server_url or ''),
            'max_connections': str(max_connections if max_connections is not None else ''),
        }
        _s, _h, data = request_json(api_url('health.php'), method='POST', payload=payload, timeout=timeout)
        return data if isinstance(data, dict) else {}

    def health_kodi(self, portal_id, max_connections, timeout=None):
        """Heartbeat Kodi resolvido exclusivamente pelo Device ID + acesso lógico.

        Usuário/senha não atravessam este contrato. O painel localiza a playlist
        vinculada ao mesmo Device ID/portal e aplica a política de conexões usando
        as credenciais que já possui no banco. O método ``health`` legado continua
        intacto para APK/clientes antigos.
        """
        payload = {
            'device_id': get_device_id(),
            'device_type': DEVICE_TYPE,
            'client_contract': 'ibo-kodi-health-v1',
            'portal_id': str(portal_id or '').strip(),
            'max_connections': str(max_connections if max_connections is not None else ''),
        }
        _s, _h, data = request_json(api_url('health.php'), method='POST', payload=payload, timeout=timeout)
        return data if isinstance(data, dict) else {}

    @staticmethod
    def _media_kind(url, timeout=2):
        """Classifica URL de anúncio sem baixar o arquivo inteiro.

        O painel manual aceita imagem e vídeo. A Home Kodi, porém, usa uma
        texture estática; portanto nunca devemos entregar MP4/WebM para ela.
        O ad_media.php preserva o nome original no parâmetro ``f``, o que
        permite classificar uploads locais sem uma requisição extra.
        """
        value = str(url or '').strip()
        if not value:
            return ''
        try:
            parsed = urllib.parse.urlparse(value)
            query = urllib.parse.parse_qs(parsed.query or '')
            media_path = (query.get('f') or [''])[0] or parsed.path or value
        except Exception:
            media_path = value
        clean = str(media_path).split('?', 1)[0].split('#', 1)[0].lower()
        image_ext = ('.jpg', '.jpeg', '.png', '.gif', '.webp')
        video_ext = ('.mp4', '.webm', '.ogg', '.mkv', '.m3u8', '.ts')
        if clean.endswith(image_ext):
            return 'image'
        if clean.endswith(video_ext):
            return 'video'

        # CDNs/URLs assinadas podem não possuir extensão. HEAD é suficiente
        # para confirmar o Content-Type sem colocar a mídia inteira em RAM.
        try:
            _s, headers, _raw = request(value, method='HEAD', timeout=timeout, max_bytes=1024)
            ctype = str((headers or {}).get('Content-Type') or (headers or {}).get('content-type') or '').lower()
            if ctype.startswith('image/'):
                return 'image'
            if ctype.startswith('video/') or 'mpegurl' in ctype:
                return 'video'
        except Exception:
            pass
        return ''

    def manual_banner_urls(self, timeout=3, limit=12):
        """Retorna imagens válidas cadastradas em Ads, preservando a ordem."""
        out = []
        seen = set()
        try:
            _s, _h, data = request_json(api_url('ads.php'), timeout=timeout)
            if isinstance(data, list):
                for row in data:
                    value = str((row or {}).get('AdUrl') or '').strip()
                    if not value:
                        continue
                    url = urllib.parse.urljoin(panel_base_url(), value)
                    if url in seen:
                        continue
                    if self._media_kind(url, timeout=min(max(float(timeout or 2), 1.0), 2.0)) != 'image':
                        continue
                    seen.add(url)
                    out.append(url)
                    if len(out) >= max(1, int(limit or 12)):
                        break
        except Exception as exc:
            log('Banner manual indisponível: %s' % exc, 'debug')
        return out

    def manual_banner_url(self, timeout=3):
        """Retorna a primeira imagem válida cadastrada em Ads.

        O Tema 2 mantém um único slot. Temas 3..5 podem usar
        ``manual_banner_urls`` para alternar várias imagens.
        """
        rows = self.manual_banner_urls(timeout=timeout, limit=1)
        return rows[0] if rows else ''

    def home_banner_url(self, panel=None, timeout=3):
        """Resolve o banner conforme o mesmo backdrop.php usado pelo painel.

        Nesta etapa a V2 cobre o slot de imagem do Tema 2. Se o painel estiver
        em TMDB, não reaproveitamos anúncios manuais antigos por engano; o
        fallback visual permanece até uma evolução TMDB específica.
        """
        panel = panel or {}
        home_url = str(panel.get('home_url1') or panel.get('home_url2') or '').strip()
        mode = self.backdrop_mode(home_url=home_url, timeout=timeout)
        if mode != 'manual':
            return ''
        return self.manual_banner_url(timeout=timeout)

    def backdrop_mode(self, home_url='', timeout=3):
        url = str(home_url or '').strip() or api_url('backdrop.php')
        if not urllib.parse.urlparse(url).scheme:
            url = urllib.parse.urljoin(panel_base_url(), url)
        try:
            _s, _h, raw = request(url, timeout=timeout, max_bytes=256 * 1024)
            text = raw.decode('utf-8', 'ignore').lower()
            if 'movies_script.js' in text or 'tmdb-theme-' in text:
                return 'tmdb'
            if 'ads.php' in text or 'slideshow' in text:
                return 'manual'
        except Exception:
            pass
        return 'manual'


    def home_showcase(self, panel=None, timeout=3, limit=12, mode=''):
        """Resolve o destaque visual dos Temas 2, 3, 4 e 5 pelo contrato atual.

        Em modo TMDB consome apenas ``api/movies.php`` do próprio painel, que
        já entrega backdrop, poster, título e descrição com cache no servidor.
        Em modo manual reutiliza as imagens válidas de Ads como slides nativos. Nenhuma chamada direta do Kodi ao TMDB e nenhum contrato novo.
        """
        panel = panel or {}
        mode = str(mode or '').strip().lower()
        if mode not in ('tmdb', 'manual'):
            mode = self.backdrop_mode(
                home_url=str(panel.get('home_url1') or panel.get('home_url2') or ''),
                timeout=timeout,
            )
        slides = []
        if mode == 'tmdb':
            try:
                _s, _h, data = request_json(api_url('movies.php'), timeout=timeout)
                rows = data if isinstance(data, list) else []
                for row in rows:
                    if not isinstance(row, dict):
                        continue
                    image = str(row.get('image') or '').strip()
                    if not image:
                        continue
                    slides.append({
                        'image': image,
                        'poster': str(row.get('artWork') or '').strip(),
                        'title': str(row.get('title') or '').strip(),
                        'plot': str(row.get('subtitle') or '').strip(),
                        'kind': str(row.get('tipo') or '').strip(),
                    })
                    if len(slides) >= max(1, int(limit or 12)):
                        break
            except Exception as exc:
                log('Destaque TMDB indisponível: %s' % exc, 'debug')
        else:
            try:
                images = self.manual_banner_urls(timeout=timeout, limit=limit)
            except Exception:
                images = []
            for image in images:
                slides.append({'image': image, 'poster': '', 'title': '', 'plot': '', 'kind': 'manual'})
        return {'mode': mode, 'slides': slides}

    def games_view(self, timeout=4):
        """Lê o WebView de Esportes/Jogos existente e o adapta ao Kodi.

        Não cria contrato novo no painel e não altera o APK. O painel continua
        sendo a fonte única de ``sports.php``/``api/esporte.php``; aqui apenas
        extraímos o cabeçalho e as URLs das imagens para uma tela nativa Kodi.
        """
        endpoint = api_url('esporte.php') + '?view=grid'
        _s, _h, raw = request(endpoint, timeout=timeout, max_bytes=768 * 1024)
        text = raw.decode('utf-8', 'ignore')

        title = 'JOGOS'
        match = re.search(r"<div\s+class=[\'\"]topbar[\'\"][^>]*>(.*?)</div>", text, re.I | re.S)
        if match:
            clean = re.sub(r'<[^>]+>', '', match.group(1))
            clean = html.unescape(clean).strip()
            if clean:
                title = clean[:80]

        images = []
        seen = set()
        for src in re.findall(r"<img[^>]+src=[\'\"]([^\'\"]+)[\'\"]", text, re.I):
            src = html.unescape(str(src or '').strip())
            if not src or 'sports_image.php' not in src:
                continue
            url = urllib.parse.urljoin(endpoint, src)
            if url not in seen:
                seen.add(url)
                images.append(url)

        return {'title': title, 'images': images}
