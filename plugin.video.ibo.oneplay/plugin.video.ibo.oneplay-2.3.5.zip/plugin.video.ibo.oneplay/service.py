# -*- coding: utf-8 -*-
"""2.2.8 hybrid service.

Opening/UI ownership intentionally remains in the plugin invoker exactly like
2.1.13.  The official service keeps Health persistent and adds only a narrow,
property-gated exit arbiter.  It never opens IBOShell and never neutralizes the
launcher during opening.
"""
import threading

from resources.lib.health import run_service, _restore_previous_context
from resources.lib.media_relay import MediaRelayService
from resources.lib.ffmpeg_direct import ensure_ffmpeg_direct, ffmpeg_direct_status
from resources.lib.prefs import get_int
from resources.lib.log import log
from resources.lib.state import load_activity

try:
    import xbmc
    import xbmcgui
except Exception:
    xbmc = None
    xbmcgui = None

_EXIT_GUARD_PROPERTY = 'IBO.V2.ExitPending'


def _sync_native_dns_override():
    try:
        import xbmcaddon
        from resources.lib.dns import apply_configured_override
        active = bool(apply_configured_override(addon=xbmcaddon.Addon()))
        log('DNS alternativo manual: %s.' % ('ativo' if active else 'desligado'), 'debug')
        return active
    except Exception as exc:
        log('DNS alternativo manual: falha ao sincronizar (%s).' % exc.__class__.__name__, 'warning')
        return False


if xbmc is not None:
    class _IBOServiceMonitor(xbmc.Monitor):
        def onSettingsChanged(self):
            _sync_native_dns_override()
else:
    _IBOServiceMonitor = None


def _ensure_optional_ffmpeg_direct():
    """Honor a persisted FFmpeg Direct preference after addon/Kodi restart.

    Users upgrading from an older ONEPLAY build may already have the switch set
    to 1. Startup may re-enable a binary that is already installed, but it never
    starts installation UI for an absent component. Installation remains an
    explicit action in ONEPLAY Settings and the binary stays an optional dependency.
    """
    if xbmc is None:
        return
    try:
        if not bool(get_int('ffmpeg_direct', default=0, low=0, high=1)):
            return
    except Exception:
        return
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(2.0):
        return
    state = ffmpeg_direct_status()
    if state.get('installed') and state.get('enabled'):
        return
    if not state.get('installed'):
        # Binary installation is an explicit user action. Never open Kodi's
        # repository/install UI from xbmc.service during startup, where it can
        # race repository refreshes and the first ONEPLAY launch.
        log('FFmpeg Direct: preferência persistida ativa, mas o componente não está instalado; aguardando ação explícita em Configurações.', 'debug')
        return
    if ensure_ffmpeg_direct(interactive=False, timeout=6.0):
        state = ffmpeg_direct_status()
        version = str(state.get('version') or '')
        log('FFmpeg Direct: componente já instalado foi habilitado pelo serviço%s.' % (
            (' (v%s)' % version) if version else ''
        ), 'debug')
    else:
        log('FFmpeg Direct: componente instalado não pôde ser habilitado no boot; playback padrão permanece disponível.', 'warning')


def _exit_arbiter(monitor=None):
    """Fast fallback for the proven 2.1.13 exit protocol.

    No activity file is read while the exit guard is absent.  When SAIR arms
    the guard, delegate to the already-proven health restoration routine.  That
    routine retains its own age/busy/window gates and is idempotent with the
    plugin-side immediate settle path.
    """
    if xbmc is None or xbmcgui is None:
        return
    monitor = monitor or xbmc.Monitor()
    try:
        window = xbmcgui.Window(10000)
    except Exception:
        window = None
    if window is None:
        return

    while not monitor.abortRequested():
        armed = False
        try:
            armed = bool(str(window.getProperty(_EXIT_GUARD_PROPERTY) or '').strip())
        except Exception:
            armed = False
        if armed:
            try:
                _restore_previous_context(load_activity())
            except Exception:
                # Health's 1 s loop remains the last fallback.  Do not let a
                # transient arbiter failure terminate the official service.
                pass
        if monitor.waitForAbort(0.05):
            break


if __name__ == '__main__':
    # Apply the manual native DNS choice before Relay/Health perform network I/O.
    _sync_native_dns_override()
    settings_monitor = _IBOServiceMonitor() if _IBOServiceMonitor is not None else None

    # Persistent owner: relay survives the plugin/UI interpreter while Kodi is
    # reproducing or preserving media state. Player fails closed if unavailable.
    media_relay = MediaRelayService()
    try:
        media_relay.start()
    except Exception:
        media_relay = None

    # Optional component preparation is isolated from Health/relay ownership.
    # It runs only when the user preference is already enabled.
    ffmpeg_thread = threading.Thread(target=_ensure_optional_ffmpeg_direct, name='IBO-FFmpegDirectSetup')
    ffmpeg_thread.daemon = True
    ffmpeg_thread.start()

    # Proven 2.2.1 ownership split: Health stays persistent on its own thread;
    # unlike 2.2.1, this main loop owns no ONEPLAY UI session.
    health_thread = threading.Thread(target=run_service, name='IBO-HealthService')
    health_thread.daemon = True
    health_thread.start()
    try:
        _exit_arbiter(settings_monitor)
    finally:
        if media_relay is not None:
            try:
                media_relay.stop()
            except Exception:
                pass
        try:
            health_thread.join(2.0)
        except Exception:
            pass
