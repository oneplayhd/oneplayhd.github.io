# -*- coding: utf-8 -*-
"""Favoritos privados do ONEPLAY IBO.

O estado vive somente em addon_data/plugin.video.ibo.oneplay.  Não lê nem
altera favourites.xml, MyVideos*.db, Textures*.db ou Thumbnails do Kodi.
default.py e service.py podem usar intérpretes distintos, por isso a escrita
usa o mesmo padrão conservador de mutex de filesystem do histórico privado.
"""
import os
import shutil
import time

from .log import log
from .storage import read_json, state_path, write_json

FAVORITES_PATH = state_path('favorites_v2.json')
LOCK_DIR = FAVORITES_PATH + '.lock'
FAVORITES_SCHEMA = 1
MAX_ITEMS = 500

# Apenas metadados necessários para reconstruir a linha no Browser e buscar
# detalhes/reproduzir pelo ID.  Credenciais/URLs resolvidas nunca são salvas.
_ALLOWED_FIELDS = (
    'stream_id', 'series_id', 'name', 'title', 'stream_icon', 'cover',
    'cover_big', 'container_extension', 'plot', 'year', 'category_id',
    '_ibo_category_id', 'epg_channel_id', 'rating', 'rating_5based', 'added',
    'releaseDate', 'genre', 'director', 'cast',
)


def _now():
    return int(time.time())


def _kind(mode):
    value = str(mode or '').strip().lower()
    return value if value in ('live', 'movie', 'series') else ''


def _item_id(mode, row):
    mode = _kind(mode)
    src = row if isinstance(row, dict) else {}
    if mode in ('live', 'movie'):
        return str(src.get('stream_id') or '').strip()
    if mode == 'series':
        return str(src.get('series_id') or '').strip()
    return ''


def _key(mode, row):
    mode = _kind(mode)
    item_id = _item_id(mode, row)
    return '%s:%s' % (mode, item_id) if mode and item_id else ''


def _empty():
    return {'schema': FAVORITES_SCHEMA, 'updated_at': 0, 'items': {}}


def _load_unlocked():
    data = read_json(FAVORITES_PATH, {})
    if not isinstance(data, dict) or int(data.get('schema') or 0) != FAVORITES_SCHEMA:
        return _empty()
    if not isinstance(data.get('items'), dict):
        data['items'] = {}
    return data


def load_favorites():
    return _load_unlocked()


def _acquire_lock(timeout=0.65, stale=8.0):
    deadline = time.monotonic() + max(0.10, float(timeout))
    while time.monotonic() < deadline:
        try:
            os.mkdir(LOCK_DIR)
            try:
                with open(os.path.join(LOCK_DIR, 'owner'), 'w', encoding='ascii') as fh:
                    fh.write('%s\n%s\n' % (os.getpid(), time.time()))
            except Exception:
                pass
            return True
        except FileExistsError:
            try:
                age = time.time() - os.path.getmtime(LOCK_DIR)
            except Exception:
                age = 0.0
            if age > stale:
                try:
                    shutil.rmtree(LOCK_DIR)
                    continue
                except Exception:
                    pass
            time.sleep(0.025)
        except Exception:
            time.sleep(0.025)
    return False


def _release_lock():
    try:
        shutil.rmtree(LOCK_DIR)
    except Exception:
        pass


def _write_mutation(mutator):
    if not _acquire_lock():
        log('Favoritos: mutex ocupado; alteração não aplicada para evitar sobrescrita.', 'debug')
        return False
    try:
        data = _load_unlocked()
        changed = bool(mutator(data))
        if not changed:
            return True
        items = data.get('items') or {}
        if len(items) > MAX_ITEMS:
            ordered = sorted(
                items.items(),
                key=lambda pair: int((pair[1] or {}).get('favorited_at') or 0),
                reverse=True,
            )
            data['items'] = dict(ordered[:MAX_ITEMS])
        data['schema'] = FAVORITES_SCHEMA
        data['updated_at'] = _now()
        write_json(FAVORITES_PATH, data)
        return True
    except Exception as exc:
        log('Favoritos: falha ao persistir alteração: %s' % exc, 'warning')
        return False
    finally:
        _release_lock()


def _snapshot(mode, row):
    mode = _kind(mode)
    src = row if isinstance(row, dict) else {}
    item_id = _item_id(mode, src)
    if not mode or not item_id:
        return {}
    out = {'kind': mode, 'favorited_at': _now()}
    for field in _ALLOWED_FIELDS:
        value = src.get(field)
        if value is None or isinstance(value, (dict, list, tuple, set)):
            continue
        out[field] = value
    if mode in ('live', 'movie'):
        out['stream_id'] = item_id
    else:
        out['series_id'] = item_id
    return out


def is_favorite(mode, row):
    key = _key(mode, row)
    if not key:
        return False
    return isinstance((load_favorites().get('items') or {}).get(key), dict)


def set_favorite(mode, row, enabled=True):
    key = _key(mode, row)
    snapshot = _snapshot(mode, row)
    if not key or not snapshot:
        return False

    def mutate(data):
        items = data.setdefault('items', {})
        if enabled:
            previous = items.get(key) if isinstance(items.get(key), dict) else {}
            # Preserva a data original ao atualizar metadados de um favorito já existente.
            original = int(previous.get('favorited_at') or 0)
            items[key] = dict(snapshot)
            if original:
                items[key]['favorited_at'] = original
            return True
        if key in items:
            del items[key]
            return True
        return False

    return _write_mutation(mutate)


def toggle_favorite(mode, row):
    active = is_favorite(mode, row)
    ok = set_favorite(mode, row, not active)
    return ('removed' if active else 'added') if ok else 'failed'


def favorite_rows(mode, limit=500):
    mode = _kind(mode)
    if not mode:
        return []
    rows = [dict(row) for row in (load_favorites().get('items') or {}).values()
            if isinstance(row, dict) and str(row.get('kind') or '') == mode]
    rows.sort(key=lambda row: int(row.get('favorited_at') or 0), reverse=True)
    result = []
    for row in rows[:max(1, int(limit))]:
        row.pop('kind', None)
        row.pop('favorited_at', None)
        row['_ibo_favorite'] = True
        result.append(row)
    return result
