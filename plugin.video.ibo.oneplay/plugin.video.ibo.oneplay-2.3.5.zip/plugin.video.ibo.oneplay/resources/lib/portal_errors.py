# -*- coding: utf-8 -*-
"""Human-facing messages for PORTAL management operations.

This module is presentation-only.  It deliberately converts technical panel,
transport and access-bootstrap failures into short explanations that a user can
understand.  Raw exceptions/reasons remain available to callers for kodi.log;
user-facing strings never echo URLs, credentials, Python exception classes or
internal failover/bootstrap names.
"""

import re

from .http import HttpError


_HTTP = {
    400: ('Solicitação inválida', 'O painel não conseguiu processar esta operação.'),
    401: ('Operação não autorizada', 'O painel não autorizou esta operação.'),
    402: ('Acesso requer renovação', 'Este acesso precisa ser renovado antes de continuar.'),
    403: ('Operação bloqueada', 'O painel não permitiu esta operação.'),
    408: ('Painel sem resposta', 'O painel demorou além do esperado. Tente novamente.'),
    409: ('Acesso alterado', 'O estado deste acesso mudou. Atualize a lista e tente novamente.'),
    410: ('Acesso não está mais disponível', 'Este acesso foi removido do painel.'),
    423: ('Acesso protegido', 'O gerenciamento deste acesso está bloqueado no painel.'),
    429: ('Muitas tentativas', 'Aguarde alguns instantes e tente novamente.'),
    500: ('Painel temporariamente indisponível', 'O painel apresentou uma falha interna. Tente novamente.'),
    502: ('Painel temporariamente indisponível', 'O serviço de gerenciamento não conseguiu alcançar o servidor de origem.'),
    503: ('Painel temporariamente indisponível', 'O serviço de gerenciamento está indisponível neste momento.'),
    504: ('Painel sem resposta', 'O serviço de gerenciamento não recebeu resposta dentro do prazo.'),
}


def _http_message(code, operation='', retry_after=0):
    try:
        status = int(code)
    except Exception:
        status = 0
    operation = str(operation or '').lower()
    if status == 401 and operation == 'connect':
        headline, detail = 'Acesso não autorizado', 'O servidor não autorizou a conexão deste acesso.'
    elif status == 403 and operation == 'connect':
        headline, detail = 'Acesso bloqueado', 'O servidor não permitiu conectar este acesso.'
    elif status in (403, 423) and operation == 'delete':
        headline, detail = 'Acesso protegido', 'O painel não permitiu excluir este acesso.'
    elif status == 403 and operation == 'list':
        headline, detail = 'Gerenciamento bloqueado', 'O painel não permitiu consultar os acessos deste dispositivo.'
    elif status == 404:
        if operation == 'delete':
            headline, detail = 'Acesso não encontrado', 'Este acesso pode já ter sido removido do painel.'
        elif operation == 'connect':
            headline, detail = 'Acesso não encontrado', 'Este acesso pode ter sido removido ou deixado de estar disponível.'
        else:
            headline, detail = 'Serviço não encontrado', 'Não foi possível localizar o serviço de gerenciamento do painel.'
    else:
        headline, detail = _HTTP.get(status, (
            'Não foi possível concluir a operação',
            'O painel retornou um erro inesperado. Tente novamente.',
        ))
    if status == 429 and retry_after:
        try:
            seconds = max(1, int(float(retry_after)))
            detail = 'Aguarde cerca de %d segundo%s e tente novamente.' % (seconds, '' if seconds == 1 else 's')
        except Exception:
            pass
    if status:
        return '%s\n%s\nHTTP %d' % (headline, detail, status)
    return '%s\n%s' % (headline, detail)


def _transport_message(error, operation=''):
    reason = getattr(error, 'reason', error)
    text = str(reason or '')
    lowered = text.lower()
    cls = reason.__class__.__name__.lower() if reason is not None else ''
    if ('gaierror' in cls or 'name or service not known' in lowered or
            'nodename nor servname' in lowered or 'temporary failure in name resolution' in lowered or
            'getaddrinfo failed' in lowered or 'no address associated with hostname' in lowered or
            'dns não resolveu' in lowered):
        return 'Painel não localizado\nA rede não conseguiu localizar o servidor de gerenciamento.'
    if 'timed out' in lowered or 'timeout' in cls or 'tempo de conexão esgotado' in lowered or 'tempo total excedido' in lowered:
        return 'Painel sem resposta\nNão foi possível concluir a comunicação dentro do prazo. Tente novamente.'
    if 'connection refused' in lowered or 'actively refused' in lowered or 'recusou a conexão' in lowered:
        return 'Painel indisponível\nO servidor de gerenciamento recusou a conexão.'
    if ('connection reset' in lowered or 'connection aborted' in lowered or 'broken pipe' in lowered or
            'remote end closed' in lowered or 'conexão interrompida' in lowered):
        return 'Conexão interrompida\nO servidor encerrou a comunicação antes de concluir a operação.'
    if 'ssl' in cls or 'certificate' in lowered or 'tls' in lowered or 'falha ssl' in lowered:
        return 'Conexão segura não validada\nNão foi possível validar a conexão segura com o painel.'
    if operation == 'connect':
        return 'Não foi possível conectar o acesso\nO servidor não respondeu corretamente. Tente novamente.'
    if operation == 'delete':
        return 'Não foi possível excluir o acesso\nO painel não respondeu corretamente. Tente novamente.'
    return 'Não foi possível carregar os acessos\nO painel não respondeu corretamente. Verifique a conexão e tente novamente.'


def _status_from_text(text):
    match = re.search(r'\bHTTP\s*(\d{3})\b', str(text or ''), flags=re.IGNORECASE)
    if not match:
        return 0
    try:
        return int(match.group(1))
    except Exception:
        return 0


def humanize_portal_error(error=None, operation='', reason='', response=None):
    """Return a stable PORTAL message without exposing implementation details."""
    operation = str(operation or '').strip().lower()
    reason_key = str(reason or '').strip().lower()
    response = response if isinstance(response, dict) else {}

    if response.get('management_locked') or str(response.get('access_manage_locked') or '').strip().lower() == 'yes':
        return 'Acesso protegido\nEste acesso não pode ser excluído porque o gerenciamento está bloqueado no painel.'

    if isinstance(error, HttpError):
        try:
            status = int(error.status or 0)
        except Exception:
            status = 0
        if status >= 400:
            return _http_message(status, operation=operation, retry_after=getattr(error, 'retry_after', 0))
        if getattr(error, 'transport', False):
            return _transport_message(error, operation=operation)

    text = str(error or '').strip()
    lowered = text.lower()
    status = _status_from_text(text)
    if status:
        return _http_message(status, operation=operation)

    # Authoritative access/management states.
    if (reason_key in ('access_denied', 'denied', 'device_blocked') or 'uso não autorizado' in lowered or
            'acesso negado' in lowered or 'não autorizado' in lowered or 'dispositivo bloqueado' in lowered):
        return 'Acesso bloqueado\nEste dispositivo não está autorizado a usar este acesso.'
    if reason_key == 'access_not_found' or 'não encontrou o acesso vinculado' in lowered:
        return 'Acesso não encontrado\nEste acesso pode ter sido removido do painel.'
    if reason_key in ('credentials_missing', 'access_context_incomplete') or 'contexto de acesso incompleto' in lowered:
        return 'Acesso incompleto\nOs dados necessários deste acesso não estão completos no painel.'
    if reason_key == 'portal_id_missing' or 'sem identificador de dns' in lowered or 'sem identificador de portal' in lowered:
        return 'Acesso incompleto\nNão foi possível identificar o acesso selecionado.'
    if reason_key in ('session_missing', 'session_changed') or 'sessão ausente' in lowered:
        return 'Sessão encerrada\nVolte à tela inicial e abra o gerenciamento de acessos novamente.'

    # Account status returned by the Xtream authority while switching portal.
    if 'acesso vencido' in lowered or 'expired' in lowered:
        return 'Acesso vencido\nEste acesso precisa ser renovado antes de conectar.'
    if 'acesso desativado' in lowered or 'disabled' in lowered:
        return 'Acesso desativado\nEste acesso está desativado no servidor.'
    if 'acesso bloqueado' in lowered or 'banned' in lowered:
        return 'Acesso bloqueado\nEste acesso está bloqueado no servidor.'
    if 'acesso inativo' in lowered or 'inactive' in lowered:
        return 'Acesso inativo\nEste acesso não está ativo no servidor.'
    if reason_key == 'account_error':
        return 'Acesso não disponível\nO servidor informou que este acesso não está ativo.'

    # Connection/bootstrap internals are intentionally translated, not echoed.
    if reason_key == 'bootstrap_deadline' or 'limite de segurança' in lowered or 'tempo de recuperação' in lowered:
        return 'Servidor do acesso sem resposta\nNenhum servidor disponível respondeu dentro do prazo.'
    if reason_key in ('client_transport', 'kodi_access_error', 'connect_error'):
        return _transport_message(error, operation=operation or 'connect')
    if reason_key in ('client_response', 'group_exhausted'):
        return 'Servidor do acesso indisponível\nNenhum servidor disponível respondeu corretamente para este acesso.'
    if reason_key == 'kodi_access_unavailable':
        return 'Serviço de acesso indisponível\nNão foi possível consultar este acesso no painel.'

    # Recognize older generic transport strings without reflecting them verbatim.
    transport_tokens = (
        'dns não resolveu', 'timed out', 'timeout', 'tempo total excedido', 'tempo de conexão esgotado',
        'connection refused', 'recusou a conexão', 'connection reset', 'connection aborted',
        'broken pipe', 'conexão interrompida', 'ssl', 'tls', 'certificate',
    )
    if any(token in lowered for token in transport_tokens):
        return _transport_message(error, operation=operation)

    if operation == 'delete':
        if 'não encontrado' in lowered or 'já foi removido' in lowered:
            return 'Acesso não encontrado\nEste acesso pode já ter sido removido do painel.'
        if 'bloque' in lowered or 'proteg' in lowered or 'recusou a exclusão' in lowered:
            return 'Acesso protegido\nO painel não permitiu excluir este acesso.'
        return 'Não foi possível excluir o acesso\nO painel não concluiu a remoção. Atualize a lista e tente novamente.'

    if operation == 'connect':
        return 'Não foi possível conectar o acesso\nO servidor não confirmou este acesso. Tente novamente.'

    return 'Não foi possível carregar os acessos\nO painel não respondeu corretamente. Verifique a conexão e tente novamente.'
