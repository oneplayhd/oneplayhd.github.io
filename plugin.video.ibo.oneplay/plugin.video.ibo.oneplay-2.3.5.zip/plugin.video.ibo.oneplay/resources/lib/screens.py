# -*- coding: utf-8 -*-
import base64
import datetime
import math
import os
import re
import time
import threading
import unicodedata
import urllib.parse

from .auth import session_client
from .constants import ADDON_VERSION
from .device import get_device_id
from .http import HttpError
from .content_errors import content_title, humanize_content_error
from .log import log
from .panel import PanelClient
from .state import load_activity, load_panel, load_session, playback_fingerprint, save_panel, save_session
from .prefs import effective_live_output, effective_time_format, get_int, get_str, live_stream_locked, set_value
from .storage import cache_catalog_image, cache_image, clear_cache, prime_catalog_image_host, state_path
from .skin_compat import window_xml_args
from .watch_history import clear_history, continue_movies, continue_series, format_position, get_entry, latest_series_resume, resume_seconds
from .favorites import favorite_rows, toggle_favorite
from .cast import cast_active, stop_active_cast
from .apk_downloader import get_apk_entries, show_download_apk
from .i18n import available_languages, effective_language_code, language_name, panel_language_code, tr, ui, window_labels

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
except Exception:
    xbmc = None
    xbmcaddon = None
    xbmcgui = None

ADDON_PATH = xbmcaddon.Addon().getAddonInfo('path') if xbmcaddon is not None else ''
SKIN = 'Default'
RES = '1080i'
ACTION_BACK = {9, 10, 92}
ACTION_LEFT = 1
ACTION_RIGHT = 2
ACTION_UP = 3
ACTION_DOWN = 4
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6
ACTION_SELECT = 7
ACTION_CONTEXT_MENU = 117

_BACKGROUND_VIDEO_PROPERTY = 'IBO.V2.BackgroundVideo'
_BACKGROUND_BACK_GUARD_SECONDS = 1.10
_BACKGROUND_BACK_GUARD_UNTIL = 0.0
_BACKGROUND_RESUME_LOCK_DIR = state_path('player_resume_transition.lock')
_BACKGROUND_RESUME_LOCK_STALE_SECONDS = 6.0
_BACKGROUND_RESUME_QUIET_SECONDS = 0.72
_BACKGROUND_RESUME_QUIET_TIMEOUT = 2.20
_HISTORY_REVISION_PROPERTY = 'IBO.V2.HistoryRevision'


def _new_window(cls, xml_name):
    """Instantiate an IBO WindowXML with fail-open skin compatibility.

    Estuary always uses the original packaged XMLs.  On third-party skins the
    compatibility layer may provide a profile-local XML copy with normalized
    font aliases.  If that constructor is rejected by a skin/device, retry the
    exact original path rather than preventing ONEPLAY from opening.
    """
    args = window_xml_args(xml_name, ADDON_PATH, SKIN, RES)
    try:
        return cls(*args)
    except Exception as exc:
        if len(args) >= 2 and str(args[1]) != str(ADDON_PATH):
            log('Skin compat: construtor alternativo recusado para %s (%s); usando original.' % (xml_name, exc), 'warning')
            return cls(xml_name, ADDON_PATH, SKIN, RES)
        raise


def _history_revision():
    if xbmcgui is None:
        return ''
    try:
        return str(xbmcgui.Window(10000).getProperty(_HISTORY_REVISION_PROPERTY) or '')
    except Exception:
        return ''


def _background_video_property_active():
    if xbmcgui is None:
        return False
    try:
        return str(xbmcgui.Window(10000).getProperty(_BACKGROUND_VIDEO_PROPERTY) or '') == '1'
    except Exception:
        return False


def _set_background_video_property(active):
    """Expõe ao skin somente um vídeo que pertença à sessão ONEPLAY.

    Player.HasVideo sozinho não é suficiente: outro add-on também pode ter um
    VideoPlayer ativo. O fingerprint em activity_v2.json é a autoridade usada
    pelo Health e evita que o ONEPLAY mostre/controle reprodução alheia.
    """
    if xbmcgui is None:
        return
    try:
        home = xbmcgui.Window(10000)
        if active:
            home.setProperty(_BACKGROUND_VIDEO_PROPERTY, '1')
        else:
            home.clearProperty(_BACKGROUND_VIDEO_PROPERTY)
    except Exception:
        pass


def _own_background_playback_active():
    if xbmc is None:
        return False
    try:
        activity = load_activity() or {}
        marker = str(activity.get('playback_hash') or '')
        kind = str(activity.get('playback_kind') or '')
        if not marker or kind not in ('live', 'movie', 'series'):
            return False
        player = xbmc.Player()
        if not player.isPlayingVideo():
            return False
        try:
            current = player.getPlayingFile() or ''
        except Exception:
            current = ''
        # Kodi pode deixar getPlayingFile() vazio durante uma transição curta;
        # o marcador ainda é válido porque o vídeo permanece ativo.
        return not current or playback_fingerprint(current) == marker
    except Exception:
        return False


def _sync_background_video_property():
    active = _own_background_playback_active()
    _set_background_video_property(active)
    return active


def _arm_background_back_guard():
    global _BACKGROUND_BACK_GUARD_UNTIL
    _BACKGROUND_BACK_GUARD_UNTIL = time.monotonic() + _BACKGROUND_BACK_GUARD_SECONDS


def _background_back_guard_open():
    return time.monotonic() >= _BACKGROUND_BACK_GUARD_UNTIL


def _claim_background_resume_transition():
    """Reserva atomicamente a transição interface -> VideoFullScreen.

    ``default.py`` pode ter mais de um intérprete vivo enquanto o Kodi termina
    modais/animações. Um boolean Python não protege esses intérpretes. O mkdir
    é atômico no Windows/Android e impede que um segundo Back abra outro
    IBOProgress/outro ciclo de ``ActivateWindow(12005)`` em paralelo.
    """
    for _attempt in range(2):
        try:
            os.mkdir(_BACKGROUND_RESUME_LOCK_DIR)
            return True
        except FileExistsError:
            try:
                age = max(0.0, time.time() - os.path.getmtime(_BACKGROUND_RESUME_LOCK_DIR))
            except Exception:
                age = 0.0
            if age > _BACKGROUND_RESUME_LOCK_STALE_SECONDS:
                # Um retorno legítimo mantém este lock durante todo o tempo em
                # VideoFullScreen; idade sozinha não significa stale. Só
                # recupere quando o fullscreen não estiver ativo.
                fullscreen_active = False
                try:
                    fullscreen_active = bool(xbmc is not None and xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'))
                except Exception:
                    fullscreen_active = False
                if not fullscreen_active:
                    try:
                        os.rmdir(_BACKGROUND_RESUME_LOCK_DIR)
                        log('Player BG: lock stale de retorno ao player recuperado.', 'debug')
                        continue
                    except Exception:
                        pass
            return False
        except Exception:
            return False
    return False


def _touch_background_resume_transition():
    """Atualiza o instante da última entrada durante o handoff.

    O diretório já funciona como mutex cross-interpreter. Reaproveitar seu
    mtime permite esperar a tecla estabilizar sem criar thread, arquivo extra
    ou estado Python que outro intérprete não enxergaria.
    """
    try:
        os.utime(_BACKGROUND_RESUME_LOCK_DIR, None)
        return True
    except Exception:
        return False


def _wait_background_resume_quiet(quiet=None, timeout=None):
    """Espera uma janela curta sem novas teclas antes de abrir fullscreen.

    O log real mostrou uma repetição de Back chegando ~650 ms depois do Back
    que pediu retorno ao player. Enquanto esperamos, o IBOShell fica visível e
    absorve qualquer cauda do controle, atualizando o mtime do mutex. Somente
    depois da entrada ficar quieta entregamos a GUI ao VideoFullScreen.
    """
    quiet = _BACKGROUND_RESUME_QUIET_SECONDS if quiet is None else max(0.0, float(quiet))
    timeout = _BACKGROUND_RESUME_QUIET_TIMEOUT if timeout is None else max(quiet, float(timeout))
    if not os.path.isdir(_BACKGROUND_RESUME_LOCK_DIR):
        return True
    deadline = time.monotonic() + timeout
    monitor = None
    try:
        monitor = xbmc.Monitor() if xbmc is not None else None
    except Exception:
        monitor = None
    while time.monotonic() < deadline:
        try:
            age = max(0.0, time.time() - os.path.getmtime(_BACKGROUND_RESUME_LOCK_DIR))
        except FileNotFoundError:
            return True
        except Exception:
            age = quiet
        if age >= quiet:
            return True
        remaining = max(0.0, min(0.05, quiet - age))
        if remaining <= 0:
            continue
        if monitor is not None:
            try:
                if monitor.waitForAbort(remaining):
                    return False
                continue
            except Exception:
                pass
        try:
            if xbmc is not None:
                xbmc.sleep(max(1, int(remaining * 1000.0)))
            else:
                time.sleep(remaining)
        except Exception:
            time.sleep(remaining)
    log('Player BG: entrada do controle não estabilizou; retorno ao fullscreen adiado.', 'debug')
    return False


def _release_background_resume_transition():
    try:
        os.rmdir(_BACKGROUND_RESUME_LOCK_DIR)
    except FileNotFoundError:
        pass
    except Exception:
        pass


def _background_resume_request_allowed():
    if not _claim_background_resume_transition():
        log('Player BG: retorno ao player já em andamento; comando repetido ignorado.', 'debug')
        return False
    return True


def _media(name):
    return os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', name)


def _safe_text(value):
    return str(value or '')


def _panel_uses_24h(panel=None):
    """Retorna o contrato de hora do painel: 1=24h, 0=12h.

    O Kodi possui uma configuração regional própria para ``System.Time``.
    Como a configuração IBO é centralizada no painel, o cabeçalho não deve
    herdar o formato regional do Kodi.
    """
    return effective_time_format(panel) == '1'


def _panel_clock_text(panel=None, stamp=None):
    """Hora local formatada estritamente conforme ``settings.time_format``."""
    current = time.time() if stamp is None else float(stamp)
    if _panel_uses_24h(panel):
        return time.strftime('%H:%M', time.localtime(current))
    value = time.strftime('%I:%M %p', time.localtime(current))
    return value[1:] if value.startswith('0') else value


_ADULT_TOKEN_RE = re.compile(r'(?:^|[^a-z0-9])(?:adult(?:o|os|a|as)?|xxx|porn(?:o)?|erotic(?:o|a)?|sexo|sex)(?:$|[^a-z0-9])')


def _adult_name(value):
    raw = str(value or '')
    if '🔞' in raw or '+18' in raw or '18+' in raw:
        return True
    try:
        normalized = unicodedata.normalize('NFKD', raw).encode('ascii', 'ignore').decode('ascii').casefold()
    except Exception:
        normalized = raw.casefold()
    return bool(_ADULT_TOKEN_RE.search(normalized))


def _adult_protection_enabled():
    """Proteção adulta é sempre ativa na V2.0.50.

    O PIN passa a ser único/central no painel. Não existe mais chave local para
    desligar a proteção nem PIN paralelo por instalação do Kodi.
    """
    return True


def _adult_panel_pin():
    """PIN parental autoritativo atualmente conhecido do painel."""
    panel = load_panel()
    session = load_session()
    return str(panel.get('pin') or session.get('pin') or '0000').strip() or '0000'


def _cache_panel_pin(value):
    """Atualiza imediatamente os snapshots locais após mudança confirmada."""
    pin = str(value or '').strip()
    if len(pin) != 4 or not pin.isdigit():
        return False
    panel = load_panel()
    if panel:
        panel['pin'] = pin
        save_panel(panel)
    session = load_session()
    if session:
        session['pin'] = pin
        save_session(session)
    return True


_ADULT_PIN_INDEX_TIMEOUT_SECONDS = 2.0


def _adult_pin_matches(value, refresh_on_miss=True):
    """Valida o PIN central pelo ``index.php`` leve, nunca pelo ``auth.php``.

    A V2.0.50 consultava o ``auth.php`` a cada PIN. Esse endpoint pode executar
    trabalho de resolução de acesso e, no log real, bloqueou a interface por
    cerca de 52 segundos. O ``index.php`` já é o preflight local/rápido do
    painel e, a partir do contrato V2.16, também devolve o PIN do dispositivo.

    O snapshot local e o PIN padrão não autorizam conteúdo protegido. Sem
    confirmação do painel, mantenha o bloqueio; o JSON é editável pelo cliente.
    """
    entered = str(value or '').strip()
    if len(entered) != 4 or not entered.isascii() or not entered.isdigit():
        return False
    if refresh_on_miss:
        started = time.time()
        try:
            state = PanelClient().index_state(timeout=_ADULT_PIN_INDEX_TIMEOUT_SECONDS) or {}
            fresh = str(state.get('pin') or '').strip()
            if (not state.get('device_blocked') and not state.get('access_denied')
                    and len(fresh) == 4 and fresh.isascii() and fresh.isdigit()):
                _cache_panel_pin(fresh)
                log('PIN parental: index.php sincronizado em %.2fs.' % max(0.0, time.time() - started), 'debug')
                return entered == fresh
            log('PIN parental: painel sem confirmação válida; acesso protegido permanece bloqueado.', 'debug')
        except Exception as exc:
            log('PIN parental: index.php indisponível; acesso protegido permanece bloqueado: %s' % exc, 'debug')
    return False


def _prompt_hidden_pin(title):
    if xbmcgui is None:
        return ''
    try:
        option = getattr(xbmcgui, 'ALPHANUM_HIDE_INPUT', 2)
        input_type = getattr(xbmcgui, 'INPUT_ALPHANUM', 0)
        return str(xbmcgui.Dialog().input(str(title), type=input_type, option=option) or '').strip()
    except Exception:
        try:
            return str(xbmcgui.Dialog().numeric(0, str(title)) or '').strip()
        except Exception:
            return ''


# Categorias podem chegar do servidor com emoji/símbolo embutido no próprio
# category_name (ex.: "Canais | ⚽ Futebol"). A fonte do Kodi pode desenhar
# esses caracteres como quadrados. Mantemos o nome/ID originais e substituímos
# SOMENTE o glifo realmente recebido por uma pequena arte local exatamente na
# posição editorial da lista. Não existe fallback por palavra/nome de categoria.
_CATEGORY_INLINE_SYMBOLS = (
    ('🏃\u200d♀️', 'runner.png'),
    ('🏃\u200d♂️', 'runner.png'),
    ('🏃\u200d♀', 'runner.png'),
    ('🏃\u200d♂', 'runner.png'),
    ('⏱️', 'stopwatch.png'),
    ('✔️', 'check2.png'),
    ('✝️', 'cross.png'),
    ('❤️', 'heart.png'),
    ('🇧🇷', 'flag_br.png'),
    ('🇩🇪', 'flag_de.png'),
    ('🇪🇸', 'flag_es.png'),
    ('🇫🇷', 'flag_fr.png'),
    ('🇮🇹', 'flag_it.png'),
    ('🇵🇹', 'flag_pt.png'),
    ('🇺🇸', 'flag_us.png'),
    ('🎞️', 'film_frames.png'),
    ('🏋️', 'lifting.png'),
    ('🏍️', 'motorcycle.png'),
    ('🏎️', 'racing.png'),
    ('🏟️', 'stadium.png'),
    ('📽️', 'projector.png'),
    ('🗞️', 'newspaper2.png'),
    ('🛰️', 'satellite2.png'),
    ('⏰', 'alarm.png'),
    ('⏱', 'stopwatch.png'),
    ('★', 'black_star.png'),
    ('☆', 'white_star.png'),
    ('⚡', 'lightning.png'),
    ('⚽', 'soccer.png'),
    ('⚾', 'baseball.png'),
    # Aliases literais encontrados na M3U real: não são inferidos pelo nome.
    # ⛹️ identifica a categoria NBA e ⛔ identifica XXX Adultos.
    ('⛹️', 'basketball.png'),
    ('⛹', 'basketball.png'),
    ('⛔', 'no_entry.png'),
    ('⛳', 'golf.png'),
    ('✅', 'check.png'),
    ('✔', 'check2.png'),
    ('✝', 'cross.png'),
    ('✨', 'sparkles.png'),
    ('❌', 'crossmark.png'),
    ('❤', 'heart.png'),
    ('⭐', 'star.png'),
    ('🆕', 'new.png'),
    ('🌍', 'earth_africa.png'),
    ('🌎', 'earth_americas.png'),
    ('🌐', 'globe.png'),
    ('🌟', 'star2.png'),
    ('🍿', 'popcorn.png'),
    ('🎞', 'film_frames.png'),
    ('🎥', 'camera.png'),
    ('🎬', 'clapper.png'),
    ('🎭', 'theater.png'),
    ('🎮', 'game.png'),
    ('🎯', 'target.png'),
    ('🎱', 'pool.png'),
    ('🎲', 'dice.png'),
    ('🎵', 'music1.png'),
    ('🎶', 'music2.png'),
    ('🎾', 'tennis.png'),
    ('🏀', 'basketball.png'),
    ('🏁', 'racing_flag.png'),
    ('🏃', 'runner.png'),
    ('🏅', 'medal.png'),
    ('🏆', 'trophy.png'),
    ('🏈', 'football.png'),
    ('🏊', 'swimming.png'),
    ('🏋', 'lifting.png'),
    ('🏍', 'motorcycle.png'),
    ('🏎', 'racing.png'),
    ('🏐', 'volleyball.png'),
    ('🏒', 'hockey.png'),
    ('👤', 'person.png'),
    ('👥', 'people.png'),
    ('👶', 'baby.png'),
    ('💎', 'diamond.png'),
    ('💥', 'boom.png'),
    ('💫', 'dizzy.png'),
    ('💰', 'moneybag.png'),
    ('💲', 'heavy_dollar.png'),
    ('💵', 'dollar.png'),
    ('💻', 'computer.png'),
    ('📡', 'satellite.png'),
    ('📢', 'loudspeaker.png'),
    ('📣', 'megaphone.png'),
    ('📰', 'newspaper.png'),
    ('📱', 'mobile.png'),
    ('📺', 'tv.png'),
    ('📻', 'radio.png'),
    ('📽', 'projector.png'),
    ('🔐', 'lock_key.png'),
    ('🔒', 'lock.png'),
    ('🔓', 'unlock.png'),
    ('🔞', 'adult.png'),
    ('🔥', 'fire.png'),
    ('🕒', 'clock.png'),
    ('🗞', 'newspaper2.png'),
    ('😂', 'joy.png'),
    ('🙏', 'pray.png'),
    ('🚀', 'rocket.png'),
    ('🚫', 'no_entry.png'),
    ('🚴', 'cycling.png'),
    ('🤣', 'rofl.png'),
    ('🤸', 'gymnastics.png'),
    ('🤼', 'wrestling.png'),
    ('🥇', 'medal1.png'),
    ('🥊', 'boxing.png'),
    ('🥋', 'martial_arts.png'),
    ('🧒', 'child.png'),
)


def _category_inline_visual(name):
    """Retorna dados visuais sem inventar símbolos ausentes no servidor."""
    raw = str(name or '')
    if not raw:
        return raw, '', '', '', ''

    # O corredor pode vir com tom de pele e/ou variante de gênero. Consumimos
    # a sequência inteira, mas só quando o próprio U+1F3C3 existe no nome.
    runner = re.search(r'🏃[🏻🏼🏽🏾🏿]?(?:\ufe0f)?(?:\u200d[♂♀]\ufe0f?)?', raw[:40])
    if runner:
        start, end = runner.span()
        icon = _media(os.path.join('category_symbols', 'runner.png'))
        prefix, suffix = raw[:start], raw[end:]
        slot = 'pipe' if prefix.rstrip().endswith('|') else ('start' if not prefix.strip() else '')
        if slot:
            return raw, prefix, suffix, icon, slot

    for symbol, filename in _CATEGORY_INLINE_SYMBOLS:
        start = raw.find(symbol)
        if start < 0 or start > 32:
            continue
        end = start + len(symbol)
        prefix, suffix = raw[:start], raw[end:]
        # Os layouts do add-on têm dois posicionamentos seguros:
        # 1) após o prefixo editorial "... |"; 2) no início do nome.
        # Qualquer símbolo em outra posição permanece no texto original em vez
        # de ser deslocado visualmente para um lugar incorreto.
        slot = 'pipe' if prefix.rstrip().endswith('|') else ('start' if not prefix.strip() else '')
        if not slot:
            continue
        return raw, prefix, suffix, _media(os.path.join('category_symbols', filename)), slot

    return raw, '', '', '', ''

def _decode_b64(value):
    text = str(value or '')
    if not text:
        return ''
    try:
        raw = base64.b64decode(text, validate=True)
        return raw.decode('utf-8', 'ignore')
    except Exception:
        return text


def _expiry_text(session):
    raw = str((session or {}).get('exp_date') or '')
    try:
        stamp = int(raw)
        if stamp > 0:
            return 'Vencimento: %s' % time.strftime('%d/%m/%Y %H:%M', time.localtime(stamp))
    except Exception:
        pass
    return 'Vencimento: —'


def _expiry_days_until(stamp, now=None):
    """Calendar-day distance used by the official APK expiry warning."""
    try:
        current = time.localtime(float(time.time() if now is None else now))
        expiry = time.localtime(int(stamp))
        current_date = datetime.date(current.tm_year, current.tm_mon, current.tm_mday)
        expiry_date = datetime.date(expiry.tm_year, expiry.tm_mon, expiry.tm_mday)
        return int((expiry_date - current_date).days)
    except Exception:
        return None


def _expiry_home_text(session, panel, now=None):
    """Mantém a data de vencimento fixa e neutra no canto da Home."""
    return _expiry_text(session)


def _expiry_popup_text(session, panel, now=None):
    """Replica a redação oficial do APK OnePlayExpireWarning.

    O painel continua controlando se o aviso existe e a antecedência 1..7.
    A redação, pontuação e variantes (vencido/hoje/amanhã/N dias) seguem a
    rotina ``OnePlayExpireWarning.buildMessage`` do APK oficial.
    """
    cfg = panel or {}
    if str(cfg.get('expire_warning_enabled') or '').strip().lower() != 'yes':
        return ''
    try:
        warning_days = int(str(cfg.get('expire_warning_days') or '4').strip())
    except Exception:
        warning_days = 4
    warning_days = max(1, min(7, warning_days))

    try:
        stamp = int(str((session or {}).get('exp_date') or '').strip())
    except Exception:
        return ''
    if stamp <= 0:
        return ''

    try:
        current_stamp = float(time.time() if now is None else now)
    except Exception:
        current_stamp = time.time()
    if current_stamp >= float(stamp):
        return 'Seu acesso está vencido.\nRenove seu plano para continuar usando o aplicativo.'

    days_left = _expiry_days_until(stamp, now=current_stamp)
    if days_left is None or days_left > warning_days:
        return ''
    if days_left < 0:
        return 'Seu acesso está vencido.\nRenove seu plano para continuar usando o aplicativo.'
    if days_left == 0:
        try:
            expire_time = time.strftime('%H:%M', time.localtime(stamp))
        except Exception:
            expire_time = ''
        if expire_time:
            return 'Seu acesso vence hoje às %s.\nPara evitar interrupção, renove seu plano antes desse horário.' % expire_time
        return 'Seu acesso vence hoje.\nPara evitar interrupção, renove seu plano antes da data de vencimento.'
    if days_left == 1:
        return 'Seu acesso vence amanhã.\nPara evitar interrupção, renove seu plano antes da data de vencimento.'
    return 'Seu acesso vence em %d dias.\nPara evitar interrupção, renove seu plano antes da data de vencimento.' % days_left


def _catalog_art(value, private_cache=True, fallback='', grid_fast=False):
    """Resolve artwork with a bounded private resilience layer.

    Remote artwork still uses Kodi normally on a healthy host, while the IBO
    keeps a byte-validated private resilience layer for low-cardinality views.
    Since V2.0.74, TMDB receives an explicit circuit-breaker because a real
    Kodi 21 log showed ~30 s image timeouts starving all image JobWorkers.
    Large movie/series grids use ``grid_fast=True``: the TMDB host is
    preflighted while IBOProgress is visible; after that, ListItem construction
    avoids all private-cache filesystem work and uses Kodi's lazy TextureCache.

    ``fallback`` is always local skin art and is preferred when the remote host
    is temporarily unavailable, so one CDN outage cannot blank unrelated views.
    """
    text = str(value or '').strip()
    if not text:
        return str(fallback or '')
    if not private_cache:
        return text

    # V2.0.77: the private resilience layer is intentionally limited to TMDB.
    # Provider/Xtream artwork already goes through Kodi's lazy TextureCache;
    # prefetching the same URL here doubles traffic and the real Kodi log showed
    # a provider image host answering HTTP 429 during long catalog navigation.
    # TMDB remains protected because that is the host that previously stalled
    # Kodi image workers for ~30 s and propagated blank artwork across screens.
    try:
        parsed = urllib.parse.urlparse(text)
        host = str(parsed.netloc or '').split('@')[-1].split(':')[0].strip().lower()
    except Exception:
        host = ''
    if host and host != 'image.tmdb.org' and not host.endswith('.image.tmdb.org'):
        return text

    try:
        if grid_fast:
            return cache_catalog_image(text, fallback=fallback)
        return cache_image(text, 0, fallback=fallback)
    except Exception as exc:
        log('Cache de arte indisponível; usando fallback seguro: %s' % exc, 'debug')
        return str(fallback or text)


# Estado efêmero por invocação do plugin. É reiniciado em toda nova abertura
# do add-on e NÃO é persistido em disco: voltar de TV/Filmes/Séries na mesma
# sessão não repete o aviso, mas uma abertura futura pode avisar novamente.
_EXPIRY_POPUP_SHOWN = False


def _status_text(session):
    session = session or {}
    mode = str(session.get('health_mode') or 'auto').capitalize()
    used = int(session.get('health_used') or 0)
    limit = int(session.get('health_limit') or 0)
    conn = 'Ilimitado' if limit == 0 and mode.lower() != 'auto' else ('%d/%d %s' % (used, limit, mode) if limit else mode)
    # Home intentionally does not expose the Xtream login. Device ID is safer
    # and is the identifier used by the IBO panel/session contract.
    return '%s  •  ID: %s  •  %s' % (session.get('portal_name') or 'Portal', get_device_id(), conn)


class ShellWindow(xbmcgui.WindowXML if xbmcgui is not None else object):
    """Persistent non-modal IBO background for one plugin session.

    Interactive screens remain WindowXMLDialog instances, but closing one no
    longer exposes Kodi/Estuary. VideoFullScreen can also replace this base
    window because it is not itself a modal dialog.

    O Shell é uma camada interna, nunca uma etapa de navegação. Durante a
    transição VideoFullScreen -> conteúdo pode existir por poucos frames sem
    uma WindowXMLDialog sobre ele. Se a cauda de uma tecla Back cair nesse
    intervalo, o comportamento padrão do Kodi faria PreviousWindow() voltar ao
    MyVideoNav e reinvocar plugin://plugin.video.ibo.oneplay. Enquanto houver
    reprodução própria, consuma esse Back transitório aqui. A janela de
    conteúdo que reaparece logo depois possui o guard contextual normal.
    """

    def onAction(self, action):
        try:
            aid = action.getId()
        except Exception:
            aid = 0

        # O Shell nunca é uma etapa navegável. Durante interface -> player,
        # qualquer tecla que chegue aqui é cauda/repetição da ação que fechou a
        # WindowXMLDialog: absorva e renove a janela de silêncio. Isso impede
        # tanto Back -> MyVideoNav quanto Enter repetido -> OSD logo ao abrir.
        if os.path.isdir(_BACKGROUND_RESUME_LOCK_DIR) and (aid in ACTION_BACK or aid == ACTION_SELECT):
            _touch_background_resume_transition()
            log('Player BG: entrada transitória absorvida pelo Shell durante handoff.', 'debug')
            return

        # Mesmo fora de uma transição, Back jamais deve navegar a partir do
        # Shell interno. Se a tela de conteúdo ainda está sendo restaurada,
        # PreviousWindow() aqui reinvoca MyVideoNav/plugin e cria duas
        # autoridades Python para a mesma reprodução.
        if aid in ACTION_BACK:
            log('Player BG: Back transitório absorvido pelo Shell interno.', 'debug')
            return
        try:
            super(ShellWindow, self).onAction(action)
        except Exception:
            pass


def open_shell():
    if xbmcgui is None:
        return None
    try:
        win = _new_window(ShellWindow, 'IBOShell.xml')
        win.show()
        if xbmc is not None:
            xbmc.sleep(80)
        return win
    except Exception as exc:
        log('Shell IBO indisponível: %s' % exc, 'warning')
        return None


def close_shell(win):
    if win is None:
        return
    try:
        win.close()
    except Exception:
        pass


class BaseWindow(xbmcgui.WindowXMLDialog if xbmcgui is not None else object):
    def configure(self, **kwargs):
        self.result = None
        self.data = dict(kwargs)
        self._apply_localization()

    def _apply_localization(self):
        try:
            for key, value in window_labels().items():
                self.setProperty(str(key), str(value or ''))
        except Exception as exc:
            log('Localização: não foi possível aplicar os rótulos da janela: %s' % exc, 'debug')

    def shutdown(self):
        """Hook chamado sempre depois que doModal() termina, inclusive no shutdown do Kodi."""
        return None

    def close_with(self, result):
        self.result = result
        self.close()

    def onAction(self, action):
        try:
            aid = action.getId()
        except Exception:
            return
        if aid in ACTION_BACK:
            self.close_with('back')


def _open(cls, xml_name, **kwargs):
    if xbmcgui is None:
        return None
    win = _new_window(cls, xml_name)
    win.configure(**kwargs)
    try:
        win.doModal()
        return getattr(win, 'result', None)
    finally:
        # Kodi pode encerrar diretamente um WindowXMLDialog durante shutdown;
        # nesse caminho close_with() não é garantido. O hook obrigatório evita
        # deixar relógio/showcase/EPG vivos no interpretador do default.py.
        try:
            win.shutdown()
        except Exception as exc:
            log('Lifecycle: cleanup da janela %s falhou: %s' % (xml_name, exc), 'warning')
        try:
            del win
        except Exception:
            pass


class ProgressWindow(BaseWindow):
    def configure(self, **kwargs):
        BaseWindow.configure(self, **kwargs)
        # Somente os progressos que pertencem ao handoff de reprodução recebem
        # a garantia extra de auto-fechamento. Progressos de painel/catálogo
        # continuam estritamente vinculados ao término da operação que os abriu.
        self._close_on_player = bool(kwargs.get('close_on_player'))
        self._player_guard_stop = threading.Event()
        self._player_guard_thread = None

    def onInit(self):
        # Marcador privado usado pelo handoff do player para distinguir a nossa
        # janela de progresso de um modal externo real do Kodi.
        self.setProperty('IBO.ProgressOwned', '1')
        self.setProperty('IBO.Progress', self.data.get('text') or 'Carregando...')
        if self._close_on_player and xbmc is not None:
            self._player_guard_thread = threading.Thread(
                target=self._close_when_player_owns_screen, name='IBO-ProgressPlayerGuard'
            )
            self._player_guard_thread.daemon = True
            self._player_guard_thread.start()

    def _close_when_player_owns_screen(self):
        """Fail-safe visual para qualquer IBOProgress de abertura de mídia.

        O handoff normal continua sendo fechado pelo player/router. Esta segunda
        garantia existe para transições encadeadas (especialmente Up Next ->
        próximo episódio), nas quais o Kodi pode promover VideoFullScreen depois
        de a posse Python da janela ter sido transferida. Assim que o player é a
        tela ativa, uma janela passiva sem botões nunca pode permanecer sobre ele.
        """
        try:
            monitor = xbmc.Monitor()
        except Exception:
            monitor = None
        while not self._player_guard_stop.is_set():
            try:
                fullscreen = bool(xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'))
            except Exception:
                fullscreen = False
            if not fullscreen and xbmcgui is not None:
                try:
                    fullscreen = int(xbmcgui.getCurrentWindowId() or 0) == 12005
                except Exception:
                    fullscreen = False
            playing_video = False
            if fullscreen:
                try:
                    playing_video = bool(xbmc.Player().isPlayingVideo())
                except Exception:
                    playing_video = False
            if fullscreen and playing_video:
                self._player_guard_stop.set()
                try:
                    self.close()
                    log('Lifecycle: IBOProgress de reprodução encerrada pelo VideoFullScreen.', 'debug')
                except Exception as exc:
                    log('Lifecycle: falha ao encerrar IBOProgress no VideoFullScreen: %s' % exc, 'warning')
                return
            if monitor is not None:
                try:
                    if monitor.waitForAbort(0.05):
                        return
                    continue
                except Exception:
                    pass
            time.sleep(0.05)

    def shutdown(self):
        try:
            self._player_guard_stop.set()
        except Exception:
            pass
        thread = getattr(self, '_player_guard_thread', None)
        if thread is not None and thread is not threading.current_thread() and thread.is_alive():
            thread.join(0.20)

    def close_with(self, result):
        try:
            self._player_guard_stop.set()
        except Exception:
            pass
        BaseWindow.close_with(self, result)


def open_progress(text, close_on_player=True):
    if xbmcgui is None:
        return None
    win = _new_window(ProgressWindow, 'IBOProgress.xml')
    win.configure(text=text, close_on_player=close_on_player)
    try:
        win.show()
        if xbmc is not None:
            xbmc.sleep(60)
        return win
    except Exception:
        close_progress(win)
        return None


def close_progress(win):
    if win is None:
        return
    # Todo IBOProgress passa pelo mesmo cleanup, inclusive os que não possuem
    # guard de player. Isso evita deixar worker visual vivo após close()/Stop.
    try:
        win.shutdown()
    except Exception:
        pass
    try:
        win.close()
    except Exception:
        pass


# Playback-opening handoff.  The wait window is created on the very Select
# event that requests playback, before the source WindowXMLDialog closes.
# This avoids exposing the empty Shell/Estuary transition while Kodi deinitializes
# the browser/detail dialog.  Router later claims the same window and keeps it
# alive through probe/failover/player startup.
_CONTENT_OPENING_WIN = None
_PLAYER_RETURN_WIN = None


def begin_player_return(text='Aguarde...'):
    """Arma somente o guard de Back para VideoFullScreen -> conteúdo.

    Desde a 2.0.90 o próprio IBOShell/videowindow é a cobertura visual do
    handoff. Abrir IBOProgress aqui criava um modal justamente enquanto outra
    rotina podia precisar entregar/receber o VideoFullScreen, alimentando
    recusas de ActivateWindow(12005) e restaurações duplicadas.
    """
    global _PLAYER_RETURN_WIN
    _arm_background_back_guard()
    # Feche defensivamente uma janela herdada de código anterior na mesma
    # invocação, mas não crie um novo modal.
    win = _PLAYER_RETURN_WIN
    _PLAYER_RETURN_WIN = None
    close_progress(win)
    return None


def finish_player_return():
    """Compatibilidade com onInit das telas; não há modal de retorno na 2.0.90."""
    global _PLAYER_RETURN_WIN
    win = _PLAYER_RETURN_WIN
    _PLAYER_RETURN_WIN = None
    close_progress(win)


def begin_content_opening(text='Abrindo conteúdo...'):

    global _CONTENT_OPENING_WIN
    if _CONTENT_OPENING_WIN is not None:
        return _CONTENT_OPENING_WIN
    try:
        _CONTENT_OPENING_WIN = open_progress(text, close_on_player=True)
    except Exception as exc:
        _CONTENT_OPENING_WIN = None
        log('Falha ao antecipar janela de abertura: %s' % exc, 'warning')
    return _CONTENT_OPENING_WIN


def claim_content_opening():
    global _CONTENT_OPENING_WIN
    win = _CONTENT_OPENING_WIN
    _CONTENT_OPENING_WIN = None
    return win


def cancel_content_opening():
    global _CONTENT_OPENING_WIN
    win = _CONTENT_OPENING_WIN
    _CONTENT_OPENING_WIN = None
    close_progress(win)


def run_progress(text, func):
    if xbmcgui is None:
        return func()
    win = _new_window(ProgressWindow, 'IBOProgress.xml')
    win.configure(text=text)
    try:
        win.show()
        if xbmc is not None:
            xbmc.sleep(60)
        return func()
    finally:
        close_progress(win)
        del win


class UpNextWindow(BaseWindow):
    def configure(self, **kwargs):
        BaseWindow.configure(self, **kwargs)
        self.item = kwargs.get('item') if isinstance(kwargs.get('item'), dict) else {}
        self.auto = bool(kwargs.get('auto'))
        self.seconds = max(3, min(20, int(kwargs.get('seconds') or 8)))
        self._stop = threading.Event()
        self._thread = None

    def onInit(self):
        self.setProperty('IBO.UpNextTitle', ui('next_episode', 'Próximo episódio'))
        self.setProperty('IBO.UpNextName', str(self.item.get('title') or ''))
        self.setProperty('IBO.UpNextMeta', 'T%s • E%s' % (self.item.get('season') or '-', self.item.get('episode') or '-'))
        self.setProperty('IBO.UpNextArt', _catalog_art(self.item.get('art') or '', fallback=_media('no_vod.png')))
        self.setProperty('IBO.UpNextCountdown', '')
        self.setProperty('IBO.UpNextPlay', ui('play_now', 'Reproduzir agora'))
        self.setProperty('IBO.UpNextCancel', window_labels().get('IBO.L.Cancel') or 'CANCELAR')
        self.setFocusId(8201)
        if self.auto:
            self._thread = threading.Thread(target=self._countdown, name='IBO-UpNext')
            self._thread.daemon = True
            self._thread.start()

    def _countdown(self):
        remaining = self.seconds
        while remaining > 0 and not self._stop.is_set():
            try:
                self.setProperty('IBO.UpNextCountdown', '%s %ds' % (ui('play_in', 'Reproduzir em'), remaining))
            except Exception:
                pass
            if self._stop.wait(1.0):
                return
            remaining -= 1
        if not self._stop.is_set():
            try:
                self.close_with('play')
            except Exception:
                pass

    def close_with(self, result):
        self._stop.set()
        BaseWindow.close_with(self, result)

    def shutdown(self):
        self._stop.set()
        thread = self._thread
        if thread is not None and thread is not threading.current_thread() and thread.is_alive():
            thread.join(0.25)

    def onClick(self, control_id):
        if control_id == 8201:
            self.close_with('play')
        elif control_id == 8202:
            self.close_with('cancel')

    def onAction(self, action):
        try:
            if action.getId() in ACTION_BACK:
                self.close_with('cancel')
                return
        except Exception:
            pass
        BaseWindow.onAction(self, action)


def show_up_next(item, auto=False, seconds=8):
    return _open(UpNextWindow, 'IBOUpNext.xml', item=item, auto=auto, seconds=seconds) == 'play'


def _access_message_parts(text):
    """Divide a mensagem de ACESSO IBO somente para apresentação visual.

    O erro original vindo de HTTP/Xtream permanece intacto na camada de rede;
    aqui ele é separado em mensagem principal, detalhe humano e código HTTP.
    """
    raw = str(text or '').strip()
    if not raw:
        return 'Não foi possível concluir o acesso', '', ''

    code = ''
    body = raw
    match = re.match(r'^HTTP\s+(\d{3})\s*(?:[—–-]\s*)?(.*)$', raw, re.IGNORECASE)
    if match:
        code = 'HTTP %s' % match.group(1)
        body = (match.group(2) or '').strip()

    headline = body
    detail = ''
    for separator in (' — ', ' – '):
        if separator in body:
            headline, detail = body.split(separator, 1)
            break

    if not detail and code == 'HTTP 429':
        retry = re.match(r'^(.*?)\s*\((tente novamente em .+?)\)\.?$', body, re.IGNORECASE)
        if retry:
            headline = retry.group(1).strip()
            detail = retry.group(2).strip()

    if not detail:
        sentence = re.match(r'^(.*?)[.!?]\s+(.+)$', body)
        if sentence:
            headline = sentence.group(1).strip()
            detail = sentence.group(2).strip()

    headline = str(headline or '').strip().rstrip(' .')
    detail = str(detail or '').strip().rstrip()
    if headline:
        headline = headline[:1].upper() + headline[1:]
    if detail:
        detail = detail[:1].upper() + detail[1:]
    return headline, detail, code


class MessageWindow(BaseWindow):
    def onInit(self):
        self.setProperty('IBO.MsgTitle', self.data.get('title') or 'IBO')
        self.setProperty('IBO.MsgText', self.data.get('text') or '')
        self.setFocusId(8001)

    def onClick(self, control_id):
        if control_id == 8001:
            self.close_with('ok')


class AccessMessageWindow(BaseWindow):
    """Diálogo dedicado a falhas de acesso, separado das mensagens genéricas."""
    def onInit(self):
        title = self.data.get('title') or 'ACESSO IBO'
        message = self.data.get('text') or ''
        headline, detail, code = _access_message_parts(message)
        device_id = get_device_id()

        self.setProperty('IBO.MsgTitle', title)
        self.setProperty('IBO.MsgAccessHeadline', headline)
        self.setProperty('IBO.MsgAccessDetail', detail)
        self.setProperty('IBO.MsgAccessCode', code)
        self.setProperty(
            'IBO.MsgDeviceLine',
            ('ID do dispositivo: %s' % device_id) if device_id else '',
        )
        self.setFocusId(8002)

    def onClick(self, control_id):
        if control_id == 8002:
            self.close_with('ok')


def show_message(title, text):
    try:
        access_screen = str(title or '').strip().upper() == 'ACESSO IBO'
    except Exception:
        access_screen = False
    if access_screen:
        return _open(AccessMessageWindow, 'IBOAccessMessage.xml', title=title, text=text)
    return _open(MessageWindow, 'IBOMessage.xml', title=title, text=text)


class ConfirmWindow(BaseWindow):
    def onInit(self):
        self.setProperty('IBO.MsgTitle', self.data.get('title') or 'CONFIRMAR')
        self.setProperty('IBO.MsgText', self.data.get('text') or '')
        self.setFocusId(8101)

    def onClick(self, control_id):
        if control_id == 8101:
            self.close_with(True)
        elif control_id == 8102:
            self.close_with(False)

    def onAction(self, action):
        try:
            if action.getId() in ACTION_BACK:
                self.close_with(False)
                return
        except Exception:
            pass
        BaseWindow.onAction(self, action)


def show_confirm(title, text):
    return bool(_open(ConfirmWindow, 'IBOConfirm.xml', title=title, text=text))


class LoginWindow(BaseWindow):
    def onInit(self):
        self.setProperty('IBO.Device', 'ID do dispositivo: %s' % get_device_id())
        self.setProperty('IBO.Message', '')

        # O formulário permanece idêntico. O QR usa apenas o snapshot leve já
        # persistido pelo preflight do painel e é sobreposto ao logo pelo XML.
        # URL ausente/inválida deixa as propriedades vazias, mantendo o logo
        # ONEPLAY original como fallback visual sem qualquer chamada de rede
        # adicional no Python da tela de Login.
        panel = load_panel() or {}
        qr_url = str(panel.get('qr_url_short') or '').strip()
        if qr_url:
            try:
                parsed = urllib.parse.urlsplit(qr_url)
                if parsed.scheme.lower() not in ('http', 'https') or not parsed.netloc:
                    qr_url = ''
            except Exception:
                qr_url = ''
        qr_description = str(panel.get('qr_description') or '').strip() if qr_url else ''
        self.setProperty('IBO.LoginQrUrl', qr_url)
        self.setProperty('IBO.LoginQrDescription', qr_description)
        self.setFocusId(2001)

    def _edit_text(self, control_id):
        try:
            return self.getControl(control_id).getText()
        except Exception:
            try:
                return self.getControl(control_id).getLabel()
            except Exception:
                return ''

    def onClick(self, control_id):
        if control_id == 2003:
            self.close_with({'action': 'login', 'username': self._edit_text(2001), 'password': self._edit_text(2002)})
        elif control_id == 2005:
            self.close_with({'action': 'exit'})

    def onAction(self, action):
        try:
            if action.getId() in ACTION_BACK:
                self.close_with({'action': 'exit'})
                return
        except Exception:
            pass
        BaseWindow.onAction(self, action)


def show_login():
    return _open(LoginWindow, 'IBOLogin.xml')


class HomeWindow(BaseWindow):
    ROUTES = {100: 'live', 101: 'movie', 102: 'series', 103: 'games', 104: 'access', 105: 'settings', 106: 'refresh', 107: 'exit'}

    def configure(self, **kwargs):
        BaseWindow.configure(self, **kwargs)
        self._showcase_stop = threading.Event()
        self._showcase_thread = None
        self._showcase_required_mode = ''
        self._expiry_popup_visible = False

    @staticmethod
    def _global_home():
        try:
            return xbmcgui.Window(10000) if xbmcgui is not None else None
        except Exception:
            return None

    def _apply_showcase_slide(self, slide):
        slide = slide if isinstance(slide, dict) else {}
        window = self._global_home()
        if window is None:
            return
        # Theme 2 must never become visually empty because TMDB stalls. When
        # its hero host is unhealthy, an empty HeroBackdrop intentionally reveals
        # the already configured manual/default banner underneath. Other showcase
        # themes retain the packaged background as their safe visual fallback.
        image_fallback = '' if self._showcase_required_mode == 'tmdb' else _media('background1.jpg')
        hero_image = _catalog_art(slide.get('image') or '', fallback=image_fallback)
        hero_poster = _catalog_art(slide.get('poster') or '', fallback=_media('no_vod.png')) if hero_image and slide.get('poster') else ''
        values = {
            'IBO.V2.HeroBackdrop': str(hero_image or ''),
            'IBO.V2.HeroPoster': str(hero_poster or ''),
            'IBO.V2.HeroTitle': str(slide.get('title') or '') if hero_image else '',
            'IBO.V2.HeroPlot': str(slide.get('plot') or '') if hero_image else '',
        }
        for key, value in values.items():
            try:
                if value:
                    window.setProperty(key, value)
                else:
                    window.clearProperty(key)
            except Exception:
                pass

    def _showcase_loop(self):
        index = 0
        signature = None
        while not self._showcase_stop.is_set():
            cache = load_panel() or {}
            cache_mode = str(cache.get('_home_showcase_mode') or '')
            slides = cache.get('_home_showcase_slides') or []
            if self._showcase_required_mode and cache_mode != self._showcase_required_mode:
                slides = []
            slides = [row for row in slides if isinstance(row, dict) and str(row.get('image') or '').strip()] if isinstance(slides, list) else []
            if slides:
                current_signature = tuple(str((row or {}).get('image') or '') for row in slides)
                if current_signature != signature:
                    signature = current_signature
                    index = 0
                self._apply_showcase_slide(slides[index % len(slides)])
                index = (index + 1) % len(slides)
                if self._showcase_stop.wait(7.0):
                    break
            else:
                if self._showcase_stop.wait(1.0):
                    break

    def onInit(self):
        global _EXPIRY_POPUP_SHOWN
        session = self.data.get('session') or {}
        panel = self.data.get('panel') or load_panel()
        theme = str(self.data.get('theme') or '1')
        self.setProperty('IBO.Expiry', _expiry_home_text(session, panel))
        self.setProperty('IBO.Status', _status_text(session))
        self.setProperty('IBO.Version', 'IBO Kodi %s' % ADDON_VERSION)

        popup_text = '' if _EXPIRY_POPUP_SHOWN else _expiry_popup_text(session, panel)
        if popup_text:
            _EXPIRY_POPUP_SHOWN = True
            self._expiry_popup_visible = True
            self.setProperty('IBO.ExpiryPopupVisible', '1')
            self.setProperty('IBO.ExpiryPopupTitle', 'AVISO DE VENCIMENTO')
            self.setProperty('IBO.ExpiryPopupText', popup_text)
        else:
            self.setProperty('IBO.ExpiryPopupVisible', '')
            self.setProperty('IBO.ExpiryPopupTitle', '')
            self.setProperty('IBO.ExpiryPopupText', '')
        if theme == '2':
            banner = _catalog_art(self.data.get('banner') or '', fallback=_media('banner.png'))
            # Mantém o banner homologado como fallback/manual e espelha em Home
            # (window 10000), que o serviço persistente consegue atualizar.
            self.setProperty('IBO.Banner', banner)
            try:
                if xbmcgui is not None:
                    xbmcgui.Window(10000).setProperty('IBO.V2.Banner', str(banner))
            except Exception:
                pass

            # No Tema 2 o carrossel só é válido quando o painel está em TMDB.
            # Em modo manual, as propriedades são limpas para revelar o banner
            # de anúncio já existente no mesmo slot.
            self._showcase_required_mode = 'tmdb'
            mode = str((panel or {}).get('_home_showcase_mode') or '')
            slides = (panel or {}).get('_home_showcase_slides') or []
            if mode == 'tmdb' and isinstance(slides, list) and slides:
                self._apply_showcase_slide(slides[0])
            else:
                self._apply_showcase_slide(None)
            self._showcase_thread = threading.Thread(target=self._showcase_loop, name='IBO-HomeShowcase')
            self._showcase_thread.daemon = True
            self._showcase_thread.start()
        elif theme in ('3', '4', '5'):
            self._showcase_required_mode = ''
            slides = (panel or {}).get('_home_showcase_slides') or []
            if isinstance(slides, list) and slides:
                self._apply_showcase_slide(slides[0])
            else:
                self._apply_showcase_slide({'image': _media('background1.jpg')})
            self._showcase_thread = threading.Thread(target=self._showcase_loop, name='IBO-HomeShowcase')
            self._showcase_thread.daemon = True
            self._showcase_thread.start()
        self.setFocusId(8901 if self._expiry_popup_visible else 100)

    def _dismiss_expiry_popup(self):
        if not self._expiry_popup_visible:
            return False
        self._expiry_popup_visible = False
        self.setProperty('IBO.ExpiryPopupVisible', '')
        try:
            self.setFocusId(100)
        except Exception:
            pass
        return True

    def close_with(self, result):
        try:
            self._showcase_stop.set()
        except Exception:
            pass
        BaseWindow.close_with(self, result)

    def shutdown(self):
        try:
            self._showcase_stop.set()
        except Exception:
            pass
        thread = getattr(self, '_showcase_thread', None)
        if thread is not None and thread is not threading.current_thread() and thread.is_alive():
            thread.join(0.50)
        if thread is not None and thread.is_alive():
            log('Lifecycle: IBO-HomeShowcase não encerrou no prazo.', 'warning')
        else:
            log('Lifecycle: IBO-HomeShowcase encerrado.', 'debug')

    def onClick(self, control_id):
        if self._expiry_popup_visible:
            if control_id == 8901:
                self._dismiss_expiry_popup()
            return
        action = self.ROUTES.get(control_id)
        if action:
            self.close_with(action)

    def onAction(self, action):
        try:
            if action.getId() in ACTION_BACK:
                if self._dismiss_expiry_popup():
                    return
                self.close_with('exit')
                return
        except Exception:
            pass
        BaseWindow.onAction(self, action)


def show_home(session, panel, banner=''):
    theme = str((panel or {}).get('theme') or (session or {}).get('theme') or '1')
    xml = {
        '1': 'IBOHome1.xml',
        '2': 'IBOHome2.xml',
        '3': 'IBOHome3.xml',
        '4': 'IBOHome4.xml',
        '5': 'IBOHome5.xml',
    }.get(theme, 'IBOHome1.xml')
    return _open(HomeWindow, xml, session=session, panel=panel, theme=theme, banner=banner)


class GamesWindow(BaseWindow):
    def configure(self, **kwargs):
        BaseWindow.configure(self, **kwargs)
        self.title = str(kwargs.get('title') or 'JOGOS')
        self.images = list(kwargs.get('images') or [])
        self.index = 0

    def onInit(self):
        self.setProperty('IBO.GamesTitle', self.title)
        self._refresh()
        self.setFocusId(9001)

    def _refresh(self):
        total = len(self.images)
        if total:
            self.index %= total
            self.setProperty('IBO.GamesImage', str(self.images[self.index]))
            self.setProperty('IBO.GamesCount', '%d / %d' % (self.index + 1, total))
            self.setProperty('IBO.GamesEmpty', '')
        else:
            self.setProperty('IBO.GamesImage', '')
            self.setProperty('IBO.GamesCount', '0 / 0')
            self.setProperty('IBO.GamesEmpty', 'Nenhuma imagem de jogos/eventos foi cadastrada no painel.')

    def _move(self, delta):
        if len(self.images) <= 1:
            return
        self.index = (self.index + int(delta)) % len(self.images)
        self._refresh()

    def onClick(self, control_id):
        if control_id == 9001:
            self.close_with('back')

    def onAction(self, action):
        try:
            aid = action.getId()
        except Exception:
            return
        if aid in ACTION_BACK:
            self.close_with('back')
            return
        if aid in (ACTION_LEFT, ACTION_PAGE_UP):
            self._move(-1)
            return
        if aid in (ACTION_RIGHT, ACTION_PAGE_DOWN):
            self._move(1)
            return
        BaseWindow.onAction(self, action)


def show_games(payload):
    payload = payload or {}
    return _open(GamesWindow, 'IBOGames.xml', title=payload.get('title') or 'JOGOS', images=payload.get('images') or [])


class BrowserWindow(BaseWindow):
    def configure(self, **kwargs):
        BaseWindow.configure(self, **kwargs)
        self.mode = str(kwargs.get('mode') or 'movie')
        # Categorias locais ficam sempre acima das categorias do provedor, mas
        # a abertura inicial continua apontando para a primeira categoria real
        # do servidor para não transformar Favoritos vazio em tela inicial.
        self._server_categories = list(kwargs.get('categories') or [])
        self.categories = [
            {'category_id': '__favorites__', 'category_name': ui('favorites', 'Favoritos')}
        ]
        if self.mode in ('movie', 'series'):
            local_rows = continue_movies(1) if self.mode == 'movie' else continue_series(1)
            if local_rows:
                self.categories.append({'category_id': '__continue__', 'category_name': ui('continue_watching', 'Continuar assistindo')})
        self.categories.extend(self._server_categories)
        self.client = kwargs.get('client')
        self.all_items = []
        self.filtered = []
        # O catálogo global é carregado somente quando existe uma pesquisa.
        # A navegação normal de Canais/Filmes/Séries continua restrita à categoria.
        self.global_items = None
        self.current_category = str(kwargs.get('category_id') or '')
        self.page = int(kwargs.get('page') or 0)
        self.query = str(kwargs.get('query') or '')
        self.page_size = get_int('page_size', default=60, low=30, high=120)
        self.selected_id = str(kwargs.get('selected_id') or '')
        self._snapshot_category = str(kwargs.get('snapshot_category') or '')
        self._items_snapshot = kwargs.get('items_snapshot')
        self._global_snapshot = kwargs.get('global_snapshot')
        self._epg_seq = 0
        self._epg_cache = {}
        self._clock_stop = threading.Event()
        self._clock_thread = None
        self._history_stop = threading.Event()
        self._history_thread = None
        self._history_revision_seen = ''
        self._epg_stop = threading.Event()
        self._epg_threads = set()
        self._epg_threads_lock = threading.Lock()
        # O painel de Filmes/Séries é abastecido em lotes, mas sem trocar/resetar
        # a página visível durante a rolagem. A V2.0.45 ainda substituía 60 itens
        # por outros 60; visualmente isso reposicionava o painel no topo a cada
        # limite de lote. Agora os próximos lotes são apenas anexados ao painel.
        self._rendered_count = 0
        self._batch_loading = False
        # Cache local dos IDs com selo visual de favorito. A tela consulta
        # esses conjuntos em memória em vez de reler favorites_v2.json para
        # cada item renderizado.
        self._favorite_movie_ids = set()
        self._favorite_live_ids = set()
        self._favorite_series_ids = set()
        if self.mode in ('movie', 'live', 'series'):
            try:
                rows = favorite_rows(self.mode)
                id_field = 'series_id' if self.mode == 'series' else 'stream_id'
                favorite_ids = set(
                    str(row.get(id_field) or '') for row in rows
                    if str(row.get(id_field) or '')
                )
                if self.mode == 'movie':
                    self._favorite_movie_ids = favorite_ids
                elif self.mode == 'live':
                    self._favorite_live_ids = favorite_ids
                else:
                    self._favorite_series_ids = favorite_ids
            except Exception:
                self._favorite_movie_ids = set()
                self._favorite_live_ids = set()
                self._favorite_series_ids = set()
        self._adult_category_ids = set()
        for category in self.categories:
            cid = str((category or {}).get('category_id') or (category or {}).get('id') or '')
            name = str((category or {}).get('category_name') or (category or {}).get('name') or '')
            if cid and _adult_name(name):
                self._adult_category_ids.add(cid)
        unlocked = kwargs.get('adult_unlocked') or []
        self._adult_unlocked = set(str(value) for value in unlocked if str(value))

    def _refresh_header_clock(self):
        try:
            self.setProperty('IBO.Clock', _panel_clock_text(load_panel()))
        except Exception:
            pass

    def _clock_loop(self):
        # Atualiza perto da virada de cada minuto, sem polling agressivo.
        while not self._clock_stop.is_set():
            self._refresh_header_clock()
            wait_seconds = max(1.0, 60.2 - (time.time() % 60.0))
            if self._clock_stop.wait(wait_seconds):
                break

    def _continue_item_id(self, row):
        if self.mode == 'movie':
            return str((row or {}).get('stream_id') or '')
        return str((row or {}).get('series_id') or '')

    def _sync_continue_history(self):
        """Sincroniza somente a categoria local Continuar assistindo.

        Enquanto o vídeo próprio segue em background, preserve a ordem e o
        painel já renderizado para não piscar/mover foco a cada gravação de 5 s.
        No Stop, quando a reprodução deixa de estar ativa, uma mudança real de
        membros (por exemplo, item que virou Assistido) é aplicada de imediato.
        Nunca há request Xtream/TMDB neste caminho.
        """
        if self.mode not in ('movie', 'series') or self.current_category != '__continue__':
            return False
        fresh = continue_movies() if self.mode == 'movie' else continue_series()
        background_active = _own_background_playback_active()
        old_rows = list(self.all_items or [])
        if background_active:
            fresh_map = {self._continue_item_id(row): row for row in fresh if self._continue_item_id(row)}
            merged = []
            for old in old_rows:
                item_id = self._continue_item_id(old)
                merged.append(dict(fresh_map.get(item_id) or old))
            # Um item que passou a ser continuável nesta mesma tela entra ao fim
            # sem reordenar os cards que o usuário já está navegando.
            old_ids = {self._continue_item_id(row) for row in old_rows}
            merged.extend(dict(row) for row in fresh if self._continue_item_id(row) not in old_ids)
            self.all_items = merged
            if not self.query:
                self.filtered = list(merged)
            return True

        old_ids = [self._continue_item_id(row) for row in old_rows]
        fresh_ids = [self._continue_item_id(row) for row in fresh]
        self.all_items = list(fresh)
        if not self.query and old_ids == fresh_ids:
            self.filtered = list(fresh)
            return True
        # Stop/finalização pode remover ou trocar o item local. Só nesse caso
        # reconstruímos o painel Continuar assistindo, preservando servidor/cache.
        self.page = 0
        self.selected_id = self.selected_id if self.selected_id in fresh_ids else ''
        self._apply_filter()
        log('Continuar assistindo: painel local atualizado após mudança do histórico.', 'debug')
        return True

    def _history_loop(self):
        self._history_revision_seen = _history_revision()
        background_seen = _background_video_property_active()
        while not self._history_stop.is_set():
            revision = _history_revision()
            background_now = _background_video_property_active()
            history_changed = bool(revision and revision != self._history_revision_seen)
            background_changed = background_now != background_seen
            if history_changed:
                self._history_revision_seen = revision
            if background_changed:
                background_seen = background_now
            if history_changed or background_changed:
                try:
                    self._sync_player_return_navigation()
                    self._sync_continue_history()
                except Exception as exc:
                    log('Continuar assistindo: repaint local falhou: %s' % exc, 'debug')
            if self._history_stop.wait(0.40):
                break

    def close_with(self, result):
        try:
            self._clock_stop.set()
            self._history_stop.set()
            self._epg_stop.set()
            self._epg_seq += 1
        except Exception:
            pass
        BaseWindow.close_with(self, result)

    def shutdown(self):
        try:
            self._clock_stop.set()
            self._history_stop.set()
            self._epg_stop.set()
            self._epg_seq += 1
        except Exception:
            pass
        clock = getattr(self, '_clock_thread', None)
        if clock is not None and clock is not threading.current_thread() and clock.is_alive():
            clock.join(0.40)
        history = getattr(self, '_history_thread', None)
        if history is not None and history is not threading.current_thread() and history.is_alive():
            history.join(0.55)
        try:
            with self._epg_threads_lock:
                workers = list(self._epg_threads)
        except Exception:
            workers = []
        deadline = time.monotonic() + 2.20
        current = threading.current_thread()
        for worker in workers:
            if worker is current or not worker.is_alive():
                continue
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            worker.join(remaining)
        alive = [worker.name for worker in workers if worker.is_alive()]
        if clock is not None and clock.is_alive():
            alive.append(clock.name)
        if history is not None and history.is_alive():
            alive.append(history.name)
        if alive:
            log('Lifecycle: workers da tela ainda ativos após cleanup: %s' % ', '.join(alive), 'warning')
        else:
            log('Lifecycle: relógio/EPG da tela encerrados.', 'debug')

    def _sync_player_return_navigation(self):
        """Define a rota UP dos botões inferiores sem reprocessar a tecla em onAction.

        Kodi 21 pode atualizar o foco nativo antes de entregar ACTION_UP ao Python.
        A navegação deve, portanto, ser declarada no próprio controle em vez de
        executar um segundo setFocusId() para o mesmo evento.
        """
        try:
            back = self.getControl(3010)
            search = self.getControl(3011)
            if _own_background_playback_active():
                target = self.getControl(3012)
                back.controlUp(target)
                search.controlUp(target)
            else:
                back.controlUp(self.getControl(3001))
                search.controlUp(self.getControl(3002))
        except Exception as exc:
            log('Navegação: não foi possível sincronizar retorno ao player: %s' % exc, 'debug')

    def onInit(self):
        self._refresh_header_clock()
        self._clock_thread = threading.Thread(target=self._clock_loop, name='IBO-HeaderClock')
        self._clock_thread.daemon = True
        self._clock_thread.start()
        if self.mode in ('movie', 'series'):
            self._history_thread = threading.Thread(target=self._history_loop, name='IBO-HistoryBrowser')
            self._history_thread.daemon = True
            self._history_thread.start()
        icons = {'live': 'tv_icon.png', 'movie': 'movie_icon.png', 'series': 'icon_series.png'}
        titles = {'live': 'CANAIS', 'movie': 'FILMES', 'series': 'SÉRIES'}
        self.setProperty('IBO.SectionIcon', icons.get(self.mode, 'movie_icon.png'))
        self.setProperty('IBO.Title', titles.get(self.mode, 'IBO'))
        background_video = _sync_background_video_property()
        if background_video:
            log('Player BG: videowindow habilitado na tela %s.' % self.mode, 'debug')
        self._sync_player_return_navigation()
        self._set_grid_visibility()
        self._populate_categories()
        valid_category_ids = {
            str((row or {}).get('category_id') or (row or {}).get('id') or '')
            for row in self.categories
        }
        if not self.current_category or self.current_category not in valid_category_ids:
            initial_rows = self._server_categories or self.categories
            if initial_rows:
                self.current_category = str((initial_rows[0] or {}).get('category_id') or (initial_rows[0] or {}).get('id') or '')
        if (_adult_protection_enabled() and self.current_category in self._adult_category_ids and
                self.current_category not in self._adult_unlocked):
            for category in self._server_categories:
                safe_id = str((category or {}).get('category_id') or (category or {}).get('id') or '')
                if safe_id and safe_id not in self._adult_category_ids:
                    self.current_category = safe_id
                    break
        self._select_category_by_id(self.current_category)
        if self.current_category == '__continue__' and self.mode in ('movie', 'series'):
            # Histórico é local e mutável durante player em background. Snapshot
            # de navegação nunca pode congelar o tempo/membros desta categoria.
            self.all_items = self._fetch_items('__continue__') or []
            self.global_items = self._global_snapshot
            self._apply_filter()
            log('Continuar assistindo: histórico local relido ao restaurar a tela.', 'debug')
        elif self._items_snapshot is not None and self._snapshot_category == self.current_category:
            self.all_items = self._items_snapshot
            self.global_items = self._global_snapshot
            self._apply_filter()
            log('Navegação: conteúdo restaurado do snapshot após retorno do player.', 'debug')
        else:
            self._load_items(self.current_category, reset_page=False)
        # O XML inicia em VOLTAR porque o Kodi 21 tenta aplicar defaultcontrol
        # antes da lista 3020 receber itens. Só movemos o foco após a carga.
        if xbmc is not None:
            xbmc.sleep(80)
        try:
            if self.selected_id and self.filtered:
                self.setFocusId(3040 if self.mode == 'live' else 3030)
                if self.mode == 'live':
                    self._update_live_info()
            elif self.getControl(3020).size() > 0:
                self.setFocusId(3020)
            else:
                self.setFocusId(3010)
        except Exception:
            try:
                self.setFocusId(3010)
            except Exception:
                pass
        finish_player_return()

    def _set_grid_visibility(self):
        # Live uses its own XML with three regions (categories / channels / EPG),
        # so it must never query controls that only exist in the movie/series grid.
        if self.mode == 'live':
            return
        for cid in (3040, 3041, 3042, 3043, 3044):
            try:
                self.getControl(cid).setVisible(False)
            except Exception:
                pass
        for cid in (3030,):
            try:
                self.getControl(cid).setVisible(True)
            except Exception:
                pass

    def _populate_categories(self):
        control = self.getControl(3020)
        control.reset()
        rows = []
        for row in self.categories:
            cid = str((row or {}).get('category_id') or (row or {}).get('id') or '')
            name = str((row or {}).get('category_name') or (row or {}).get('name') or ('Categoria ' + cid))
            rows.append((cid, name))
        items = []
        for cid, name in rows:
            raw_name, prefix, suffix, category_icon, icon_slot = _category_inline_visual(name)
            li = xbmcgui.ListItem(label=raw_name)
            li.setProperty('category_id', cid)
            if category_icon:
                li.setProperty('category_icon', category_icon)
                li.setProperty('category_icon_slot', icon_slot)
                li.setProperty('category_prefix', prefix.rstrip())
                li.setProperty('category_suffix', suffix)
            items.append(li)
        control.addItems(items)

    def _select_category_by_id(self, category_id):
        control = self.getControl(3020)
        for idx in range(control.size()):
            item = control.getListItem(idx)
            if str(item.getProperty('category_id')) == str(category_id or ''):
                try:
                    control.selectItem(idx)
                except Exception:
                    pass
                return

    def _merge_category_catalog(self, exclude_adult=False):
        """Reconstrói um catálogo global a partir das categorias do Xtream.

        O limite HTTP de 16 MiB permanece intacto. Se o endpoint global de
        Canais/Filmes/Séries for grande demais, a pesquisa global é composta por
        respostas menores de cada categoria. IDs são deduplicados porque alguns
        provedores repetem o mesmo conteúdo em mais de uma categoria.
        """
        getters = {
            'live': self.client.live_streams,
            'movie': self.client.vod_streams,
            'series': self.client.series,
        }
        getter = getters.get(self.mode)
        if getter is None:
            return []
        merged = []
        seen = set()
        for category in self.categories:
            cid = str((category or {}).get('category_id') or (category or {}).get('id') or '')
            if not cid or cid in ('__favorites__', '__continue__') or (exclude_adult and cid in self._adult_category_ids):
                continue
            rows = getter(cid)
            for row in rows if isinstance(rows, list) else []:
                if isinstance(row, dict) and not str(row.get('category_id') or row.get('_ibo_category_id') or ''):
                    row = dict(row)
                    row['_ibo_category_id'] = cid
                if self.mode in ('live', 'movie'):
                    item_id = str((row or {}).get('stream_id') or '')
                else:
                    item_id = str((row or {}).get('series_id') or '')
                key = item_id or ('name:' + self._search_text(self._name(row)))
                if key in seen:
                    continue
                seen.add(key)
                merged.append(row)
        log('Catálogo global de %s reconstruído por categorias: %d itens.' % (self.mode, len(merged)), 'debug')
        return merged

    def _row_is_adult(self, row):
        if not isinstance(row, dict):
            return False
        cid = str(row.get('category_id') or row.get('_ibo_category_id') or '')
        if cid and cid in self._adult_category_ids:
            return True
        # Defensive fallback for unusual Xtream payloads without category_id.
        return _adult_name(row.get('category_name') or row.get('category') or '')

    def _verify_adult_category(self, category_id):
        cid = str(category_id or '')
        if not _adult_protection_enabled() or cid not in self._adult_category_ids:
            return True
        if cid in self._adult_unlocked:
            return True
        entered = _prompt_hidden_pin('PIN DO CONTEÚDO ADULTO')
        if not _adult_pin_matches(entered):
            if entered:
                show_message('CONTEÚDO ADULTO', 'PIN não confirmado. Confira o PIN e a conexão com o painel.')
            return False
        self._adult_unlocked.add(cid)
        return True

    def _fetch_items(self, category_id):
        getters = {
            'live': self.client.live_streams,
            'movie': self.client.vod_streams,
            'series': self.client.series,
        }
        getter = getters.get(self.mode)
        if getter is None:
            return []
        local_id = str(category_id or '')
        if local_id == '__favorites__':
            rows = favorite_rows(self.mode)
            # Favoritar nunca pode contornar a proteção adulta. Em uma nova
            # sessão, favoritos de categoria adulta só reaparecem depois que
            # aquela categoria tiver sido desbloqueada pelo PIN normal.
            if _adult_protection_enabled() and self._adult_category_ids:
                rows = [row for row in rows if not self._row_is_adult(row) or
                        str((row or {}).get('category_id') or (row or {}).get('_ibo_category_id') or '') in self._adult_unlocked]
            return rows
        if local_id == '__continue__':
            return continue_movies() if self.mode == 'movie' else continue_series()
        if category_id:
            return getter(category_id)
        if self.client.global_catalog_oversized(self.mode):
            log('Catálogo global %s já marcado acima de 16 MiB; pulando endpoint global e usando categorias em cache.' % self.mode, 'debug')
            return self._merge_category_catalog()
        try:
            return getter('')
        except HttpError as exc:
            if 'excedeu o limite' not in str(exc).lower():
                raise
            self.client.mark_global_catalog_oversized(self.mode)
            log('Catálogo global %s excedeu 16 MiB; marcador salvo pelo TTL do cache e agregação segura por categorias ativada.' % self.mode, 'warning')
            return self._merge_category_catalog()

    def _load_items(self, category_id, reset_page=True):
        previous_category = self.current_category
        self.current_category = str(category_id or '')
        if str(previous_category or '') != self.current_category:
            self.selected_id = ''
        if reset_page:
            self.page = 0
        try:
            def _load_category():
                rows = self._fetch_items(self.current_category) or []
                if self.mode in ('movie', 'series') and rows:
                    # A prova do host acontece antes de IBOProgress fechar.
                    # A montagem posterior da grade não toca disco/rede por card.
                    prime_catalog_image_host(
                        ((row or {}).get('stream_icon') or
                         (row or {}).get('cover') or
                         (row or {}).get('cover_big') or '')
                        for row in rows
                    )
                return rows

            self.all_items = run_progress(
                'Carregando %s...' % {'live':'canais','movie':'filmes','series':'séries'}.get(self.mode,'conteúdo'),
                _load_category
            ) or []
            # O catálogo global é interno à pesquisa; não existe item visual "Todos".
            if self.mode in ('live', 'movie', 'series') and not self.current_category:
                self.global_items = self.all_items
        except Exception as exc:
            self.all_items = []
            log('%s: falha técnica ao carregar catálogo: %s' % (content_title(self.mode), exc), 'warning')
            show_message(content_title(self.mode), humanize_content_error(exc, kind=self.mode, phase='catalog'))
        self._apply_filter()

    def _name(self, row):
        return str((row or {}).get('name') or (row or {}).get('title') or '')

    @staticmethod
    def _search_text(value):
        # Casefold is stronger than lower() for Unicode while remaining cheap.
        try:
            return str(value or '').casefold()
        except Exception:
            return str(value or '').lower()

    def _global_search_source(self):
        if self.mode not in ('live', 'movie', 'series'):
            return self.all_items
        if self.global_items is not None:
            return self.global_items
        try:
            labels = {'live': 'canais', 'movie': 'filmes', 'series': 'séries'}
            if _adult_protection_enabled() and self._adult_category_ids:
                # Quando o PIN está ativo, a pesquisa nem consulta categorias
                # adultas. Isso evita vazamento por nome/capa em resultados globais
                # mesmo em provedores que omitem category_id no endpoint global.
                loader = lambda: self._merge_category_catalog(exclude_adult=True)
            else:
                loader = lambda: self._fetch_items('')
            self.global_items = run_progress(
                'Preparando pesquisa global de %s...' % labels.get(self.mode, 'conteúdos'),
                loader
            ) or []
        except Exception as exc:
            self.global_items = []
            log('%s: falha técnica ao preparar pesquisa global: %s' % (content_title(self.mode), exc), 'warning')
            show_message(content_title(self.mode), humanize_content_error(exc, kind=self.mode, phase='search'))
        return self.global_items

    def _apply_filter(self):
        q = self._search_text(self.query.strip())
        source = self._global_search_source() if q and self.mode in ('live', 'movie', 'series') else self.all_items
        protect_search = bool(q and _adult_protection_enabled())
        self.filtered = [
            row for row in source
            if (not protect_search or not self._row_is_adult(row))
            and (not q or q in self._search_text(self._name(row)))
        ]
        self.setProperty('IBO.Count', 'Total: %d' % len(self.filtered))
        if self.mode == 'live':
            self._render_live()
        else:
            self._render_page()

    def _render_live(self):
        control = self.getControl(3040)
        control.reset()
        items = []
        selected_pos = 0
        for idx, row in enumerate(self.filtered):
            li = xbmcgui.ListItem(label=self._name(row))
            art = _catalog_art((row or {}).get('stream_icon') or '', private_cache=False, fallback=_media('live_fallback.png'))
            li.setArt({'thumb': art, 'icon': art, 'poster': art})
            sid = str((row or {}).get('stream_id') or '')
            li.setProperty('id', sid)
            if sid and sid in self._favorite_live_ids:
                li.setProperty('ibo_favorite', '1')
            li.setProperty('extension', str((row or {}).get('container_extension') or self.client.output or 'm3u8'))
            li.setProperty('plot', str((row or {}).get('plot') or ''))
            li.setProperty('index', str(idx))
            items.append(li)
            if self.selected_id and sid == self.selected_id:
                selected_pos = idx
        control.addItems(items)
        if items:
            try:
                control.selectItem(selected_pos)
            except Exception:
                pass
        self._update_live_info()

    def _grid_item(self, row, absolute_index):
        item_label = self._name(row)
        if (row or {}).get('_ibo_history') and float((row or {}).get('_ibo_resume') or 0.0) >= 30.0:
            item_label = '%s • %s' % (item_label, ui('continue_watching', 'Continuar assistindo'))
        li = xbmcgui.ListItem(label=item_label)
        # O grid usa a URL estável e deixa o TextureCache nativo do Kodi fazer
        # seu trabalho lazy. Isso evita o download duplo que o log real mostrou
        # chegando a HTTP 429 em servidores de capas.
        fallback = _media('no_vod.png') if self.mode in ('movie', 'series') else _media('live_fallback.png')
        art = _catalog_art(
            (row or {}).get('stream_icon') or (row or {}).get('cover') or (row or {}).get('cover_big') or '',
            private_cache=True,
            fallback=fallback,
            grid_fast=True,
        )
        li.setArt({'thumb': art, 'poster': art})
        if self.mode == 'movie':
            item_id = str((row or {}).get('stream_id') or '')
            li.setProperty('id', item_id)
            li.setProperty('extension', str((row or {}).get('container_extension') or 'mp4'))
            if item_id and item_id in self._favorite_movie_ids:
                li.setProperty('ibo_favorite', '1')
        else:
            item_id = str((row or {}).get('series_id') or '')
            li.setProperty('id', item_id)
            if item_id and item_id in self._favorite_series_ids:
                li.setProperty('ibo_favorite', '1')
        li.setProperty('index', str(int(absolute_index)))
        return li, item_id

    def _render_page(self):
        """Initial/reset render; subsequent navigation only appends batches.

        ``page`` is retained as a resume hint for contexts returned from details.
        When reopening a catalog, enough batches are staged to include that
        position, then the previously selected item is restored. Normal scrolling
        never calls ``reset()`` again.
        """
        total = len(self.filtered)
        pages = max(1, int(math.ceil(total / float(self.page_size))))
        self.page = max(0, min(self.page, pages - 1))

        selected_abs = -1
        if self.selected_id:
            for idx, row in enumerate(self.filtered):
                if self.mode == 'movie':
                    item_id = str((row or {}).get('stream_id') or '')
                else:
                    item_id = str((row or {}).get('series_id') or '')
                if item_id == self.selected_id:
                    selected_abs = idx
                    break

        target_count = min(total, max(self.page_size, (self.page + 1) * self.page_size))
        if selected_abs >= 0:
            target_count = min(total, max(target_count, ((selected_abs // self.page_size) + 1) * self.page_size))

        items = []
        grid_started = time.monotonic()
        for absolute, row in enumerate(self.filtered[:target_count]):
            li, _item_id = self._grid_item(row, absolute)
            items.append(li)
        log('Grade %s: %d ListItems preparados em %.3fs.' % (
            self.mode, len(items), time.monotonic() - grid_started
        ), 'debug')

        control = self.getControl(3030)
        control.reset()
        control.addItems(items)
        self._rendered_count = len(items)

        selected_pos = selected_abs if 0 <= selected_abs < self._rendered_count else 0
        if items:
            try:
                control.selectItem(selected_pos)
            except Exception:
                pass
        if selected_pos >= 0:
            self.page = selected_pos // self.page_size
        self.setProperty('IBO.Page', '%d / %d' % (self.page + 1, pages))

    def _grid_position(self):
        try:
            return int(self.getControl(3030).getSelectedPosition())
        except Exception:
            return 0

    def _grid_size(self):
        try:
            return int(self.getControl(3030).size())
        except Exception:
            return 0

    def _has_next_page(self):
        # Nome mantido por compatibilidade interna; agora significa "há itens
        # filtrados ainda não anexados ao painel".
        return self._rendered_count < len(self.filtered)

    def _append_next_page(self):
        if self.mode == 'live' or self._batch_loading or not self._has_next_page():
            return False
        self._batch_loading = True
        try:
            start = max(0, int(self._rendered_count))
            end = min(len(self.filtered), start + self.page_size)
            items = []
            grid_started = time.monotonic()
            for absolute in range(start, end):
                li, _item_id = self._grid_item(self.filtered[absolute], absolute)
                items.append(li)
            log('Grade %s: lote %d-%d preparado em %.3fs.' % (
                self.mode, start, end, time.monotonic() - grid_started
            ), 'debug')
            if not items:
                return False
            self.getControl(3030).addItems(items)
            self._rendered_count = end
            return True
        finally:
            self._batch_loading = False

    def _ensure_rendered(self, absolute_index):
        target = max(0, int(absolute_index))
        while target >= self._rendered_count and self._has_next_page():
            if not self._append_next_page():
                break
        return target < self._rendered_count

    def _select_grid_absolute(self, absolute_index):
        if not self.filtered:
            return False
        target = max(0, min(int(absolute_index), len(self.filtered) - 1))
        if not self._ensure_rendered(target):
            return False
        try:
            self.getControl(3030).selectItem(target)
            self.setFocusId(3030)
        except Exception:
            return False
        self.page = target // self.page_size
        pages = max(1, int(math.ceil(len(self.filtered) / float(self.page_size))))
        self.setProperty('IBO.Page', '%d / %d' % (self.page + 1, pages))
        return True

    def _turn_page(self, delta, column=None):
        """PageUp/PageDown without replacing the panel contents.

        Kept under the historical method name so existing callers/tests remain
        simple. The target is an absolute index inside the same continuous panel.
        """
        if self.mode == 'live' or self._batch_loading:
            return False
        pos = self._grid_position()
        if int(delta) > 0:
            target = min(len(self.filtered) - 1, pos + self.page_size)
        else:
            target = max(0, pos - self.page_size)
        if target == pos:
            return False
        return self._select_grid_absolute(target)

    def _clear_search_for_category(self):
        if not self.query:
            return
        self.query = ''
        self.page = 0
        self.selected_id = ''
        try:
            self.getControl(3005).setText('')
        except Exception:
            pass

    def _selected_category(self):
        try:
            return self.getControl(3020).getSelectedItem().getProperty('category_id')
        except Exception:
            return ''

    def _selected_row(self):
        control_id = 3040 if self.mode == 'live' else 3030
        try:
            li = self.getControl(control_id).getSelectedItem()
        except Exception:
            return None, None
        if li is None:
            return None, None
        try:
            absolute = int(li.getProperty('index'))
            return self.filtered[absolute], li
        except Exception:
            return None, li

    @staticmethod
    def _epg_stamp(value):
        text = str(value or '').strip()
        if not text:
            return 0
        try:
            number = int(float(text))
            if number > 1000000000:
                return number
        except Exception:
            pass
        for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%d/%m/%Y %H:%M:%S', '%d/%m/%Y %H:%M'):
            try:
                return int(time.mktime(time.strptime(text, fmt)))
            except Exception:
                pass
        return 0

    @staticmethod
    def _epg_clock(stamp):
        try:
            return time.strftime('%H:%M', time.localtime(int(stamp))) if int(stamp) > 0 else '--:--'
        except Exception:
            return '--:--'

    def _epg_view(self, rows):
        now = int(time.time())
        normalized = []
        for row in rows if isinstance(rows, list) else []:
            if not isinstance(row, dict):
                continue
            title = _decode_b64(row.get('title') or row.get('name') or '').strip() or 'Sem título'
            desc = _decode_b64(row.get('description') or row.get('desc') or '').strip()
            start = self._epg_stamp(row.get('start_timestamp') or row.get('start') or row.get('start_time'))
            end = self._epg_stamp(row.get('stop_timestamp') or row.get('end_timestamp') or row.get('end') or row.get('stop'))
            normalized.append((start, end, title, desc))
        if not normalized:
            return {
                'now_time': '--:--',
                'now_title': 'Programação indisponível',
                'now_desc': 'O servidor não informou EPG para este canal.',
                'upcoming': [],
            }

        current_idx = 0
        for idx, item in enumerate(normalized):
            start, end = item[0], item[1]
            if start and end and start <= now < end:
                current_idx = idx
                break
            if start and start >= now:
                current_idx = idx
                break

        cstart, cend, ctitle, cdesc = normalized[current_idx]
        upcoming = []
        for start, end, title, _desc in normalized[current_idx + 1:current_idx + 6]:
            upcoming.append({
                'time': '%s - %s' % (self._epg_clock(start), self._epg_clock(end)),
                'title': title,
            })
        progress = 0
        if cstart and cend and cend > cstart:
            progress = int(max(0, min(100, round(((now - cstart) / float(cend - cstart)) * 100.0))))
        return {
            'now_time': '%s - %s' % (self._epg_clock(cstart), self._epg_clock(cend)),
            'now_title': ctitle,
            'now_desc': cdesc[:360],
            'progress': progress,
            'upcoming': upcoming,
        }

    def _format_epg(self, rows):
        """Legacy text representation kept for diagnostics/tests."""
        view = self._epg_view(rows)
        now_text = '%s  %s' % (view.get('now_time') or '--:--', view.get('now_title') or '')
        if view.get('now_desc'):
            now_text += '\n' + str(view.get('now_desc'))
        upcoming = view.get('upcoming') or []
        next_text = '\n\n'.join('%s  %s' % (item.get('time') or '--:--', item.get('title') or '') for item in upcoming)
        if not next_text:
            next_text = 'Sem próximos programas informados.'
        return now_text, next_text

    def _set_live_properties(self, row, now_text='', epg_text='', view=None):
        try:
            self.setProperty('IBO.LiveName', self._name(row) if row else '')
            # O painel lateral toca somente a arte do canal selecionado; aqui
            # vale usar o cache resiliente sem enfileirar o catálogo Live inteiro.
            self.setProperty('IBO.LiveIcon', _catalog_art((row or {}).get('stream_icon') or '', private_cache=True, fallback=_media('live_fallback.png')))
            if view is None:
                view = {
                    'now_time': '',
                    'now_title': str(now_text or 'Carregando programação...'),
                    'now_desc': '',
                    'upcoming': [],
                }
            self.setProperty('IBO.LiveNowTime', str(view.get('now_time') or ''))
            self.setProperty('IBO.LiveNowTitle', str(view.get('now_title') or ''))
            self.setProperty('IBO.LiveNowDesc', str(view.get('now_desc') or ''))
            self.setProperty('IBO.LiveNow', str(now_text or ''))
            self.setProperty('IBO.LiveEPG', str(epg_text or ''))
            upcoming = list(view.get('upcoming') or [])
            for idx in range(5):
                item = upcoming[idx] if idx < len(upcoming) else {}
                self.setProperty('IBO.EPG%dTime' % (idx + 1), str(item.get('time') or ''))
                self.setProperty('IBO.EPG%dTitle' % (idx + 1), str(item.get('title') or ''))
        except Exception:
            pass

    def _epg_rows_cached_or_fetch(self, stream_id):
        if stream_id in self._epg_cache:
            return self._epg_cache.get(stream_id) or []
        data = self.client.request('get_short_epg', {'stream_id': stream_id, 'limit': 8}, cached=True, ttl=60, timeout=2)
        rows = data.get('epg_listings') if isinstance(data, dict) else []
        rows = rows if isinstance(rows, list) else []
        self._epg_cache[stream_id] = rows
        return rows

    def _apply_live_list_epg(self, index, view):
        try:
            control = self.getControl(3040)
            if index < 0 or index >= control.size():
                return
            li = control.getListItem(index)
            title = str((view or {}).get('now_title') or '')
            progress = int((view or {}).get('progress') or 0)
            if title and title != 'Programação indisponível':
                li.setProperty('epg_line', '%s • %d%%' % (title, progress))
                li.setProperty('epg_percent', str(progress))
            else:
                li.setProperty('epg_line', '')
                li.setProperty('epg_percent', '')
        except Exception:
            pass

    def _epg_worker(self, seq, selected_index, row):
        try:
            # Debounce: a lista/foco responde instantaneamente; rede/EPG só começa
            # se o usuário realmente permanecer naquele canal por 120 ms.
            if self._epg_stop.wait(0.12) or seq != self._epg_seq:
                return
            order = [selected_index]
            for distance in (1, 2):
                for idx in (selected_index - distance, selected_index + distance):
                    if 0 <= idx < len(self.filtered) and idx not in order:
                        order.append(idx)
            for idx in order:
                if self._epg_stop.is_set() or seq != self._epg_seq:
                    return
                target = self.filtered[idx] if 0 <= idx < len(self.filtered) else {}
                stream_id = str((target or {}).get('stream_id') or '')
                if not stream_id:
                    continue
                try:
                    rows = self._epg_rows_cached_or_fetch(stream_id)
                    view = self._epg_view(rows)
                    self._apply_live_list_epg(idx, view)
                    if idx == selected_index and seq == self._epg_seq:
                        now_text, epg_text = self._format_epg(rows)
                        self._set_live_properties(row, now_text, epg_text, view=view)
                except Exception as exc:
                    log('EPG do canal %s indisponível: %s' % (stream_id, exc), 'debug')
                    if idx == selected_index and seq == self._epg_seq:
                        plot = str((row or {}).get('plot') or '').strip()
                        view = {'now_time':'--:--','now_title':plot or 'Programação indisponível para este canal.',
                                'now_desc':'O servidor não respondeu ao EPG em tempo hábil.','progress':0,'upcoming':[]}
                        self._set_live_properties(row, view['now_title'], view['now_desc'], view=view)
        finally:
            try:
                with self._epg_threads_lock:
                    self._epg_threads.discard(threading.current_thread())
            except Exception:
                pass

    def _update_live_info(self):
        if self.mode != 'live':
            return
        row, li = self._selected_row()
        self._epg_seq += 1
        seq = self._epg_seq
        if not row:
            self._set_live_properties({}, 'Selecione um canal.', '')
            return
        stream_id = str((row or {}).get('stream_id') or '')
        self.selected_id = stream_id
        self._set_live_properties(row, 'Carregando programação...', '')
        if not stream_id or self._epg_stop.is_set():
            if not stream_id:
                self._set_live_properties(row, 'Programação indisponível para este canal.', '')
            return
        try:
            selected_index = int((li.getProperty('index') if li is not None else '') or self.getControl(3040).getSelectedPosition())
        except Exception:
            selected_index = 0
        thread = threading.Thread(target=self._epg_worker, args=(seq, selected_index, dict(row)), name='IBO-EPG-Debounce')
        thread.daemon = True
        with self._epg_threads_lock:
            self._epg_threads.add(thread)
        thread.start()

    def _context(self):
        if self.mode != 'live':
            try:
                self.page = max(0, self._grid_position() // self.page_size)
            except Exception:
                pass
        data = {
            'category_id': self.current_category,
            'query': self.query,
            'page': self.page,
            'snapshot_category': self.current_category,
            'items_snapshot': self.all_items,
            'global_snapshot': self.global_items,
        }
        if self._adult_unlocked:
            data['adult_unlocked'] = sorted(self._adult_unlocked)
        row, _li = self._selected_row()
        if row:
            if self.mode in ('live', 'movie'):
                data['selected_id'] = str((row or {}).get('stream_id') or '')
            else:
                data['selected_id'] = str((row or {}).get('series_id') or '')
        return data

    def _toggle_selected_favorite(self):
        row, selected_li = self._selected_row()
        if not isinstance(row, dict):
            return False
        # Dentro de Favoritos, guardar a posição antes da remoção. Live e
        # IBOBrowser usam defaultcontrol=3010 (Voltar); reconstruir a lista/grade
        # pode devolver o foco ao botão ou, em Filmes/Séries, saltar para o
        # primeiro card. Preservamos a posição absoluta e selecionamos o próximo
        # item na mesma posição (ou o anterior, se era o último favorito).
        favorite_pos = -1
        if self.current_category == '__favorites__' and self.mode in ('live', 'movie', 'series'):
            try:
                control_id = 3040 if self.mode == 'live' else 3030
                favorite_pos = int(self.getControl(control_id).getSelectedPosition())
            except Exception:
                favorite_pos = -1
        candidate = dict(row)
        # Alguns endpoints Xtream não repetem category_id em cada item. Salvar
        # o contexto real preserva proteção adulta e diagnóstico sem guardar URL.
        if (not candidate.get('category_id') and not candidate.get('_ibo_category_id') and
                self.current_category not in ('', '__favorites__', '__continue__')):
            candidate['_ibo_category_id'] = str(self.current_category)
        result = toggle_favorite(self.mode, candidate)
        if result == 'failed':
            try:
                xbmcgui.Dialog().notification(ui('favorites', 'Favoritos'), 'Não foi possível alterar o favorito.', time=1800, sound=False)
            except Exception:
                pass
            return False
        text = ui('favorite_removed', 'Removido dos favoritos') if result == 'removed' else ui('favorite_added', 'Adicionado aos favoritos')
        try:
            xbmcgui.Dialog().notification(ui('favorites', 'Favoritos'), text, time=1800, sound=False)
        except Exception:
            pass
        log('Favoritos: %s %s:%s.' % (result, self.mode, str(candidate.get('stream_id') or candidate.get('series_id') or '')), 'debug')
        # O selo acompanha Filmes/Canais/Séries e mantém o cache local coerente
        # para os próximos itens renderizados. Em Canais, o ListItem já presente
        # na ControlList é atualizado in-place; não resetamos a lista porque
        # IBOLive usa defaultcontrol=3010 (Voltar) e reset() pode roubar o foco
        # do canal selecionado.
        if self.mode in ('movie', 'live', 'series'):
            favorite_id = str(candidate.get('series_id') or '') if self.mode == 'series' else str(candidate.get('stream_id') or '')
            if self.mode == 'movie':
                favorite_ids = self._favorite_movie_ids
            elif self.mode == 'live':
                favorite_ids = self._favorite_live_ids
            else:
                favorite_ids = self._favorite_series_ids
            if favorite_id:
                if result == 'added':
                    favorite_ids.add(favorite_id)
                    try:
                        if selected_li is not None:
                            selected_li.setProperty('ibo_favorite', '1')
                            if self.mode == 'live':
                                selected_li.setLabel(self._name(candidate))
                    except Exception:
                        pass
                else:
                    favorite_ids.discard(favorite_id)
                    try:
                        if selected_li is not None:
                            selected_li.setProperty('ibo_favorite', '')
                            if self.mode == 'live':
                                selected_li.setLabel(self._name(candidate))
                    except Exception:
                        pass
        if self.current_category == '__favorites__':
            if self.mode == 'live':
                self._epg_seq += 1
            self.all_items = self._fetch_items('__favorites__')
            self.selected_id = ''
            self.page = 0
            self._apply_filter()
            if self.mode == 'live' and self.filtered:
                try:
                    control = self.getControl(3040)
                    target_pos = min(max(favorite_pos, 0), max(0, control.size() - 1))
                    control.selectItem(target_pos)
                    target_row = self.filtered[target_pos] if target_pos < len(self.filtered) else {}
                    self.selected_id = str((target_row or {}).get('stream_id') or '')
                    self.setFocusId(3040)
                    self._update_live_info()
                    log('Favoritos Live: foco preservado na lista após remoção (posição=%d).' % target_pos, 'debug')
                except Exception as exc:
                    log('Favoritos Live: restauração de foco após remoção falhou: %s' % exc, 'debug')
            elif self.mode in ('movie', 'series') and self.filtered:
                try:
                    target_pos = min(max(favorite_pos, 0), len(self.filtered) - 1)
                    if self._select_grid_absolute(target_pos):
                        target_row = self.filtered[target_pos]
                        if self.mode == 'movie':
                            self.selected_id = str((target_row or {}).get('stream_id') or '')
                        else:
                            self.selected_id = str((target_row or {}).get('series_id') or '')
                        log('Favoritos %s: foco preservado na grade após remoção (posição=%d).' % (self.mode, target_pos), 'debug')
                except Exception as exc:
                    log('Favoritos %s: restauração de foco após remoção falhou: %s' % (self.mode, exc), 'debug')
            elif not self.filtered:
                try:
                    # Favoritos vazio: permanecer na própria categoria Favoritos,
                    # nunca no botão Voltar.
                    self._select_category_by_id('__favorites__')
                    self.setFocusId(3020)
                except Exception:
                    pass
        return True

    def _selected_context_menu(self):
        row, selected_li = self._selected_row()
        if not isinstance(row, dict):
            return False
        options = []
        actions = []
        if self.mode in ('live', 'movie'):
            options.append(ui('cast', 'Transmitir'))
            actions.append('cast')
        if cast_active():
            options.append(ui('cast_stop', 'Parar transmissão'))
            actions.append('cast_stop')
        favorite_on = False
        try:
            favorite_on = bool(selected_li is not None and selected_li.getProperty('ibo_favorite') == '1')
        except Exception:
            favorite_on = False
        options.append(('Remover dos favoritos' if favorite_on else 'Adicionar aos favoritos'))
        actions.append('favorite')
        try:
            choice = xbmcgui.Dialog().contextmenu(options)
        except Exception:
            choice = xbmcgui.Dialog().select('ONEPLAY', options)
        if choice is None or int(choice) < 0 or int(choice) >= len(actions):
            return True
        selected = actions[int(choice)]
        if selected == 'favorite':
            self._toggle_selected_favorite()
            return True
        self._epg_seq += 1
        if selected == 'cast_stop':
            self.close_with({'action': 'cast_stop', 'context': self._context()})
            return True
        action = 'cast_live' if self.mode == 'live' else 'cast_movie'
        self.close_with({'action': action, 'item': row, 'context': self._context()})
        return True

    def onClick(self, control_id):
        if control_id == 3001 or control_id == 3010:
            self._epg_seq += 1
            self.close_with({'action': 'home'})
        elif control_id == 3002:
            if self.mode != 'live':
                self._epg_seq += 1
                self.close_with({'action': 'section', 'mode': 'live'})
            return
        elif control_id == 3003:
            self._epg_seq += 1
            self.close_with({'action': 'section', 'mode': 'movie'})
        elif control_id == 3004:
            self._epg_seq += 1
            self.close_with({'action': 'section', 'mode': 'series'})
        elif control_id == 3012:
            try:
                if _own_background_playback_active():
                    if not _background_resume_request_allowed():
                        return
                    self._epg_seq += 1
                    self.close_with({'action': 'resume_player', 'context': self._context()})
            except Exception:
                pass
        elif control_id == 3011:
            # PROCURAR é um atalho para a caixa de pesquisa do topo; não executa
            # uma busca vazia nem reinicia o catálogo por conta própria.
            try:
                self.setFocusId(3005)
            except Exception:
                pass
        elif control_id == 3006:
            try:
                self.query = self.getControl(3005).getText()
            except Exception:
                self.query = ''
            self.page = 0
            self.selected_id = ''
            self._apply_filter()
            try:
                self.setFocusId(3040 if self.mode == 'live' else 3030)
            except Exception:
                pass
        elif control_id == 3020:
            category_id = self._selected_category()
            if not self._verify_adult_category(category_id):
                return
            had_search = bool(self.query)
            self._clear_search_for_category()
            if str(category_id) != str(self.current_category) or had_search:
                self.selected_id = ''
                self._load_items(category_id)
            # Enter em uma categoria confirma e entra no conteúdo.
            target = 3040 if self.mode == 'live' else 3030
            if self.filtered:
                if xbmc is not None:
                    xbmc.sleep(50)
                try:
                    self.setFocusId(target)
                except Exception:
                    pass
                if self.mode == 'live':
                    self._update_live_info()
        elif control_id == 3040 and self.mode == 'live':
            row, _li = self._selected_row()
            if row:
                self._epg_seq += 1
                begin_content_opening()
                self.close_with({'action': 'play_live', 'item': row, 'context': self._context()})
        elif control_id == 3030 and self.mode in ('movie', 'series'):
            row, _li = self._selected_row()
            if row:
                action = 'movie_detail' if self.mode == 'movie' else 'series_detail'
                self.close_with({'action': action, 'item': row, 'context': self._context()})

    def onAction(self, action):
        try:
            aid = action.getId()
        except Exception:
            return
        if aid == ACTION_CONTEXT_MENU:
            try:
                focus_id = self.getFocusId()
            except Exception:
                focus_id = 0
            if focus_id == (3040 if self.mode == 'live' else 3030):
                if get_int('universal_cast', default=0, low=0, high=1):
                    self._selected_context_menu()
                else:
                    # Contrato homologado 2.3.4: OK longo alterna Favorito
                    # diretamente, sem abrir menu intermediário.
                    self._toggle_selected_favorite()
                return
        if aid in ACTION_BACK:
            if _own_background_playback_active():
                if not _background_back_guard_open():
                    log('Player BG: repetição inicial de Back ignorada após retorno do fullscreen.', 'debug')
                    return
                if not _background_resume_request_allowed():
                    return
                self._epg_seq += 1
                log('Player BG: Back físico retornando ao mesmo player.', 'debug')
                self.close_with({'action': 'resume_player', 'context': self._context()})
                return
            self._epg_seq += 1
            self.close_with({'action': 'home'})
            return
        try:
            focus_id = self.getFocusId()
        except Exception:
            focus_id = 0
        if self.mode != 'live' and focus_id == 3030 and aid == ACTION_PAGE_DOWN:
            self._turn_page(1)
            return
        if self.mode != 'live' and focus_id == 3030 and aid == ACTION_PAGE_UP:
            self._turn_page(-1)
            return

        # Category -> content is explicit in every section. Merely highlighting
        # another category does not fire onClick in Kodi, so Direita must first
        # commit/load the highlighted category and only then move the focus.
        content_id = 3040 if self.mode == 'live' else 3030
        if aid == ACTION_RIGHT and focus_id == 3020:
            category_id = self._selected_category()
            if not self._verify_adult_category(category_id):
                return
            had_search = bool(self.query)
            self._clear_search_for_category()
            if str(category_id) != str(self.current_category) or had_search:
                self.selected_id = ''
                self._load_items(category_id)
            if self.filtered:
                if xbmc is not None:
                    xbmc.sleep(50)
                try:
                    self.setFocusId(content_id)
                except Exception:
                    pass
                if self.mode == 'live':
                    self._update_live_info()
            return

        # Filmes/Séries usam um painel contínuo abastecido em lotes. Ao chegar
        # ao fim do lote carregado, apenas anexamos o próximo e avançamos para o
        # índice absoluto seguinte; não existe reset/troca de "página" que possa
        # recolocar visualmente o usuário no topo.
        if self.mode != 'live' and focus_id == 3030:
            pos = self._grid_position()
            size = self._grid_size()
            columns = 6
            if aid == ACTION_DOWN and size and pos >= max(0, size - columns) and self._has_next_page():
                if self._append_next_page():
                    self._select_grid_absolute(min(pos + columns, len(self.filtered) - 1))
                return
            if aid == ACTION_RIGHT and size and pos == size - 1 and self._has_next_page():
                if self._append_next_page():
                    self._select_grid_absolute(min(pos + 1, len(self.filtered) - 1))
                return

        if aid == ACTION_LEFT and focus_id == content_id:
            # Live is a single vertical list, so Left always returns to categories.
            # Movie/series is a poster grid: let Kodi move left inside the row and
            # only let the panel's own onleft route to categories at the first column.
            if self.mode == 'live':
                try:
                    self.setFocusId(3020)
                except Exception:
                    pass
                return

        if self.mode == 'live' and aid in (ACTION_UP, ACTION_DOWN) and focus_id == 3040:
            self._update_live_info()
        BaseWindow.onAction(self, action)


def show_browser(mode, categories, client, context=None):
    context = context or {}
    xml_name = 'IBOLive.xml' if str(mode) == 'live' else 'IBOBrowser.xml'
    return _open(BrowserWindow, xml_name, mode=mode, categories=categories, client=client,
                 category_id=context.get('category_id',''), query=context.get('query',''),
                 page=context.get('page',0), selected_id=context.get('selected_id',''),
                 adult_unlocked=context.get('adult_unlocked') or [],
                 snapshot_category=context.get('snapshot_category',''),
                 items_snapshot=context.get('items_snapshot'), global_snapshot=context.get('global_snapshot'))


class SeriesEpisodesWindow(BaseWindow):
    def configure(self, **kwargs):
        BaseWindow.configure(self, **kwargs)
        self.client = kwargs.get('client')
        self.series = kwargs.get('series') or {}
        self.info = kwargs.get('info') or {}
        self.season_keys = []
        self.resume_entry = kwargs.get('resume_entry') if isinstance(kwargs.get('resume_entry'), dict) else {}

        self._history_stop = threading.Event()
        self._history_thread = None
        self._history_revision_seen = ''

    @staticmethod
    def _episode_base_label(row):
        num = (row or {}).get('episode_num') or (row or {}).get('episode_number') or ''
        title = str((row or {}).get('title') or ('Episódio %s' % num))
        return ('E%s - %s' % (num, title) if num else title), title

    def _refresh_episode_history(self):
        try:
            season_item = self.getControl(4100).getSelectedItem()
            season = season_item.getProperty('season') if season_item is not None else ''
        except Exception:
            season = ''
        rows = (self.info.get('episodes') or {}).get(str(season), [])
        control = self.getControl(4200)
        for idx, row in enumerate(rows if isinstance(rows, list) else []):
            if idx >= control.size():
                break
            stream_id = str((row or {}).get('id') or (row or {}).get('stream_id') or '')
            state = get_entry('series', stream_id)
            suffix = ''
            if state.get('watched'):
                suffix = ' • %s' % ui('watched', 'Assistido')
            elif float(state.get('position') or 0) >= 30.0:
                suffix = ' • %s' % ui('continue_watching', 'Continuar assistindo')
            base_label, _title = self._episode_base_label(row)
            try:
                control.getListItem(idx).setLabel(base_label + suffix)
            except Exception:
                pass

    def _history_loop(self):
        self._history_revision_seen = _history_revision()
        background_seen = _background_video_property_active()
        while not self._history_stop.is_set():
            revision = _history_revision()
            background_now = _background_video_property_active()
            history_changed = bool(revision and revision != self._history_revision_seen)
            background_changed = background_now != background_seen
            if history_changed:
                self._history_revision_seen = revision
            if background_changed:
                background_seen = background_now
            if history_changed or background_changed:
                try:
                    self._refresh_episode_history()
                    back = self.getControl(4001)
                    back.controlRight(self.getControl(4002) if background_now else back)
                except Exception as exc:
                    log('Séries: repaint local do histórico falhou: %s' % exc, 'debug')
            if self._history_stop.wait(0.40):
                break

    def close_with(self, result):
        self._history_stop.set()
        BaseWindow.close_with(self, result)

    def shutdown(self):
        self._history_stop.set()
        worker = getattr(self, '_history_thread', None)
        if worker is not None and worker is not threading.current_thread() and worker.is_alive():
            worker.join(0.55)

    def onInit(self):
        self.setProperty('IBO.SeriesTitle', str(self.series.get('name') or 'Série'))
        episodes = self.info.get('episodes') or {}
        if isinstance(episodes, dict):
            self.season_keys = sorted(episodes.keys(), key=lambda x: int(x) if str(x).isdigit() else str(x))
        seasons = self.getControl(4100); seasons.reset()
        for key in self.season_keys:
            li = xbmcgui.ListItem(label='Temporada %s' % key)
            li.setProperty('season', str(key)); seasons.addItem(li)
        if self.season_keys:
            target_season = str(self.resume_entry.get('season') or self.season_keys[0])
            if target_season not in [str(x) for x in self.season_keys]:
                target_season = str(self.season_keys[0])
            try:
                seasons.selectItem([str(x) for x in self.season_keys].index(target_season))
            except Exception:
                pass
            self._populate_episodes(target_season, select_stream_id=str(self.resume_entry.get('stream_id') or ''))
        # VOLTAR AO PLAYER fica disponível durante reprodução, mas não deve
        # roubar o foco. A ordem visual/nativa é VOLTAR -> VOLTAR AO PLAYER.
        # Declaramos a rota no controle para evitar processar a mesma seta duas
        # vezes (Kodi nativo + onAction Python), como já corrigido no Browser.
        background_video = _sync_background_video_property()
        if background_video:
            log('Player BG: videowindow habilitado na tela de episódios.', 'debug')
        try:
            back = self.getControl(4001)
            if background_video:
                back.controlRight(self.getControl(4002))
            else:
                back.controlRight(back)
            self.setFocusId(4001)
        except Exception:
            try:
                self.setFocusId(4001)
            except Exception:
                pass
        # O Kodi 21 pode recusar foco em lista durante onInit; o XML inicia em VOLTAR.
        self._history_thread = threading.Thread(target=self._history_loop, name='IBO-HistoryEpisodes')
        self._history_thread.daemon = True
        self._history_thread.start()
        finish_player_return()

    def _populate_episodes(self, season, select_stream_id=''):
        rows = (self.info.get('episodes') or {}).get(str(season), [])
        control = self.getControl(4200); control.reset()
        selected_pos = 0
        for idx, row in enumerate(rows if isinstance(rows, list) else []):
            num = row.get('episode_num') or row.get('episode_number') or ''
            base_label, title = self._episode_base_label(row)
            stream_id = str(row.get('id') or row.get('stream_id') or '')
            state = get_entry('series', stream_id)
            suffix = ''
            if state.get('watched'):
                suffix = ' • %s' % ui('watched', 'Assistido')
            elif float(state.get('position') or 0) >= 30.0:
                suffix = ' • %s' % ui('continue_watching', 'Continuar assistindo')
            label = base_label + suffix
            li = xbmcgui.ListItem(label=label)
            info = row.get('info') or {}
            art = _catalog_art(info.get('movie_image') or info.get('cover_big') or self.series.get('cover') or '', fallback=_media('no_vod.png'))
            li.setArt({'thumb': art})
            li.setProperty('id', stream_id)
            li.setProperty('extension', str(row.get('container_extension') or 'mp4'))
            li.setProperty('plot', str(info.get('plot') or ''))
            li.setProperty('title', title)
            li.setProperty('episode', str(num or '0'))
            li.setProperty('season', str(season))
            control.addItem(li)
            if select_stream_id and stream_id == str(select_stream_id):
                selected_pos = idx
        if control.size() > 0:
            try:
                control.selectItem(selected_pos)
            except Exception:
                pass

    def onClick(self, control_id):
        if control_id == 4001:
            self.close_with('back')
        elif control_id == 4002:
            try:
                if _own_background_playback_active():
                    if not _background_resume_request_allowed():
                        return
                    self.close_with({'action': 'resume_player'})
            except Exception:
                pass
        elif control_id == 4100:
            try:
                season = self.getControl(4100).getSelectedItem().getProperty('season')
                self._populate_episodes(season)
                self.setFocusId(4200)
            except Exception:
                pass
        elif control_id == 4200:
            try:
                li = self.getControl(4200).getSelectedItem()
                if li is not None:
                    begin_content_opening()
                    self.close_with({'action': 'play', 'id': li.getProperty('id'), 'title': li.getProperty('title') or li.getLabel(),
                                     'extension': li.getProperty('extension'), 'art': li.getArt('thumb'),
                                     'plot': li.getProperty('plot'), 'season': li.getProperty('season'),
                                     'episode': li.getProperty('episode')})
            except Exception as exc:
                log('Séries: falha técnica ao selecionar episódio: %s' % exc, 'warning')
                show_message('REPRODUÇÃO', humanize_content_error(exc, kind='series', phase='episode_select'))

    def onAction(self, action):
        try:
            aid = action.getId()
            if (aid == ACTION_CONTEXT_MENU and self.getFocusId() == 4200 and
                    get_int('universal_cast', default=0, low=0, high=1)):
                li = self.getControl(4200).getSelectedItem()
                if li is not None:
                    options = [ui('cast', 'Transmitir')]
                    actions = ['cast']
                    if cast_active():
                        options.append(ui('cast_stop', 'Parar transmissão'))
                        actions.append('cast_stop')
                    try:
                        choice = xbmcgui.Dialog().contextmenu(options)
                    except Exception:
                        choice = xbmcgui.Dialog().select('ONEPLAY', options)
                    if choice is not None and int(choice) >= 0 and int(choice) < len(actions):
                        if actions[int(choice)] == 'cast_stop':
                            self.close_with({'action': 'cast_stop'})
                        else:
                            self.close_with({'action': 'cast', 'id': li.getProperty('id'), 'title': li.getProperty('title') or li.getLabel(),
                                             'extension': li.getProperty('extension'), 'art': li.getArt('thumb'),
                                             'plot': li.getProperty('plot'), 'season': li.getProperty('season'),
                                             'episode': li.getProperty('episode')})
                    return
            if aid in ACTION_BACK:
                if _own_background_playback_active():
                    if not _background_back_guard_open():
                        log('Player BG: repetição inicial de Back ignorada após retorno do fullscreen.', 'debug')
                        return
                    if not _background_resume_request_allowed():
                        return
                    log('Player BG: Back físico retornando ao mesmo player.', 'debug')
                    self.close_with({'action': 'resume_player'}); return
                self.close_with('back'); return
        except Exception:
            pass
        # A navegação Direita é nativa via controlRight(); não repetir a tecla
        # em Python, pois Kodi 21 pode já ter atualizado o foco antes do callback.
        BaseWindow.onAction(self, action)


def show_series_episodes(client, series, info):
    resume_entry = latest_series_resume((series or {}).get('series_id'))
    return _open(SeriesEpisodesWindow, 'IBOSeriesEpisodes.xml', client=client, series=series, info=info, resume_entry=resume_entry)


class InfoWindow(BaseWindow):
    def configure(self, **kwargs):
        BaseWindow.configure(self, **kwargs)
        self.payload = kwargs.get('payload') or {}
        self._history_stop = threading.Event()
        self._history_thread = None
        self._history_revision_seen = ''

    def _refresh_resume_label(self):
        kind = str(self.payload.get('kind') or 'movie')
        stream_id = str(self.payload.get('stream_id') or '')
        resume_at = resume_seconds(kind, stream_id) if stream_id else float(self.payload.get('resume_at') or 0.0)
        self.payload['resume_at'] = resume_at
        if resume_at >= 30.0:
            self.setProperty('IBO.PlayLabel', '%s • %s' % (ui('continue_watching', 'Continuar'), format_position(resume_at)))
        else:
            self.setProperty('IBO.PlayLabel', str(window_labels().get('IBO.L.Play') or 'REPRODUZIR'))

    def _history_loop(self):
        self._history_revision_seen = _history_revision()
        background_seen = _background_video_property_active()
        while not self._history_stop.is_set():
            revision = _history_revision()
            background_now = _background_video_property_active()
            history_changed = bool(revision and revision != self._history_revision_seen)
            background_changed = background_now != background_seen
            if history_changed:
                self._history_revision_seen = revision
            if background_changed:
                background_seen = background_now
            if history_changed or background_changed:
                try:
                    self._refresh_resume_label()
                    back = self.getControl(5002)
                    back.controlRight(self.getControl(5003) if background_now else back)
                except Exception as exc:
                    log('Continuar assistindo: tempo da tela de filme não pôde ser repintado: %s' % exc, 'debug')
            if self._history_stop.wait(0.40):
                break

    def close_with(self, result):
        self._history_stop.set()
        BaseWindow.close_with(self, result)

    def shutdown(self):
        self._history_stop.set()
        worker = getattr(self, '_history_thread', None)
        if worker is not None and worker is not threading.current_thread() and worker.is_alive():
            worker.join(0.55)

    def onInit(self):
        p = self.payload
        self.setProperty('IBO.Backdrop', _catalog_art(p.get('backdrop') or _media('background1.jpg')))
        self.setProperty('IBO.Poster', _catalog_art(p.get('poster') or '', fallback=_media('no_vod.png')))
        self.setProperty('IBO.InfoTitle', str(p.get('title') or ''))
        self.setProperty('IBO.Meta', str(p.get('meta') or ''))
        self.setProperty('IBO.Plot', str(p.get('plot') or 'Sinopse não disponível.'))
        self._refresh_resume_label()
        background_video = _sync_background_video_property()
        if background_video:
            log('Player BG: videowindow habilitado na tela de filme.', 'debug')
        try:
            # Ordem horizontal autoritativa: REPRODUZIR -> VOLTAR ->
            # VOLTAR AO PLAYER. O retorno ao player nunca rouba o foco ao abrir
            # ou restaurar a tela de detalhes.
            back = self.getControl(5002)
            if background_video:
                back.controlRight(self.getControl(5003))
            else:
                back.controlRight(back)
            self.setFocusId(5001)
        except Exception:
            self.setFocusId(5001)
        self._history_thread = threading.Thread(target=self._history_loop, name='IBO-HistoryInfo')
        self._history_thread.daemon = True
        self._history_thread.start()
        finish_player_return()

    def onClick(self, control_id):
        if control_id == 5001:
            begin_content_opening()
            self.close_with('play')
        elif control_id == 5002:
            self.close_with('back')
        elif control_id == 5003:
            try:
                if _own_background_playback_active():
                    if not _background_resume_request_allowed():
                        return
                    self.close_with('resume_player')
            except Exception:
                pass

    def onAction(self, action):
        try:
            aid = action.getId()
            if aid == ACTION_CONTEXT_MENU and get_int('universal_cast', default=0, low=0, high=1):
                options = [ui('cast', 'Transmitir')]
                actions = ['cast']
                if cast_active():
                    options.append(ui('cast_stop', 'Parar transmissão'))
                    actions.append('cast_stop')
                try:
                    choice = xbmcgui.Dialog().contextmenu(options)
                except Exception:
                    choice = xbmcgui.Dialog().select('ONEPLAY', options)
                if choice is not None and int(choice) >= 0 and int(choice) < len(actions):
                    self.close_with(actions[int(choice)])
                return
            if aid in ACTION_BACK:
                if _own_background_playback_active():
                    if not _background_back_guard_open():
                        log('Player BG: repetição inicial de Back ignorada após retorno do fullscreen.', 'debug')
                        return
                    if not _background_resume_request_allowed():
                        return
                    log('Player BG: Back físico retornando ao mesmo player.', 'debug')
                    self.close_with('resume_player'); return
                self.close_with('back'); return
        except Exception:
            pass
        # Direita/Esquerda ficam sob navegação nativa. Não usar setFocusId()
        # aqui: uma única seta não pode produzir dois avanços de foco.
        BaseWindow.onAction(self, action)


def show_info(payload):
    return _open(InfoWindow, 'IBOInfo.xml', payload=payload)


class AccountWindow(BaseWindow):
    def configure(self, **kwargs):
        BaseWindow.configure(self, **kwargs)
        self.session = kwargs.get('session') or {}

    def onInit(self):
        s = self.session
        limit = int(s.get('health_limit') or 0)
        used = int(s.get('health_used') or 0)
        mode = str(s.get('health_mode') or 'auto').capitalize()
        connections = 'Ilimitado' if limit == 0 and mode.lower() != 'auto' else ('%d / %d %s' % (used, limit, mode) if limit else mode)
        lines = [
            'Portal: %s' % (s.get('portal_name') or '—'),
            'ID do dispositivo: %s' % get_device_id(),
            'Conexões: %s' % connections,
            _expiry_text(s),
        ]
        self.setProperty('IBO.AccountInfo', '\n\n'.join(lines))
        self.setFocusId(5801)

    def onClick(self, control_id):
        if control_id == 5801:
            self.close_with('back')

    def onAction(self, action):
        try:
            if action.getId() in ACTION_BACK:
                self.close_with('back'); return
        except Exception:
            pass
        BaseWindow.onAction(self, action)


def show_account(session):
    return _open(AccountWindow, 'IBOAccount.xml', session=session)


class CastDeviceChoiceWindow(BaseWindow):
    """Seletor centralizado de receivers no padrão visual do ONEPLAY.

    Esta janela é estritamente de apresentação/seleção. Descoberta, cache,
    wake, handoff e protocolos permanecem sob autoridade de ``cast.py``.
    """

    LIST_ID = 6201
    CANCEL_ID = 6202

    def configure(self, **kwargs):
        BaseWindow.configure(self, **kwargs)
        self.title = str(kwargs.get('title') or ui('cast', 'Transmitir'))
        self.devices = list(kwargs.get('devices') or [])

    @staticmethod
    def _protocol_label(device):
        return 'Google Cast' if str((device or {}).get('protocol') or '') == 'googlecast' else 'DLNA'

    @classmethod
    def _detail_label(cls, device):
        protocol = cls._protocol_label(device)
        model = str((device or {}).get('model') or '').strip()
        name = str((device or {}).get('name') or '').strip()
        if model and model.casefold() not in name.casefold():
            return '%s  •  %s' % (protocol, model)
        return protocol

    def onInit(self):
        self.setProperty('IBO.CastTitle', self.title)
        control = self.getControl(self.LIST_ID)
        control.reset()
        items = []
        for idx, device in enumerate(self.devices):
            item = xbmcgui.ListItem(label=str((device or {}).get('name') or 'Dispositivo'))
            item.setProperty('index', str(idx))
            item.setProperty('detail', self._detail_label(device))
            items.append(item)
        if items:
            try:
                control.addItems(items)
            except Exception:
                for item in items:
                    control.addItem(item)
        if control.size() > 0:
            control.selectItem(0)
            self.setFocusId(self.LIST_ID)
        else:
            self.setFocusId(self.CANCEL_ID)

    def _selected_index(self):
        try:
            item = self.getControl(self.LIST_ID).getSelectedItem()
            if item is None:
                return None
            idx = int(item.getProperty('index'))
            if 0 <= idx < len(self.devices):
                return idx
        except Exception:
            pass
        return None

    def onClick(self, control_id):
        if control_id == self.LIST_ID:
            self.close_with(self._selected_index())
        elif control_id == self.CANCEL_ID:
            self.close_with(None)

    def onAction(self, action):
        try:
            if action.getId() in ACTION_BACK:
                self.close_with(None)
                return
        except Exception:
            pass
        BaseWindow.onAction(self, action)


def show_cast_device_choice(devices, title=None):
    return _open(
        CastDeviceChoiceWindow, 'IBOCastSelect.xml',
        devices=list(devices or []), title=title or ui('cast', 'Transmitir'),
    )


class SettingChoiceWindow(BaseWindow):
    """Seletor modal no padrão dos fragments de configuração do APK IBO."""

    LIST_ID = 6101
    OK_ID = 6102
    CANCEL_ID = 6103

    def configure(self, **kwargs):
        BaseWindow.configure(self, **kwargs)
        self.title = str(kwargs.get('title') or 'Configuração')
        self.choices = list(kwargs.get('choices') or [])
        self.selected = int(kwargs.get('selected') or 0)
        # Apenas seletores que representam uma preferência já aplicada exibem
        # o marcador 'Selecionado'. A lista de APK, por exemplo, é uma ação e
        # não deve sugerir que o primeiro aplicativo já esteja configurado.
        self.mark_selected = bool(kwargs.get('mark_selected', False))

    def onInit(self):
        self.setProperty('IBO.ChoiceTitle', self.title)
        control = self.getControl(self.LIST_ID)
        control.reset()
        selected_pos = min(max(0, self.selected), len(self.choices) - 1) if self.choices else 0
        items = []
        for idx, choice in enumerate(self.choices):
            try:
                label, value = choice[0], choice[1]
            except Exception:
                continue
            item = xbmcgui.ListItem(label=str(label))
            item.setProperty('value', str(value))
            item.setProperty('status', ui('selected', 'Selecionado') if self.mark_selected and idx == selected_pos else '')
            items.append(item)
        # addItems() entrega a lista ao GUI em uma única mensagem e evita uma
        # sequência de repaint/focus durante a abertura dos seletores numéricos.
        if items:
            try:
                control.addItems(items)
            except Exception:
                for item in items:
                    control.addItem(item)
        if control.size() > 0:
            pos = min(max(0, selected_pos), control.size() - 1)
            control.selectItem(pos)
            self.setFocusId(self.LIST_ID)
        else:
            self.setFocusId(self.CANCEL_ID)

    def _result(self):
        try:
            item = self.getControl(self.LIST_ID).getSelectedItem()
            return item.getProperty('value') if item is not None else None
        except Exception:
            return None

    def onClick(self, control_id):
        if control_id == self.LIST_ID:
            self.setFocusId(self.OK_ID)
        elif control_id == self.OK_ID:
            self.close_with(self._result())
        elif control_id == self.CANCEL_ID:
            self.close_with(None)

    def onAction(self, action):
        try:
            if action.getId() in ACTION_BACK:
                self.close_with(None)
                return
        except Exception:
            pass
        BaseWindow.onAction(self, action)


def show_setting_choice(title, choices, selected=0, mark_selected=False):
    return _open(SettingChoiceWindow, 'IBOSettingChoice.xml', title=title, choices=choices, selected=selected, mark_selected=mark_selected)


class SettingsWindow(BaseWindow):
    """Configurações no padrão visual/estrutural do APK IBO oficial.

    A tela principal preserva o padrão visual do APK: botão Voltar no
    topo esquerdo, título central e grade expansível de opções. Os valores
    abrem um seletor modal, reproduzindo o fluxo dos fragments do APK. Somente as
    preferências operacionais permanecem expostas; o antigo TTL do catálogo foi
    removido porque o cache agora persiste até uma ação explícita do usuário.
    """

    LIST_ID = 6001
    BACK_ID = 6002
    # A grade usa três colunas no XML, mas a fonte dos itens permanece única.
    # Assim novas opções entram aqui e o painel continua crescendo em linhas;
    # a rolagem vertical entra automaticamente quando exceder a área visível.
    SETTINGS = (
        {'key':'request_timeout','label':'Timeout de rede','label_id':'network_timeout','icon':'official_ic_timmer.png','low':5,'high':30,'step':1,'unit':'s'},
        {'key':'failover_attempts','label':'Tentativas de failover','label_id':'failover_attempts','icon':'official_ic_auto.png','low':1,'high':8,'step':1},
        {'action':'stream_format','label':'Tipo de fluxo','label_id':'stream_type','icon':'change_m3u_icon.png'},
        {'action':'time_format','label':'Formato de hora','label_id':'time_format','icon':'official_ic_timmer.png'},
        {'action':'language','label':'Mudar idioma','label_id':'change_language','icon':'settings.png'},
        {'key':'page_size','label':'Itens por página','label_id':'items_per_page','icon':'official_ic_widget.png','low':30,'high':120,'step':10},
        {'key':'ffmpeg_direct','label':'Reprodutor FFmpeg Direct','label_id':'ffmpeg_direct','icon':'official_ic_external_player.png','low':0,'high':1,'step':1,'kind':'toggle'},
        {'key':'universal_cast','label':'Chromecast / DLNA','label_id':'universal_cast','icon':'official_ic_external_player.png','low':0,'high':1,'step':1,'kind':'toggle'},
        {'key':'up_next_auto','label':'Próximo episódio automático','label_id':'up_next_auto','icon':'official_ic_auto.png','low':0,'high':1,'step':1,'kind':'toggle'},
        {'action':'adult_pin','label':'Alterar PIN adulto','label_id':'change_adult_pin','icon':'official_ic_lock.png'},
        {'action':'clear_cache','label':'Limpar cache','label_id':'clear_cache','icon':'official_ic_delete.png'},
        {'action':'clear_watch_history','label':'Limpar histórico de reprodução','label_id':'clear_watch_history','icon':'official_ic_delete.png'},
        {'action':'account','label':'Minha conta','label_id':'my_account','icon':'account_icon.png'},
        {'action':'access','label':'Portal de acesso','label_id':'access_portal','icon':'change_m3u_icon.png'},
        {'action':'download_apk','label':'Baixar aplicativos APK','label_id':'download_apk','icon':'official_apk_download.png'},
    )
    DEFAULTS = {'request_timeout':8,'failover_attempts':5,'page_size':60,'ffmpeg_direct':0,'universal_cast':0,'up_next_auto':0}

    def configure(self, **kwargs):
        BaseWindow.configure(self, **kwargs)
        # Impede reentrada de um segundo WindowXMLDialog enquanto o primeiro
        # seletor ainda está sendo aberto/fechado pelo mesmo evento de controle.
        self._choice_active = False

    def onInit(self):
        self.setProperty('IBO.SettingsDevice', 'ID do dispositivo: %s' % get_device_id())
        self._populate(0)
        self._restore_focus(0)

    def _value(self, key):
        return get_int(key, default=self.DEFAULTS.get(key, 0))

    def _set(self, key, value):
        set_value(key, int(value))

    def _entry_label(self, entry):
        label_id = str(entry.get('label_id') or '')
        fallback = str(entry.get('label') or '')
        if label_id == 'time_format':
            return tr('time_format', fallback)
        if label_id == 'change_language':
            return tr('change_language', fallback)
        if label_id == 'clear_cache':
            return 'Limpar cache' if effective_language_code() == 'pt' else tr('delete_cache', fallback)
        return ui(label_id, fallback) if label_id else fallback

    @staticmethod
    def _panel_output(panel=None):
        data = panel if isinstance(panel, dict) else load_panel()
        value = str((data or {}).get('live_stream_format') or (data or {}).get('output') or 'm3u8').strip().lower()
        return value if value in ('m3u8', 'ts') else 'm3u8'

    def _format_value(self, entry):
        # Os cards da grade exibem somente o nome da função. O estado aplicado
        # fica dentro do seletor, evitando abreviações e poluição visual.
        return ''

    def _populate(self, selected=0):
        control = self.getControl(self.LIST_ID)
        control.reset()
        items = []
        for index, entry in enumerate(self.SETTINGS):
            item = xbmcgui.ListItem(label=self._entry_label(entry))
            item.setProperty('index', str(index))
            item.setProperty('icon', str(entry.get('icon') or 'settings.png'))
            item.setProperty('value', self._format_value(entry))
            items.append(item)
        if items:
            try:
                control.addItems(items)
            except Exception:
                for item in items:
                    control.addItem(item)
        if control.size() > 0:
            control.selectItem(min(max(0, int(selected)), control.size() - 1))

    def _restore_focus(self, selected=0):
        """Restaura foco sem resetar/repopular a grade.

        A partir da grade names-only, quase toda alteração muda apenas a
        preferência persistida, não o conteúdo visual dos cards. Manter o
        Panel vivo evita repaint e corrida de foco ao voltar de um diálogo
        filho, especialmente em Android/TV Box mais lento.
        """
        try:
            control = self.getControl(self.LIST_ID)
            if control.size() <= 0:
                self.setFocusId(self.BACK_ID)
                return
            pos = min(max(0, int(selected)), control.size() - 1)
            control.selectItem(pos)
            self.setFocusId(self.LIST_ID)
        except Exception:
            try:
                self.setFocusId(self.BACK_ID)
            except Exception:
                pass

    def _selected(self):
        try:
            control = self.getControl(self.LIST_ID)
            pos = control.getSelectedPosition()
            if 0 <= pos < len(self.SETTINGS):
                return pos, self.SETTINGS[pos]
        except Exception:
            pass
        return -1, None

    def _choices(self, entry):
        key = entry.get('key')
        current = self._value(key)
        if entry.get('kind') == 'toggle':
            values = [0, 1]
        else:
            low, high, step = int(entry['low']), int(entry['high']), int(entry['step'])
            values = list(range(low, high + 1, step))
            if current not in values:
                values.append(current)
                values = sorted(set(values))
        choices = []
        selected = 0
        for idx, value in enumerate(values):
            if value == current:
                selected = idx
            if entry.get('kind') == 'toggle':
                label = ui('activated', 'Ativado') if value else ui('deactivated', 'Desativado')
            elif entry.get('unit') == 's':
                label = '%d segundo%s' % (value, '' if value == 1 else 's')
            else:
                label = str(value)
            choices.append((label, value))
        return choices, selected

    def _show_choice(self, title, choices, selected=0, mark_selected=True):
        """Abre um único seletor modal depois de devolver o clique ao Kodi.

        Kodi 21 pode ainda estar finalizando o evento Select do Panel quando um
        segundo WindowXMLDialog é criado dentro de onClick(). Um settle curto e
        um guarda de reentrada evitam o estado em que o diálogo aparece mas não
        recebe navegação, observado nos seletores numéricos de Timeout/Failover.
        Nenhuma rede é consultada aqui; o valor só é persistido após OK.
        """
        if getattr(self, '_choice_active', False):
            return None
        self._choice_active = True
        try:
            if xbmc is not None:
                xbmc.sleep(70)
            return show_setting_choice(title, choices, selected, mark_selected=mark_selected)
        finally:
            self._choice_active = False

    def _change_stream_format(self, pos):
        panel = load_panel() or {}
        panel_output = self._panel_output(panel)
        if live_stream_locked(panel):
            current = 'HLS (.m3u8)' if panel_output == 'm3u8' else 'MPEG-TS (.ts)'
            # Em modo Fixo a janela continua consultiva: mostra claramente que
            # o valor vem do painel, mas OK/Cancelar/Back não gravam override.
            self._show_choice(
                self._entry_label({'label_id':'stream_type','label':'Tipo de fluxo'}),
                [('%s · %s · %s' % (ui('panel_default', 'Padrão do painel'), current, ui('fixed_by_panel', 'Fixo pelo painel')), '__panel_fixed__')],
                0,
                mark_selected=True,
            )
            self._restore_focus(pos)
            return
        override = get_str('live_stream_output_override', 'panel').strip().lower()
        if override not in ('m3u8', 'ts'):
            override = 'panel'
        panel_name = 'HLS' if panel_output == 'm3u8' else 'MPEG-TS'
        choices = [
            ('%s (%s)' % (ui('panel_default', 'Padrão do painel'), panel_name), 'panel'),
            ('HLS (.m3u8)', 'm3u8'),
            ('MPEG-TS (.ts)', 'ts'),
        ]
        selected = {'panel':0, 'm3u8':1, 'ts':2}.get(override, 0)
        result = self._show_choice(self._entry_label({'label_id':'stream_type','label':'Tipo de fluxo'}), choices, selected)
        if result in ('panel', 'm3u8', 'ts'):
            set_value('live_stream_output_override', result)
        self._restore_focus(pos)

    def _change_time_format(self, pos):
        panel = load_panel() or {}
        panel_value = '0' if str(panel.get('time_format', '1')).strip().lower() in ('0','12','12h','false','no','off') else '1'
        override = get_str('time_format_override', 'panel').strip().lower()
        if override not in ('0','1'):
            override = 'panel'
        ptext = '24H' if panel_value == '1' else '12H'
        choices = [
            ('%s (%s)' % (ui('panel_default', 'Padrão do painel'), ptext), 'panel'),
            (tr('_24_hour_format', '24 horas'), '1'),
            (tr('_12_hour_format', '12 horas'), '0'),
        ]
        selected = {'panel':0, '1':1, '0':2}.get(override, 0)
        result = self._show_choice(tr('time_format', 'Formato de hora'), choices, selected)
        if result in ('panel', '0', '1'):
            set_value('time_format_override', result)
        self._restore_focus(pos)

    def _change_language(self, pos):
        panel_code = panel_language_code()
        override = get_str('language_code_override', 'panel').strip().lower() or 'panel'
        allowed = dict(available_languages())
        if override != 'panel' and override not in allowed:
            override = 'panel'
        choices = [('%s (%s)' % (ui('panel_default', 'Padrão do painel'), language_name(panel_code)), 'panel')]
        choices.extend([('%s (%s)' % (name, code), code) for code, name in available_languages()])
        selected = 0
        if override != 'panel':
            for idx, (_label, value) in enumerate(choices):
                if value == override:
                    selected = idx
                    break
        result = self._show_choice(tr('change_language', 'Mudar idioma'), choices, selected)
        if result == 'panel' or result in allowed:
            set_value('language_code_override', result)
            self._apply_localization()
            self.setProperty('IBO.SettingsDevice', 'ID do dispositivo: %s' % get_device_id())
            # Idioma é a única preferência que altera os próprios nomes dos
            # cards; por isso somente aqui a grade precisa ser reconstruída.
            self._populate(pos)
        self._restore_focus(pos)

    def _change_adult_pin(self):
        current = _prompt_hidden_pin('PIN ATUAL')
        if not current:
            return False
        if not _adult_pin_matches(current):
            show_message('ALTERAR PIN', 'PIN não confirmado. Confira o PIN atual e a conexão com o painel.')
            return False
        new_pin = _prompt_hidden_pin('NOVO PIN (4 DÍGITOS)')
        if not new_pin:
            return False
        if len(new_pin) != 4 or not new_pin.isdigit():
            show_message('ALTERAR PIN', 'O novo PIN deve conter exatamente 4 dígitos.')
            return False
        confirm = _prompt_hidden_pin('CONFIRME O NOVO PIN')
        if not confirm:
            return False
        if confirm != new_pin:
            show_message('ALTERAR PIN', 'A confirmação do PIN não confere.')
            return False
        try:
            result = PanelClient().update_parental_pin(new_pin, timeout=self._value('request_timeout')) or {}
        except Exception as exc:
            log('Alteração do PIN parental no painel falhou: %s' % exc, 'warning')
            show_message('ALTERAR PIN', 'Não foi possível atualizar o PIN no painel.')
            return False
        success = result.get('success')
        if success not in (True, 1, '1', 'true', 'TRUE'):
            message = str(result.get('message') or result.get('mensagem') or 'Painel recusou a alteração do PIN.')
            show_message('ALTERAR PIN', message)
            return False
        returned = str(result.get('pin') or result.get('parent_control') or new_pin).strip()
        if returned != new_pin:
            show_message('ALTERAR PIN', 'O painel não confirmou o novo PIN.')
            return False
        _cache_panel_pin(new_pin)
        show_message('ALTERAR PIN', 'PIN atualizado com sucesso no painel.')
        return True

    def _run(self, pos, entry):
        if not entry:
            return
        key = entry.get('key')
        if key:
            choices, selected = self._choices(entry)
            result = self._show_choice(self._entry_label(entry), choices, selected)
            if result is not None and str(result) != '':
                try:
                    value = int(result)
                    if key == 'ffmpeg_direct' and value == 1:
                        # The binary component is intentionally not a hard
                        # addon.xml dependency.  Only an explicit user choice
                        # asks Kodi's own add-on manager to install/enable it.
                        from .ffmpeg_direct import ensure_ffmpeg_direct, ffmpeg_direct_status
                        if ensure_ffmpeg_direct(interactive=True, timeout=20.0):
                            self._set(key, 1)
                            state = ffmpeg_direct_status()
                            version = str(state.get('version') or '')
                            show_message(
                                'FFMPEG DIRECT',
                                'Componente oficial instalado e ativo%s.' % ((' · v%s' % version) if version else ''),
                            )
                        else:
                            self._set(key, 0)
                            show_message(
                                'FFMPEG DIRECT',
                                'Não foi possível instalar ou habilitar o componente oficial pelo Kodi. A opção permaneceu desativada.',
                            )
                    else:
                        self._set(key, value)
                        if key == 'universal_cast' and value == 0 and cast_active():
                            try:
                                stop_active_cast(notify_device=True)
                                log('Universal Cast: desativado nas configurações; sessão externa encerrada.', 'debug')
                            except Exception as stop_exc:
                                log('Universal Cast: falha ao encerrar sessão durante desativação: %s' % stop_exc, 'warning')
                except Exception as exc:
                    if key == 'ffmpeg_direct':
                        try:
                            self._set(key, 0)
                        except Exception:
                            pass
                        log('FFmpeg Direct: falha ao aplicar configuração: %s' % exc, 'warning')
                    self._restore_focus(pos)
                    return
            self._restore_focus(pos)
            return
        action = entry.get('action')
        if action == 'stream_format':
            self._change_stream_format(pos)
            return
        elif action == 'time_format':
            self._change_time_format(pos)
            return
        elif action == 'language':
            self._change_language(pos)
            return
        elif action == 'adult_pin':
            self._change_adult_pin()
        elif action == 'clear_cache':
            if show_confirm('LIMPAR CACHE', 'Deseja limpar o cache local do catálogo e das artes?'):
                clear_cache()
                show_message('CONFIGURAÇÕES', 'Cache local do catálogo e das artes limpo com sucesso.')
        elif action == 'clear_watch_history':
            if show_confirm(ui('clear_watch_history', 'Limpar histórico de reprodução'), ui('clear_watch_history_confirm', 'Deseja apagar o progresso e o histórico de filmes e séries deste aparelho?')):
                clear_history()
                show_message('CONFIGURAÇÕES', ui('watch_history_cleared', 'Histórico de reprodução limpo com sucesso.'))
        elif action == 'account':
            show_account(load_session())
        elif action == 'download_apk':
            apps = get_apk_entries()
            if not apps:
                show_message('DOWNLOAD DE APK', 'Nenhum aplicativo está disponível para download.')
            else:
                choices = [(app.get('label') or app.get('filename') or 'APK', idx) for idx, app in enumerate(apps)]
                selected = self._show_choice('Selecionar APK para download', choices, 0, mark_selected=False)
                if selected is not None and str(selected) != '':
                    try:
                        index = int(selected)
                    except Exception:
                        index = -1
                    if 0 <= index < len(apps):
                        show_download_apk(apps[index])
        elif action in ('refresh', 'access'):
            # Essas ações já possuem fluxo autoritativo no router. A tela apenas
            # devolve a intenção para reutilizar exatamente o mesmo código da Home.
            self.close_with({'action': action})
            return
        self._restore_focus(pos)

    def onClick(self, control_id):
        if control_id == self.LIST_ID:
            pos, entry = self._selected()
            self._run(pos, entry)
        elif control_id == self.BACK_ID:
            self.close_with('back')

    def onAction(self, action):
        try:
            aid = action.getId()
            if aid in ACTION_BACK:
                self.close_with('back')
                return
            # A navegação direcional da grade fica sob responsabilidade do
            # próprio controle Panel/XML. No Kodi 21, o foco/índice pode ser
            # atualizado antes de WindowXML.onAction(), então repetir UP/DOWN
            # aqui faria uma única tecla avançar duas posições.
        except Exception:
            pass
        BaseWindow.onAction(self, action)


def show_settings():
    return _open(SettingsWindow, 'IBOSettings.xml')


class AccessWindow(BaseWindow):
    def configure(self, **kwargs):
        BaseWindow.configure(self, **kwargs)
        self.session = kwargs.get('session') or {}
        self.portals = list(kwargs.get('portals') or [])

    def onInit(self):
        control = self.getControl(7001); control.reset()
        for portal in self.portals:
            li = xbmcgui.ListItem(label=str(portal.get('name') or ('Portal ' + str(portal.get('id') or ''))))
            li.setProperty('id', str(portal.get('id') or ''))
            li.setProperty('url', str(portal.get('url') or ''))
            li.setProperty('is_protected', '1' if str(portal.get('is_protected') or '').lower() in ('1','true','yes','on') else '0')
            control.addItem(li)
        current = str(self.session.get('portal_id') or '')
        for idx in range(control.size()):
            if control.getListItem(idx).getProperty('id') == current:
                control.selectItem(idx); break
        self._update_info()
        self.setFocusId(7001 if control.size() > 0 else 7004)

    def _selected(self):
        try:
            li = self.getControl(7001).getSelectedItem()
            if li is None: return None
            pid = li.getProperty('id')
            return next((p for p in self.portals if str(p.get('id') or '') == pid), None)
        except Exception:
            return None

    def _update_info(self):
        portal = self._selected() or {}
        locked = str(portal.get('is_protected') or '').lower() in ('1', 'true', 'yes', 'on')
        info = [
            'Portal: %s' % (portal.get('name') or '—'),
            'DNS ID: %s' % (portal.get('id') or '—'),
            'ID do dispositivo: %s' % get_device_id(),
            'Gerenciamento: %s' % ('Bloqueado pelo painel' if locked else 'Permitido'),
            'Conexões: %s / %s' % (self.session.get('health_used') or 0, self.session.get('health_limit') or 'Auto'),
        ]
        self.setProperty('IBO.AccessInfo', '\n\n'.join(info))
        self.setProperty('IBO.DeleteLabel', 'EXCLUSÃO BLOQUEADA' if locked else 'EXCLUIR ACESSO')

    def onClick(self, control_id):
        if control_id == 7001:
            self._update_info()
        elif control_id == 7002:
            portal = self._selected()
            if portal:
                self.close_with({'action':'use','id':str(portal.get('id') or '')})
        elif control_id == 7003:
            portal = self._selected()
            if portal:
                locked = str(portal.get('is_protected') or '').lower() in ('1','true','yes','on')
                if locked:
                    self.close_with({'action':'locked','id':str(portal.get('id') or ''),'name':str(portal.get('name') or '')})
                else:
                    self.close_with({'action':'delete','id':str(portal.get('id') or ''),'name':str(portal.get('name') or '')})
        elif control_id == 7004:
            self.close_with({'action':'back'})

    def onAction(self, action):
        try:
            aid = action.getId()
            if aid in ACTION_BACK:
                self.close_with({'action':'back'}); return
            if self.getFocusId() == 7001 and aid in (ACTION_UP, ACTION_DOWN):
                if xbmc is not None: xbmc.sleep(20)
                self._update_info()
        except Exception:
            pass
        BaseWindow.onAction(self, action)


def show_access(session, portals):
    return _open(AccessWindow, 'IBOAccess.xml', session=session, portals=portals)
