"""Bounded DNS A-response parsing for the optional resolver."""
import secrets
import socket
import struct


def build_query(domain):
    name = str(domain).rstrip('.').encode('idna')
    labels = name.split(b'.')
    if len(name) > 253 or any(not part or len(part) > 63 for part in labels):
        raise ValueError('Nome DNS inválido.')
    question = b''.join(bytes([len(part)]) + part for part in labels) + b'\0\0\1\0\1'
    return struct.pack('!6H', secrets.randbelow(65536), 0x0100, 1, 0, 0, 0) + question


def _name(data, offset):
    labels, seen = [], set()
    end = None
    for _ in range(128):
        if offset >= len(data) or offset in seen:
            raise ValueError('Nome DNS truncado ou circular.')
        seen.add(offset)
        length = data[offset]
        if length & 0xC0 == 0xC0:
            if offset + 1 >= len(data):
                raise ValueError('Ponteiro DNS truncado.')
            if end is None:
                end = offset + 2
            offset = ((length & 0x3F) << 8) | data[offset + 1]
            continue
        if length & 0xC0 or offset + 1 + length > len(data):
            raise ValueError('Label DNS inválido.')
        offset += 1
        if not length:
            return b'.'.join(labels).lower(), end if end is not None else offset
        labels.append(data[offset:offset + length])
        if sum(map(len, labels)) + len(labels) > 254:
            raise ValueError('Nome DNS longo demais.')
        offset += length
    raise ValueError('Compressão DNS excedeu limite.')


def parse_response(data, query):
    try:
        if len(data) < 12 or len(query) < 17:
            return None
        ident, flags, questions, answers, _ns, _ar = struct.unpack('!6H', data[:12])
        if (data[:2] != query[:2] or not flags & 0x8000 or flags & 0x7A0F
                or questions != 1 or answers > 128):
            return None
        wanted, query_end = _name(query, 12)
        question, offset = _name(data, 12)
        if question != wanted or data[offset:offset + 4] != query[query_end:query_end + 4]:
            return None
        offset += 4
        aliases, addresses = {}, []
        for _ in range(answers):
            owner, offset = _name(data, offset)
            if offset + 10 > len(data):
                return None
            kind, family, _ttl, length = struct.unpack('!HHIH', data[offset:offset + 10])
            offset += 10
            if offset + length > len(data):
                return None
            if family == 1 and kind == 1 and length == 4:
                addresses.append((owner, socket.inet_ntoa(data[offset:offset + 4])))
            elif family == 1 and kind == 5:
                alias, end = _name(data, offset)
                if end != offset + length:
                    return None
                aliases[owner] = alias
            offset += length
        allowed = {wanted}
        current = wanted
        for _ in range(128):
            current = aliases.get(current)
            if not current or current in allowed:
                break
            allowed.add(current)
        return next((ip for owner, ip in addresses if owner in allowed), None)
    except (ValueError, IndexError, struct.error, OSError):
        return None
