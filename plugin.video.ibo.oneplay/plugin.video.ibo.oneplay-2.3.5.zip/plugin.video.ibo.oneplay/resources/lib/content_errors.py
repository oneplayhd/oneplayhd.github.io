# -*- coding: utf-8 -*-
"""Human-facing errors for content/navigation/playback.

This module is intentionally presentation-only.  Technical exceptions remain
available to callers for kodi.log diagnostics; user-facing strings never expose
URLs, credentials, Python exception classes, relay/failover internals or access
(Device ID) semantics.
"""

from .http import HttpError


_TITLES = {
    'live': 'TV AO VIVO',
    'movie': 'FILMES',
    'series': 'SÉRIES',
}

_HTTP = {
    400: ('Solicitação de conteúdo inválida', 'O servidor não aceitou a solicitação desta mídia.'),
    401: ('Conteúdo não autorizado', 'O servidor de conteúdo não autorizou esta mídia.'),
    402: ('Conteúdo requer liberação', 'O servidor informou que esta mídia requer renovação ou permissão.'),
    403: ('Conteúdo bloqueado', 'O servidor negou a reprodução desta mídia.'),
    404: ('Conteúdo não encontrado', 'Esta mídia pode ter sido removida ou alterada no servidor.'),
    408: ('Servidor sem resposta', 'O servidor do conteúdo não respondeu dentro do prazo.'),
    409: ('Conflito ao abrir o conteúdo', 'O servidor não conseguiu concluir esta solicitação agora.'),
    410: ('Conteúdo não está mais disponível', 'Esta mídia foi removida do servidor.'),
    423: ('Conteúdo bloqueado', 'Esta mídia está bloqueada no servidor.'),
    429: ('Muitas tentativas no servidor', 'Aguarde alguns instantes e tente novamente.'),
    500: ('Erro no servidor do conteúdo', 'O servidor apresentou uma falha interna ao abrir esta mídia.'),
    502: ('Origem do conteúdo indisponível', 'O servidor intermediário não conseguiu alcançar a origem da mídia.'),
    503: ('Conteúdo temporariamente indisponível', 'O servidor está indisponível neste momento. Tente novamente depois.'),
    504: ('Origem sem resposta', 'O servidor intermediário não recebeu resposta da origem da mídia.'),
}

_HUMAN_PREFIXES = (
    'Solicitação de conteúdo inválida', 'Conteúdo não autorizado', 'Conteúdo requer liberação',
    'Conteúdo bloqueado', 'Conteúdo não encontrado', 'Servidor sem resposta',
    'Conflito ao abrir o conteúdo', 'Conteúdo não está mais disponível',
    'Muitas tentativas no servidor', 'Erro no servidor do conteúdo',
    'Origem do conteúdo indisponível', 'Conteúdo temporariamente indisponível',
    'Origem sem resposta', 'Servidor do conteúdo não localizado', 'Servidor indisponível',
    'Conexão interrompida', 'Conexão segura não validada', 'Conteúdo sem dados de vídeo',
    'Resposta inválida do servidor', 'Canal sem transmissão válida', 'Conteúdo indisponível',
    'Reprodução não iniciada', 'Reprodução interrompida', 'Não foi possível iniciar a reprodução',
    'Não foi possível carregar', 'Não foi possível pesquisar', 'Não foi possível preparar',
    'Não foi possível abrir este episódio', 'Canal indisponível', 'Filme indisponível', 'Episódio indisponível',
)


def content_title(kind, default='IBO'):
    return _TITLES.get(str(kind or '').lower(), str(default or 'IBO'))


def content_http_message(status, retry_after=0):
    try:
        code = int(status)
    except Exception:
        return 'Erro no servidor do conteúdo\nO servidor retornou uma resposta que não pôde ser concluída.'
    headline, detail = _HTTP.get(code, (
        'Erro no servidor do conteúdo',
        'O servidor retornou um erro ao abrir esta mídia.',
    ))
    if code == 429 and retry_after:
        try:
            seconds = max(1, int(float(retry_after)))
            detail = 'Aguarde cerca de %d segundo%s e tente novamente.' % (seconds, '' if seconds == 1 else 's')
        except Exception:
            pass
    return '%s\n%s\nHTTP %d' % (headline, detail, code)


def content_transport_message(exc):
    reason = getattr(exc, 'reason', exc)
    text = str(reason or '')
    lowered = text.lower()
    cls = reason.__class__.__name__.lower() if reason is not None else ''
    if ('gaierror' in cls or 'name or service not known' in lowered or
            'nodename nor servname' in lowered or 'temporary failure in name resolution' in lowered or
            'getaddrinfo failed' in lowered or 'no address associated with hostname' in lowered or
            'dns não resolveu' in lowered):
        return 'Servidor do conteúdo não localizado\nA rede não conseguiu localizar o endereço do servidor.'
    if 'timed out' in lowered or 'timeout' in cls or 'tempo de conexão esgotado' in lowered:
        return 'Servidor sem resposta\nA conexão com o servidor do conteúdo demorou além do esperado.'
    if 'connection refused' in lowered or 'actively refused' in lowered or 'recusou a conexão' in lowered:
        return 'Servidor indisponível\nO servidor do conteúdo recusou a conexão.'
    if ('connection reset' in lowered or 'connection aborted' in lowered or 'broken pipe' in lowered or
            'remote end closed' in lowered or 'conexão interrompida' in lowered):
        return 'Conexão interrompida\nO servidor encerrou a conexão durante a abertura do conteúdo.'
    if 'ssl' in cls or 'certificate' in lowered or 'tls' in lowered or 'falha ssl' in lowered:
        return 'Conexão segura não validada\nNão foi possível validar a conexão segura com o servidor do conteúdo.'
    return 'Servidor sem resposta\nNão foi possível concluir a comunicação com o servidor do conteúdo.'


def _phase_fallback(kind, phase):
    kind = str(kind or '').lower()
    phase = str(phase or '').lower()
    if phase == 'details':
        if kind == 'movie':
            return 'Não foi possível carregar as informações do filme.\nTente novamente.'
        if kind == 'series':
            return 'Não foi possível carregar temporadas e episódios.\nTente novamente.'
    if phase == 'categories':
        noun = {'live': 'canais', 'movie': 'filmes', 'series': 'séries'}.get(kind, 'conteúdos')
        return 'Não foi possível carregar as categorias de %s.\nTente novamente.' % noun
    if phase == 'catalog':
        noun = {'live': 'os canais', 'movie': 'os filmes', 'series': 'as séries'}.get(kind, 'os conteúdos')
        return 'Não foi possível carregar %s.\nTente novamente.' % noun
    if phase == 'search':
        noun = {'live': 'os canais', 'movie': 'os filmes', 'series': 'as séries'}.get(kind, 'os conteúdos')
        return 'Não foi possível pesquisar %s agora.\nTente novamente.' % noun
    if phase == 'episode_select':
        return 'Não foi possível abrir este episódio.\nTente novamente.'
    if phase == 'session':
        return 'Conteúdo indisponível\nNão foi possível preparar esta seção. Volte à tela inicial e tente novamente.'
    if phase in ('player', 'playback'):
        label = {'live': 'Canal', 'movie': 'Filme', 'series': 'Episódio'}.get(kind, 'Conteúdo')
        return '%s indisponível\nNão foi possível abrir esta mídia agora. Tente novamente.' % label
    return 'Não foi possível concluir esta operação.\nTente novamente.'


def humanize_content_error(error=None, kind='', phase='', fallback=''):
    """Return a stable user-facing content error without leaking internals."""
    status = getattr(error, 'status', None) if isinstance(error, HttpError) else None
    try:
        status_code = int(status) if status is not None else 0
    except Exception:
        status_code = 0
    if status_code >= 400:
        return content_http_message(status_code, getattr(error, 'retry_after', 0))

    text = str(error or '').strip()
    lowered = text.lower()

    # Media-semantic failures take precedence over the generic transport flag.
    # Some probes mark an empty/invalid response as transport=True only so the
    # failover path can continue; the user still needs the actual media cause.
    if 'sem bytes de mídia' in lowered or 'sem dados de mídia' in lowered:
        return 'Conteúdo sem dados de vídeo\nO servidor respondeu, mas não enviou dados de mídia.'
    if 'conteúdo inválido em vez de mídia' in lowered or 'resposta inválida' in lowered or 'json inválido' in lowered:
        return 'Resposta inválida do servidor\nO servidor respondeu, mas não enviou dados válidos para este conteúdo.'
    if 'playlist hls inválida' in lowered or 'hls inválid' in lowered:
        return 'Canal sem transmissão válida\nA lista de reprodução recebida está vazia ou inválida.'
    if ('outra dns ainda não testada' in lowered or 'failover esgotado' in lowered or
            'orçamento total esgotado' in lowered or 'nenhum servidor' in lowered):
        return 'Conteúdo indisponível\nNenhum servidor disponível respondeu corretamente com esta mídia.'
    if 'não iniciou a reprodução' in lowered or 'não conseguiu iniciar o player' in lowered or 'limite de segurança' in lowered:
        return 'Reprodução não iniciada\nO vídeo não começou dentro do tempo esperado.'
    if 'stream ficou sem progresso' in lowered or 'sem progresso' in lowered:
        return 'Reprodução interrompida\nO vídeo parou de avançar e foi encerrado para evitar travar o Kodi.'
    if 'proteção de mídia indisponível' in lowered:
        return 'Não foi possível iniciar a reprodução\nA proteção local da mídia não está disponível. Reinicie o Kodi e tente novamente.'
    if 'acesso bloqueado' in lowered or 'não autorizado' in lowered or 'acesso negado' in lowered:
        return 'Conteúdo bloqueado\nO servidor não autorizou a abertura desta mídia.'
    if 'sessão ausente' in lowered or 'sessão inválida' in lowered:
        return 'Conteúdo indisponível\nNão foi possível preparar esta seção. Volte à tela inicial e tente novamente.'

    # Transport HttpError may still carry the older technical wording from
    # generic HTTP helpers. Translate it before accepting already-human text.
    if isinstance(error, HttpError) and getattr(error, 'transport', False):
        return content_transport_message(error)

    # A previously humanized value may cross more than one layer (probe ->
    # player -> router). Keep it stable instead of wrapping it again.
    if text and any(text.startswith(prefix) for prefix in _HUMAN_PREFIXES):
        return text

    # Strings from older/non-HttpError paths are classified without ever being
    # echoed back to the user.
    if ('dns não resolveu' in lowered or 'getaddrinfo' in lowered or 'name or service not known' in lowered or
            'temporary failure in name resolution' in lowered):
        return 'Servidor do conteúdo não localizado\nA rede não conseguiu localizar o endereço do servidor.'
    if 'timeout' in lowered or 'timed out' in lowered or 'tempo de conexão esgotado' in lowered:
        return 'Servidor sem resposta\nA conexão com o servidor do conteúdo demorou além do esperado.'
    if 'connection refused' in lowered or 'recusou a conexão' in lowered:
        return 'Servidor indisponível\nO servidor do conteúdo recusou a conexão.'
    if ('connection reset' in lowered or 'connection aborted' in lowered or 'broken pipe' in lowered or
            'conexão interrompida' in lowered):
        return 'Conexão interrompida\nO servidor encerrou a conexão durante a abertura do conteúdo.'
    if 'ssl' in lowered or 'tls' in lowered or 'certificate' in lowered:
        return 'Conexão segura não validada\nNão foi possível validar a conexão segura com o servidor do conteúdo.'

    if fallback:
        return str(fallback)
    return _phase_fallback(kind, phase)
