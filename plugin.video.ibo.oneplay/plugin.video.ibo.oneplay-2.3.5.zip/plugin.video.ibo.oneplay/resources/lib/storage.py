# -*- coding: utf-8 -*-
import hashlib
import json
import os
import queue
import shutil
import time
import threading
import urllib.error
import urllib.parse
import urllib.request
import uuid

from .constants import ADDON_ID, XTREAM_USER_AGENT
from .log import log

try:
    import xbmcvfs
except Exception:
    xbmcvfs = None


def translate(path):
    if xbmcvfs is not None:
        try:
            return xbmcvfs.translatePath(path)
        except Exception:
            pass
    if path.startswith('special://profile/'):
        return os.path.join('/tmp', path[len('special://profile/'):])
    return path


def profile_dir():
    path = translate('special://profile/addon_data/%s/' % ADDON_ID)
    os.makedirs(path, exist_ok=True)
    return path


def cache_dir():
    path = os.path.join(profile_dir(), 'cache_v2')
    os.makedirs(path, exist_ok=True)
    return path


def image_cache_dir():
    """Persistent artwork cache; only manual full cache cleanup removes it."""
    path = os.path.join(cache_dir(), 'images')
    os.makedirs(path, exist_ok=True)
    return path


_IMAGE_QUEUE = queue.Queue(maxsize=24)
_IMAGE_PENDING = set()
_IMAGE_PENDING_LOCK = threading.Lock()
_IMAGE_WORKERS_STARTED = False
_IMAGE_WORKERS_LOCK = threading.Lock()
_IMAGE_WORKER_THREADS = []
_IMAGE_STOP = threading.Event()
_IMAGE_CLEANUP_LOCK = threading.Lock()
_IMAGE_LAST_CLEANUP = 0.0
_IMAGE_EPOCH = 0
_IMAGE_WORKER_COUNT = 2
_IMAGE_MAX_BYTES = 8 * 1024 * 1024
_IMAGE_CACHE_MAX_BYTES = 256 * 1024 * 1024
_IMAGE_CACHE_MAX_FILES = 1600
_IMAGE_HOST_OK_TTL = 45.0
_IMAGE_HOST_FAIL_TTL = 75.0
_IMAGE_HOST_PROBE_TIMEOUT = 0.75
_IMAGE_HOST_STATE = {}
_IMAGE_HOST_LOCK = threading.Lock()


def _remote_image_url(value):
    text = str(value or '').strip()
    if not text:
        return ''
    try:
        parsed = urllib.parse.urlparse(text)
    except Exception:
        return ''
    return text if parsed.scheme in ('http', 'https') and parsed.netloc else ''


def _image_host(url):
    try:
        return (urllib.parse.urlparse(str(url or '')).netloc or '').strip().lower()
    except Exception:
        return ''


def _mark_image_host(url, ok):
    host = _image_host(url)
    if not host:
        return
    ttl = _IMAGE_HOST_OK_TTL if ok else _IMAGE_HOST_FAIL_TTL
    now = time.monotonic()
    with _IMAGE_HOST_LOCK:
        current = _IMAGE_HOST_STATE.get(host)
        # Once a host is in a short failure/rate-limit window, a concurrent
        # success from another in-flight worker must not reopen the floodgate.
        if ok and current:
            current_ok, current_expires = current
            if not current_ok and now < float(current_expires or 0):
                return
        _IMAGE_HOST_STATE[host] = (bool(ok), now + ttl)


def _image_host_state(url):
    host = _image_host(url)
    if not host:
        return None
    now = time.monotonic()
    with _IMAGE_HOST_LOCK:
        row = _IMAGE_HOST_STATE.get(host)
        if not row:
            return None
        ok, expires = row
        if now >= float(expires or 0):
            _IMAGE_HOST_STATE.pop(host, None)
            return None
        return bool(ok)


def _probe_image_host(url):
    """Fast circuit-breaker probe before Kodi receives a remote artwork URL.

    The Kodi image loader uses a much longer curl timeout than the private IBO
    artwork cache. A single slow CDN can therefore occupy every JobWorker and
    make unrelated Home/channel art disappear. Probe only once per host window;
    on transport/5xx failure, all following misses use a local fallback instead
    of feeding more long-running remote jobs to Kodi.
    """
    state = _image_host_state(url)
    if state is not None:
        return state
    req = urllib.request.Request(
        url,
        headers={
            'User-Agent': XTREAM_USER_AGENT,
            'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=_IMAGE_HOST_PROBE_TIMEOUT) as response:
            status = int(getattr(response, 'status', 200) or 200)
            if status >= 500:
                _mark_image_host(url, False)
                return False
            sample = response.read(4096)
            if not sample or not _sniff_image_extension(sample):
                # A responsive server returning HTML/unsupported payload is not
                # a host-wide outage. Reject only this miss and keep the host up.
                _mark_image_host(url, True)
                return False
        _mark_image_host(url, True)
        return True
    except urllib.error.HTTPError as exc:
        code = int(getattr(exc, 'code', 0) or 0)
        if code == 429:
            # 429 is host-wide rate limiting, not a bad individual poster.
            # Close the circuit briefly so queued/private jobs cannot amplify it.
            _mark_image_host(url, False)
            log('Host de arte em rate limit (%s): HTTP 429' % _image_host(url), 'debug')
            return False
        if 400 <= code < 500:
            # 404/403 proves the host is responsive; do not black-hole other art.
            _mark_image_host(url, True)
            return False
        _mark_image_host(url, False)
        log('Host de arte temporariamente indisponível (%s): HTTP %s' % (_image_host(url), code or '?'), 'debug')
        return False
    except Exception as exc:
        _mark_image_host(url, False)
        log('Host de arte temporariamente indisponível (%s): %s' % (_image_host(url), exc), 'debug')
        return False

def _image_extension(url):
    """Best-effort extension hint from the URL only.

    This is never trusted as proof that the response is an image. Some image
    CDNs return HTML/error payloads with a .jpg URL, while dynamic endpoints
    return valid JPEG/PNG/WebP without any extension at all.
    """
    try:
        path = urllib.parse.urlparse(str(url or '')).path.lower()
    except Exception:
        path = ''
    for ext in ('.jpg', '.jpeg', '.png', '.webp', '.gif', '.avif', '.svg', '.bmp'):
        if path.endswith(ext):
            return ext
    return '.img'


_IMAGE_CACHE_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.webp', '.gif', '.avif', '.svg', '.bmp', '.img')


def _image_cache_digest(url):
    return hashlib.sha256(str(url or '').encode('utf-8', 'ignore')).hexdigest()


def _image_cache_path(url, extension=None):
    ext = str(extension or _image_extension(url) or '.img').lower()
    if not ext.startswith('.'):
        ext = '.' + ext
    return os.path.join(image_cache_dir(), _image_cache_digest(url) + ext)


def _image_cache_paths(url):
    """All cache names that may belong to one URL, including legacy V2.0.36 files."""
    hint = _image_extension(url)
    exts = [hint]
    for ext in _IMAGE_CACHE_EXTENSIONS:
        if ext not in exts:
            exts.append(ext)
    return [_image_cache_path(url, ext) for ext in exts]


def _image_cache_kodi_path(path):
    """Return a Kodi-native VFS path instead of an OS-specific translated path."""
    name = os.path.basename(str(path or ''))
    if not name:
        return ''
    return 'special://profile/addon_data/%s/cache_v2/images/%s' % (ADDON_ID, name)


def _sniff_image_extension(data):
    """Identify formats Kodi commonly receives for artwork from file magic.

    The extension/content-type supplied by a server is not trusted. Returning
    an empty string means the payload must not be promoted to the local cache.
    """
    raw = bytes(data or b'')
    if raw.startswith(b'\xff\xd8\xff'):
        return '.jpg'
    if raw.startswith(b'\x89PNG\r\n\x1a\n'):
        return '.png'
    if raw.startswith((b'GIF87a', b'GIF89a')):
        return '.gif'
    if len(raw) >= 12 and raw[:4] == b'RIFF' and raw[8:12] == b'WEBP':
        return '.webp'
    if raw.startswith(b'BM'):
        return '.bmp'
    if len(raw) >= 16 and raw[4:8] == b'ftyp':
        brands = raw[8:64].lower()
        if b'avif' in brands or b'avis' in brands:
            return '.avif'
    # SVG can start with UTF-8 BOM, whitespace or an XML declaration.
    text = raw[:4096]
    if text.startswith(b'\xef\xbb\xbf'):
        text = text[3:]
    lowered = text.lstrip().lower()
    if lowered.startswith(b'<svg') or (lowered.startswith(b'<?xml') and b'<svg' in lowered[:2048]):
        return '.svg'
    return ''


def _sniff_image_file(path):
    try:
        with open(path, 'rb') as fh:
            return _sniff_image_extension(fh.read(4096))
    except Exception:
        return ''


def _promote_cache_extension(path, canonical):
    """Migrate a valid legacy/misnamed cache entry to its real image extension."""
    if os.path.abspath(path) == os.path.abspath(canonical):
        return path
    tmp = '%s.%s.%s.%s.tmp' % (canonical, os.getpid(), threading.get_ident(), uuid.uuid4().hex)
    try:
        os.makedirs(os.path.dirname(canonical), exist_ok=True)
        with open(path, 'rb') as src, open(tmp, 'wb') as dst:
            shutil.copyfileobj(src, dst, length=64 * 1024)
            dst.flush()
            try:
                os.fsync(dst.fileno())
            except Exception:
                pass
        _binary_replace(tmp, canonical)
        delete(path)
        return canonical
    except Exception:
        return ''
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass


def _remove_image_variants(url, keep=''):
    keep_abs = os.path.abspath(keep) if keep else ''
    for candidate in _image_cache_paths(url):
        try:
            if keep_abs and os.path.abspath(candidate) == keep_abs:
                continue
            if os.path.exists(candidate):
                delete(candidate)
        except Exception:
            pass


def _image_cache_lookup(url, ttl):
    """Return ``(path, fresh)`` for byte-validated cached artwork.

    ``ttl`` <= 0 (or ``None``) means persistent artwork: a valid file never
    expires by age and remains usable until the user runs the full cache cleanup.
    Positive TTLs remain supported for narrowly-scoped callers that truly need
    time-based refresh semantics.
    """
    now = time.time()
    persistent = ttl is None or float(ttl or 0) <= 0
    fresh_age = None if persistent else max(1, int(ttl))
    stale_age = None if persistent else fresh_age
    stale = None
    for path in _image_cache_paths(url):
        try:
            if not os.path.isfile(path):
                continue
            age = now - os.path.getmtime(path)
            if os.path.getsize(path) <= 0:
                delete(path)
                continue
            if stale_age is not None and age > stale_age:
                delete(path)
                continue
            detected = _sniff_image_file(path)
            if not detected:
                delete(path)
                continue
            canonical = _image_cache_path(url, detected)
            if os.path.abspath(path) != os.path.abspath(canonical):
                path = _promote_cache_extension(path, canonical)
                if not path:
                    continue
            if not (os.path.isfile(path) and _sniff_image_file(path)):
                continue
            _remove_image_variants(url, keep=path)
            if fresh_age is None or age <= fresh_age:
                return path, True
            try:
                mtime = os.path.getmtime(path)
            except Exception:
                mtime = 0
            if stale is None or mtime > stale[0]:
                stale = (mtime, path)
        except Exception:
            try:
                if os.path.exists(path):
                    delete(path)
            except Exception:
                pass
    return (stale[1], False) if stale else ('', False)


def _image_cache_hit(url, ttl):
    path, fresh = _image_cache_lookup(url, ttl)
    return path if fresh else ''


def _image_cache_existing(url):
    """Worker-side race guard; caller has already enforced TTL."""
    for path in _image_cache_paths(url):
        try:
            if not os.path.isfile(path) or os.path.getsize(path) <= 0:
                continue
            detected = _sniff_image_file(path)
            if not detected:
                continue
            # A valid payload with a misleading/legacy extension still needs
            # promotion before Kodi should consume it as local artwork.
            canonical = _image_cache_path(url, detected)
            if os.path.abspath(path) == os.path.abspath(canonical):
                return path
        except Exception:
            pass
    return ''


def _cleanup_image_cache(ttl, force=False):
    global _IMAGE_LAST_CLEANUP
    now = time.time()
    with _IMAGE_CLEANUP_LOCK:
        if not force and (now - _IMAGE_LAST_CLEANUP) < 60.0:
            return
        _IMAGE_LAST_CLEANUP = now
        root = image_cache_dir()
        entries = []
        total = 0
        for name in os.listdir(root):
            path = os.path.join(root, name)
            if not os.path.isfile(path):
                continue
            try:
                mtime = os.path.getmtime(path)
                size = os.path.getsize(path)
            except Exception:
                continue
            # Interrupted Kodi/Python processes may leave unique temp files.
            # They are never valid artwork and should not accumulate forever.
            if name.endswith('.tmp'):
                if (now - mtime) > 600.0:
                    delete(path)
                continue
            # Valid artwork is not removed by elapsed time when ttl <= 0.
            # Capacity guards below remain a storage-safety mechanism only;
            # "Limpar cache" is the explicit user-facing destructive cleanup.
            if ttl is not None and float(ttl or 0) > 0 and (now - mtime) > max(1, int(ttl)):
                delete(path)
                continue
            # Do not retain corrupt/non-image payloads as "fresh" cache hits.
            if not _sniff_image_file(path):
                delete(path)
                continue
            entries.append((mtime, size, path))
            total += size
        if len(entries) <= _IMAGE_CACHE_MAX_FILES and total <= _IMAGE_CACHE_MAX_BYTES:
            return
        entries.sort(key=lambda row: row[0])
        while entries and (len(entries) > _IMAGE_CACHE_MAX_FILES or total > _IMAGE_CACHE_MAX_BYTES):
            _mtime, size, path = entries.pop(0)
            delete(path)
            total = max(0, total - size)


def _binary_replace(tmp, path):
    last_exc = None
    for attempt in range(20):
        try:
            os.replace(tmp, path)
            return
        except (PermissionError, OSError) as exc:
            winerr = getattr(exc, 'winerror', None)
            err_no = getattr(exc, 'errno', None)
            if winerr not in (5, 32) and err_no not in (13, 16):
                raise
            last_exc = exc
            time.sleep(min(0.01 + (attempt * 0.005), 0.06))
    if last_exc is not None:
        raise last_exc


def _download_image(url, epoch):
    digest = _image_cache_digest(url)
    tmp = os.path.join(
        image_cache_dir(),
        '%s.%s.%s.%s.tmp' % (digest, os.getpid(), threading.get_ident(), uuid.uuid4().hex),
    )
    try:
        req = urllib.request.Request(
            url,
            headers={
                'User-Agent': XTREAM_USER_AGENT,
                'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
            },
        )
        # O cache privado é best-effort: Kodi continua usando a URL remota
        # quando ele falha. Um socket curto + prazo total impedem que um worker
        # de capa retenha o interpretador do plugin durante o shutdown do Kodi.
        deadline = time.monotonic() + 2.0
        with urllib.request.urlopen(req, timeout=1.0) as response:
            try:
                length = int(response.headers.get('Content-Length') or 0)
            except Exception:
                length = 0
            if length > _IMAGE_MAX_BYTES:
                raise ValueError('imagem acima do limite')
            os.makedirs(image_cache_dir(), exist_ok=True)
            total = 0
            with open(tmp, 'wb') as fh:
                while True:
                    if _IMAGE_STOP.is_set() or time.monotonic() >= deadline:
                        raise TimeoutError('cache de imagem cancelado/expirado')
                    chunk = response.read(64 * 1024)
                    if not chunk:
                        break
                    if _IMAGE_STOP.is_set():
                        raise TimeoutError('cache de imagem cancelado')
                    total += len(chunk)
                    if total > _IMAGE_MAX_BYTES:
                        raise ValueError('imagem acima do limite')
                    fh.write(chunk)
                fh.flush()
                try:
                    os.fsync(fh.fileno())
                except Exception:
                    pass
            if total <= 0:
                raise ValueError('imagem vazia')
            detected = _sniff_image_file(tmp)
            if not detected:
                raise ValueError('resposta não contém uma imagem suportada')
            # A limpeza manual invalida qualquer download que já estava em voo.
            if epoch != _IMAGE_EPOCH:
                return ''
            final_path = _image_cache_path(url, detected)
            _binary_replace(tmp, final_path)
            _remove_image_variants(url, keep=final_path)
            return final_path
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass


def _image_worker():
    while not _IMAGE_STOP.is_set():
        try:
            item = _IMAGE_QUEUE.get(timeout=0.20)
        except queue.Empty:
            continue
        pending_key = None
        try:
            if _IMAGE_STOP.is_set():
                continue
            if not isinstance(item, tuple) or len(item) != 3:
                continue
            url, epoch, ttl = item
            pending_key = (epoch, url)
            if epoch != _IMAGE_EPOCH:
                continue
            # Another worker/process may have completed it while this job waited.
            cached, fresh = _image_cache_lookup(url, ttl)
            if not fresh:
                # A previous timeout/5xx/429 for this host may have happened
                # while this item was waiting in the queue. Do not keep hitting
                # a host whose circuit is already closed.
                if _image_host_state(url) is False:
                    continue
                try:
                    result = _download_image(url, epoch)
                    if result:
                        _mark_image_host(url, True)
                except urllib.error.HTTPError as exc:
                    code = int(getattr(exc, 'code', 0) or 0)
                    _mark_image_host(url, False if code == 429 or code >= 500 or code <= 0 else True)
                    log('Cache de imagem ignorou %s: HTTP %s' % (url, code or '?'), 'debug')
                except Exception as exc:
                    _mark_image_host(url, False)
                    # A failed private cache must never poison the visible art.
                    # The caller continues with a local fallback whenever the
                    # circuit-breaker classifies the artwork host as unhealthy.
                    log('Cache de imagem ignorou %s: %s' % (url, exc), 'debug')
        finally:
            try:
                if pending_key is not None:
                    with _IMAGE_PENDING_LOCK:
                        _IMAGE_PENDING.discard(pending_key)
            except Exception:
                pass
            _IMAGE_QUEUE.task_done()


def _ensure_image_workers():
    global _IMAGE_WORKERS_STARTED, _IMAGE_WORKER_THREADS
    if _IMAGE_WORKERS_STARTED and any(thread.is_alive() for thread in _IMAGE_WORKER_THREADS):
        return
    with _IMAGE_WORKERS_LOCK:
        if _IMAGE_WORKERS_STARTED and any(thread.is_alive() for thread in _IMAGE_WORKER_THREADS):
            return
        _IMAGE_STOP.clear()
        _IMAGE_WORKER_THREADS = []
        for index in range(_IMAGE_WORKER_COUNT):
            thread = threading.Thread(target=_image_worker, name='IBO-ImageCache-%d' % (index + 1))
            thread.daemon = True
            thread.start()
            _IMAGE_WORKER_THREADS.append(thread)
        _IMAGE_WORKERS_STARTED = True


def shutdown_image_workers(timeout=2.25):
    """Encerra deterministicamente os workers privados de artwork.

    Kodi aguarda threads Python do invocador mesmo depois que ``doModal()``
    retorna no shutdown. Esses workers antes ficavam bloqueados para sempre em
    ``Queue.get()``. O Event acorda o loop, invalida jobs em voo e um join com
    prazo compartilhado confirma a liberação do interpretador.
    """
    global _IMAGE_WORKERS_STARTED, _IMAGE_WORKER_THREADS, _IMAGE_EPOCH
    with _IMAGE_WORKERS_LOCK:
        threads = list(_IMAGE_WORKER_THREADS)
        _IMAGE_STOP.set()
        with _IMAGE_PENDING_LOCK:
            _IMAGE_EPOCH += 1
            _IMAGE_PENDING.clear()
    deadline = time.monotonic() + max(0.0, float(timeout or 0.0))
    current = threading.current_thread()
    for thread in threads:
        if thread is current or not thread.is_alive():
            continue
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        thread.join(remaining)
    alive = [thread.name for thread in threads if thread.is_alive()]
    with _IMAGE_WORKERS_LOCK:
        _IMAGE_WORKER_THREADS = [thread for thread in threads if thread.is_alive()]
        _IMAGE_WORKERS_STARTED = bool(_IMAGE_WORKER_THREADS)
    if alive:
        log('Lifecycle: workers de imagem ainda ativos após cleanup: %s' % ', '.join(alive), 'warning')
        return False
    log('Lifecycle: workers de imagem encerrados.', 'debug')
    return True


def _queue_image_refresh(remote, ttl):
    with _IMAGE_PENDING_LOCK:
        epoch = _IMAGE_EPOCH
        pending_key = (epoch, remote)
        if pending_key in _IMAGE_PENDING:
            return False
        _IMAGE_PENDING.add(pending_key)
    _ensure_image_workers()
    try:
        _IMAGE_QUEUE.put_nowait((remote, epoch, 0 if ttl is None or float(ttl or 0) <= 0 else max(1, int(ttl))))
        return True
    except queue.Full:
        with _IMAGE_PENDING_LOCK:
            _IMAGE_PENDING.discard(pending_key)
        log('Fila privada de arte cheia; mantendo renderização sem novo prefetch.', 'debug')
        return False


def prime_catalog_image_host(urls):
    """Preflight TMDB once while the loading modal is still visible.

    Large grids must not touch the private image cache once IBOProgress closes:
    on slower HDD/CPU devices, validating many private cache candidates can
    visibly stall the GUI even with no network request. The first TMDB artwork
    in the category performs the existing bounded circuit-breaker probe here.
    Provider/Xtream artwork is ignored because it already uses Kodi's lazy path.
    """
    try:
        iterator = iter(urls or ())
    except TypeError:
        iterator = iter((urls,))
    for value in iterator:
        remote = _remote_image_url(value)
        if not remote:
            continue
        host = _image_host(remote)
        if host != 'image.tmdb.org' and not host.endswith('.image.tmdb.org'):
            continue
        return _probe_image_host(remote)
    return True


def cache_catalog_image(url, fallback=''):
    """Filesystem-free resolver for large movie/series grids.

    V2.0.95 performs zero private-cache lookups and zero synchronous probes per
    card. ``prime_catalog_image_host`` performs the bounded TMDB preflight while
    IBOProgress is visible; after it closes, the grid hot path only reads the
    in-memory host state and hands the stable URL to Kodi's native TextureCache.

    An explicitly unhealthy host still gets the local fallback. If no state is
    available (for example after the state TTL during a long browse), the remote
    URL follows the historical fast path rather than blocking the GUI.
    """
    remote = _remote_image_url(url)
    if not remote:
        return str(url or fallback or '')

    if _image_host_state(remote) is False:
        return str(fallback or '')
    return remote


def cache_image(url, ttl=0, fallback=''):
    """Resolve artwork without letting a slow CDN monopolize Kodi workers.

    Catalog artwork is persistent by default: once a byte-valid local copy is
    stored it does not expire by elapsed time. With no local copy, one short
    host probe decides whether Kodi may safely receive the remote URL. If the
    host is stalling, a local fallback is returned immediately instead of
    spawning many ~30 s TextureCache jobs.
    """
    remote = _remote_image_url(url)
    if not remote:
        return str(url or fallback or '')

    cached, fresh = _image_cache_lookup(remote, ttl)
    if cached:
        if not fresh and _image_host_state(remote) is not False:
            _queue_image_refresh(remote, ttl)
        return _image_cache_kodi_path(cached)

    _cleanup_image_cache(ttl)
    if not _probe_image_host(remote):
        return str(fallback or '')

    _queue_image_refresh(remote, ttl)
    return remote


def _drain_image_queue():
    """Discard queued jobs from an invalidated epoch without blocking."""
    while True:
        try:
            _IMAGE_QUEUE.get_nowait()
        except queue.Empty:
            break
        else:
            try:
                _IMAGE_QUEUE.task_done()
            except Exception:
                pass


def state_path(name):
    return os.path.join(profile_dir(), name)


def read_json(path, default=None):
    if default is None:
        default = {}
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:
        return default


def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    # Plugin UI and xbmc.service run in independent Python interpreters and can
    # update activity/session state at the same time. A fixed '.tmp' filename
    # races on Windows; give each writer its own temporary file and atomically
    # replace only the final target.
    tmp = '%s.%s.%s.%s.tmp' % (path, os.getpid(), threading.get_ident(), uuid.uuid4().hex)
    try:
        with open(tmp, 'x', encoding='utf-8',
                  opener=lambda name, flags: os.open(name, flags, 0o600)) as fh:
            json.dump(data, fh, ensure_ascii=False, separators=(',', ':'))
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except Exception:
                pass
        # Windows/Kodi may keep the destination opened for a few milliseconds
        # while the service and plugin interpreters exchange activity state.
        # A unique tmp file prevents tmp-name races, but os.replace() can still
        # raise WinError 5/32 (sharing/access violation). Retry the atomic swap
        # briefly instead of turning a transient file lock into a router error.
        last_exc = None
        for attempt in range(20):
            try:
                os.replace(tmp, path)
                last_exc = None
                break
            except (PermissionError, OSError) as exc:
                winerr = getattr(exc, 'winerror', None)
                err_no = getattr(exc, 'errno', None)
                if winerr not in (5, 32) and err_no not in (13, 16):
                    raise
                last_exc = exc
                time.sleep(min(0.01 + (attempt * 0.005), 0.06))
        if last_exc is not None:
            raise last_exc
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass


def delete(path):
    try:
        os.remove(path)
    except FileNotFoundError:
        pass
    except Exception as exc:
        log('Falha ao remover arquivo de estado: %s' % exc, 'debug')


def _cache_path(namespace, key):
    digest = hashlib.sha256(('%s\n%s' % (namespace, key)).encode('utf-8', 'ignore')).hexdigest()
    return os.path.join(cache_dir(), digest + '.json')


def cache_get(namespace, key, ttl=None):
    """Read cached JSON; no TTL means persistent until explicit invalidation."""
    path = _cache_path(namespace, key)
    try:
        if not os.path.isfile(path):
            return None
        if ttl is not None and float(ttl or 0) > 0 and time.time() - os.path.getmtime(path) > float(ttl):
            return None
    except Exception:
        return None
    return read_json(path, None)


def cache_put(namespace, key, value):
    try:
        write_json(_cache_path(namespace, key), value)
    except Exception as exc:
        log('Falha ao gravar cache: %s' % exc, 'debug')




def clear_catalog_cache():
    """Invalidate catalog/API JSON while preserving already downloaded artwork."""
    path = cache_dir()
    for name in os.listdir(path):
        target = os.path.join(path, name)
        if os.path.isdir(target):
            continue
        try:
            # Cache JSON uses hashed .json files at cache_v2 root. Leave artwork
            # (cache_v2/images) untouched so an explicit refresh does not create
            # unnecessary CDN traffic or blank already-known covers.
            if name.endswith('.json'):
                delete(target)
        except Exception as exc:
            log('Falha ao invalidar item de catálogo: %s' % exc, 'debug')


def clear_cache():
    global _IMAGE_EPOCH
    # Invalida também downloads de arte já enfileirados/em andamento para que
    # uma limpeza manual nunca seja repovoada por um job antigo logo depois.
    with _IMAGE_PENDING_LOCK:
        _IMAGE_EPOCH += 1
        _IMAGE_PENDING.clear()
    _drain_image_queue()
    with _IMAGE_HOST_LOCK:
        _IMAGE_HOST_STATE.clear()
    path = cache_dir()
    for name in os.listdir(path):
        target = os.path.join(path, name)
        try:
            if os.path.isdir(target):
                shutil.rmtree(target, ignore_errors=True)
            else:
                delete(target)
        except Exception as exc:
            log('Falha ao limpar item de cache: %s' % exc, 'debug')
