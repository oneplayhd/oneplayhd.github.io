# -*- coding: utf-8 -*-
"""Isolated DLNA compatibility helpers for renderers with stricter Live handling.

This module intentionally stays outside the normal ONEPLAY playback path.
It never mutates panel/session state and never changes the user's configured
Xtream output.  For an LG/webOS DLNA renderer it may *temporarily* test the
same Live stream_id as a direct MPEG-TS endpoint.  When that endpoint is not
proven valid, callers must fall back to the unmodified V11 preparation path.

No DLNAPlayOn source code is embedded here.  The implementation uses only the
existing ONEPLAY Xtream client/probe and credential-safe Relay contracts.
"""

from .auth import session_client
from .http import HttpError
from .log import log
from .media_relay import register_playback
from .state import load_session


_LG_MARKERS = ('webos', '[lg]', 'lg electronics', 'lg tv', 'lg smart')


def is_lg_webos_renderer(device):
    """Conservatively identify an LG/webOS DLNA renderer.

    False positives are deliberately avoided because the compatibility path
    must never change behavior for already-working DLNA renderers.
    """
    row = device if isinstance(device, dict) else {}
    if str(row.get('protocol') or '').strip().lower() != 'dlna':
        return False
    text = ' '.join(
        str(row.get(key) or '').strip().lower()
        for key in ('name', 'model')
        if str(row.get(key) or '').strip()
    )
    if not text:
        return False
    return any(marker in text for marker in _LG_MARKERS)


def prepare_lg_live_ts(stream_id, timeout=2.6):
    """Try the same Live stream as direct TS without mutating session state.

    This is a compatibility *probe*, not a new failover authority.  It uses the
    currently active Xtream server only.  If .ts is unavailable or does not
    contain media bytes, the caller receives ``fallback=True`` and must execute
    the original V11 preparation path unchanged.
    """
    stream_id = str(stream_id or '').strip()
    if not stream_id:
        return {'ok': False, 'fallback': True, 'reason': 'stream_id ausente'}

    session = load_session()
    if not isinstance(session, dict) or not session:
        return {'ok': False, 'fallback': True, 'reason': 'sessão ausente'}

    try:
        client = session_client(session)
        raw = client.live_url(stream_id, 'ts')
        # Keep this compatibility probe shorter than the normal homologated
        # Live preflight.  A hanging optional .ts endpoint must not penalize the
        # standard HLS path for long.
        client.probe(raw, timeout=max(1.8, min(3.0, float(timeout))), kind='live')
    except HttpError as exc:
        log('DLNA LG: TS direto indisponível no servidor ativo (%s); fluxo V11 será preservado.' %
            (exc.status or 'rede'), 'debug')
        return {'ok': False, 'fallback': True, 'reason': 'ts indisponível'}
    except Exception as exc:
        log('DLNA LG: prova TS direta não confirmou mídia (%s); fluxo V11 será preservado.' %
            exc.__class__.__name__, 'debug')
        return {'ok': False, 'fallback': True, 'reason': 'ts não confirmado'}

    try:
        relay_url, relay_session_id = register_playback(raw, 'live')
    except Exception as exc:
        # Do not bypass the credential firewall.  A direct provider URL must
        # never be handed to the renderer when Relay registration is unavailable.
        log('DLNA LG: TS válido, mas Relay seguro indisponível (%s); sem fallback direto.' %
            exc.__class__.__name__, 'warning')
        return {
            'ok': False,
            'fallback': False,
            'error': 'Proteção de mídia indisponível. Reinicie o Kodi e tente novamente.',
        }

    log('DLNA LG: mesmo stream confirmado em TS direto; usando Relay V5 sem alterar saída Xtream salva.', 'debug')
    return {
        'ok': True,
        'url': str(relay_url or ''),
        'mime': 'video/mp2t',
        'relay_session_id': str(relay_session_id or ''),
        'kind': 'live',
        'compat_mode': 'lg_direct_ts',
    }
