# -*- coding: utf-8 -*-
"""Small compatibility layer for Kodi's official inputstream.ffmpegdirect.

The binary add-on remains optional for ONEPLAY.  When the user explicitly
selects FFmpeg Direct, this module can ask Kodi's own add-on manager to install
or enable it.  Playback code only receives a boolean/format decision; media
URLs and Xtream credentials never pass through this module.
"""
import json
import time
import threading

from .log import log

try:
    import xbmc
    import xbmcvfs
except Exception:
    xbmc = None
    xbmcvfs = None


FFMPEG_DIRECT_ID = 'inputstream.ffmpegdirect'
_ENSURE_LOCK = threading.Lock()


def _jsonrpc(method, params=None):
    if xbmc is None:
        return {}
    payload = {'jsonrpc': '2.0', 'id': 1, 'method': str(method)}
    if params is not None:
        payload['params'] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(payload)) or '{}')
    except Exception:
        return {}


def _cond(expr):
    if xbmc is None:
        return False
    try:
        return bool(xbmc.getCondVisibility(str(expr)))
    except Exception:
        return False


def _installed_fast():
    """Cheap filesystem-level presence check with no missing-addon probe.

    On Kodi 21, System.HasAddon may stay true briefly after an uninstall while
    the add-on database/repository catalogue is being refreshed.  Calling
    AddonIsEnabled during that stale interval emits "Unknown addon id".
    Checking addon.xml in Kodi's installed add-on roots avoids that race.
    """
    if xbmcvfs is None:
        return False
    for root in ('special://home/addons/', 'special://xbmc/addons/', 'special://xbmcbinaddons/'):
        try:
            if xbmcvfs.exists(root + FFMPEG_DIRECT_ID + '/addon.xml'):
                return True
        except Exception:
            continue
    return False


def _enabled_fast():
    if not _installed_fast():
        return False
    return _cond('System.AddonIsEnabled(%s)' % FFMPEG_DIRECT_ID)


def ffmpeg_direct_status():
    """Return installed/enabled/version without probing a missing addon id.

    IMPORTANT: Addons.GetAddonDetails on an absent id writes an EXCEPTION to
    kodi.log on Kodi 21. Presence is checked from Kodi add-on directories first; JSON-RPC catalogue
    metadata is queried only after addon.xml exists locally.
    """
    if xbmc is None:
        return {'installed': False, 'enabled': False, 'version': ''}

    installed = _installed_fast()
    if not installed:
        return {'installed': False, 'enabled': False, 'version': ''}

    enabled = _enabled_fast()
    version = ''
    # Metadata is optional. Use GetAddons (installed catalogue) rather than
    # GetAddonDetails so a concurrent uninstall cannot produce an exception.
    response = _jsonrpc(
        'Addons.GetAddons',
        {
            'enabled': 'all',
            'installed': True,
            'properties': ['enabled', 'version', 'name'],
        },
    )
    rows = ((response.get('result') or {}).get('addons') or [])
    for row in rows if isinstance(rows, list) else []:
        if str((row or {}).get('addonid') or '') == FFMPEG_DIRECT_ID:
            enabled = bool((row or {}).get('enabled', enabled))
            version = str((row or {}).get('version') or '')
            break
    return {'installed': True, 'enabled': bool(enabled), 'version': version}


def ffmpeg_direct_available():
    # Hot path used by playback: avoid enumerating the whole add-on catalogue.
    return bool(_installed_fast() and _enabled_fast())


def _wait_available(timeout):
    """Short wait used only after enabling an already-installed component."""
    if xbmc is None:
        return False
    deadline = time.monotonic() + max(0.0, float(timeout or 0.0))
    while time.monotonic() < deadline:
        if _installed_fast() and _enabled_fast():
            return True
        try:
            xbmc.sleep(100)
        except Exception:
            time.sleep(0.10)
    return bool(_installed_fast() and _enabled_fast())


def ensure_ffmpeg_direct(interactive=False, timeout=20.0):
    """Ensure Kodi's official optional inputstream exists and is enabled.

    Missing binaries are installed only after an explicit user action. A
    single-flight lock prevents duplicate setup attempts in this interpreter.
    The persistent service may enable an already installed component but never
    opens the installation UI on Kodi startup.
    """
    if xbmc is None:
        return False
    acquired = _ENSURE_LOCK.acquire(False)
    if not acquired:
        return _wait_available(min(max(1.0, float(timeout or 0.0)), 6.0))
    try:
        state = ffmpeg_direct_status()
        if state.get('installed') and state.get('enabled'):
            return True

        if state.get('installed'):
            try:
                xbmc.executebuiltin('EnableAddon(%s)' % FFMPEG_DIRECT_ID)
            except Exception as exc:
                log('FFmpeg Direct: falha ao solicitar habilitação pelo Kodi: %s' % exc, 'warning')
                return False
            ok = _wait_available(min(max(1.0, float(timeout or 0.0)), 6.0))
            if ok:
                state = ffmpeg_direct_status()
                log('FFmpeg Direct: componente oficial habilitado%s.' % (
                    (' (v%s)' % state.get('version')) if state.get('version') else ''
                ), 'debug')
            return ok

        if not interactive:
            return False

        try:
            xbmc.executebuiltin('UpdateAddonRepos')
        except Exception:
            pass
        try:
            # CRITICAL UX CONTRACT: InstallAddon is executed in blocking mode.
            # Kodi keeps its own confirmation/installation modal active.  If
            # the user selects NO, this call returns as soon as the dialog
            # closes; if YES, Kodi's modal installer runs to completion before
            # returning.  Therefore ONEPLAY never leaves a delayed failure
            # armed while the user is already navigating elsewhere.
            xbmc.executebuiltin('InstallAddon(%s)' % FFMPEG_DIRECT_ID, True)
        except Exception as exc:
            log('FFmpeg Direct: falha ao solicitar instalação pelo Kodi: %s' % exc, 'warning')
            return False

        # No polling window after the native modal.  Absence here means the
        # modal installation was declined/cancelled/failed and is terminal for
        # this explicit action.
        if not _installed_fast():
            log('FFmpeg Direct: instalação modal encerrada sem componente instalado.', 'debug')
            return False

        if not _enabled_fast():
            try:
                xbmc.executebuiltin('EnableAddon(%s)' % FFMPEG_DIRECT_ID, True)
            except Exception:
                return False
            if not _wait_available(min(3.0, max(1.0, float(timeout or 0.0)))):
                return False

        state = ffmpeg_direct_status()
        if state.get('installed') and state.get('enabled'):
            log('FFmpeg Direct: componente oficial instalado e habilitado%s.' % (
                (' (v%s)' % state.get('version')) if state.get('version') else ''
            ), 'debug')
            return True
        return False
    finally:
        _ENSURE_LOCK.release()

def ffmpeg_direct_format(url_or_format):
    value = str(url_or_format or '').strip()
    lowered = value.lower()
    if lowered in ('hls', 'm3u8'):
        return 'hls'
    if lowered in ('ts', 'mpegts', 'mpeg-ts'):
        return 'ts'
    raw = value.split('|', 1)[0]
    path = raw.split('?', 1)[0].lower()
    if path.endswith('.m3u8'):
        return 'hls'
    if path.endswith('.ts'):
        return 'ts'
    return ''


def configure_ffmpeg_direct(item, url_or_format, kind='live'):
    """Attach ffmpegdirect properties to the *resolved* Kodi ListItem."""
    fmt = ffmpeg_direct_format(url_or_format)
    if item is None or not fmt:
        return False
    try:
        item.setProperty('inputstream', FFMPEG_DIRECT_ID)
        item.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        item.setProperty(
            'inputstream.ffmpegdirect.is_realtime_stream',
            'true' if str(kind or '').lower() == 'live' else 'false',
        )
        if fmt == 'hls':
            item.setMimeType('application/vnd.apple.mpegurl')
            item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        else:
            item.setMimeType('video/mp2t')
        try:
            item.setContentLookup(False)
        except Exception:
            pass
        return True
    except Exception as exc:
        log('FFmpeg Direct: não foi possível configurar o ListItem resolvido: %s' % exc, 'warning')
        return False
