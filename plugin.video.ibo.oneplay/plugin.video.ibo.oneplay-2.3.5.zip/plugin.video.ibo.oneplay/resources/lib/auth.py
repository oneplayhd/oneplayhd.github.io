# -*- coding: utf-8 -*-
import time
import urllib.parse

from .http import HttpError
from .log import log
from .panel import PanelClient
from .state import clear_session, load_panel, load_prefs, load_session, save_panel, save_prefs, save_session
from .prefs import effective_live_output, get_int
from .xtream import XtreamAccountError, XtreamClient

PANEL_KEYS = (
    'pin', 'note_title', 'note_content', 'qr_url_short', 'qr_description',
    'home_url1', 'home_url2', 'theme', 'stream_type', 'output', 'live_stream_format', 'live_stream_lock',
    'time_format', 'language_code', 'expire_warning_enabled', 'expire_warning_days',
    'device_limit_reached', 'device_limit', 'devices_in_use', 'access_denied',
    'access_manage_locked', 'device_blocked', 'auto_test_enabled', 'auto_test_configured'
)


# Credenciais Xtream existem somente neste dicionário do interpretador atual.
# Nenhuma função de persistência recebe esse estado como autoridade. Quando um
# novo interpretador precisa do acesso, ele o reconstrói pelo Device ID no painel.
_RUNTIME_ACCESS = {}


def _runtime_portal_key(portal_id):
    return str(portal_id or '').strip()


def _normalized_bases(values):
    out = []
    seen = set()
    for value in values or []:
        clean = str(value or '').strip().rstrip('/')
        marker = clean.casefold()
        if clean and marker not in seen:
            seen.add(marker)
            out.append(clean)
    return out


def _allowed_bases_from_access(access, primary=''):
    access = access if isinstance(access, dict) else {}
    values = [primary, access.get('base_url')]
    for row in access.get('group_dns') if isinstance(access.get('group_dns'), list) else []:
        if isinstance(row, dict):
            values.append(row.get('base_url'))
    return _normalized_bases(values)


def _remember_runtime_access(portal_id, base_url, username, password, output='m3u8', access_revision='', allowed_bases=None):
    key = _runtime_portal_key(portal_id)
    username = str(username or '')
    password = str(password or '')
    base_url = str(base_url or '').strip().rstrip('/')
    if not key or not username or not password or not base_url:
        return False
    allowed = _normalized_bases(list(allowed_bases or []) + [base_url])
    _RUNTIME_ACCESS[key] = {
        'base_url': base_url,
        'username': username,
        'password': password,
        'output': str(output or 'm3u8'),
        'access_revision': str(access_revision or ''),
        'allowed_bases': allowed,
        'at': time.time(),
    }
    return True


def _forget_runtime_access(portal_id=''):
    key = _runtime_portal_key(portal_id)
    if key:
        _RUNTIME_ACCESS.pop(key, None)
    else:
        _RUNTIME_ACCESS.clear()


def _runtime_access_from_panel(data, timeout=2.5):
    """Resolve credenciais em memória usando somente o Device ID + portal_id."""
    data = dict(data or {})
    portal_id = _runtime_portal_key(data.get('portal_id'))
    if not portal_id:
        raise ValueError('Sessão sem identificador de acesso.')
    panel = PanelClient().kodi_access(portal_id, timeout=timeout) or {}
    denied = str(panel.get('access_denied') or '').strip()
    if panel.get('device_blocked') or denied or str(panel.get('reason') or '') == 'access_denied':
        clear_session()
        _forget_runtime_access(portal_id)
        raise ValueError(denied or 'Acesso bloqueado. Uso não autorizado.')
    if not panel.get('ok'):
        reason = str(panel.get('reason') or 'access_context_error')
        if reason == 'access_not_found':
            clear_session()
        _forget_runtime_access(portal_id)
        raise ValueError('O painel não encontrou o acesso vinculado ao Device ID (%s).' % reason)

    access = panel.get('access') if isinstance(panel.get('access'), dict) else {}
    username = str(access.get('username') or '')
    password = str(access.get('password') or '')
    output = str(access.get('output') or panel.get('output') or panel.get('live_stream_format') or 'm3u8')
    authoritative = str(access.get('base_url') or '').strip().rstrip('/')
    if not username or not password or not authoritative:
        raise ValueError('Contexto de acesso incompleto no painel.')

    # A sessão pode estar usando um espelho físico do mesmo failover_group.
    # Preserve-o somente quando o painel ainda o declara no grupo autorizado.
    requested = str(data.get('base_url') or data.get('server_url') or '').strip().rstrip('/')
    allowed_values = _allowed_bases_from_access(access, authoritative)
    allowed = {value.casefold(): value for value in allowed_values}
    base_url = allowed.get(requested.casefold(), authoritative) if requested else authoritative
    revision = str(access.get('access_revision') or '')
    _remember_runtime_access(portal_id, base_url, username, password, output, revision, allowed_values)
    return _RUNTIME_ACCESS[portal_id], panel


def _access_summaries(panel):
    rows = (panel or {}).get('accesses')
    if not isinstance(rows, list):
        rows = (panel or {}).get('urls') or []
    out = []
    seen = set()
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        pid = str(row.get('id') or row.get('dns_id') or '').strip()
        if not pid or pid in seen:
            continue
        seen.add(pid)
        out.append({
            'id': pid,
            'name': str(row.get('name') or row.get('playlist_name') or row.get('title') or ('DNS ' + pid)),
            'is_protected': '1' if str(row.get('is_protected') or '').lower() in ('1','true','yes','on') else '0',
        })
    return out


def panel_subset(panel):
    subset = {key: panel.get(key) for key in PANEL_KEYS if key in panel}
    summaries = _access_summaries(panel)
    if summaries or 'accesses' in (panel or {}) or 'urls' in (panel or {}):
        subset['access_portals'] = summaries
    return subset


def selected_portal_id():
    return str(load_prefs().get('portal_id') or '')


def set_selected_portal(portal_id):
    prefs = load_prefs()
    prefs['portal_id'] = str(portal_id or '')
    save_prefs(prefs)


def session_client(session=None):
    data = dict(session or load_session() or {})
    if not data:
        raise ValueError('Sessão IBO ausente.')
    portal_id = _runtime_portal_key(data.get('portal_id'))

    # Migração defensiva de qualquer session_v2.json antigo ainda contendo
    # credenciais: aproveita-as apenas em memória e saneia o arquivo na hora.
    legacy_user = str(data.get('username') or '')
    legacy_pass = str(data.get('password') or '')
    if portal_id and legacy_user and legacy_pass:
        _remember_runtime_access(
            portal_id,
            data.get('base_url') or data.get('server_url'),
            legacy_user,
            legacy_pass,
            data.get('output') or effective_live_output(),
            data.get('access_revision') or '',
        )
        save_session(data)
        data.pop('username', None)
        data.pop('password', None)

    runtime = _RUNTIME_ACCESS.get(portal_id) if portal_id else None
    if not runtime:
        runtime, _panel = _runtime_access_from_panel(data, timeout=2.5)

    # O transporte físico pode mudar por failover, mas a sessão em disco não é
    # autoridade para inventar uma URL. Só aceite uma base que o contexto atual
    # do painel declarou como pertencente ao mesmo grupo lógico.
    requested = str(data.get('base_url') or data.get('server_url') or '').strip().rstrip('/')
    allowed = {str(value).casefold(): str(value) for value in (runtime.get('allowed_bases') or []) if str(value).strip()}
    runtime_base = str(runtime.get('base_url') or '').strip().rstrip('/')
    base_url = allowed.get(requested.casefold(), runtime_base) if requested else runtime_base
    if not base_url:
        raise ValueError('Contexto de transporte ausente para o acesso vinculado.')
    return XtreamClient(base_url, runtime.get('username'), runtime.get('password'), effective_live_output())


def _portal_by_id(portals, portal_id):
    for row in portals if isinstance(portals, list) else []:
        if str((row or {}).get('id') or '') == str(portal_id or ''):
            return row
    return portals[0] if isinstance(portals, list) and portals else None


def connect_from_panel(portal_id='', failed_url='', failed_reason='', allow_auto_test=False, allow_panel_failover=True, prefetched_auth=None, prefetched_base_url='', single_attempt=False, fast_media=False, panel_timeout=None, xtream_timeout=None, deadline=None):
    panel_client = PanelClient()
    selected = str(portal_id or selected_portal_id())
    if fast_media and not selected:
        return {'ok': False, 'error': 'Acesso atual sem identificador de portal para failover.', 'reason': 'portal_id_missing'}
    seen = set()
    last_error = None
    # Media failover is deliberately one panel round-trip per candidate. The
    # player owns the bounded retry loop and proves the candidate with the real
    # media URL on the client network. Normal login/bootstrap keeps its original
    # retry semantics.
    attempts = 1 if (single_attempt or fast_media) else get_int('failover_attempts', default=5, low=1, high=8)

    next_failed_url = str(failed_url or '')
    next_failed_reason = str(failed_reason or '')

    def _remaining():
        if deadline is None:
            return None
        try:
            return max(0.0, float(deadline) - time.monotonic())
        except Exception:
            return None

    for attempt in range(attempts):
        remaining = _remaining()
        if remaining is not None and remaining < 0.50:
            return {
                'ok': False,
                'error': 'Dispositivo reconhecido, mas o tempo total de recuperação foi esgotado.',
                'reason': 'bootstrap_deadline',
                'technical': True,
            }
        effective_panel_timeout = panel_timeout
        if remaining is not None:
            requested = float(panel_timeout) if panel_timeout is not None else remaining
            effective_panel_timeout = max(0.25, min(requested, remaining))
        panel_started = time.time()
        try:
            panel = panel_client.auth(
                failed_url=next_failed_url,
                failed_reason=next_failed_reason,
                timeout=effective_panel_timeout,
                allow_auto_test=allow_auto_test,
                allow_failover=allow_panel_failover,
                media_failover=fast_media,
                target_portal_id=selected,
            )
        except Exception as exc:
            if fast_media:
                return {
                    'ok': False,
                    'error': 'Painel indisponível durante o failover rápido: %s' % exc,
                    'reason': 'panel_error',
                    'technical': True,
                }
            raise
        log('auth.php concluído em %.2fs (failover=%s, auto_test=%s).' % (
            max(0.0, time.time() - panel_started),
            'on' if allow_panel_failover else 'off',
            'on' if allow_auto_test else 'off',
        ) + (' [media-fast]' if fast_media else ''), 'debug')
        save_panel(panel_subset(panel))
        denied = str(panel.get('access_denied') or '').strip()
        if denied:
            clear_session()
            return {'ok': False, 'error': denied, 'panel': panel, 'denied': True, 'reason': 'access_denied'}
        portals = panel.get('urls') or []
        portal = _portal_by_id(portals, selected)
        if not portal:
            if fast_media:
                return {
                    'ok': False,
                    'error': 'Nenhuma DNS alternativa disponível para este acesso.',
                    'panel': panel,
                    'reason': str(panel.get('media_failover_reason') or 'no_alternative'),
                    'technical': True,
                }
            clear_session()
            return {'ok': False, 'error': 'Nenhum acesso liberado para este dispositivo.', 'panel': panel}
        marker = str(portal.get('url') or '').strip().lower()
        if marker in seen:
            break
        seen.add(marker)
        try:
            client = XtreamClient.from_portal(portal)
            if fast_media:
                # The panel has already authorized this device/access and only
                # selected the next mirror. Do not duplicate player_api + Health
                # here: the caller immediately probes the exact media endpoint.
                # Keep the same logical session id and accounting metadata.
                previous = load_session()
                if not previous:
                    return {'ok': False, 'error': 'Sessão ausente durante failover de mídia.', 'reason': 'session_missing'}
                session = dict(previous)
                session.update({
                    'base_url': client.base_url,
                    'server_url': client.base_url,
                    'username': client.username,
                    'password': client.password,
                    'output': client.output,
                    'portal_id': str(portal.get('id') or previous.get('portal_id') or ''),
                    'portal_name': str(portal.get('name') or portal.get('playlist_name') or previous.get('portal_name') or ''),
                    'theme': str(panel.get('theme') or previous.get('theme') or '1'),
                    'pin': str(panel.get('pin') or previous.get('pin') or '0000'),
                    'panel_connected_at': int(time.time()),
                })
                # Do not persist an unproven mirror. The player commits this
                # candidate only after the exact channel/VOD endpoint returns
                # real media bytes. This also keeps Heartbeat from observing a
                # transient candidate that may fail a moment later.
                return {'ok': True, 'session': session, 'panel': panel, 'media_fast': True}
            expected_prefetch = str(prefetched_base_url or '').rstrip('/')
            if attempt == 0 and isinstance(prefetched_auth, dict) and expected_prefetch and client.base_url == expected_prefetch:
                auth = prefetched_auth
                log('Xtream já validado no primeiro acesso; reutilizando autenticação sem segunda consulta.', 'debug')
            else:
                remaining = _remaining()
                if remaining is not None and remaining < 0.50:
                    return {
                        'ok': False,
                        'error': 'Dispositivo reconhecido, mas o tempo total de recuperação foi esgotado.',
                        'panel': panel,
                        'reason': 'bootstrap_deadline',
                        'technical': True,
                    }
                effective_xtream_timeout = xtream_timeout
                if remaining is not None:
                    requested = float(xtream_timeout) if xtream_timeout is not None else min(4.0, remaining)
                    effective_xtream_timeout = max(0.40, min(requested, remaining))
                xtream_started = time.time()
                auth = client.authenticate(timeout=effective_xtream_timeout) if effective_xtream_timeout is not None else client.authenticate()
                log('Xtream authenticate concluído em %.2fs para portal id=%s.' % (
                    max(0.0, time.time() - xtream_started),
                    str(portal.get('id') or ''),
                ), 'debug')
            session = client.session_dict(portal, auth)
            session.update({
                'theme': str(panel.get('theme') or '1'),
                'pin': str(panel.get('pin') or '0000'),
                'portal_count': len(portals),
                'panel_connected_at': int(time.time()),
            })
            set_selected_portal(str(portal.get('id') or ''))
            _remember_runtime_access(
                str(portal.get('id') or ''), client.base_url, client.username, client.password,
                client.output, str((portal or {}).get('access_revision') or '')
            )
            saved = save_session(session)
            try:
                health_started = time.time()
                health = panel_client.health_kodi(saved.get('portal_id'), saved.get('max_connections'))
                log('Health inicial concluído em %.2fs.' % max(0.0, time.time() - health_started), 'debug')
                saved['health_mode'] = str(health.get('mode') or 'auto')
                saved['health_used'] = int(health.get('used') or 0)
                saved['health_limit'] = int(health.get('limit') or 0)
                saved['last_health_at'] = int(time.time())
                saved['auto_refresh_tick'] = 0
                save_session(saved)
                if not health.get('allowed', True) and health.get('enforce'):
                    clear_session()
                    reason = str(health.get('reason') or '')
                    msg = 'Acesso bloqueado. Uso não autorizado.' if reason == 'device_blocked' else 'Limite de conexões ativas atingido.'
                    return {'ok': False, 'error': msg, 'panel': panel}
            except Exception as exc:
                log('Health inicial falhou sem invalidar o login: %s' % exc, 'warning')
            return {'ok': True, 'session': load_session(), 'panel': panel, 'auth': auth}
        except XtreamAccountError as exc:
            if single_attempt:
                return {'ok': False, 'error': str(exc), 'panel': panel, 'reason': 'account_error'}
            return {'ok': False, 'error': str(exc), 'panel': panel}
        except HttpError as exc:
            last_error = exc
            next_failed_url = exc.url or str(portal.get('url') or '')
            next_failed_reason = 'client_transport' if exc.transport else 'client_response'
            if single_attempt:
                return {
                    'ok': False,
                    'error': str(exc),
                    'panel': panel,
                    'reason': next_failed_reason,
                    'failed_url': next_failed_url,
                    'technical': True,
                }
            log('Failover tentativa %d: %s' % (attempt + 1, next_failed_reason), 'warning')
        except Exception as exc:
            last_error = exc
            next_failed_url = str(portal.get('url') or '')
            next_failed_reason = 'client_response'
            if single_attempt:
                return {
                    'ok': False,
                    'error': str(exc),
                    'panel': panel,
                    'reason': next_failed_reason,
                    'failed_url': next_failed_url,
                    'technical': True,
                }
    return {'ok': False, 'error': str(last_error or 'Não foi possível conectar ao servidor IBO.')}


def _kodi_access_unavailable(error):
    """Distingue indisponibilidade do endpoint novo de uma negativa autoritativa."""
    if isinstance(error, HttpError):
        return bool(error.transport or error.status in (404, 405, 500, 501, 502, 503, 504))
    return True


def _save_kodi_access_session(panel_client, panel, access, client, auth, physical_dns_id=''):
    """Persiste uma sessão já provada pelo Kodi e aplica Health antes da Home."""
    denied = str((panel or {}).get('access_denied') or '').strip()
    if (panel or {}).get('device_blocked') or denied:
        clear_session()
        return {
            'ok': False,
            'error': denied or 'Acesso bloqueado. Uso não autorizado.',
            'panel': panel,
            'blocked': True,
            'reason': 'access_denied',
        }

    portal_id = str((access or {}).get('portal_id') or '')
    portal_name = str((access or {}).get('portal_name') or ('DNS ' + portal_id))
    portal = {'id': portal_id, 'name': portal_name, 'playlist_name': portal_name}
    session = client.session_dict(portal, auth)
    summaries = _access_summaries(panel or {})
    session.update({
        'theme': str((panel or {}).get('theme') or '1'),
        'pin': str((panel or {}).get('pin') or '0000'),
        'portal_count': len(summaries) if summaries else 1,
        'panel_connected_at': int(time.time()),
        'failover_group': str((access or {}).get('failover_group') or ''),
        'failover_group_size': int((access or {}).get('group_size') or 1),
        'physical_dns_id': str(physical_dns_id or portal_id),
        # O valor é HMAC gerado pelo painel. Permite detectar troca administrativa
        # sem persistir nem hash simples de usuário/senha no aparelho.
        'access_revision': str((access or {}).get('access_revision') or ''),
    })
    set_selected_portal(portal_id)
    panel_cache = load_panel()
    panel_cache.update(panel_subset(panel or {}))
    save_panel(panel_cache)
    _remember_runtime_access(
        portal_id, client.base_url, client.username, client.password, client.output,
        str((access or {}).get('access_revision') or ''),
        _allowed_bases_from_access(access, client.base_url),
    )
    saved = save_session(session)
    try:
        health_started = time.time()
        health = panel_client.health_kodi(saved.get('portal_id'), saved.get('max_connections'))
        log('Health inicial concluído em %.2fs.' % max(0.0, time.time() - health_started), 'debug')
        saved['health_mode'] = str(health.get('mode') or 'auto')
        saved['health_used'] = int(health.get('used') or 0)
        saved['health_limit'] = int(health.get('limit') or 0)
        saved['last_health_at'] = int(time.time())
        saved['auto_refresh_tick'] = 0
        save_session(saved)
        if not health.get('allowed', True) and health.get('enforce'):
            clear_session()
            reason = str(health.get('reason') or '')
            msg = 'Acesso bloqueado. Uso não autorizado.' if reason == 'device_blocked' else 'Limite de conexões ativas atingido.'
            return {'ok': False, 'error': msg, 'panel': panel, 'reason': reason or 'device_limit_reached'}
    except Exception as exc:
        # Preserva a política histórica: falha transitória do Health não converte
        # uma credencial Xtream válida em falha de login. O serviço repetirá o
        # Heartbeat e aplicará eventual bloqueio autoritativo em seguida.
        log('Health inicial falhou sem invalidar o login: %s' % exc, 'warning')
    return {'ok': True, 'session': load_session(), 'panel': panel, 'auth': auth}


def connect_from_kodi_access(portal_id, prefetched_auth=None, prefetched_base_url='', allow_group_failover=True, endpoint_timeout=2.5, xtream_timeout=4, prefetched_panel=None, deadline=None):
    """Bootstrap rápido de acesso já vinculado, exclusivo do Kodi 2.0.54+.

    O painel apenas entrega a credencial do ``portal_id`` autorizado e as DNSs
    pertencentes ao MESMO ``failover_group``. O Kodi prova player_api.php na sua
    própria rede; nenhuma DNS de outro grupo participa desta sessão.
    """
    target = str(portal_id or '').strip()
    if not target:
        return {'ok': False, 'error': 'Acesso sem identificador de DNS.', 'reason': 'portal_id_missing'}

    def _remaining():
        if deadline is None:
            return None
        try:
            return max(0.0, float(deadline) - time.monotonic())
        except Exception:
            return None

    panel_client = PanelClient()
    started = time.time()
    if isinstance(prefetched_panel, dict):
        panel = dict(prefetched_panel)
        elapsed = max(0.0, time.time() - started)
        log('kodi_access.php: contexto autoritativo já obtido nesta abertura; reutilizando sem segunda consulta.', 'debug')
    else:
        try:
            remaining = _remaining()
            if remaining is not None and remaining < 0.35:
                return {
                    'ok': False,
                    'error': 'Dispositivo reconhecido, mas o tempo de recuperação do acesso foi esgotado.',
                    'reason': 'bootstrap_deadline',
                    'technical': True,
                }
            effective_endpoint_timeout = float(endpoint_timeout or 2.5)
            if remaining is not None:
                effective_endpoint_timeout = max(0.25, min(effective_endpoint_timeout, remaining))
            panel = panel_client.kodi_access(target, timeout=effective_endpoint_timeout) or {}
        except Exception as exc:
            elapsed = max(0.0, time.time() - started)
            log('kodi_access.php indisponível em %.2fs: %s' % (elapsed, exc), 'warning')
            return {
                'ok': False,
                'error': str(exc),
                'reason': 'kodi_access_unavailable' if _kodi_access_unavailable(exc) else 'kodi_access_error',
                'technical': True,
            }

        elapsed = max(0.0, time.time() - started)
        server_ms = int(panel.get('elapsed_ms') or 0)
        log('kodi_access.php concluído em %.2fs (servidor=%dms).' % (elapsed, server_ms), 'debug')

    denied = str(panel.get('access_denied') or '').strip()
    if panel.get('device_blocked') or denied or str(panel.get('reason') or '') == 'access_denied':
        clear_session()
        return {
            'ok': False,
            'error': denied or 'Acesso bloqueado. Uso não autorizado.',
            'panel': panel,
            'blocked': True,
            'reason': 'access_denied',
        }
    if not panel.get('ok'):
        reason = str(panel.get('reason') or 'access_context_error')
        # Endpoint existe e respondeu autoritativamente: não cair no auth.php,
        # pois access_not_found/credentials_missing não são falha de transporte.
        return {
            'ok': False,
            'error': 'O painel não encontrou o acesso vinculado.' if reason == 'access_not_found' else 'Não foi possível reconstruir o acesso (%s).' % reason,
            'panel': panel,
            'reason': reason,
        }

    access = panel.get('access') if isinstance(panel.get('access'), dict) else {}
    username = str(access.get('username') or '')
    password = str(access.get('password') or '')
    output = str(access.get('output') or panel.get('output') or panel.get('live_stream_format') or 'm3u8')
    base_url = str(access.get('base_url') or '').rstrip('/')
    if not username or not password or not base_url:
        return {'ok': False, 'error': 'Contexto de acesso incompleto.', 'panel': panel, 'reason': 'access_context_incomplete'}

    group_rows = access.get('group_dns') if isinstance(access.get('group_dns'), list) else []
    candidates = []
    seen = set()

    def _append_candidate(dns_id, url, name=''):
        clean = str(url or '').strip().rstrip('/')
        marker = clean.lower()
        if not clean or marker in seen:
            return
        seen.add(marker)
        candidates.append({
            'dns_id': str(dns_id or ''),
            'base_url': clean,
            'name': str(name or ''),
        })

    # Contrato preservado: a DNS vinculada é sempre testada primeiro.
    _append_candidate(target, base_url, access.get('portal_name'))
    if allow_group_failover:
        for row in group_rows:
            if not isinstance(row, dict):
                continue
            _append_candidate(row.get('dns_id'), row.get('base_url'), row.get('name'))

    last_error = None
    expected_prefetch = str(prefetched_base_url or '').rstrip('/')
    for pos, candidate in enumerate(candidates, 1):
        candidate_url = str(candidate.get('base_url') or '').rstrip('/')
        physical_dns_id = str(candidate.get('dns_id') or target)
        client = XtreamClient(candidate_url, username, password, output)
        try:
            if pos == 1 and isinstance(prefetched_auth, dict) and expected_prefetch and candidate_url == expected_prefetch:
                auth = prefetched_auth
                log('Xtream já validado no primeiro acesso; bootstrap Kodi reutilizou a autenticação sem segunda consulta.', 'debug')
            else:
                remaining = _remaining()
                if remaining is not None and remaining < 0.50:
                    return {
                        'ok': False,
                        'error': 'Dispositivo reconhecido, mas nenhum servidor do acesso respondeu dentro do limite de segurança.',
                        'panel': panel,
                        'reason': 'bootstrap_deadline',
                        'technical': True,
                    }
                effective_xtream_timeout = float(xtream_timeout or 4.0)
                if remaining is not None:
                    effective_xtream_timeout = max(0.40, min(effective_xtream_timeout, remaining))
                xtream_started = time.time()
                auth = client.authenticate(timeout=effective_xtream_timeout)
                log('Bootstrap Kodi: Xtream concluído em %.2fs na DNS física id=%s (%d/%d).' % (
                    max(0.0, time.time() - xtream_started), physical_dns_id, pos, len(candidates)), 'debug')
            if physical_dns_id != target:
                log('Bootstrap Kodi: DNS vinculada indisponível; sessão reconstruída por espelho id=%s do mesmo grupo.' % physical_dns_id, 'warning')
            return _save_kodi_access_session(panel_client, panel, access, client, auth, physical_dns_id=physical_dns_id)
        except XtreamAccountError as exc:
            # Espelhos do mesmo grupo compartilham a credencial. Uma recusa real
            # encerra o grupo em vez de tentar serviços não relacionados.
            return {'ok': False, 'error': str(exc), 'panel': panel, 'reason': 'account_error'}
        except HttpError as exc:
            last_error = exc
            if pos < len(candidates):
                log('Bootstrap Kodi: DNS física id=%s falhou tecnicamente; tentando próximo espelho do mesmo grupo.' % physical_dns_id, 'warning')
                continue
            return {
                'ok': False,
                'error': str(exc),
                'panel': panel,
                'reason': 'client_transport' if exc.transport else 'client_response',
                'failed_url': exc.url or candidate_url,
                'technical': True,
            }
        except Exception as exc:
            last_error = exc
            if pos < len(candidates):
                log('Bootstrap Kodi: DNS física id=%s falhou; tentando próximo espelho do mesmo grupo.' % physical_dns_id, 'warning')
                continue
            return {
                'ok': False,
                'error': str(exc),
                'panel': panel,
                'reason': 'client_response',
                'failed_url': candidate_url,
                'technical': True,
            }

    return {'ok': False, 'error': str(last_error or 'Nenhuma DNS do grupo respondeu.'), 'panel': panel, 'reason': 'group_exhausted', 'technical': True}


def _dns_priority(row, fallback):
    try:
        value = int(str((row or {}).get('failover_priority') or '').strip())
        return value if value >= 0 else fallback
    except Exception:
        return fallback


def _dns_groups(dns_rows):
    """Agrupa DNSs pelo contrato failover_group do painel.

    - mesmo failover_group = espelhos do mesmo serviço/mesma credencial;
    - grupo vazio = DNS independente, portanto nunca compartilha credencial com
      outra DNS sem grupo;
    - a ordem entre grupos segue a primeira aparição no index.php;
    - dentro do grupo, menor failover_priority é tentada primeiro.
    """
    groups = []
    by_key = {}
    for source_index, dns in enumerate(list(dns_rows or [])):
        if not isinstance(dns, dict):
            continue
        raw_group = str(dns.get('failover_group') or '').strip()
        if raw_group:
            key = 'group:' + raw_group.casefold()
            label = raw_group
        else:
            # Sem grupo é serviço independente conforme contrato homologado.
            key = 'dns:' + str(dns.get('id') or source_index)
            label = ''
        entry = by_key.get(key)
        if entry is None:
            entry = {'key': key, 'label': label, 'rows': [], 'order': source_index}
            by_key[key] = entry
            groups.append(entry)
        row = dict(dns)
        row['_source_index'] = source_index
        row['_priority'] = _dns_priority(row, 1000000 + source_index)
        entry['rows'].append(row)
    for entry in groups:
        entry['rows'].sort(key=lambda row: (row.get('_priority', 1000000), row.get('_source_index', 0)))
    return groups


def _locate_dns_by_failover_group(dns_rows, username, password, timeout=4):
    """Localiza acesso respeitando o mesmo contrato de grupos do APK.

    Para cada serviço/grupo, tenta somente a DNS prioritária. As DNSs seguintes
    daquele grupo são failover e só são consultadas se a anterior falhar por
    rota/transporte/resposta técnica. Se uma DNS do grupo responde normalmente
    mas rejeita a conta, o grupo inteiro é descartado e a busca passa para o
    próximo serviço, pois os espelhos do mesmo grupo compartilham credenciais.
    """
    groups = _dns_groups(dns_rows)
    if not groups:
        return None, None, ''
    last_error = ''
    for group_pos, group in enumerate(groups, 1):
        rows = group.get('rows') or []
        label = group.get('label') or ('DNS ' + str((rows[0] if rows else {}).get('id') or ''))
        log('Login manual: verificando grupo %s (%d/%d), %d DNS.' % (
            label, group_pos, len(groups), len(rows)), 'debug')
        for dns_pos, dns in enumerate(rows, 1):
            try:
                log('Login manual: grupo=%s DNS id=%s prioridade=%s (%d/%d).' % (
                    label, dns.get('id'), dns.get('_priority'), dns_pos, len(rows)), 'debug')
                client = XtreamClient(dns.get('url'), username, password, 'm3u8')
                validated_auth = client.authenticate(timeout=timeout)
                log('Login manual: acesso validado no grupo=%s DNS id=%s; busca encerrada.' % (
                    label, dns.get('id')), 'debug')
                clean = dict(dns)
                clean.pop('_source_index', None)
                clean.pop('_priority', None)
                clean['_validated_base_url'] = client.base_url
                return clean, validated_auth, ''
            except XtreamAccountError as exc:
                last_error = str(exc)
                log('Login manual: grupo=%s respondeu e recusou a credencial; espelhos do grupo não serão consultados.' % label, 'debug')
                # Mesma credencial vale em todos os espelhos do grupo.
                break
            except Exception as exc:
                last_error = str(exc)
                if dns_pos < len(rows):
                    log('Login manual: DNS id=%s indisponível; tentando próximo espelho do mesmo grupo.' % dns.get('id'), 'debug')
                else:
                    log('Login manual: grupo=%s indisponível; seguindo para o próximo grupo.' % label, 'debug')
    return None, None, last_error


def manual_login(username, password):
    username = str(username or '').strip()
    password = str(password or '').strip()
    if not username or not password:
        return {'ok': False, 'error': 'Informe usuário e senha.'}
    panel = PanelClient()
    try:
        # index.php V2.0.4 é o preflight leve e autoritativo: bloqueio do
        # dispositivo é resolvido no painel ANTES de consultar qualquer Xtream.
        state = panel.index_state(timeout=3)
    except Exception as exc:
        return {'ok': False, 'error': 'Não foi possível consultar o painel: %s' % exc}
    denied = str(state.get('access_denied') or '').strip()
    if state.get('device_blocked') or denied:
        clear_session()
        return {'ok': False, 'error': denied or 'Acesso bloqueado. Uso não autorizado.'}
    dns_rows = panel.dns_from_state(state)
    log('index.php retornou %d DNS no catálogo global; login aplicará failover_group antes de testar credenciais.' % len(dns_rows))
    if not dns_rows:
        return {'ok': False, 'error': 'Nenhuma DNS cadastrada no painel.'}

    # Contrato igual ao APK: primeiro acesso percorre SERVIÇOS (grupos), não
    # uma lista global de DNSs. Dentro de cada grupo, DNS secundária só é
    # consultada quando a prioritária falha tecnicamente.
    dns, validated_auth, last_error = _locate_dns_by_failover_group(dns_rows, username, password, timeout=4)
    if not dns:
        return {'ok': False, 'error': last_error or 'Usuário/senha não foram encontrados nas DNS do painel.'}
    try:
        add_started = time.time()
        added = panel.add_access(dns.get('id'), username, password, timeout=4)
        log('add.php concluiu o registro do primeiro acesso em %.2fs.' % max(0.0, time.time() - add_started), 'debug')
    except Exception as exc:
        return {'ok': False, 'error': 'Credencial válida, mas o painel não conseguiu registrar o acesso: %s' % exc}
    if int(added.get('success') or 0) != 1:
        return {'ok': False, 'error': str(added.get('message') or added.get('mensagem') or added.get('access_denied') or 'O painel recusou o acesso.')}
    portal_id = str(dns.get('id') or '')
    set_selected_portal(portal_id)
    validated_base_url = str(dns.pop('_validated_base_url', '') or '').rstrip('/')

    # V2.0.54: após o Xtream já ter sido validado e add.php ter confirmado o
    # vínculo, não há motivo para reconstruir tudo pelo auth.php. O endpoint
    # Kodi devolve apenas este acesso e o seu failover_group.
    fast = connect_from_kodi_access(
        portal_id=portal_id,
        prefetched_auth=validated_auth,
        prefetched_base_url=validated_base_url,
        allow_group_failover=False,
    )
    if fast.get('reason') != 'kodi_access_unavailable':
        return fast

    # Compatibilidade conservadora caso o add-on seja atualizado antes do painel.
    # No V2.19 esta ramificação não deve aparecer no log.
    log('Primeiro acesso: kodi_access.php ausente; usando auth.php legado como fallback de compatibilidade.', 'warning')
    return connect_from_panel(
        portal_id=portal_id,
        allow_panel_failover=False,
        prefetched_auth=validated_auth,
        prefetched_base_url=validated_base_url,
    )

def automatic_test_ready(state):
    """Retorna True somente quando o preflight autoriza Teste Automático."""
    state = state if isinstance(state, dict) else {}
    enabled = str(state.get('auto_test_enabled') or '').strip().lower() in ('1', 'true', 'yes', 'on')
    configured = str(state.get('auto_test_configured') or '').strip().lower() in ('1', 'true', 'yes', 'on')
    return bool(enabled and configured)


def _kodi_auto_test_endpoint_missing(error):
    """Fallback legado somente quando o endpoint dedicado realmente não existe."""
    return isinstance(error, HttpError) and error.status in (404, 405, 501)


def _kodi_auto_test_v2_unsupported(error):
    """Painel V2.20: endpoint existe, mas ainda aceita somente o contrato V1."""
    return isinstance(error, HttpError) and error.status == 403


def _automatic_test_error_message(status, error=''):
    status = str(status or '').strip().lower()
    error = str(error or '').strip().lower()
    if status == 'disabled':
        return 'Teste Automático desativado.'
    if status == 'configuration_error':
        return 'Teste Automático não está configurado corretamente no painel.'
    if status == 'invalid_device':
        return 'ID do dispositivo inválido para o Teste Automático.'
    if status in ('processing', 'pending'):
        return 'Teste Automático já possui uma solicitação registrada. O Kodi não repetirá o teste automaticamente.'
    if status == 'success':
        return 'O Teste Automático deste dispositivo já foi gerado. Para liberar nova tentativa, use Resetar ou Excluir em Testes no painel.'
    if status == 'error':
        return 'O Teste Automático deste dispositivo já foi tentado e está registrado como erro. Resete o registro no painel para liberar nova tentativa.'
    if error == 'device_limit_reached':
        return 'Limite de conexões ativas atingido.'
    if error.startswith('http_'):
        return 'O serviço de Teste Automático respondeu com erro (%s).' % error.replace('_', ' ').upper()
    if error in ('transport_error', 'curl_unavailable', 'curl_init_failed'):
        return 'O serviço de Teste Automático está temporariamente indisponível.'
    if error == 'credentials_not_recognized':
        return 'O Teste Automático não retornou uma credencial reconhecida.'
    if error == 'local_access_failed':
        return 'O painel recebeu a credencial do teste, mas não conseguiu registrar o acesso.'
    return 'Não foi possível concluir o Teste Automático%s.' % ((' (' + (error or status) + ')') if (error or status) else '')


_AUTO_TEST_ACTIVATION_BUDGET_SECONDS = 12.0
_AUTO_TEST_ACTIVATION_RECOVERY_WINDOW_SECONDS = 45.0
_AUTO_TEST_ACTIVATION_DELAYS = (2.0, 3.0, 3.0, 4.0)


def _activation_pending_result(last=None):
    out = dict(last or {})
    out.update({
        'ok': False,
        'reason': 'automatic_test_activation_pending',
        'activation_pending': True,
        'error': 'Acesso criado com sucesso. A ativação ainda está sendo concluída. Aguarde alguns instantes e abra novamente.',
    })
    return out


def _wait_for_auto_test_activation(portal_id, panel_client=None, initial_result=None, max_wait=None):
    """Aguarda somente a propagação do acesso recém-criado.

    Não solicita outro teste, não chama auth.php e não atravessa grupos. Cada
    rodada usa kodi_access.php e testa somente a DNS vinculada + seus espelhos.
    """
    target = str(portal_id or '').strip()
    if not target:
        return _activation_pending_result({'reason': 'auto_test_access_missing'})
    client = panel_client or PanelClient()
    budget = _AUTO_TEST_ACTIVATION_BUDGET_SECONDS if max_wait is None else max(0.0, float(max_wait))
    started = time.time()
    attempt = 0
    last = initial_result if isinstance(initial_result, dict) else None

    while True:
        attempt += 1
        if last is None:
            last = connect_from_kodi_access(target, allow_group_failover=True)
        if last.get('ok'):
            last['reason'] = 'automatic_test_access'
            log('Ativação pós-Teste Automático concluída em %.2fs (%d tentativa(s)).' % (max(0.0, time.time() - started), attempt), 'debug')
            return last
        if last.get('blocked') or last.get('reason') in ('access_denied',):
            return last
        if last.get('reason') == 'kodi_access_unavailable':
            return last

        elapsed = max(0.0, time.time() - started)
        if elapsed >= budget:
            log('Ativação pós-Teste Automático ainda pendente após %.2fs; nenhum novo teste será solicitado.' % elapsed, 'warning')
            return _activation_pending_result(last)

        delay_index = min(attempt - 1, len(_AUTO_TEST_ACTIVATION_DELAYS) - 1)
        delay = _AUTO_TEST_ACTIVATION_DELAYS[delay_index]
        remaining = max(0.0, budget - elapsed)
        if remaining <= 0:
            return _activation_pending_result(last)
        delay = min(delay, remaining)
        log('Teste Automático já gerado; aguardando ativação do acesso antes de nova validação (tentativa %d).' % (attempt + 1), 'debug')
        if delay > 0:
            time.sleep(delay)
        last = None


def _auto_test_state(client, timeout=4.0):
    started = time.time()
    state = client.kodi_auto_test(action='state', timeout=timeout, contract='ibo-kodi-auto-test-v2') or {}
    log('kodi_auto_test.php state concluído em %.2fs (status=%s, can_generate=%s, access=%s).' % (
        max(0.0, time.time() - started),
        str(state.get('status') or 'none'),
        'yes' if state.get('can_generate') else 'no',
        'yes' if state.get('access_exists') else 'no',
    ), 'debug')
    return state


def _auto_test_run(client, contract='ibo-kodi-auto-test-v2'):
    started = time.time()
    test = client.kodi_auto_test(action='run', timeout=18.0, contract=contract) or {}
    elapsed = max(0.0, time.time() - started)
    server_ms = int(test.get('elapsed_ms') or 0)
    provider_ms = int(test.get('provider_elapsed_ms') or 0)
    log('kodi_auto_test.php run concluído em %.2fs (servidor=%dms, provedor=%dms, status=%s).' % (
        elapsed, server_ms, provider_ms, str(test.get('status') or test.get('reason') or 'unknown')), 'debug')
    return test


def automatic_test(prefetched_state=None):
    """Segue literalmente o registro de ``tests.php`` antes de gerar um teste.

    Painel V2.21: ``state`` nunca alcança o fornecedor. Somente ``none`` ou
    ``reset`` autorizam ``run``. ``success/error/pending/processing`` bloqueiam
    nova geração até ação administrativa. Após ``success``, o Kodi entra em uma
    fase curta de ativação e nunca converte um 404 temporário em novo teste.
    """
    try:
        client = PanelClient()
        state = prefetched_state if isinstance(prefetched_state, dict) else client.index_state(timeout=3)
        cache = load_panel()
        cache.update(panel_subset(state))
        save_panel(cache)
        denied = str(state.get('access_denied') or '').strip()
        if state.get('device_blocked') or denied:
            return {'ok': False, 'error': denied or 'Acesso bloqueado. Uso não autorizado.', 'reason': 'denied'}
        if not automatic_test_ready(state):
            log('Teste Automático: desativado ou não configurado; endpoint dedicado não chamado.', 'debug')
            return {'ok': False, 'error': 'Teste Automático desativado.', 'reason': 'auto_test_disabled'}

        legacy_v1 = False
        try:
            registry = _auto_test_state(client)
        except Exception as exc:
            if _kodi_auto_test_endpoint_missing(exc):
                log('Teste Automático: kodi_auto_test.php ausente; usando auth.php legado como fallback de compatibilidade.', 'warning')
                return connect_from_panel(allow_auto_test=True)
            if _kodi_auto_test_v2_unsupported(exc):
                # V2.20: a tentativa V2 foi rejeitada antes do fornecedor. O
                # próprio contrato V1 ainda respeita activation_tests e pode ser
                # executado uma única vez com segurança.
                legacy_v1 = True
                registry = None
                log('Teste Automático: Painel anterior ao contrato state/run; usando kodi_auto_test V1 uma única vez.', 'warning')
            else:
                log('Estado do Teste Automático indisponível; nenhuma nova solicitação será feita: %s' % exc, 'warning')
                return {'ok': False, 'error': 'Não foi possível consultar o estado do Teste Automático: %s' % exc, 'reason': 'auto_test_state_error'}

        if isinstance(registry, dict):
            denied = str(registry.get('access_denied') or '').strip()
            if registry.get('device_blocked') or denied or str(registry.get('reason') or '') == 'access_denied':
                clear_session()
                return {'ok': False, 'error': denied or 'Acesso bloqueado. Uso não autorizado.', 'reason': 'denied'}

            registry_status = str(registry.get('status') or 'none').strip().lower()
            portal_id = str(registry.get('portal_id') or '').strip()
            if registry.get('access_exists') and portal_id:
                set_selected_portal(portal_id)
                return _wait_for_auto_test_activation(portal_id, panel_client=client)

            if not registry.get('can_generate'):
                error = str(registry.get('error') or registry.get('reason') or registry_status or 'test_registry')
                log('Teste Automático não repetido: tests.php status=%s, test_id=%s.' % (
                    registry_status, str(registry.get('test_id') or '0')), 'debug')
                return {
                    'ok': False,
                    'error': _automatic_test_error_message(registry_status, error),
                    'reason': 'auto_test_registry_locked',
                    'auto_test_status': registry_status,
                    'test_registry_blocked': True,
                    'test_id': registry.get('test_id'),
                }

        try:
            test = _auto_test_run(client, contract='ibo-kodi-auto-test-v1' if legacy_v1 else 'ibo-kodi-auto-test-v2')
        except Exception as exc:
            # Timeout/transporte pode significar que o servidor continua
            # processando. Nunca faça segunda solicitação automática.
            log('Teste Automático Kodi falhou sem repetir a solicitação: %s' % exc, 'warning')
            return {'ok': False, 'error': 'Não foi possível concluir o Teste Automático: %s' % exc, 'reason': 'auto_test_endpoint_error'}

        denied = str(test.get('access_denied') or '').strip()
        if test.get('device_blocked') or denied or str(test.get('reason') or '') == 'access_denied':
            clear_session()
            return {'ok': False, 'error': denied or 'Acesso bloqueado. Uso não autorizado.', 'reason': 'denied'}

        status = str(test.get('status') or '').strip().lower()
        if not test.get('ok') or status != 'success':
            error = str(test.get('error') or test.get('reason') or status or 'auto_test_failed')
            return {
                'ok': False,
                'error': _automatic_test_error_message(status, error),
                'reason': error,
                'auto_test_status': status,
                'test_registry_blocked': bool(test.get('registry_locked')),
            }

        portal_id = str(test.get('portal_id') or '').strip()
        if not portal_id:
            return _activation_pending_result({'auto_test_status': status})
        set_selected_portal(portal_id)

        fast = _wait_for_auto_test_activation(portal_id, panel_client=client)
        if fast.get('reason') != 'kodi_access_unavailable':
            return fast

        # Painel parcial/antigo: auto-test existe, mas kodi_access não.
        log('Teste Automático: kodi_access.php ausente após sucesso; usando auth.php legado sem novo Teste Automático.', 'warning')
        return connect_from_panel(portal_id=portal_id, allow_auto_test=False, allow_panel_failover=False)
    except Exception as exc:
        return {'ok': False, 'error': str(exc), 'reason': 'auto_test_error'}


_RECOVERY_INDEX_ATTEMPTS = 3
_RECOVERY_INDEX_DELAY_SECONDS = 0.65
_RECOVERY_INDEX_TIMEOUT_SECONDS = 3
_RECOVERY_BOOTSTRAP_BUDGET_SECONDS = 12.0


def _confirmed_recovery_state(client, deadline=None):
    """Confirma o estado do DID antes de liberar Login/Teste Automático.

    Na primeira execução após limpar os dados do Kodi, rede/painel podem ainda
    estar estabilizando. Uma resposta vazia isolada não deve ser tratada como
    prova de que o dispositivo perdeu o vínculo. Por isso, somente o estado
    ``sem acesso`` recebe duas confirmações curtas. Erros transitórios do
    index.php também são repetidos dentro da mesma janela de bootstrap.

    A função continua somente de leitura: não chama auth.php, não cria acesso,
    não executa Teste Automático e não altera failover. Bloqueio ou acesso já
    presente encerram a confirmação imediatamente, sem qualquer atraso extra.
    """
    attempts = max(1, int(_RECOVERY_INDEX_ATTEMPTS))
    last_state = None
    last_error = None

    for attempt in range(attempts):
        try:
            remaining = None if deadline is None else max(0.0, float(deadline) - time.monotonic())
            if remaining is not None and remaining < 0.35:
                raise HttpError('Tempo total excedido na consulta do Device ID.', transport=True)
            effective_timeout = float(_RECOVERY_INDEX_TIMEOUT_SECONDS)
            if remaining is not None:
                effective_timeout = max(0.25, min(effective_timeout, remaining))
            state = client.index_state(timeout=effective_timeout)
            state = state if isinstance(state, dict) else {}
            last_state = state
            last_error = None

            denied = str(state.get('access_denied') or '').strip()
            accesses = client.accesses_from_state(state)
            if state.get('device_blocked') or denied or accesses:
                if attempt:
                    log('Restauração por ID: vínculo/estado confirmado na tentativa %d/%d.' % (attempt + 1, attempts), 'debug')
                return state

            if attempt < attempts - 1:
                log('Restauração por ID: index.php ainda sem acesso na tentativa %d/%d; confirmando novamente antes do Login.' % (attempt + 1, attempts), 'debug')
        except Exception as exc:
            last_error = exc
            if attempt < attempts - 1:
                log('Restauração por ID: index.php indisponível na tentativa %d/%d (%s); repetindo antes do Login.' % (attempt + 1, attempts, exc), 'warning')

        if attempt < attempts - 1:
            delay = float(_RECOVERY_INDEX_DELAY_SECONDS)
            if deadline is not None:
                delay = min(delay, max(0.0, float(deadline) - time.monotonic()))
            if delay > 0:
                time.sleep(delay)

    # Uma resposta válida e vazia repetida é um ``no_access`` confirmado. Se
    # nenhuma tentativa produziu estado válido, preserve a semântica index_error.
    if last_state is not None:
        return last_state
    if last_error is not None:
        raise last_error
    return {}


def recover_registered_access():
    """Restaura silenciosamente um acesso já vinculado ao ID do dispositivo.

    Não cria acesso e não executa Teste Automático. Quando o index.php confirma
    um vínculo, usa kodi_access.php; auth.php fica apenas como fallback para
    painéis anteriores ao contrato V2.19.
    Isso permite bloquear, expulsar e depois liberar o mesmo ID sem exigir que
    o usuário digite novamente credenciais que já permanecem cadastradas.

    V2.0.42: antes de declarar ``no_access`` e abrir Login/Teste Automático, o
    bootstrap confirma rapidamente o mesmo DID no index.php. Isso elimina a
    corrida observada na primeira abertura após ``Limpar dados`` do Kodi.
    """
    if load_session():
        return {'ok': True, 'reason': 'session_exists', 'session': load_session()}
    client = PanelClient()
    deadline = time.monotonic() + float(_RECOVERY_BOOTSTRAP_BUDGET_SECONDS)
    recovery_started = time.monotonic()
    try:
        state = _confirmed_recovery_state(client, deadline=deadline)
    except Exception as exc:
        log('Restauração por ID: index.php indisponível após confirmação: %s' % exc, 'warning')
        if isinstance(exc, HttpError) and int(exc.status or 0) == 429:
            wait = int(getattr(exc, 'retry_after', 0) or 0)
            message = 'O painel recebeu muitas consultas deste acesso.'
            if wait > 0:
                message += ' Tente novamente em %d segundos.' % wait
            return {'ok': False, 'reason': 'index_error', 'error': message, 'silent': True, 'retry_after': wait}
        return {'ok': False, 'reason': 'index_error', 'error': str(exc), 'silent': True}

    cache = load_panel()
    cache.update(panel_subset(state))
    save_panel(cache)
    denied = str(state.get('access_denied') or '').strip()
    if state.get('device_blocked') or denied:
        log('Restauração por ID: dispositivo ainda bloqueado; auth.php não chamado.', 'debug')
        return {
            'ok': False,
            'reason': 'denied',
            'blocked': True,
            'error': denied or 'Acesso bloqueado. Uso não autorizado.',
        }

    accesses = client.accesses_from_state(state)
    if not accesses:
        log('Restauração por ID: nenhum acesso cadastrado; liberando decisão de Teste Automático da abertura.', 'debug')
        return {'ok': False, 'reason': 'no_access', 'silent': True, 'state': state}

    wanted = selected_portal_id()
    ids = [str(row.get('id') or '') for row in accesses]
    portal_id = wanted if wanted in ids else ids[0]
    if portal_id != wanted:
        set_selected_portal(portal_id)
    log('Restauração por ID: acesso cadastrado encontrado no DNS id=%s; bootstrap Kodi limitará o contexto ao mesmo grupo.' % portal_id, 'debug')

    remaining = max(0.0, deadline - time.monotonic())
    if remaining < 0.50:
        return {
            'ok': False,
            'reason': 'bootstrap_deadline',
            'technical': True,
            'error': 'Dispositivo reconhecido, mas o servidor do acesso não respondeu dentro do limite de segurança.',
        }
    fast_started = time.time()
    fast = connect_from_kodi_access(
        portal_id,
        allow_group_failover=True,
        endpoint_timeout=min(2.5, remaining),
        xtream_timeout=min(4.0, remaining),
        deadline=deadline,
    )
    log('Restauração por ID: bootstrap Kodi concluído em %.2fs (total=%.2fs).' % (
        max(0.0, time.time() - fast_started), max(0.0, time.monotonic() - recovery_started)), 'debug')
    if fast.get('reason') != 'kodi_access_unavailable':
        if fast.get('ok'):
            physical = str((fast.get('session') or {}).get('physical_dns_id') or portal_id)
            fast['reason'] = 'recovered_device_access' if physical == portal_id else 'recovered_device_access_failover'
            log('Restauração por ID: acesso recuperado pelo endpoint Kodi%s.' % ('' if physical == portal_id else ' via espelho do mesmo grupo'), 'debug')
            return fast

        # Se o acesso veio de um Teste Automático recém-concluído, falha/404
        # logo após a criação pode ser apenas propagação do fornecedor. Consulta
        # somente o ESTADO do registro; nunca solicita outro teste aqui.
        if fast.get('technical') or fast.get('reason') in ('account_error', 'access_not_found', 'access_context_incomplete'):
            try:
                registry = _auto_test_state(client)
            except Exception:
                registry = {}
            registry_status = str((registry or {}).get('status') or '').strip().lower()
            registry_portal = str((registry or {}).get('portal_id') or '').strip()
            try:
                age = float((registry or {}).get('test_age_seconds'))
            except Exception:
                age = 999999.0
            if registry_status == 'success' and (registry or {}).get('recent_success') and registry_portal == portal_id:
                remaining = max(0.0, min(
                    _AUTO_TEST_ACTIVATION_BUDGET_SECONDS,
                    _AUTO_TEST_ACTIVATION_RECOVERY_WINDOW_SECONDS - age,
                    deadline - time.monotonic(),
                ))
                if remaining > 0:
                    log('Restauração por ID: Teste Automático recente detectado; aguardando propagação sem gerar novo teste.', 'debug')
                    activated = _wait_for_auto_test_activation(portal_id, panel_client=client, initial_result=fast, max_wait=remaining)
                    if activated.get('ok'):
                        physical = str((activated.get('session') or {}).get('physical_dns_id') or portal_id)
                        activated['reason'] = 'recovered_device_access' if physical == portal_id else 'recovered_device_access_failover'
                    return activated
        return fast

    # Painel anterior ao V2.19: preserva integralmente o fluxo legado abaixo.
    log('Restauração por ID: kodi_access.php ausente; usando auth.php legado como fallback de compatibilidade.', 'warning')
    try:
        direct_started = time.time()
        remaining = max(0.0, deadline - time.monotonic())
        if remaining < 0.50:
            return {'ok': False, 'reason': 'bootstrap_deadline', 'technical': True,
                    'error': 'Dispositivo reconhecido, mas o servidor do acesso não respondeu dentro do limite de segurança.'}
        result = connect_from_panel(
            portal_id=portal_id,
            allow_auto_test=False,
            allow_panel_failover=False,
            single_attempt=True,
            panel_timeout=min(2.5, remaining),
            xtream_timeout=min(4.0, remaining),
            deadline=deadline,
        )
        log('Restauração por ID: tentativa direta legada concluída em %.2fs.' % max(0.0, time.time() - direct_started), 'debug')
    except Exception as exc:
        # Falha de comunicação com o próprio painel não é evidência de falha
        # da DNS Xtream. Não aciona failover às cegas.
        return {'ok': False, 'reason': 'connect_error', 'error': str(exc)}

    if result.get('ok'):
        result['reason'] = 'recovered_device_access'
        log('Restauração por ID: DNS vinculada respondeu; acesso recuperado sem failover.', 'debug')
        return result

    # Credencial recusada, bloqueio ou ausência do portal não justificam testar
    # espelhos. O failover só entra quando a DNS vinculada falhou tecnicamente.
    if not result.get('technical'):
        log('Restauração por ID: resposta não técnica; failover não acionado (%s).' % str(result.get('reason') or 'erro'), 'debug')
        return result

    failed_url = str(result.get('failed_url') or '')
    failed_reason = str(result.get('reason') or 'client_response')
    log('Restauração por ID: DNS vinculada falhou tecnicamente (%s); acionando failover do mesmo grupo.' % failed_reason, 'warning')
    try:
        failover_started = time.time()
        remaining = max(0.0, deadline - time.monotonic())
        if remaining < 0.50:
            return {'ok': False, 'reason': 'bootstrap_deadline', 'technical': True,
                    'error': 'Dispositivo reconhecido, mas o failover não respondeu dentro do limite de segurança.'}
        fallback = connect_from_panel(
            portal_id=portal_id,
            failed_url=failed_url,
            failed_reason=failed_reason,
            allow_auto_test=False,
            allow_panel_failover=True,
            panel_timeout=min(2.5, remaining),
            xtream_timeout=min(4.0, remaining),
            deadline=deadline,
        )
        log('Restauração por ID: failover do grupo concluído em %.2fs.' % max(0.0, time.time() - failover_started), 'debug')
    except Exception as exc:
        return {'ok': False, 'reason': 'connect_error', 'error': str(exc)}
    if fallback.get('ok'):
        fallback['reason'] = 'recovered_device_access_failover'
        log('Restauração por ID: acesso recuperado pelo failover do grupo.', 'debug')
    return fallback



def validate_session_identity_for_open(endpoint_timeout=2.5, xtream_timeout=4, total_budget=10.0):
    """Confirma a identidade da sessão local contra o acesso atual do painel.

    Esta checagem é propositalmente independente do cooldown visual do painel:
    o cooldown pode evitar theme/banner/index.php repetidos, mas nunca deve
    autorizar uma credencial local que já foi substituída administrativamente.

    A sessão local guarda apenas um ``access_revision`` opaco (HMAC do painel).
    Se a revisão continua igual, as credenciais recebidas nesta consulta ficam
    somente em RAM e não há segunda autenticação Xtream. Se mudou (ou não existe
    em uma sessão antiga), o acesso é reconstruído/provado antes da Home.
    Como usuário/senha não ficam em disco, indisponibilidade do painel preserva
    o vínculo local apenas para nova tentativa, mas não abre uma sessão offline.
    Bloqueio/remoção/mudança continuam decisões autoritativas do painel.
    """
    session = load_session()
    if not session:
        return {'ok': False, 'reason': 'no_session'}

    identity_deadline = time.monotonic() + max(3.0, float(total_budget or 10.0))
    session_id = str(session.get('session_id') or '')
    portal_id = str(session.get('portal_id') or '').strip()
    if not portal_id:
        # Sessão muito antiga/incompleta: não há credencial local para usar como
        # fallback. Remova só esse snapshot e deixe o Device ID reconstruir o
        # vínculo autoritativo pelo index.php/kodi_access.php.
        clear_session()
        recovered = recover_registered_access() or {}
        if recovered.get('ok'):
            recovered['reason'] = 'legacy_session_recovered_by_device_id'
        return recovered

    client = PanelClient()
    started = time.time()
    try:
        panel = client.kodi_access(portal_id, timeout=endpoint_timeout) or {}
    except Exception as exc:
        # Sem credenciais persistidas, não existe uma sessão offline que possa
        # substituir a autoridade do Device ID/painel. Preserve o vínculo local
        # para a próxima tentativa, mas não abra Home nem peça usuário/senha.
        log('Identidade do acesso: painel indisponível; acesso aguardará nova consulta por Device ID: %s' % exc, 'warning')
        latest = load_session()
        if not latest or str(latest.get('session_id') or '') != session_id:
            return {'ok': False, 'reason': 'session_changed'}
        return {
            'ok': False, 'session': latest, 'reason': 'panel_unavailable', 'stale': True,
            'error': 'Não foi possível consultar o painel agora. Tente abrir o ONEPLAY novamente.',
        }

    log('Identidade do acesso: contexto atual lido do painel em %.2fs.' % max(0.0, time.time() - started), 'debug')

    denied = str(panel.get('access_denied') or '').strip()
    reason = str(panel.get('reason') or '')
    if panel.get('device_blocked') or denied or reason == 'access_denied':
        clear_session()
        return {
            'ok': False,
            'reason': 'access_denied',
            'blocked': True,
            'error': denied or 'Acesso bloqueado. Uso não autorizado.',
            'panel': panel,
        }

    if not panel.get('ok'):
        # O endpoint respondeu: esta é uma decisão autoritativa, não uma falha
        # de rede. A sessão local antiga não pode continuar como acesso válido.
        clear_session()
        if reason == 'access_not_found':
            recovered = recover_registered_access() or {}
            if recovered.get('ok'):
                recovered['identity_changed'] = True
                recovered['reason'] = 'access_relinked'
                log('Identidade do acesso: vínculo anterior mudou; novo acesso do painel revalidado.', 'info')
            return recovered
        return {
            'ok': False,
            'reason': reason or 'access_context_error',
            'error': 'O acesso atual do painel não pôde ser validado (%s).' % (reason or 'contexto inválido'),
            'panel': panel,
            'identity_changed': True,
        }

    access = panel.get('access') if isinstance(panel.get('access'), dict) else {}
    panel_portal = str(access.get('portal_id') or portal_id).strip()
    panel_username = str(access.get('username') or '')
    panel_password = str(access.get('password') or '')
    panel_revision = str(access.get('access_revision') or '')
    if not panel_username or not panel_password or (panel_portal and panel_portal != portal_id):
        clear_session()
        _forget_runtime_access(portal_id)
        return {
            'ok': False,
            'reason': 'access_context_incomplete',
            'error': 'O painel retornou um acesso diferente ou incompleto; revalidação necessária.',
            'panel': panel,
            'identity_changed': True,
        }

    # O painel já entregou as credenciais nesta abertura: ficam apenas em RAM.
    _remember_runtime_access(
        portal_id,
        access.get('base_url') or session.get('base_url') or session.get('server_url'),
        panel_username, panel_password,
        access.get('output') or panel.get('output') or effective_live_output(),
        panel_revision,
        _allowed_bases_from_access(access, access.get('base_url')),
    )
    local_revision = str(session.get('access_revision') or '')
    same_identity = bool(panel_revision and local_revision and panel_revision == local_revision)
    latest = load_session()
    if not latest or str(latest.get('session_id') or '') != session_id:
        return {'ok': False, 'reason': 'session_changed'}

    # O painel V2.22 já devolve na própria abertura o snapshot visual atual
    # (theme, idioma, hora, aviso de vencimento, lock etc.). Aplicar este cache
    # imediatamente evita esperar o sync completo/index.php quando a sessão
    # continua válida.
    panel_cache = load_panel()
    panel_cache.update(panel_subset(panel))
    save_panel(panel_cache)

    panel_base_url = str(access.get('base_url') or '').strip().rstrip('/')
    local_base_url = str(latest.get('base_url') or latest.get('server_url') or '').strip().rstrip('/')
    transport_changed = bool(panel_base_url) and local_base_url != panel_base_url

    if same_identity and transport_changed:
        # O painel confirmou que o mesmo acesso agora aponta para outra DNS/URL.
        # A sessão antiga deixa de ser autoridade; provar a nova URL na abertura
        # evita manter a sessão agarrada ao transporte anterior.
        clear_session()
        log('Identidade do acesso: credencial confere, mas a DNS/URL autoritativa mudou; revalidando o acesso atual.', 'info')
        result = connect_from_kodi_access(
            portal_id=portal_id,
            allow_group_failover=True,
            endpoint_timeout=endpoint_timeout,
            xtream_timeout=xtream_timeout,
            prefetched_panel=panel,
            deadline=identity_deadline,
        ) or {}
        result['identity_changed'] = True
        if result.get('ok'):
            result['reason'] = 'transport_revalidated'
            log('Identidade do acesso: DNS/URL atual do painel validada e sessão substituída.', 'info')
        return result

    if same_identity:
        latest['access_revision'] = panel_revision
        latest['theme'] = str(panel.get('theme') or latest.get('theme') or '1')
        latest['pin'] = str(panel.get('pin') or latest.get('pin') or '0000')
        summaries = _access_summaries(panel or {})
        if summaries:
            latest['portal_count'] = len(summaries)
        latest['panel_connected_at'] = int(time.time())
        save_session(latest)
        log('Identidade do acesso: sessão local confere com o acesso atual do painel (DNS id=%s); snapshot aplicado sem aguardar o sync completo.' % portal_id, 'debug')
        return {'ok': True, 'session': load_session(), 'panel': panel, 'reason': 'identity_match'}

    # Mudança confirmada pelo painel: a credencial anterior deixa de ser
    # autoridade imediatamente. Nunca volte a ela se a nova revalidação falhar.
    clear_session()
    log('Identidade do acesso: revisão autoritativa mudou no painel; revalidando o acesso atual.', 'info')
    result = connect_from_kodi_access(
        portal_id=portal_id,
        allow_group_failover=True,
        endpoint_timeout=endpoint_timeout,
        xtream_timeout=xtream_timeout,
        prefetched_panel=panel,
        deadline=identity_deadline,
    ) or {}
    result['identity_changed'] = True
    if result.get('ok'):
        result['reason'] = 'identity_revalidated'
        log('Identidade do acesso: nova credencial do painel validada e sessão substituída.', 'info')
    return result


def sync_panel_for_open():
    """Sincronização rápida e não destrutiva pelo index.php V2.0.4.

    O endpoint leve confirma bloqueio/remoção, trava de gerenciamento e tema
    sem executar failover/probes do auth.php. Acesso, troca e Teste Automático
    usam endpoints dedicados; auth.php permanece só para compatibilidade legada.
    """
    session = load_session()
    if not session:
        return {'ok': False, 'reason': 'no_session'}
    session_id = session.get('session_id')
    client = PanelClient()
    try:
        state = client.index_state(timeout=3)
        denied = str(state.get('access_denied') or '').strip()
        if state.get('device_blocked') or denied:
            clear_session()
            return {'ok': False, 'reason': 'denied', 'error': denied or 'Acesso bloqueado. Uso não autorizado.'}
        if int(state.get('accounts') or 0) <= 0:
            clear_session()
            return {'ok': False, 'reason': 'removed'}
        accesses = client.accesses_from_state(state)
        current_id = str(session.get('portal_id') or '')
        if accesses and current_id and not any(str(row.get('id') or '') == current_id for row in accesses):
            clear_session()
            return {'ok': False, 'reason': 'removed'}

        # Nunca ressuscitar uma sessão que o Heartbeat removeu enquanto esta
        # leitura estava em voo.
        latest = load_session()
        if not latest or latest.get('session_id') != session_id:
            return {'ok': False, 'reason': 'session_changed'}

        latest['theme'] = str(state.get('theme') or latest.get('theme') or '1')
        if accesses:
            latest['portal_count'] = len(accesses)
        save_session(latest)

        cache = load_panel()
        cache.update(panel_subset(state))
        save_panel(cache)
        return {'ok': True, 'session': load_session(), 'panel': state}
    except Exception as exc:
        # Também na exceção, jamais devolver a sessão antiga se ela já foi
        # invalidada por Health/remoção administrativa.
        latest = load_session()
        if not latest or latest.get('session_id') != session_id:
            return {'ok': False, 'reason': 'session_changed'}
        log('Sincronização visual do painel falhou; usando cache local: %s' % exc, 'warning')
        return {'ok': True, 'session': latest, 'panel': None, 'stale': True}

def switch_portal(portal_id):
    set_selected_portal(portal_id)
    fast = connect_from_kodi_access(portal_id, allow_group_failover=True)
    if fast.get('reason') != 'kodi_access_unavailable':
        return fast
    log('Troca de acesso: kodi_access.php ausente; usando auth.php legado como fallback de compatibilidade.', 'warning')
    return connect_from_panel(portal_id=portal_id)


def failover_for_media(failed_url, transport=False, timeout=2.5, excluded_urls=None):
    """Resolve somente a próxima DNS física do acesso atual.

    V2.0.53 não chama auth.php neste caminho. O endpoint media_failover.php
    consulta apenas o vínculo do dispositivo e o grupo DNS, retornando a URL
    candidata sem player_api, Health, migração ou lock de sessão.
    """
    session = load_session()
    if not session:
        return {'ok': False, 'error': 'Sessão ausente.', 'reason': 'session_missing'}
    portal_id = str(session.get('portal_id') or '')
    if not portal_id:
        return {'ok': False, 'error': 'Acesso atual sem identificador de portal para failover.', 'reason': 'portal_id_missing'}
    client = PanelClient()
    started = time.time()
    try:
        data = client.media_failover_candidate(
            portal_id,
            failed_url=str(failed_url or ''),
            excluded_urls=excluded_urls or [],
            timeout=max(1.0, min(float(timeout or 2.5), 3.0)),
        )
    except Exception as exc:
        return {
            'ok': False,
            'error': 'Painel indisponível durante o failover rápido: %s' % exc,
            'reason': 'panel_error',
            'technical': True,
        }
    elapsed = max(0.0, time.time() - started)
    server_ms = int(data.get('elapsed_ms') or 0) if isinstance(data, dict) else 0
    log('media_failover.php concluído em %.2fs (servidor=%dms).' % (elapsed, server_ms), 'debug')
    denied = str(data.get('access_denied') or '').strip()
    if denied:
        clear_session()
        return {'ok': False, 'error': denied, 'denied': True, 'reason': 'access_denied'}
    candidate = data.get('candidate') if isinstance(data.get('candidate'), dict) else {}
    base_url = str(candidate.get('base_url') or '').strip().rstrip('/')
    if not data.get('ok') or not base_url:
        return {
            'ok': False,
            'error': 'Nenhuma DNS alternativa disponível para este acesso.',
            'reason': str(data.get('reason') or 'no_alternative'),
            'technical': True,
        }
    candidate_portal = str(candidate.get('portal_id') or portal_id)
    candidate_session = dict(session)
    candidate_session.update({
        'base_url': base_url,
        'server_url': base_url,
        'portal_id': candidate_portal,
        'portal_name': str(candidate.get('portal_name') or session.get('portal_name') or ''),
        'panel_connected_at': int(time.time()),
    })
    # media_failover.php acabou de autorizar esta DNS para o mesmo grupo. Atualize
    # apenas o cache em memória para que session_client() aceite a candidata sem
    # reconsultar o painel e sem transformar a URL persistida em autoridade.
    runtime = _RUNTIME_ACCESS.get(candidate_portal)
    if runtime:
        allowed = _normalized_bases(list(runtime.get('allowed_bases') or []) + [base_url])
        runtime['allowed_bases'] = allowed
        runtime['base_url'] = base_url
        runtime['at'] = time.time()
    return {'ok': True, 'session': candidate_session, 'media_fast': True, 'reason': str(data.get('reason') or 'candidate')}
