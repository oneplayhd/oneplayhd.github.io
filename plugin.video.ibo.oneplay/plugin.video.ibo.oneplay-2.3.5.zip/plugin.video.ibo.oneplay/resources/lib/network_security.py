"""Small transport boundaries; no panel/API payload changes."""
import http.client
import ipaddress
import socket
import urllib.error
import urllib.parse
import urllib.request


def http_url(value, https_only=False):
    raw = str(value or '')
    if any(ord(char) < 32 or ord(char) == 127 for char in raw) or '\\' in raw:
        raise ValueError('URL com caracteres inválidos.')
    parsed = urllib.parse.urlsplit(raw)
    if (parsed.scheme not in (('https',) if https_only else ('http', 'https'))
            or not parsed.hostname or parsed.username is not None or parsed.password is not None
            or (parsed.port is not None and not 1 <= parsed.port <= 65535)):
        raise ValueError('URL HTTP(S) inválida ou insegura.')
    return raw


class HTTPOnlyRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        http_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class HTTPSOnlyRedirect(HTTPOnlyRedirect):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        http_url(newurl, https_only=True)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def https_open(request, timeout=30):
    http_url(request.full_url, https_only=True)
    return urllib.request.build_opener(HTTPSOnlyRedirect()).open(request, timeout=timeout)


_LAN_NETWORKS = tuple(ipaddress.ip_network(value) for value in (
    '10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', '100.64.0.0/10',
))


def lan_ipv4(value):
    try:
        address = ipaddress.ip_address(str(value))
        return address.version == 4 and any(address in network for network in _LAN_NETWORKS)
    except ValueError:
        return False


def _lan_connection(address, timeout=socket._GLOBAL_DEFAULT_TIMEOUT, source_address=None):
    # Resolve at connect time, then connect to that numeric address directly.
    # No second hostname resolution can replace the validated destination.
    host, port = address
    failure = None
    for family, kind, proto, _canonical, endpoint in socket.getaddrinfo(
            host, port, socket.AF_INET, socket.SOCK_STREAM):
        if not lan_ipv4(endpoint[0]):
            continue
        sock = socket.socket(family, kind, proto)
        try:
            if timeout is not socket._GLOBAL_DEFAULT_TIMEOUT:
                sock.settimeout(timeout)
            if source_address:
                sock.bind(source_address)
            sock.connect(endpoint)
            return sock
        except OSError as exc:
            failure = exc
            sock.close()
    raise OSError('Dispositivo LAN indisponível ou endereço não permitido.') from failure


class _LANHTTPConnection(http.client.HTTPConnection):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._create_connection = _lan_connection


class _LANHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._create_connection = _lan_connection


class _LANHTTPHandler(urllib.request.HTTPHandler):
    def http_open(self, req):
        return self.do_open(_LANHTTPConnection, req)


class _LANHTTPSHandler(urllib.request.HTTPSHandler):
    def https_open(self, req):
        return self.do_open(_LANHTTPSConnection, req, context=self._context)


class _LANRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Descriptions may redirect locally. POST commands carry media handles:
        # never replay them to another destination, even inside the LAN.
        http_url(newurl, https_only=req.type == 'https')
        if req.get_method() not in ('GET', 'HEAD'):
            raise urllib.error.HTTPError(req.full_url, code, 'Redirecionamento de comando bloqueado.', headers, fp)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def lan_open(request, timeout=3):
    http_url(request.full_url)
    # A system proxy would move the connection outside the LAN boundary.
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({}), _LANHTTPHandler(), _LANHTTPSHandler(), _LANRedirect())
    return opener.open(request, timeout=timeout)
