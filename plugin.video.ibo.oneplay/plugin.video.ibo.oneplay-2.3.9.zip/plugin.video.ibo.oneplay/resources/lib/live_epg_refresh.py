# -*- coding: utf-8 -*-
"""Bounded, session-scoped Live EPG OSD refresh (V8 candidate).

Runs in the existing Kodi service, independently of fullscreen/background GUI.
It never starts, stops or changes media.  Failure is always nonfatal.
"""
import time


from .state import load_activity, playback_fingerprint
from .log import log
from .player import _format_live_epg, _epg_stamp

try:
    import xbmc
except Exception:
    xbmc = None


def _usable_rows(rows, now):
    """Exclude concluded programs so expired EPG is never presented as Agora.

    Reuse the original OnePlay formatter for valid programs; only constrain
    its input. Bad/undated data do not overwrite the displayed item.
    """
    good = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        start = _epg_stamp(row.get('start_timestamp') or row.get('start') or row.get('start_time'))
        end = _epg_stamp(row.get('stop_timestamp') or row.get('end_timestamp') or row.get('end') or row.get('stop'))
        if not (start and end and end > now and start < end):
            continue
        good.append((start, row))
    good.sort(key=lambda item: item[0])
    return [row for _, row in good]


def _publish_plot(player, plot, expected_hash, expected_stream):
    """Submit GUI_MSG_UPDATE_ITEM, not a mutation of a detached InfoTag copy.

    Kodi's getVideoInfoTag() returns a copy. getPlayingItem() retains the
    current ListItem identity, artwork and other metadata when only Plot is
    changed. Caller must recheck session before invoking this function.
    """
    activity = load_activity() or {}
    meta = activity.get('playback_meta') or {}
    if not (str(activity.get('playback_hash') or '') == str(expected_hash)
            and isinstance(meta, dict)
            and str(meta.get('stream_id') or '') == str(expected_stream)
            and _matching_live(player, activity)):
        return False
    item = player.getPlayingItem()
    tag = item.getVideoInfoTag()
    tag.setPlot(plot)
    # Crucial: getVideoInfoTag() by itself does not publish the changed tag.
    # This API notifies the Kodi GUI about the current playing ListItem.
    player.updateInfoTag(item)
    return True


def _next_boundary(rows, now):
    boundaries = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        for key in ('start_timestamp', 'start', 'start_time', 'stop_timestamp', 'end_timestamp', 'end', 'stop'):
            value = _epg_stamp(row.get(key))
            if value > now:
                boundaries.append(value)
    return min(boundaries) if boundaries else 0


def _matching_live(player, activity):
    if str(activity.get('playback_kind') or '') != 'live':
        return False
    expected = str(activity.get('playback_hash') or '')
    if not expected:
        return False
    try:
        return bool(player.isPlayingVideo() and playback_fingerprint(player.getPlayingFile()) == expected)
    except Exception:
        return False


def run_live_epg_refresh(monitor=None):
    if xbmc is None:
        return
    monitor = monitor or xbmc.Monitor()
    player = xbmc.Player()
    identity = None
    rows = []
    next_query_at = 0.0
    boundary = 0
    last_plot = None
    last_fail_log = 0.0
    while not monitor.abortRequested():
        try:
            activity = load_activity() or {}
            metadata = activity.get('playback_meta') or {}
            stream_id = str(metadata.get('stream_id') or '') if isinstance(metadata, dict) else ''
            valid = bool(stream_id and _matching_live(player, activity))
            new_identity = (activity.get('playback_hash'), stream_id, metadata.get('portal_id') if isinstance(metadata, dict) else '') if valid else None
            if new_identity != identity:
                identity = new_identity
                rows = []
                boundary = 0
                last_plot = None
                next_query_at = 0.0
            if valid:
                now = time.time()
                if now >= next_query_at:
                    # Exact short EPG API already owns a 60s cache/TTL. Never
                    # bypass it or fetch faster than its intended cadence.
                    next_query_at = now + 65.0
                    try:
                        from .auth import session_client
                        fetched = session_client().short_epg(stream_id, limit=8)
                        if isinstance(fetched, list):
                            rows = fetched
                            boundary = _next_boundary(rows, int(now))
                    except Exception as exc:
                        # Do not retry a failing server on every polling tick.
                        if now - last_fail_log >= 180:
                            log('EPG Live: atualização indisponível (%s); player preservado.' % exc.__class__.__name__, 'debug')
                            last_fail_log = now
                if rows:
                    usable = _usable_rows(rows, int(now))
                    plot, _, _ = _format_live_epg(usable) if usable else ('', '', '')
                    if plot and plot != last_plot:
                        # Recheck identity immediately before changing InfoTag:
                        # channel switching and stop must never inherit old EPG.
                        current = load_activity() or {}
                        if (str(current.get('playback_hash') or '') == str(identity[0])
                                and _matching_live(player, current)):
                            try:
                                if _publish_plot(player, plot, identity[0], stream_id):
                                    last_plot = plot
                                    log('EPG Live: updateInfoTag enviado ao item em reprodução (verificar Informações no Kodi).', 'debug')
                            except Exception as exc:
                                if now - last_fail_log >= 180:
                                    log('EPG Live: Kodi não aceitou atualização do InfoTag (%s).' % exc.__class__.__name__, 'debug')
                                    last_fail_log = now
                    # At a schedule boundary refresh with the cached rows on
                    # the next polling tick; network TTL remains 65 seconds.
                    if boundary and now >= boundary:
                        boundary = _next_boundary(rows, int(now))
        except Exception as exc:
            log('EPG Live: acompanhamento isolado falhou (%s).' % exc.__class__.__name__, 'debug')
        if monitor.waitForAbort(5.0):
            break
