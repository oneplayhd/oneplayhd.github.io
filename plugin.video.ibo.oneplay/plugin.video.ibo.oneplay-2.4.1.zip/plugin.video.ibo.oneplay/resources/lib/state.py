# -*- coding: utf-8 -*-
import hashlib
import time
import uuid

from .constants import STATE_SCHEMA
from .storage import delete, delete_json_atomic, json_schema, read_json, state_path, update_json_atomic

SESSION = state_path('session_v2.json')
PANEL = state_path('panel_v2.json')
ACTIVITY = state_path('activity_v2.json')
PREFS = state_path('preferences_v2.json')


def load_session():
    data = read_json(SESSION, {})
    if not isinstance(data, dict) or json_schema(data) != STATE_SCHEMA:
        return {}
    # Upgrade in-place: the first read after installing this build removes any
    # plaintext credentials left by an older homologated session immediately.
    if 'username' in data or 'password' in data:
        try:
            def sanitize(current):
                value = dict(current or {})
                value.pop('username', None)
                value.pop('password', None)
                return value
            data = update_json_atomic(SESSION, sanitize, {})
        except Exception:
            # Nunca devolva uma sessão funcional deixando a cópia antiga com
            # credenciais em disco. O Device ID consegue reconstruir o vínculo
            # pelo painel, então falhar fechado aqui é seguro e recuperável.
            delete(SESSION)
            return {}
    return data


def save_session(data, expected_session=None):
    incoming = dict(data or {})
    # Segurança 2.3.0 — o Device ID/painel são a autoridade do acesso. Credenciais
    # Xtream podem existir no processo Python enquanto necessárias, mas nunca são
    # persistidas em session_v2.json. Isto também migra silenciosamente sessões
    # antigas assim que forem regravadas.
    incoming.pop('username', None)
    incoming.pop('password', None)

    def merge(current):
        current = dict(current or {})
        if expected_session is not None and current.get('session_id') != expected_session:
            return current
        incoming_id = str(incoming.get('session_id') or '')
        current_id = str(current.get('session_id') or '')
        # A new authenticated session replaces the old one. Updates belonging
        # to the same session merge under one lock so Health/player/UI do not
        # discard unrelated fields written by another Kodi interpreter.
        value = {} if incoming_id and current_id and incoming_id != current_id else current
        value.update(incoming)
        value.pop('username', None)
        value.pop('password', None)
        value['schema'] = STATE_SCHEMA
        value.setdefault('session_id', uuid.uuid4().hex)
        value['updated_at'] = int(time.time())
        return value

    return update_json_atomic(SESSION, merge, {})


def clear_session():
    delete_json_atomic(SESSION)
    clear_playback()


def load_panel():
    data = read_json(PANEL, {})
    if not isinstance(data, dict) or json_schema(data) != STATE_SCHEMA:
        return {}
    return data


_VISUAL_KEYS = ('theme', 'home_url1', 'home_url2')
_ART_KEYS = ('_home_showcase_mode', '_home_showcase_slides', '_home_showcase_at', '_banner_url')


def visual_signature(panel):
    return tuple(str((panel or {}).get(k) or '') for k in _VISUAL_KEYS)


def save_panel(data, expected_visual=None, expected_session=None, expected_generation=None, expected_usage=None, art_started=None):
    incoming = dict(data or {})
    stamp = incoming.pop('_visual_request_ns', None)
    def merge(current):
        value = dict(current or {})
        if expected_session is not None:
            session = read_json(SESSION, {}) or {}
            if not session or session.get('session_id') != expected_session:
                return value
        if expected_usage is not None:
            activity = read_json(ACTIVITY, {}) or {}
            if activity.get('usage_session_id') != expected_usage or not activity.get('usage_active'):
                return value
        if expected_generation is not None and str(value.get('_visual_generation') or '') != expected_generation:
            return value
        if expected_visual is not None and visual_signature(value) != expected_visual:
            return value
        if art_started is not None:
            last_art = int(value.get('_visual_art_request_ns') or 0)
            if last_art <= time.monotonic_ns() and last_art > art_started:
                return value
            value['_visual_art_request_ns'] = art_started
        patch = dict(incoming)
        if 'theme' in patch:
            theme = str(patch['theme'] or '')
            if theme not in ('1', '2', '3', '4', '5'):
                for key in _VISUAL_KEYS:
                    patch.pop(key, None)
            else:
                patch['theme'] = theme
        if any(k in patch for k in _VISUAL_KEYS):
            now = time.monotonic_ns()
            previous = int(value.get('_visual_request_ns') or 0)
            if previous > now:
                previous = 0  # reboot / monotonic clock reset
            if stamp is not None and int(stamp) < previous:
                for key in _VISUAL_KEYS:
                    patch.pop(key, None)
            else:
                before = visual_signature(value)
                after = visual_signature(dict(value, **patch))
                if before != after:
                    value['_visual_generation'] = uuid.uuid4().hex
                    value.pop('_visual_art_request_ns', None)
                    for key in _ART_KEYS:
                        value[key] = [] if key == '_home_showcase_slides' else (0 if key == '_home_showcase_at' else '')
                if stamp is not None:
                    value['_visual_request_ns'] = int(stamp)
        value.update(patch)
        value['schema'] = STATE_SCHEMA
        value['updated_at'] = int(time.time())
        return value
    return update_json_atomic(PANEL, merge, {})


def load_prefs():
    data = read_json(PREFS, {})
    return data if isinstance(data, dict) else {}


def save_prefs(data):
    incoming = dict(data or {})
    def merge(current):
        value = dict(current or {})
        value.update(incoming)
        return value
    return update_json_atomic(PREFS, merge, {})


def _clear_playback_fields(data):
    for key in ('playback_url', 'playback_hash', 'playback_kind', 'playback_title', 'playback_at', 'playback_meta', 'playback_relay_session_id', 'playback_resume_at'):
        data.pop(key, None)
    return data


def mark_ui(active, route=''):
    """Mark the IBO usage session as active/inactive.

    ``session_v2.json`` is the stored authenticated access and must survive a
    normal SAIR.  ``activity_v2.json`` is the runtime usage session.  Keeping
    those concepts separate lets SAIR stop Heartbeat immediately without
    forcing the customer to type credentials again on the next launch.
    """
    now = int(time.time())
    active = bool(active)
    def mutate(current):
        data = dict(current or {})
        data['ui_active'] = active
        data['usage_active'] = active
        data['route'] = str(route or '')
        data['at'] = now
        if active:
            if not str(data.get('usage_session_id') or '') or data.get('usage_ended_at'):
                data['usage_session_id'] = uuid.uuid4().hex
                data['usage_started_at'] = now
            data.pop('usage_ended_at', None)
        else:
            data['usage_ended_at'] = now
            _clear_playback_fields(data)
        return data
    return update_json_atomic(ACTIVITY, mutate, {})


def request_exit_return():
    """Atomically end IBO usage and request restoration of Kodi history.

    The persistent service consumes this token only after the plugin's modal
    windows / DialogBusy are gone.  No target window is hard-coded: the service
    asks Kodi to go Back only while the underlying container is still this
    add-on's plugin:// root.
    """
    now = time.time()
    token = uuid.uuid4().hex
    def mutate(current):
        data = dict(current or {})
        data['ui_active'] = False
        data['usage_active'] = False
        data['route'] = 'exit'
        data['at'] = int(now)
        data['usage_ended_at'] = int(now)
        _clear_playback_fields(data)
        data['exit_return_token'] = token
        data['exit_return_requested_at'] = now
        return data
    update_json_atomic(ACTIVITY, mutate, {})
    return token


def clear_exit_return(token=''):
    changed = [False]
    def mutate(current):
        data = dict(current or {})
        active_token = str(data.get('exit_return_token') or '')
        if token and active_token and active_token != str(token):
            return data
        for key in ('exit_return_token', 'exit_return_requested_at'):
            if key in data:
                data.pop(key, None)
                changed[0] = True
        return data
    update_json_atomic(ACTIVITY, mutate, {})
    return changed[0]


def request_panel_sync():
    token = uuid.uuid4().hex
    def mutate(current):
        data = dict(current or {})
        data['panel_sync_token'] = token
        data['panel_sync_requested_at'] = int(time.time())
        return data
    update_json_atomic(ACTIVITY, mutate, {})
    return token

def playback_fingerprint(url):
    raw = str(url or '').split('|', 1)[0]
    return hashlib.sha256(raw.encode('utf-8', 'ignore')).hexdigest() if raw else ''


def mark_playback(url='', kind='', title='', meta=None, relay_session_id='', resume_at=0.0):
    relay_id = str(relay_session_id or '').strip()
    try:
        resume_value = max(0.0, float(resume_at or 0.0))
    except Exception:
        resume_value = 0.0
    safe_meta = None
    if isinstance(meta, dict):
        # Defesa em profundidade: activity_v2 nunca recebe URL de stream,
        # usuário, senha ou qualquer campo arbitrário vindo de callers futuros.
        allowed = (
            'kind', 'stream_id', 'title', 'extension', 'art', 'plot', 'year',
            'season', 'episode', 'series_id', 'series_title', 'series_art', 'portal_id',
        )
        safe_meta = {key: meta.get(key) for key in allowed if meta.get(key) is not None}

    def mutate(current):
        data = dict(current or {})
        data.update({'playback_hash': playback_fingerprint(url), 'playback_kind': str(kind or ''), 'playback_title': str(title or ''), 'playback_at': int(time.time())})
        if relay_id:
            data['playback_relay_session_id'] = relay_id
        else:
            data.pop('playback_relay_session_id', None)
        if str(kind or '') in ('movie', 'series') and resume_value >= 30.0:
            data['playback_resume_at'] = round(resume_value, 3)
        else:
            data.pop('playback_resume_at', None)
        if safe_meta is not None:
            data['playback_meta'] = safe_meta
        else:
            data.pop('playback_meta', None)
        data.pop('playback_url', None)
        return data
    return update_json_atomic(ACTIVITY, mutate, {})


def clear_playback():
    return update_json_atomic(ACTIVITY, lambda current: _clear_playback_fields(dict(current or {})), {})


def load_activity():
    data = read_json(ACTIVITY, {})
    return data if isinstance(data, dict) else {}
