from __future__ import unicode_literals, absolute_import, division

import os
import queue
import sys
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# Make resources/lib importable so `superstream` package resolves.
_ADDON_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
_LIB_PATH = os.path.join(_ADDON_PATH, 'resources', 'lib')
if _LIB_PATH not in sys.path:
    sys.path.insert(0, _LIB_PATH)

from superstream import config, tmdb, utils
from superstream.resolver import get_streams, CancelledError, Progress, warm_all_catalogs_background

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else 0


class _QueueProgress(Progress):
    """Thread-safe progress bridge.

    The resolver runs on a worker thread; it enqueues progress updates and
    polls a shared cancel flag. The *main* (GUI) thread drains the queue and
    drives ``xbmcgui.DialogProgress`` itself, which is the only thread-safe way
    to touch Kodi's GUI. This mirrors the Stremio addon's cancellation/budget
    behaviour while keeping the UI responsive.
    """

    def __init__(self):
        self._queue = queue.Queue()
        self._cancelled = False
        self._lock = threading.Lock()

    def update(self, percent, message=''):
        try:
            self._queue.put_nowait((percent, message))
        except queue.Full:
            pass

    def is_canceled(self):
        with self._lock:
            return self._cancelled

    def set_cancelled(self):
        with self._lock:
            self._cancelled = True

    def drain(self):
        """Return all queued (percent, message) updates, newest kept."""
        updates = []
        while True:
            try:
                updates.append(self._queue.get_nowait())
            except queue.Empty:
                break
        return updates


def _notify(message, is_error=False, is_warning=False):
    icon = xbmcgui.NOTIFICATION_ERROR if is_error else (
        xbmcgui.NOTIFICATION_WARNING if is_warning else xbmcgui.NOTIFICATION_INFO)
    xbmcgui.Dialog().notification(config.ADDON_NAME, message, icon)


def _open_dialog_progress(title):
    dp = None
    try:
        dp = xbmcgui.DialogProgress()
        dp.create(title)
        dp.update(0, 'Iniciando...')
    except Exception as e:
        if config.DEBUG:
            xbmc.log('[SuperStream] DialogProgress indisponivel: %s' % e, xbmc.LOGWARNING)
        dp = None
    return dp


def _thumb(poster_path):
    if poster_path:
        return '%s/%s%s' % (config.TMDB_IMAGE_BASE, config.TMDB_POSTER_W, poster_path)
    return ''


def _fanart(backdrop_path):
    if backdrop_path:
        return '%s/%s%s' % (config.TMDB_IMAGE_BASE, config.TMDB_BACKDROP_W, backdrop_path)
    return ''


def show_root():
    items = [
        ('Filmes Populares', 'movies_popular'),
        ('Séries Populares', 'tv_popular'),
        ('Pesquisar', 'search'),
    ]
    for label, action in items:
        li = xbmcgui.ListItem(label=label)
        url = 'plugin://%s?action=%s' % (config.ADDON_ID, action)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.setPluginCategory(HANDLE, 'SuperStream')
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    # Prime the disk cache in the background so movie resolution is fast.
    warm_all_catalogs_background()


def _browse_catalog(endpoint_type, page=1):
    if endpoint_type == 'movies_popular':
        data = tmdb.discover_movies(page)
        media_type = 'movie'
        kind = 'movie'
        content = 'movies'
        category = 'Filmes'
    else:
        data = tmdb.discover_tv(page)
        media_type = 'tv'
        kind = 'tv'
        content = 'tvshows'
        category = 'Séries'

    if not data:
        xbmcgui.Dialog().notification(config.ADDON_NAME, 'Erro ao carregar catálogo TMDb', xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return

    results = data.get('results') or []
    xbmcplugin.setContent(HANDLE, content)

    for item in results:
        title = item.get('title') or item.get('name') or ''
        year = ''
        if item.get('release_date'):
            year = item['release_date'][:4]
        elif item.get('first_air_date'):
            year = item['first_air_date'][:4]
        tmdb_id = str(item.get('id', ''))
        poster = _thumb(item.get('poster_path'))
        fanart = _fanart(item.get('backdrop_path'))

        info = {
            'title': title,
            'originaltitle': item.get('original_title') or item.get('original_name') or '',
            'plot': item.get('overview') or '',
            'aired': item.get('release_date') or item.get('first_air_date') or '',
        }
        yr = int(year) if year.isdigit() else None
        if yr:
            info['year'] = yr
        if kind == 'tv':
            info['mediatype'] = 'tvshow'
            info['tvshowtitle'] = title
        else:
            info['mediatype'] = 'movie'

        li = xbmcgui.ListItem(label=title)
        li.setArt({'poster': poster, 'fanart': fanart})
        li.setInfo('video', info)
        is_tv = kind == 'tv'
        li.setProperty('IsPlayable', 'false' if is_tv else 'true')
        if is_tv:
            url = 'plugin://%s?action=seasons&tmdb_id=%s' % (config.ADDON_ID, tmdb_id)
        else:
            url = 'plugin://%s?action=play&tmdb_id=%s&media_type=%s&iconimage=%s' % (
                config.ADDON_ID, tmdb_id, media_type, poster)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    total_pages = data.get('total_pages', 1) or 1
    if int(page) < int(total_pages):
        next_page = int(page) + 1
        label = '[ Próxima página (%d/%d) ]' % (next_page, total_pages)
        li = xbmcgui.ListItem(label=label)
        url = 'plugin://%s?action=%s&page=%d' % (config.ADDON_ID, endpoint_type, next_page)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.setPluginCategory(HANDLE, 'SuperStream - ' + category)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)


def show_seasons(tmdb_id):
    details = tmdb.get_tv_details(tmdb_id)
    if not details:
        xbmcgui.Dialog().notification(config.ADDON_NAME, 'Erro ao carregar série', xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return

    xbmcplugin.setContent(HANDLE, 'tvshows')
    poster = _thumb(details.get('poster_path'))
    fanart = _fanart(details.get('backdrop_path'))
    for s in details.get('seasons', []):
        season_num = s.get('season_number', 0)
        label = s.get('name') or 'Temporada %d' % season_num
        if s.get('episode_count'):
            label = '%s (%d eps)' % (label, s['episode_count'])
        li = xbmcgui.ListItem(label=label)
        li.setArt({'poster': poster, 'fanart': fanart})
        li.setInfo('video', {
            'title': details.get('name', ''),
            'tvshowtitle': details.get('name', ''),
            'mediatype': 'season',
        })
        url = 'plugin://%s?action=episodes&tmdb_id=%s&season=%d' % (config.ADDON_ID, tmdb_id, season_num)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.setPluginCategory(HANDLE, 'SuperStream - Temporadas')
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)


def show_episodes(tmdb_id, season):
    episodes = tmdb.get_season_episodes(tmdb_id, season)
    details = tmdb.get_tv_details(tmdb_id) or {}
    if not episodes:
        xbmcgui.Dialog().notification(config.ADDON_NAME, 'Nenhum episódio', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return

    xbmcplugin.setContent(HANDLE, 'episodes')
    poster = _thumb(details.get('poster_path'))
    fanart = _fanart(details.get('backdrop_path'))
    show_title = details.get('name', '')
    for ep in episodes:
        ep_num = ep.get('episode_number', 0)
        label = 'Episódio %d - %s' % (ep_num, ep.get('name', ''))
        li = xbmcgui.ListItem(label=label)
        li.setArt({'poster': poster, 'fanart': fanart, 'thumb': _thumb(ep.get('still_path'))})
        air = ep.get('air_date') or ''
        li.setInfo('video', {
            'title': ep.get('name', ''),
            'tvshowtitle': show_title,
            'season': season,
            'episode': ep_num,
            'plot': ep.get('overview', ''),
            'aired': air,
            'mediatype': 'episode',
        })
        li.setProperty('IsPlayable', 'true')
        url = 'plugin://%s?action=play&tmdb_id=%s&media_type=tv&season=%d&episode=%d&iconimage=%s' % (
            config.ADDON_ID, tmdb_id, season, ep_num, poster)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.setPluginCategory(HANDLE, 'SuperStream - Episódios')
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)


def do_search():
    keyboard = xbmc.Keyboard()
    keyboard.setHeading('Pesquisar')
    keyboard.doModal()
    if not keyboard.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return
    query = keyboard.getText()
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return

    results = tmdb.search_tmdb(query)
    if not results or not (results.get('movies') or results.get('tv')):
        xbmcgui.Dialog().notification(config.ADDON_NAME, 'Nenhum resultado', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return

    xbmcplugin.setContent(HANDLE, 'movies')
    for item in (results.get('movies') or []):
        label = '%s (%s)' % (item.get('title') or '', (item.get('release_date') or '')[:4])
        li = xbmcgui.ListItem(label=label)
        li.setArt({'poster': _thumb(item.get('poster_path'))})
        li.setInfo('video', {
            'title': item.get('title') or '',
            'plot': item.get('overview') or '',
            'mediatype': 'movie',
        })
        li.setProperty('IsPlayable', 'true')
        url = 'plugin://%s?action=play&tmdb_id=%s&media_type=movie' % (config.ADDON_ID, str(item.get('id', '')))
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    for item in (results.get('tv') or []):
        label = '%s (%s)' % (item.get('name') or '', (item.get('first_air_date') or '')[:4])
        li = xbmcgui.ListItem(label=label)
        li.setArt({'poster': _thumb(item.get('poster_path'))})
        li.setInfo('video', {
            'title': item.get('name') or '',
            'plot': item.get('overview') or '',
            'mediatype': 'tvshow',
            'tvshowtitle': item.get('name') or '',
        })
        li.setProperty('IsPlayable', 'false')
        url = 'plugin://%s?action=seasons&tmdb_id=%s' % (config.ADDON_ID, str(item.get('id', '')))
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.setPluginCategory(HANDLE, 'SuperStream - Pesquisa')
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)


def play_item(tmdb_id, media_type, season=None, episode=None, iconimage=''):
    """Resolve streams with a cancellable progress dialog + route budget.

    The slow resolution runs on a daemon worker thread so the GUI thread stays
    free to drive ``DialogProgress``. Mirrors the Stremio addon: catalogs are
    warmed in parallel with the TMDB lookup, all 4 servers are searched in
    parallel, and a hard route budget caps the time a user waits.
    """
    if not tmdb_id:
        _notify('ID inválido', is_error=True)
        return

    progress = _QueueProgress()
    result = {'streams': [], 'done': False, 'cancelled': False, 'error': None}
    done_event = threading.Event()

    def worker():
        try:
            result['streams'] = get_streams(tmdb_id, media_type, season, episode, progress=progress)
        except CancelledError:
            result['cancelled'] = True
        except Exception as e:
            if config.DEBUG:
                xbmc.log('[SuperStream] Erro na resolucao: %s' % e, xbmc.LOGERROR)
            result['error'] = str(e)
        finally:
            result['done'] = True
            done_event.set()

    t = threading.Thread(target=worker, name='superstream-resolver')
    t.daemon = True
    t.start()

    dp = _open_dialog_progress(config.ADDON_NAME)

    budget_deadline = time.time() + config.ROUTE_BUDGET_MS / 1000.0
    timed_out = False

    try:
        while not done_event.is_set():
            # Drive the dialog from the GUI (main) thread only.
            for percent, message in progress.drain():
                if dp is not None:
                    try:
                        dp.update(int(percent), '[%d%%] %s' % (int(percent), message))
                    except Exception:
                        pass

            # User cancelled the progress dialog -> signal the worker to abort.
            if dp is not None and not progress.is_canceled():
                try:
                    if dp.iscanceled():
                        progress.set_cancelled()
                except Exception:
                    pass

            if time.time() > budget_deadline:
                timed_out = True
                break

            # Poll interval keeps the dialog responsive & cancel-aware.
            done_event.wait(timeout=0.15)
    finally:
        if dp is not None:
            try:
                dp.close()
            except Exception:
                pass

    if result.get('cancelled'):
        xbmc.executebuiltin('Dialog.Close(all,true)')
        return

    if not done_event.is_set() and timed_out:
        # Budget exceeded: warming continues in the background (like Stremio's
        # behaviorHints.warming). The catalog cache is hotter for the next try.
        _notify('Busca em background. Tente novamente em instantes.', is_warning=True)
        return

    if result.get('error'):
        _notify('Erro: %s' % result['error'], is_error=True)
        return

    streams = result.get('streams') or []
    if not streams:
        _notify('Nenhum stream encontrado', is_warning=True)
        return

    choices = []
    choice_meta = []
    for s in streams:
        quality = s.get('quality', 'SD')
        server = s.get('server', '')
        emoji_q = config.QUALITY_EMOJIS.get(quality, '📺')
        emoji_s = config.SERVER_EMOJIS.get(server, '🌐')
        title = (s.get('title') or '').replace('\n', ' | ')
        label = '%s [%s] %s | %s %s' % (emoji_q, quality, title, emoji_s, server)
        choices.append(label)
        choice_meta.append(s)

    dialog = xbmcgui.Dialog()
    ret = dialog.select('Selecione o stream', choices)
    if ret < 0:
        return

    selected = choice_meta[ret]
    # li = xbmcgui.ListItem(label=selected.get('title', ''))
    # li.setProperty('IsPlayable', 'true')
    # url = selected.get('url', '')
    # if url:
    #     li.setPath(url)
    # xbmcplugin.setResolvedUrl(HANDLE, True, listitem=li)
    url = selected.get('url', '')
    title = selected.get('title', '')

    if url:
        li = xbmcgui.ListItem(label=title)
        #li.setProperty('IsPlayable', 'true')
        li.setPath(url)
        if iconimage:
            li.setArt({
                'poster': iconimage,
                'thumb': iconimage
            })

        xbmc.Player().play(url, li)    


def _parse_params():
    from urllib.parse import parse_qs, urlparse
    qs = {}
    if len(sys.argv) > 2:
        raw = sys.argv[2]
        if raw.startswith('?'):
            raw = raw[1:]
        qs = parse_qs(urlparse('?' + raw).query)
    flat = {}
    for k in qs:
        flat[k] = qs[k][0] if qs[k] else ''
    return flat


def run():
    params = _parse_params()
    action = params.get('action', 'root')

    if action == 'root':
        show_root()
    elif action == 'movies_popular':
        _browse_catalog('movies_popular', int(params.get('page', '1') or 1))
    elif action == 'tv_popular':
        _browse_catalog('tv_popular', int(params.get('page', '1') or 1))
    elif action == 'search':
        do_search()
    elif action == 'seasons':
        show_seasons(params.get('tmdb_id', ''))
    elif action == 'episodes':
        show_episodes(params.get('tmdb_id', ''), int(params.get('season', '1') or 1))
    elif action == 'play':
        tmdb_id = params.get('tmdb_id', '')
        media_type = params.get('media_type', 'movie')
        season = params.get('season')
        episode = params.get('episode')
        season = int(season) if season else None
        episode = int(episode) if episode else None
        iconimage = params.get('iconimage', '')
        play_item(tmdb_id, media_type, season, episode, iconimage)
    else:
        show_root()


if __name__ == '__main__':
    run()
