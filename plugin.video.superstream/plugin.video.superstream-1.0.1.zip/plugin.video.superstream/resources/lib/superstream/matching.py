from __future__ import unicode_literals, absolute_import, division

from . import config
from .utils import normalize_text, calculate_similarity


def get_movie_search_terms(title, original_title):
    terms = []
    seen = set()

    def add(term, weight, source):
        key = term.lower()
        if key in seen:
            return
        seen.add(key)
        terms.append({'term': term.strip(), 'weight': weight, 'source': source})

    if title:
        t = title.strip()
        add(t, 1.0, 'title_pt')
        no_accent = normalize_text(t)
        if no_accent != t.lower():
            add(no_accent, 0.98, 'title_pt_normalized')

    if original_title and original_title != title:
        add(original_title.strip(), 0.95, 'title_en')

    terms.sort(key=lambda x: x['weight'], reverse=True)
    return terms


def get_series_search_terms(title, original_title):
    terms = []
    seen = set()

    def add(term, weight, source):
        key = term.lower()
        if key in seen:
            return
        seen.add(key)
        terms.append({'term': term.strip(), 'weight': weight, 'source': source})

    if title:
        add(title.strip(), 1.0, 'title_pt')
    if original_title and original_title != title:
        add(original_title.strip(), 0.95, 'title_en')

    terms.sort(key=lambda x: x['weight'], reverse=True)
    return terms


def calculate_match_score(stream_title, stream_year, search_term, target_year):
    normalized_stream = normalize_text(stream_title)
    normalized_search = normalize_text(search_term['term'])

    if target_year and stream_year and target_year != stream_year:
        return 0.0, ['ano %s != %s' % (stream_year, target_year)]

    year_bonus = 0.0
    if target_year and not stream_year:
        year_bonus = -0.1
    elif target_year and stream_year and target_year == stream_year:
        year_bonus = 0.05

    if len(normalized_search) < 3:
        return 0.0, ['termo muito curto']

    if normalized_stream == normalized_search:
        score = min(1.0, 1.0 + year_bonus)
        reason = ['EXATO "%s"' % search_term['term']]
        if year_bonus > 0:
            reason.append('%s' % target_year)
        return score, reason

    stream_words = [w for w in normalized_stream.split(' ') if len(w) > 2]
    search_words = [w for w in normalized_search.split(' ') if len(w) > 2]

    if search_words and stream_words:
        all_found = True
        for s_word in search_words:
            found = False
            for t_word in stream_words:
                if t_word == s_word:
                    found = True
                    break
            if not found:
                all_found = False
                break

        if all_found:
            extra_words = len(stream_words) - len(search_words)
            if extra_words == 0:
                score = min(0.97, 0.97 + year_bonus)
                reason = ['EXATO "%s"' % search_term['term']]
                if year_bonus > 0:
                    reason.append('%s' % target_year)
                return score, reason
            elif extra_words <= 1:
                score = min(0.92, 0.92 + year_bonus)
                reason = ['"%s" + %d extra' % (search_term['term'], extra_words)]
                if year_bonus > 0:
                    reason.append('%s' % target_year)
                return score, reason

    sim = calculate_similarity(normalized_search, normalized_stream)
    if sim > 0.7:
        score = min(0.85, 0.7 + (sim - 0.7) * 0.5 + year_bonus)
        return score, ['similaridade %d%%' % int(sim * 100)]

    return 0.0, ['sem match']
