from __future__ import unicode_literals, absolute_import, division

import threading
from concurrent.futures import ThreadPoolExecutor

from . import config, tmdb, xtream, utils
from .cache import Cache

route_cache = Cache(ttl=config.ROUTE_CACHE_TTL)

_QUALITY_ORDER = {'4K': 4, 'FHD': 3, 'HD': 2, 'SD': 1, 'CAM': 0}


class CancelledError(Exception):
    pass


class Progress:
    """Protocol: default.py provides a concrete adapter around DialogProgress."""

    def update(self, percent, message=''):
        pass

    def is_canceled(self):
        return False


def warm_all_catalogs_background():
    """Pre-fetch every Xtream catalog in the background so the disk cache is hot
    before the user picks a movie/series. Non-blocking; cache hits make this a
    cheap no-op on warm catalogs."""
    servers = config.XTREAM_SERVERS
    actions = ('get_vod_streams', 'get_series')

    def _warm(server, action):
        try:
            xtream.make_xtream_request(server, action)
        except Exception:
            pass

    def _run():
        with ThreadPoolExecutor(max_workers=len(servers) * len(actions)) as exe:
            futures = []
            for action in actions:
                for server in servers:
                    futures.append(exe.submit(_warm, server, action))
            for f in futures:
                f.result()

    t = threading.Thread(target=_run, name='superstream-prewarm')
    t.daemon = True
    t.start()


def _report(progress, percent, message):
    if progress is not None:
        progress.update(percent, message)
        if progress.is_canceled():
            raise CancelledError()


def get_streams(imdb_id, media_type, season=None, episode=None, progress=None):
    """Resolve streams for an IMDB id (``tt...``) across the 4 Xtream servers.

    The id may also be a TMDb numeric id; both are accepted. When an IMDB id is
    supplied it is mapped to TMDb via /find. Mirrors the Stremio pipeline:
      1. warm Xtream catalogs in parallel with the TMDB metadata fetch
      2. search all servers against the (cached) catalogs in parallel
      3. score + sort by quality then similarity
      4. build stream URLs (series: fetch episode info with bounded concurrency)
    All stages report progress through ``progress`` and honor cancellation.
    """
    is_series = media_type in ('tv', 'series')
    season_num = season if season else 1
    episode_num = episode if episode else 1

    cache_key = '%s_%s_%s_%s' % (imdb_id, media_type, season_num, episode_num)
    cached = route_cache.get(cache_key)
    if cached is not None:
        _report(progress, 100, 'Usando cache')
        return cached

    _report(progress, 8, 'Preparando catálogos...')

    # Phase 1: warm all 4 catalogs in parallel while TMDB resolves the title.
    # On a cold cache this collapses to the slowest of (catalog warmup | tmdb),
    # exactly like the Stremio addon's catalogWarmup + tmdbPromise.
    catalog_action = 'get_series' if is_series else 'get_vod_streams'
    servers = config.XTREAM_SERVERS

    warmup_done = threading.Event()

    def warm_catalogs():
        try:
            with ThreadPoolExecutor(max_workers=len(servers)) as exe:
                list(exe.map(lambda s: xtream.make_xtream_request(s, catalog_action), servers))
        except Exception:
            pass
        finally:
            warmup_done.set()

    warmup_thread = threading.Thread(target=warm_catalogs, name='superstream-warmup')
    warmup_thread.daemon = True
    warmup_thread.start()

    tmdb_info = tmdb.get_tmdb_info(imdb_id, media_type)
    warmup_thread.join()

    if not tmdb_info:
        _report(progress, 100, 'TMDb não encontrou')
        return []

    _report(progress, 28, 'Buscando em 4 servidores...')

    title = tmdb_info.get('title', '') or ''
    year = tmdb_info.get('year', '') or ''
    original_title = tmdb_info.get('original_title', '') or ''

    # Phase 2: search every server's (now cached) catalog in parallel.
    search_fn = xtream.search_series_streams if is_series else xtream.search_movie_streams
    results = [None] * len(servers)

    def _search_at(idx):
        try:
            results[idx] = search_fn(servers[idx], title, year, original_title)
        except Exception:
            results[idx] = []

    with ThreadPoolExecutor(max_workers=len(servers)) as exe:
        list(exe.map(_search_at, range(len(servers))))

    all_matches = [m for r in results if r for m in r]
    _report(progress, 55, '%d matches encontrados' % len(all_matches))

    if not all_matches:
        _report(progress, 100, 'Nenhum stream encontrado')
        return []

    # Phase 3: sort by quality then similarity (best first).
    all_matches.sort(
        key=lambda m: (
            _QUALITY_ORDER.get(m['quality'], 0),
            m['similarity'],
        ),
        reverse=True,
    )

    # Phase 4: dedupe by (stream_id, server) then build the final URLs.
    top = all_matches[:config.MAX_CANDIDATES]
    seen = set()
    unique = []
    for m in top:
        mk = '%s_%s' % (m['id'], m['server']['username'])
        if mk in seen:
            continue
        seen.add(mk)
        unique.append(m)

    _report(progress, 75, 'Construindo URLs de stream...')

    def build_entry(match):
        try:
            quality = match.get('quality') or 'SD'
            stream_url = ''

            if is_series:
                series_info = xtream.get_series_info(match['server'], match['id'])
                if series_info:
                    ep = xtream.find_episode(series_info, season_num, episode_num)
                    if ep:
                        stream_url = '%s/series/%s/%s/%s.mp4' % (
                            match['server']['url'],
                            match['server']['username'],
                            match['server']['password'],
                            ep.get('id') or ep.get('episode_id') or ep.get('stream_id'),
                        )
                        if ep.get('info'):
                            ep_quality = utils.get_video_quality_from_info(ep['info'])
                            if ep_quality != 'SD':
                                quality = ep_quality
                if not stream_url:
                    return None
            else:
                stream_url = xtream.build_stream_url(match['server'], match['id'], False)

            formatted_title = utils.create_formatted_title(
                title, year, quality, match['server']['name'],
                is_series, season_num, episode_num, match.get('subtitled', False),
            )
            return {
                'name': config.PROVIDER_NAME,
                'title': formatted_title,
                'url': stream_url,
                'quality': quality,
                'server': match['server']['name'],
                'behaviorHints': {
                    'notWebReady': True,
                    'bingeGroup': 'superstream-%s:%s' % ('series' if is_series else 'movie', imdb_id),
                },
            }
        except Exception as e:
            if config.DEBUG:
                import xbmc
                xbmc.log('[SuperStream] Erro ao montar stream: %s' % e, xbmc.LOGWARNING)
            return None

    if is_series:
        with ThreadPoolExecutor(max_workers=config.DETAIL_CONCURRENCY) as exe:
            built = list(exe.map(build_entry, unique))
    else:
        built = [build_entry(m) for m in unique]

    streams = [b for b in built if b]
    streams = streams[:config.MAX_RESULTS]

    _report(progress, 100, '%d streams prontos' % len(streams))

    if streams:
        route_cache.set(cache_key, streams)
    return streams
