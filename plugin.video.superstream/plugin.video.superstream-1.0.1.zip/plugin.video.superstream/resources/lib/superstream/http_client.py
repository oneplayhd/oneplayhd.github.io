from __future__ import unicode_literals, absolute_import, division

import http.client
import json
import threading
import time
import urllib.parse

import xbmc

from . import config


_ua_index = 0
_ua_lock = threading.Lock()


def _get_ua():
    global _ua_index
    with _ua_lock:
        ua = config.USER_AGENTS[_ua_index % len(config.USER_AGENTS)]
        _ua_index = (_ua_index + 1) % len(config.USER_AGENTS)
    return ua


def _default_headers():
    return {
        'User-Agent': _get_ua(),
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'pt-BR,en-US;q=0.9,en;q=0.8',
        'Connection': 'keep-alive',
    }


_thread_local = threading.local()


def _pool():
    if not hasattr(_thread_local, 'conns'):
        _thread_local.conns = {}
    return _thread_local.conns


def _split_url(url):
    parsed = urllib.parse.urlparse(url)
    scheme = parsed.scheme or 'http'
    host = parsed.hostname
    port = parsed.port or (443 if scheme == 'https' else 80)
    path = parsed.path or '/'
    if parsed.query:
        path += '?' + parsed.query
    return scheme, host, port, path


def _new_conn(scheme, host, port, timeout):
    if scheme == 'https':
        return http.client.HTTPSConnection(host, port, timeout=timeout)
    return http.client.HTTPConnection(host, port, timeout=timeout)


def _get_conn(scheme, host, port, timeout):
    key = (scheme, host, port)
    conns = _pool()
    conn = conns.get(key)
    if conn is None:
        conn = _new_conn(scheme, host, port, timeout)
        conns[key] = conn
    return conn


def _drop_conn(scheme, host, port):
    conns = _pool()
    key = (scheme, host, port)
    bad = conns.pop(key, None)
    if bad is not None:
        try:
            bad.close()
        except Exception:
            pass


def _do_request(url, method='GET', body=None, headers=None, timeout=30.0):
    scheme, host, port, path = _split_url(url)
    if not host:
        raise ValueError('URL sem host: %s' % url)

    last_err = None
    for attempt in range(3):
        conn = None
        try:
            conn = _get_conn(scheme, host, port, timeout)
            h = _default_headers()
            if headers:
                h.update(headers)
            conn.request(method, path, body=body, headers=h)
            resp = conn.getresponse()
            data = resp.read()
            status = resp.status
            if 200 <= status < 300:
                return data, status
            last_err = 'HTTP %d' % status
            if status in (403, 404, 401):
                break
        except (http.client.HTTPException, ConnectionError, OSError, EOFError) as e:
            last_err = str(e) or 'erro de conexao'
            _drop_conn(scheme, host, port)
            time.sleep(0.1 * (attempt + 1))
            continue
        finally:
            conn = None
    raise IOError('Request falhou apos retries: %s (%s)' % (url, last_err))


def fetch_json(url, timeout=30.0):
    data, _status = _do_request(url, timeout=timeout)
    try:
        return json.loads(data.decode('utf-8', errors='replace'))
    except ValueError:
        if config.DEBUG:
            xbmc.log('[SuperStream] Erro ao parsear JSON: %s' % url, xbmc.LOGWARNING)
        return None


def fetch_raw(url, timeout=30.0):
    data, _status = _do_request(url, timeout=timeout)
    return data


def reset_connections():
    conns = _pool()
    for key in list(conns.keys()):
        c = conns.pop(key, None)
        if c is not None:
            try:
                c.close()
            except Exception:
                pass
