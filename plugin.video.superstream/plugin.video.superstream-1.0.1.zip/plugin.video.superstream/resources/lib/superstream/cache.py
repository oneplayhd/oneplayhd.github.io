from __future__ import unicode_literals, absolute_import, division

import threading
import time

from . import config
from .disk_cache import DiskCache


_locks = {}
_cache = {}
_inflight = {}
_lock = threading.Lock()


def get_cache(key, timeout):
    entry = _cache.get(key)
    if entry is None:
        return None
    age = time.time() - entry[1]
    if age < timeout:
        return entry[0]
    _cache.pop(key, None)
    return None


def set_cache(key, data):
    _cache[key] = (data, time.time())


def _lock_for(key):
    with _lock:
        lk = _locks.get(key)
        if lk is None:
            lk = threading.Lock()
            _locks[key] = lk
    return lk


def memoize(key, timeout=config.CACHE_TIMEOUT):
    def decorator(func):
        def wrapper(*args, **kwargs):
            cached = get_cache(key, timeout)
            if cached is not None:
                return cached
            lk = _lock_for(key)
            lk.acquire()
            try:
                cached = get_cache(key, timeout)
                if cached is not None:
                    return cached
                data = func(*args, **kwargs)
                set_cache(key, data)
                return data
            finally:
                lk.release()
        return wrapper
    return decorator


class Cache:
    def __init__(self, ttl):
        self.ttl = ttl
        self._store = {}
        self._inflight = {}
        self._lock = threading.Lock()

    def get(self, key):
        entry = self._store.get(key)
        if entry is None:
            return None
        if time.time() - entry[1] < self.ttl:
            return entry[0]
        self._store.pop(key, None)
        return None

    def set(self, key, data):
        self._store[key] = (data, time.time())

    def get_or_compute(self, key, factory, inflight=True):
        cached = self.get(key)
        if cached is not None:
            return cached
        if inflight:
            ev = self._inflight.get(key)
            if ev is not None:
                ev.wait()
                return self.get(key)
            ev = threading.Event()
            self._inflight[key] = ev
        try:
            data = factory()
            self.set(key, data)
            return data
        finally:
            if inflight:
                self._inflight.pop(key, None)
                ev.set()


class PersistentCache(Cache):
    """Cache that also persists to disk so it survives across plugin processes.

    Kodi runs every plugin action in a fresh Python process, so in-memory
    caches vanish between the catalog browse and the stream resolve. This
    persists the expensive Xtream/TMDb payloads to disk (same role the Stremio
    server keeps in RAM) so resolution is fast on every invocation after the
    first cold fetch.
    """

    def __init__(self, ttl, subdir):
        super(PersistentCache, self).__init__(ttl)
        self._disk = DiskCache(subdir, ttl)

    def get(self, key):
        v = super(PersistentCache, self).get(key)
        if v is not None:
            return v
        v = self._disk.get(key)
        if v is not None:
            self._store[key] = (v, time.time())
            return v
        return None

    def set(self, key, data):
        super(PersistentCache, self).set(key, data)
        self._disk.set(key, data)


def clear_all():
    _cache.clear()
    _inflight.clear()
    _locks.clear()
