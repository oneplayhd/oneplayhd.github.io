from __future__ import unicode_literals, absolute_import, division

import threading

import xbmc

from . import config, http_client, utils
from .cache import PersistentCache
from .matching import get_movie_search_terms, get_series_search_terms, calculate_match_score


catalog_cache = PersistentCache(ttl=config.CATALOG_CACHE_TIMEOUT, subdir='xtream_catalog')
_catalog_inflight = {}
_catalog_inflight_lock = threading.Lock()


def _xtream_catalog_key(server, action):
    return '%s:%s:%s' % (server['name'], server['username'], action)


def _build_player_api_url(server, action, extra_params=None):
    params = {
        'username': server['username'],
        'password': server['password'],
        'action': action,
    }
    if extra_params:
        for key in extra_params:
            params[key] = extra_params[key]
    return utils.build_url(server['url'] + '/player_api.php', params)


def make_xtream_request(server, action, extra_params=None):
    is_catalog = (extra_params is None) and action in ('get_vod_streams', 'get_series')
    key = _xtream_catalog_key(server, action) if is_catalog else None

    if is_catalog:
        cached = catalog_cache.get(key)
        if cached is not None:
            return cached
        with _catalog_inflight_lock:
            ev = _catalog_inflight.get(key)
            own_event = ev is None
            if own_event:
                ev = threading.Event()
                _catalog_inflight[key] = ev
        if not own_event:
            # Another thread is warming this catalog: wait for it, then use
            # whatever landed in cache (same promise semantics as the addon).
            ev.wait()
            cached = catalog_cache.get(key)
            if cached is not None:
                return cached
            return None

    timeout = config.XTREAM_CATALOG_TIMEOUT_MS / 1000.0 if is_catalog else config.XTREAM_DETAIL_TIMEOUT_MS / 1000.0
    url = _build_player_api_url(server, action, extra_params)
    try:
        data = http_client.fetch_json(url, timeout=timeout)
        if is_catalog and isinstance(data, list):
            catalog_cache.set(key, data)
        return data
    except Exception:
        if config.DEBUG:
            xbmc.log('[SuperStream] Xtream %s falhou: %s' % (action, server['name']), xbmc.LOGWARNING)
        return None
    finally:
        if is_catalog:
            with _catalog_inflight_lock:
                ev = _catalog_inflight.pop(key, None)
            if ev is not None:
                ev.set()


def search_movie_streams(server, title, year, original_title):
    search_terms = get_movie_search_terms(title, original_title)
    if not search_terms:
        return []

    data = make_xtream_request(server, 'get_vod_streams')
    if not data or not isinstance(data, list):
        return []

    matches = []
    for stream in data:
        if not isinstance(stream, dict):
            continue
        name = stream.get('name', '')
        if not name:
            continue
        stream_title = utils.extract_title_from_name(name)
        stream_year = utils.extract_year_from_name(name)
        subtitled = utils.is_subtitled(name)

        best_score = 0.0
        best_reasons = []
        for search_term in search_terms:
            score, reasons = calculate_match_score(stream_title, stream_year, search_term, year)
            if score > best_score:
                best_score = score
                best_reasons = reasons

        if best_score >= config.MIN_MATCH_SCORE:
            stream_id = stream.get('stream_id', '')
            if stream_id:
                matches.append({
                    'name': name,
                    'title': stream_title,
                    'year': stream_year,
                    'quality': utils.extract_quality(name),
                    'id': str(stream_id),
                    'server': server,
                    'match_reason': ' | '.join(best_reasons),
                    'similarity': best_score,
                    'subtitled': subtitled,
                })

    matches.sort(key=lambda m: m['similarity'], reverse=True)
    return matches


def search_series_streams(server, title, year, original_title):
    search_terms = get_series_search_terms(title, original_title)
    if not search_terms:
        return []

    data = make_xtream_request(server, 'get_series')
    if not data or not isinstance(data, list):
        return []

    matches = []
    for stream in data:
        if not isinstance(stream, dict):
            continue
        name = stream.get('name', '')
        if not name:
            continue
        stream_title = utils.extract_title_from_name(name)
        stream_year = utils.extract_year_from_name(name)
        subtitled = utils.is_subtitled(name)

        best_score = 0.0
        best_reasons = []
        for search_term in search_terms:
            score, reasons = calculate_match_score(stream_title, stream_year, search_term, year)
            if score > best_score:
                best_score = score
                best_reasons = reasons

        if best_score >= config.MIN_MATCH_SCORE:
            series_id = stream.get('series_id', '') or stream.get('id', '')
            if series_id:
                matches.append({
                    'name': name,
                    'title': stream_title,
                    'year': stream_year,
                    'quality': utils.extract_quality(name),
                    'id': str(series_id),
                    'server': server,
                    'match_reason': ' | '.join(best_reasons),
                    'similarity': best_score,
                    'subtitled': subtitled,
                })

    matches.sort(key=lambda m: m['similarity'], reverse=True)
    return matches


def get_series_info(server, series_id):
    info = make_xtream_request(server, 'get_series_info', {'series_id': series_id})
    return info


def find_episode(series_info, season, episode):
    episodes = series_info.get('episodes') or {}
    season_key = str(season)
    season_episodes = episodes.get(season_key)
    if not season_episodes:
        return None
    for ep in season_episodes:
        if str(ep.get('episode_num')) == str(episode):
            return ep
    return None


def build_stream_url(server, match_id, is_series):
    if is_series:
        return '%s/series/%s/%s/%s.mp4' % (server['url'], server['username'], server['password'], match_id)
    return '%s/movie/%s/%s/%s.mp4' % (server['url'], server['username'], server['password'], match_id)


def warm_catalogs(is_series):
    from concurrent.futures import ThreadPoolExecutor
    action = 'get_series' if is_series else 'get_vod_streams'
    def fetch(server):
        try:
            make_xtream_request(server, action)
        except Exception:
            return None
        return server['name']
    with ThreadPoolExecutor(max_workers=len(config.XTREAM_SERVERS)) as exe:
        list(exe.map(fetch, config.XTREAM_SERVERS))
