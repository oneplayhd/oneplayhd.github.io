from __future__ import unicode_literals, absolute_import, division

import re
import unicodedata
import urllib.parse

from . import config


_RE_QUALITY = re.compile(
    r'\s*(?:HD|FHD|4K|CAM|HDCAM|TS|WEB|WEB-DL|BluRay|DVD|HDRip|BDRip|480p|720p|1080p|2160p)\s*',
    re.IGNORECASE)
_RE_YEAR_BRACKET = re.compile(r'\s*[\[\(]\d{4}[\]\)]\s*')
_RE_SEASON_EPISODE = re.compile(r'\s*S\d{1,2}E\d{1,2}\s*', re.IGNORECASE)
_RE_TEMPORADA = re.compile(r'\s*Temporada\s*\d+\s*', re.IGNORECASE)
_RE_EPISODIO = re.compile(r'\s*Epis[dá]dio\s*\d+\s*', re.IGNORECASE)
_RE_YEAR_PAREN = re.compile(r'\s*\(\d{4}\)\s*')
_RE_DASH = re.compile(r'\s*-\s*.*$')
_RE_EMPTY = re.compile(r'\s*\[\]\s*')
_RE_BRACKET = re.compile(r'\s*\[.*?\]\s*')
_RE_SUB_L_BRACKET = re.compile(r'\s*\[L\]\s*', re.IGNORECASE)
_RE_SUB_L_DASH = re.compile(r'\s*-\s*L\s*', re.IGNORECASE)
_RE_SUB_L_PAREN = re.compile(r'\s*\(L\)\s*', re.IGNORECASE)
_RE_YEAR_EXTRACT = re.compile(r'[\[\(](\d{4})[\]\)]')
_RE_SUB_DASH = re.compile(r'-\s*l\b')


def build_url(base_url, params):
    parts = []
    for key in params:
        value = params[key]
        if value is None:
            continue
        parts.append(urllib.parse.quote(str(key), safe='') + '=' + urllib.parse.quote(str(value), safe=''))
    if parts:
        return base_url + '?' + '&'.join(parts)
    return base_url


def normalize_text(text):
    if not text:
        return ''
    text = text.lower()
    text = unicodedata.normalize('NFKD', text)
    text = text.encode('ascii', 'ignore').decode('utf-8', 'ignore')
    text = re.sub(r'[^a-z0-9\s]', ' ', text)
    text = ' '.join(text.split())
    return text


def calculate_similarity(text1, text2):
    norm1 = normalize_text(text1)
    norm2 = normalize_text(text2)
    tokens1 = norm1.split(' ')
    tokens2 = norm2.split(' ')
    set1 = set(tokens1)
    set2 = set(tokens2)
    intersection = set1 & set2
    union = set1 | set2
    if not union:
        return 0.0
    jaccard = len(intersection) / len(union)
    matches = 0
    min_len = min(len(norm1), len(norm2))
    for i in range(min_len):
        if norm1[i] == norm2[i]:
            matches += 1
    max_len = max(len(norm1), len(norm2))
    sequence_sim = matches / max_len if max_len > 0 else 0.0
    return (jaccard * 0.7) + (sequence_sim * 0.3)


def extract_title_from_name(name):
    if not name:
        return ''
    title = name
    title = _RE_QUALITY.sub('', title)
    title = _RE_YEAR_BRACKET.sub('', title)
    title = _RE_SEASON_EPISODE.sub('', title)
    title = _RE_TEMPORADA.sub('', title)
    title = _RE_EPISODIO.sub('', title)
    title = _RE_YEAR_PAREN.sub('', title)
    title = _RE_DASH.sub('', title)
    title = _RE_EMPTY.sub('', title)
    title = _RE_BRACKET.sub('', title)
    title = _RE_SUB_L_BRACKET.sub('', title)
    title = _RE_SUB_L_DASH.sub('', title)
    title = _RE_SUB_L_PAREN.sub('', title)
    return title.strip()


def extract_year_from_name(name):
    if not name:
        return ''
    match = _RE_YEAR_EXTRACT.search(name)
    return match.group(1) if match else ''


def extract_quality(name):
    if not name:
        return 'SD'
    name_lower = name.lower()
    if '4k' in name_lower or '2160' in name_lower:
        return '4K'
    if 'fhd' in name_lower or 'full hd' in name_lower or '1080' in name_lower:
        return 'FHD'
    if ' hd' in name_lower or '720' in name_lower or name_lower.startswith('hd'):
        return 'HD'
    if 'cam' in name_lower or 'hdcam' in name_lower or 'cinema' in name_lower or ' ts' in name_lower or name_lower.startswith('ts'):
        return 'CAM'
    return 'SD'


def is_subtitled(name):
    if not name:
        return False
    name_lower = name.lower()
    if '[l]' in name_lower:
        return True
    if _RE_SUB_DASH.search(name_lower):
        return True
    if '(l)' in name_lower:
        return True
    if 'legendado' in name_lower:
        return True
    return False


def get_video_quality_from_info(info):
    if not info:
        return 'SD'
    video = info.get('video') or {}
    width = video.get('width', 0) or 0
    height = video.get('height', 0) or 0
    if width >= 3840 or height >= 2160:
        return '4K'
    if width >= 1920 or height >= 1080:
        return 'FHD'
    if width >= 1280 or height >= 720:
        return 'HD'
    if width > 0 and height > 0:
        return 'SD'
    return 'SD'


def create_formatted_title(title, year, quality, server_name, is_series, season, episode, subtitled):
    quality_emoji = config.QUALITY_EMOJIS.get(quality, '📺')
    quality_label = config.QUALITY_LABELS.get(quality, quality)
    server_emoji = config.SERVER_EMOJIS.get(server_name, '🌐')
    sub_tag = ' [LEGENDADO]' if subtitled else ''
    display_title = title
    if is_series and season and episode:
        display_title = '%s S%02dE%02d' % (title, season, episode)
    return '%s %s%s (%s)\n%s %s\n🎯 %s' % (
        quality_emoji, display_title, sub_tag, year or '????', server_emoji, server_name, quality_label)
