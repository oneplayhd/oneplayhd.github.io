from __future__ import unicode_literals, absolute_import, division

import hashlib
import json
import os
import time

import xbmc
import xbmcaddon
import xbmcvfs

from . import config


_addon = xbmcaddon.Addon()


def _data_dir():
    try:
        profile = _addon.getAddonInfo('profile')
        full = xbmcvfs.translatePath(profile)
    except Exception:
        full = xbmcvfs.translatePath('special://profile/addon_data/%s' % config.ADDON_ID)
    if not os.path.isdir(full):
        try:
            os.makedirs(full)
        except OSError:
            pass
    return full


class DiskCache:
    """Persistent JSON cache in the addon's userdata folder.

    Kodi runs every plugin action in a fresh Python process, so in-memory
    caches are lost between the catalog browse and the stream resolve. This
    persists the expensive Xtream/TMDb payloads to disk (same role the Stremio
    server keeps in RAM) so resolution is fast on every invocation after the
    first cold fetch.
    """

    def __init__(self, subdir, ttl):
        self.subdir = subdir
        self.ttl = ttl
        self.root = os.path.join(_data_dir(), subdir)

    def _path(self, key):
        safe = hashlib.md5(key.encode('utf-8')).hexdigest()
        return os.path.join(self.root, safe + '.json')

    def get(self, key):
        p = self._path(key)
        if not os.path.exists(p):
            return None
        try:
            if (time.time() - os.path.getmtime(p)) > self.ttl:
                return None
            with open(p, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            if config.DEBUG:
                xbmc.log('[SuperStream] disk cache miss %s: %s' % (self.subdir, e), xbmc.LOGDEBUG)
            try:
                os.remove(p)
            except OSError:
                pass
            return None

    def set(self, key, data):
        try:
            if not os.path.isdir(self.root):
                os.makedirs(self.root)
            p = self._path(key)
            tmp = p + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(data, f)
            os.replace(tmp, p)
        except Exception as e:
            if config.DEBUG:
                xbmc.log('[SuperStream] disk cache write fail %s: %s' % (self.subdir, e), xbmc.LOGWARNING)

    def clear(self):
        if not os.path.isdir(self.root):
            return
        for fn in os.listdir(self.root):
            if fn.endswith('.json'):
                try:
                    os.remove(os.path.join(self.root, fn))
                except OSError:
                    pass
