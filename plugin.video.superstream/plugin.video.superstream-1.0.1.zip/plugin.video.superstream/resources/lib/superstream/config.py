from __future__ import unicode_literals, absolute_import, division

ADDON_NAME = 'SuperStream'
ADDON_ID = 'plugin.video.superstream'
VERSION = '1.0.0'

TMDB_API_KEY = '1865f43a0549ca50d341dd9ab8b29f49'
TMDB_BASE_URL = 'https://api.themoviedb.org/3'
TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p'
TMDB_BACKDROP_W = 'w1280'
TMDB_POSTER_W = 'w500'

PROVIDER_NAME = 'SuperStream'
MAX_RESULTS = 5
CACHE_TIMEOUT = 600
MAX_CANDIDATES = 8
MIN_MATCH_SCORE = 0.85
TMDB_TIMEOUT_MS = 4500
XTREAM_CATALOG_TIMEOUT_MS = 6500
XTREAM_DETAIL_TIMEOUT_MS = 4500
CATALOG_CACHE_TIMEOUT = 600
ROUTE_CACHE_TTL = 1800
ROUTE_BUDGET_MS = 15000
DETAIL_CONCURRENCY = 3
TMDB_CACHE_TTL = 86400

XTREAM_SERVERS = [
    {'url': 'http://auth.dnskode.com', 'username': 'ander0545', 'password': 'ander132', 'name': 'Server 1'},
    {'url': 'http://auth.dnskode.com', 'username': 'MarcusFatima', 'password': '22032020', 'name': 'Server 2'},
    {'url': 'http://auth.dnskode.com', 'username': 'RAFAELNEGRELLO20', 'password': '6h6idpmk9mg', 'name': 'Server 3'},
    {'url': 'http://auth.dnskode.com', 'username': 'felipaosoares', 'password': 'o73e6f2vqb5', 'name': 'Server 4'},
]

SERVER_EMOJIS = {
    'Server 1': '',
    'Server 2': '',
    'Server 3': '',
    'Server 4': '',
}

QUALITY_EMOJIS = {
    '4K': '',
    'FHD': '',
    'HD': '',
    'SD': '',
    'CAM': '',
}

QUALITY_LABELS = {
    '4K': '4K Ultra HD',
    'FHD': 'Full HD 1080p',
    'HD': 'HD 720p',
    'SD': 'SD',
    'CAM': 'CAM',
}

IMDB_TO_TMDB = {
    'tt0813715': '1639', 'tt0944947': '1399', 'tt0903747': '1396',
    'tt1520211': '1402', 'tt0773262': '1405', 'tt0412142': '1408',
    'tt0460681': '1622', 'tt0436992': '57223', 'tt0098780': '456',
    'tt0108778': '1668', 'tt0121955': '2316', 'tt0386676': '2996',
    'tt0397442': '1418', 'tt0460649': '1100', 'tt1442437': '1421',
    'tt1704271': '34307', 'tt2306299': '44217', 'tt2560140': '100088',
    'tt3322312': '82856',
}

USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
]

DEBUG = True
