from __future__ import unicode_literals, absolute_import, division

import xbmc

from . import config, http_client, utils
from .cache import PersistentCache


tmdb_cache = PersistentCache(ttl=config.TMDB_CACHE_TTL, subdir='tmdb')


def _imdb_to_tmdb(imdb_id):
    if imdb_id in config.IMDB_TO_TMDB:
        return config.IMDB_TO_TMDB[imdb_id]
    find_url = utils.build_url(config.TMDB_BASE_URL + '/find/' + imdb_id, {
        'api_key': config.TMDB_API_KEY,
        'external_source': 'imdb_id',
        'language': 'pt-BR',
    })
    data = http_client.fetch_json(find_url, timeout=config.TMDB_TIMEOUT_MS / 1000.0)
    if not data:
        return None
    for key in ('movie_results', 'tv_results'):
        results = data.get(key) or []
        if results:
            return str(results[0].get('id'))
    return None


def get_tmdb_info(tmdb_id, media_type):
    is_series = media_type in ('tv', 'series')
    endpoint = 'tv' if is_series else 'movie'
    final_id = tmdb_id

    cache_key = 'tmdb_%s_%s' % (final_id, media_type)
    cached = tmdb_cache.get(cache_key)
    if cached is not None:
        return cached

    if isinstance(final_id, str) and final_id.startswith('tt'):
        mapped = _imdb_to_tmdb(final_id)
        if mapped:
            final_id = mapped
            if config.DEBUG:
                xbmc.log('[SuperStream] Mapeamento IMDB->TMDB: %s -> %s' % (tmdb_id, final_id), xbmc.LOGDEBUG)
        else:
            if config.DEBUG:
                xbmc.log('[SuperStream] Nenhum resultado TMDb para %s' % tmdb_id, xbmc.LOGDEBUG)
            tmdb_cache.set(cache_key, None)
            return None

    params = {'api_key': config.TMDB_API_KEY, 'language': 'pt-BR'}
    url = utils.build_url(config.TMDB_BASE_URL + '/' + endpoint + '/' + str(final_id), params)
    data = http_client.fetch_json(url, timeout=config.TMDB_TIMEOUT_MS / 1000.0)
    if not data:
        tmdb_cache.set(cache_key, None)
        return None

    if is_series:
        result = {
            'title': data.get('name') or '',
            'year': (data.get('first_air_date') or '')[:4],
            'type': 'series',
            'tmdb_id': str(data.get('id', '')),
            'imdb_id': data.get('imdb_id') or '',
            'original_title': data.get('original_name') or '',
            'overview': data.get('overview') or '',
        }
    else:
        result = {
            'title': data.get('title') or '',
            'year': (data.get('release_date') or '')[:4],
            'type': 'movie',
            'tmdb_id': str(data.get('id', '')),
            'imdb_id': data.get('imdb_id') or '',
            'original_title': data.get('original_title') or '',
            'overview': data.get('overview') or '',
        }

    if config.DEBUG:
        xbmc.log('[SuperStream] TMDB info: "%s" (%s)' % (result.get('title'), result.get('year')), xbmc.LOGDEBUG)
    tmdb_cache.set(cache_key, result)
    return result


def discover_movies(page=1):
    url = utils.build_url(config.TMDB_BASE_URL + '/discover/movie', {
        'api_key': config.TMDB_API_KEY,
        'language': 'pt-BR',
        'sort_by': 'popularity.desc',
        'include_adult': 'false',
        'page': page,
    })
    return http_client.fetch_json(url, timeout=config.TMDB_TIMEOUT_MS / 1000.0)


def discover_tv(page=1):
    url = utils.build_url(config.TMDB_BASE_URL + '/discover/tv', {
        'api_key': config.TMDB_API_KEY,
        'language': 'pt-BR',
        'sort_by': 'popularity.desc',
        'include_adult': 'false',
        'page': page,
    })
    return http_client.fetch_json(url, timeout=config.TMDB_TIMEOUT_MS / 1000.0)


def search_tmdb(query, page=1):
    movies_url = utils.build_url(config.TMDB_BASE_URL + '/search/movie', {
        'api_key': config.TMDB_API_KEY,
        'language': 'pt-BR',
        'query': query,
        'page': page,
    })
    tv_url = utils.build_url(config.TMDB_BASE_URL + '/search/tv', {
        'api_key': config.TMDB_API_KEY,
        'language': 'pt-BR',
        'query': query,
        'page': page,
    })
    movies = http_client.fetch_json(movies_url, timeout=config.TMDB_TIMEOUT_MS / 1000.0) or {}
    tv = http_client.fetch_json(tv_url, timeout=config.TMDB_TIMEOUT_MS / 1000.0) or {}
    return {
        'movies': movies.get('results') or [],
        'tv': tv.get('results') or [],
        'movie_pages': movies.get('total_pages', 1),
        'tv_pages': tv.get('total_pages', 1),
    }


def get_imdb_id(tmdb_id, media_type):
    endpoint = 'tv' if media_type in ('tv', 'series') else 'movie'
    params = {
        'api_key': config.TMDB_API_KEY,
        'language': 'pt-BR',
        'append_to_response': 'external_ids',
    }
    url = utils.build_url(config.TMDB_BASE_URL + '/' + endpoint + '/' + str(tmdb_id), params)
    data = http_client.fetch_json(url, timeout=config.TMDB_TIMEOUT_MS / 1000.0)
    if not data:
        return ''
    if media_type in ('tv', 'series'):
        ext = data.get('external_ids') or {}
        return ext.get('imdb_id') or data.get('imdb_id') or ''
    return data.get('imdb_id') or ''


def get_tv_details(tmdb_id):
    """Return a TV show's seasons for browsing (cached 24h)."""
    cache_key = 'tv_details_%s' % tmdb_id
    cached = tmdb_cache.get(cache_key)
    if cached is not None:
        return cached

    params = {'api_key': config.TMDB_API_KEY, 'language': 'pt-BR'}
    url = utils.build_url(config.TMDB_BASE_URL + '/tv/' + str(tmdb_id), params)
    data = http_client.fetch_json(url, timeout=config.TMDB_TIMEOUT_MS / 1000.0)
    if not data:
        tmdb_cache.set(cache_key, None)
        return None

    seasons = []
    for s in (data.get('seasons') or []):
        if s.get('season_number') == 0:
            continue
        seasons.append({
            'season_number': s.get('season_number'),
            'name': s.get('name') or s.get('air_date', '') or ('Temporada %d' % s.get('season_number', 0)),
            'air_date': s.get('air_date') or '',
            'episode_count': s.get('episode_count') or 0,
        })

    result = {
        'name': data.get('name') or '',
        'original_name': data.get('original_name') or '',
        'year': (data.get('first_air_date') or '')[:4],
        'imdb_id': data.get('imdb_id') or '',
        'overview': data.get('overview') or '',
        'poster_path': data.get('poster_path') or '',
        'backdrop_path': data.get('backdrop_path') or '',
        'seasons': seasons,
    }
    tmdb_cache.set(cache_key, result)
    return result


def get_season_episodes(tmdb_id, season):
    cache_key = 'tv_season_%s_%s' % (tmdb_id, season)
    cached = tmdb_cache.get(cache_key)
    if cached is not None:
        return cached

    params = {'api_key': config.TMDB_API_KEY, 'language': 'pt-BR'}
    url = utils.build_url(config.TMDB_BASE_URL + '/tv/' + str(tmdb_id) + '/season/' + str(season), params)
    data = http_client.fetch_json(url, timeout=config.TMDB_TIMEOUT_MS / 1000.0)
    if not data:
        tmdb_cache.set(cache_key, None)
        return []

    episodes = []
    for e in (data.get('episodes') or []):
        episodes.append({
            'episode_number': e.get('episode_number'),
            'name': e.get('name') or '',
            'overview': e.get('overview') or '',
            'air_date': e.get('air_date') or '',
            'still_path': e.get('still_path') or '',
        })
    tmdb_cache.set(cache_key, episodes)
    return episodes
