import hashlib
import json
import re
import ssl
import urllib.request

DEFAULT_BLOSSOM_SERVERS = [
    "https://blossom.primal.net",
    "https://blossom.band",
    "https://nostr.download",
]

MAX_BLOB_BYTES = 64 * 1024 * 1024
HASH_RE = re.compile(r"^[0-9a-f]{64}$", re.IGNORECASE)

_STRICT_CACHE = None


class BlobError(Exception):
    pass


def sha256_hex(data):
    return hashlib.sha256(data).hexdigest()


def _opener(verify=True):
    global _STRICT_CACHE
    key_info = bool(verify)
    if _STRICT_CACHE is None:
        _STRICT_CACHE = {}
    if key_info not in _STRICT_CACHE:
        context = ssl.create_default_context() if verify else ssl._create_unverified_context()
        _STRICT_CACHE[key_info] = urllib.request.build_opener(
            urllib.request.HTTPSHandler(context=context)
        )
    return _STRICT_CACHE[key_info]


def fetch_url(url, timeout, collector=None, headers=None):
    try:
        request = urllib.request.Request(url, headers=headers or {})
        return _opener(True).open(request, timeout=timeout)
    except Exception as exc:
        text = str(exc).lower()
        if "certificate" not in text and "ssl" not in type(exc).__name__.lower():
            raise
        if collector is not None:
            collector.append("%s: %s" % (url, exc))
        request = urllib.request.Request(url, headers=headers or {})
        return _opener(False).open(request, timeout=timeout)


def normalize_blossom_list(values):
    result = []
    for value in list(values or []) + list(DEFAULT_BLOSSOM_SERVERS):
        raw = str(value or "").strip().rstrip("/")
        if not raw.startswith("http://") and not raw.startswith("https://"):
            continue
        if raw not in result:
            result.append(raw)
    return result


def blob_url(server, blob_hash):
    return server.rstrip("/") + "/" + blob_hash.lower()


def _read_response(response):
    data = b""
    while len(data) <= MAX_BLOB_BYTES:
        chunk = response.read(262144)
        if not chunk:
            break
        data += chunk
    if len(data) > MAX_BLOB_BYTES:
        raise BlobError("blob too large")
    return data


def download_blob(blob_hash, servers, expected_size=None, timeout=120.0):
    if not blob_hash or not HASH_RE.match(blob_hash or ""):
        raise BlobError("invalid blob hash")
    blob_hash = blob_hash.lower()
    errors = []
    headers = {"User-Agent": "ngit-kodi-repo/1.0", "Accept": "*/*"}
    for server in normalize_blossom_list(servers):
        url = blob_url(server, blob_hash)
        warnings = []
        try:
            with fetch_url(url, timeout, warnings, headers) as response:
                data = _read_response(response)
        except Exception as exc:
            errors.append("%s: %s" % (server, exc))
            continue
        actual = sha256_hex(data)
        if actual != blob_hash:
            errors.append("%s: hash mismatch" % server)
            continue
        if expected_size is not None and int(expected_size) >= 0 and len(data) != int(expected_size):
            errors.append("%s: size mismatch" % server)
            continue
        return {
            "data": data,
            "server": server,
            "hash": blob_hash,
            "size": len(data),
            "tlsFallback": warnings,
        }
    raise BlobError(
        "blob %s not found on Blossom (%s)" % (blob_hash[:12], "; ".join(errors) or "no servers")
    )


def parse_descriptor(tag):
    if not tag or not isinstance(tag, (list, tuple)) or len(tag) < 2:
        return None
    blob_hash = str(tag[1] or "").lower()
    if not HASH_RE.match(blob_hash):
        return None
    server = None
    size = None
    mime = None
    if len(tag) > 2 and str(tag[2] or "").startswith("http"):
        server = str(tag[2]).rstrip("/")
    if len(tag) > 3 and str(tag[3] or ""):
        try:
            size = int(str(tag[3]))
        except ValueError:
            size = None
    if len(tag) > 4:
        mime = str(tag[4] or "") or None
    return {
        "hash": blob_hash,
        "server": server,
        "size": size,
        "mime": mime,
    }
