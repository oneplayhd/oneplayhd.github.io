import hashlib
import json
import os
import re
import threading
import time
import xml.etree.ElementTree as ET
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, unquote, quote

import catalog as catalog_module
import blossom

SERVER_PORT_FALLBACK = 9432
XML_HEADER = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<addons>\n'
XML_FOOTER = "\n</addons>\n"
TOKEN_RE = re.compile(r"^[A-Za-z0-9._+-]{1,64}$")
CONTENT_TYPES = {
    "png": "image/png",
    "jpg": "image/jpeg",
    "jpeg": "image/jpeg",
    "gif": "image/gif",
    "webp": "image/webp",
    "bmp": "image/bmp",
    "svg": "image/svg+xml",
}
ART_TAGS = {"icon", "fanart", "screenshot"}


class BridgeConfig:
    def __init__(self, port=SERVER_PORT_FALLBACK, relays=None, blossom_servers=None,
                 sources=None, discover=True, tag="ngit", refresh_minutes=30,
                 timeout=9.0, log=None, prebuild=False):
        import ngnostr
        self.port = int(port)
        self.relays = ngnostr.normalize_relay_list(relays)
        if not self.relays:
            self.relays = ngnostr.normalize_relay_list([
                "wss://relay.damus.io", "wss://nos.lol", "wss://relay.primal.net"
            ])
        self.blossom = blossom.normalize_blossom_list(blossom_servers)
        self.sources = protocol_sources(sources)
        self.discover = bool(discover)
        self.tag = str(tag or "").strip()
        self.refresh_minutes = max(1, int(refresh_minutes))
        self.timeout = float(timeout)
        self.prebuild = bool(prebuild)
        self.log = log or (lambda message: None)


def protocol_sources(values):
    import protocol
    return protocol.parse_sources(values or [])


def make_bridge(config, data_dir, log=None):
    return Bridge(config, data_dir, log=log)


def wipe_profile_cache(data_dir, log=None):
    import shutil
    for name in ("art", "zips"):
        target = os.path.join(data_dir, name)
        if os.path.isdir(target):
            shutil.rmtree(target, ignore_errors=True)
    try:
        os.unlink(os.path.join(data_dir, "catalog.json"))
    except OSError:
        pass
    if log:
        log("profile cache wiped (art, zips, catalog.json)")


def serialize_entry(entry):
    return {
        "addon_id": entry["addon_id"],
        "version": entry["version"],
        "name": entry["name"],
        "provider": entry.get("provider") or "",
        "element": entry["element"],
        "owner": entry["owner"],
        "npub": entry.get("npub") or "",
        "project": entry["project"],
        "createdAt": entry.get("createdAt") or 0,
        "prefix": entry.get("prefix") or "",
        "blossom": entry.get("blossom") or [],
        "manifest": {"version": 1, "tree": entry["manifest"].get("tree", [])},
        "assets": entry.get("assets") or [],
        "description": entry.get("description") or "",
    }


def deserialize_entry(value):
    return {
        "addon_id": value["addon_id"],
        "version": value["version"],
        "name": value.get("name") or value["addon_id"],
        "provider": value.get("provider") or "",
        "element": value["element"],
        "owner": value["owner"],
        "npub": value.get("npub") or "",
        "project": value["project"],
        "createdAt": value.get("createdAt") or 0,
        "prefix": value.get("prefix") or "",
        "blossom": value.get("blossom") or [],
        "manifest": {"version": 1, "tree": value["manifest"].get("tree", [])},
        "assets": value.get("assets") or [],
        "description": value.get("description") or "",
    }


def build_addons_xml(entries):
    lines = [XML_HEADER]
    for addon_id in sorted(entries):
        lines.append("  " + entries[addon_id]["element"])
    lines.append(XML_FOOTER)
    return "".join(lines).encode("utf-8")


class BridgeError(Exception):
    pass


class Bridge(BridgeConfig):
    def __init__(self, config, data_dir, log=None):
        source = config if isinstance(config, dict) else {}
        port = source.get("port", SERVER_PORT_FALLBACK)
        relays = source.get("relays", [])
        blossom_servers = source.get("blossom", source.get("blossomServers", []))
        raw_sources = source.get("sources", [])
        discover = source.get("discover", True)
        tag = source.get("tag", "ngit")
        refresh_minutes = source.get("refreshMinutes", 30)
        timeout = source.get("timeout", 9.0)
        prebuild = source.get("prebuild", False)
        super().__init__(
            port=port,
            relays=relays,
            blossom_servers=blossom_servers,
            sources=raw_sources,
            discover=discover,
            tag=tag,
            refresh_minutes=refresh_minutes,
            timeout=timeout,
            log=log,
            prebuild=prebuild,
        )
        self.data_dir = data_dir
        self._state_lock = threading.Lock()
        self._entries = {}
        self._snapshot = None
        self._snapshot_lock = threading.Lock()
        self._refresh_lock = threading.Lock()
        self._last_refresh = 0.0
        self._zip_locks = {}
        self._prebuild_thread = None
        self._server = None
        self._thread = None
        self._load_cache()

    def _cache_file(self):
        return os.path.join(self.data_dir, "catalog.json")

    def _load_cache(self):
        path = self._cache_file()
        if not os.path.exists(path):
            return
        try:
            with open(path, "r", encoding="utf-8") as handle:
                values = json.load(handle)
            entries = {key: deserialize_entry(value) for key, value in values.items()}
        except Exception:
            return
        if entries:
            self._entries = entries
            self._snapshot = build_addons_xml(entries)

    def _save_cache(self, entries):
        path = self._cache_file()
        try:
            os.makedirs(self.data_dir, exist_ok=True)
            temporary = path + ".tmp"
            payload = {key: serialize_entry(value) for key, value in entries.items()}
            with open(temporary, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False)
            os.replace(temporary, path)
        except Exception:
            pass

    def start(self):
        if self._server is not None:
            return
        server = ThreadingHTTPServer(("127.0.0.1", self.port), create_handler(self))
        server.daemon_threads = True
        self._server = server
        self._thread = threading.Thread(target=server.serve_forever, daemon=True)
        self._thread.start()
        self.log("bridge listening on http://127.0.0.1:%d (addons: %d)"
                 % (self.port, len(self._entries)))

    def stop(self):
        server = self._server
        self._server = None
        if server is not None:
            server.shutdown()
            server.server_close()

    def tick(self):
        if time.monotonic() - self._last_refresh < self.refresh_minutes * 60.0:
            return
        self.refresh()

    def refresh(self, force=False):
        with self._refresh_lock:
            if not force and time.monotonic() - self._last_refresh < self.refresh_minutes * 60.0:
                return
            self._refresh_block()

    def _refresh_block(self):
        self._last_refresh = time.monotonic()
        try:
            config = SimpleNamespace(self)
            entries = catalog_module.discover(config)
            self.log("discovery finished: %d addon(s)" % len(entries))
        except Exception as exc:
            self.log("discovery failed: %s" % exc)
            return
        if entries is not None and not entries and self._entries:
            self.log("discovery empty, keeping %d cached addon(s)" % len(self._entries))
            return
        mapping = dict(self._entries) if entries is None else {}
        for entry in entries:
            mapping[entry["addon_id"]] = entry
        with self._state_lock:
            self._entries = mapping
        self._save_cache(mapping)
        with self._snapshot_lock:
            self._snapshot = build_addons_xml(mapping)
        self._start_prebuild(mapping)

    def _start_prebuild(self, mapping):
        if not self.prebuild:
            self.log("prebuild disabled (packages download only on install)")
            return
        thread = self._prebuild_thread
        if thread is not None and thread.is_alive():
            return
        self._prebuild_thread = threading.Thread(
            target=self._prebuild_zips, args=(mapping,), daemon=True
        )
        self._prebuild_thread.start()

    def _prebuild_zips(self, mapping):
        self.log("prebuilding zips for %d addon(s)" % len(mapping))
        for addon_id, entry in sorted(
            mapping.items(), key=lambda item: item[1].get("createdAt") or 0, reverse=True
        ):
            try:
                version = entry["version"]
                safe_id = _token(addon_id)
                safe_version = _token(version)
                if not safe_id or not safe_version:
                    continue
                path = os.path.join(
                    self.data_dir, "zips", safe_id, "%s-%s.zip" % (safe_id, safe_version)
                )
                if os.path.exists(path):
                    continue
                self._build_zip(entry, os.path.dirname(path), safe_id, safe_version)
                self.log("zip ready: %s %s" % (addon_id, version))
            except Exception as exc:
                self.log("prebuild failed for %s: %s" % (addon_id, exc))

    def wipe_profile_cache(self):
        wipe_profile_cache(self.data_dir)

    def addons_xml(self):
        if self._snapshot is None or (
            time.monotonic() - self._last_refresh > self.refresh_minutes * 60.0
        ):
            self.refresh()
        return self._snapshot

    def checksum(self):
        snapshot = self.addons_xml()
        if snapshot is None:
            raise BridgeError("addons.xml unavailable")
        return hashlib.md5(snapshot).hexdigest()

    def has_zip(self, addon_id):
        entry = self._entry_for(addon_id)
        if entry is None:
            return None
        version = entry["version"]
        safe_id = _token(addon_id)
        safe_version = _token(version)
        if not safe_id or not safe_version:
            return None
        directory = os.path.join(self.data_dir, "zips", safe_id)
        path = os.path.join(directory, "%s-%s.zip" % (safe_id, safe_version))
        if os.path.exists(path):
            return path
        return self._build_zip(entry, directory, safe_id, safe_version)

    def _entry_for(self, addon_id):
        with self._state_lock:
            return self._entries.get(addon_id)

    def _tree_item(self, tree, path):
        for item in tree:
            if str(item.get("path") or "") == path:
                return item
        return None

    def art(self, addon_id, rel_path):
        entry = self._entry_for(addon_id)
        if entry is None:
            raise BridgeError("addon not found: %s" % addon_id)
        relative = str(rel_path or "").strip().lstrip("/")
        if not relative or "\\" in relative or ".." in relative or relative.startswith("/"):
            raise BridgeError("invalid art path")
        if relative not in [str(a.get("path") or "").strip() for a in entry.get("assets") or []]:
            raise BridgeError("art not declared by addon: %s" % relative)
        prefix = entry.get("prefix") or ""
        item = self._tree_item(entry["manifest"].get("tree", []), prefix + relative)
        if item is None:
            raise BridgeError("art not in repository tree: %s" % relative)
        servers = list(entry.get("blossom") or []) + list(item.get("servers") or [])
        extension = os.path.splitext(relative)[1].lstrip(".").lower()
        safe_id = _token(addon_id)
        art_dir = os.path.join(self.data_dir, "art", safe_id or "raw")
        try:
            os.makedirs(art_dir, exist_ok=True)
        except OSError:
            pass
        cached = os.path.join(art_dir, str(item.get("sha256") or "raw") +
                              (("." + extension) if extension else ""))
        if not os.path.exists(cached):
            blob = blossom.download_blob(
                item.get("sha256"), servers, expected_size=item.get("size"),
                timeout=120.0,
            )
            if blob["tlsFallback"]:
                self.log("tls fallback for art %s (%s); content verified by SHA-256"
                         % (relative, blob["server"]))
            temporary = cached + ".tmp"
            with open(temporary, "wb") as handle:
                handle.write(blob["data"])
            os.replace(temporary, cached)
        with open(cached, "rb") as handle:
            data = handle.read()
        return data, CONTENT_TYPES.get(extension, "application/octet-stream")

    def _build_zip(self, entry, directory, safe_id, safe_version):
        lock = self._zip_locks.get(safe_id)
        if lock is None:
            lock = threading.Lock()
            self._zip_locks[safe_id] = lock
        with lock:
            path = os.path.join(directory, "%s-%s.zip" % (safe_id, safe_version))
            if os.path.exists(path):
                return path
            import zipfile
            import tempfile
            os.makedirs(directory, exist_ok=True)
            handle = tempfile.NamedTemporaryFile(
                delete=False, dir=directory, suffix=".zip.tmp"
            )
            handle.close()
            temporary = handle.name
            try:
                with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED) as archive:
                    tree = entry["manifest"].get("tree", [])
                    if not tree:
                        raise BridgeError("manifest tree is empty")
                    prefix = entry.get("prefix") or ""
                    servers = entry.get("blossom") or []
                    archive.writestr(zipfile.ZipInfo(safe_id + "/"), b"")
                    for item in tree:
                        relative = str(item.get("path") or "")
                        if not relative or relative.startswith(("/", "\\")) or ".." in relative:
                            raise BridgeError("unsafe path in manifest: %r" % relative)
                        if prefix:
                            if not relative.startswith(prefix) or relative == prefix.rstrip("/"):
                                continue
                            relative = relative[len(prefix):]
                        if not relative:
                            continue
                        servers_for_file = servers + list(item.get("servers") or [])
                        blob = blossom.download_blob(
                            item.get("sha256"),
                            servers_for_file,
                            expected_size=item.get("size"),
                            timeout=120.0,
                        )
                        if blob["tlsFallback"]:
                            self.log("tls fallback for %s (%s); content verified by SHA-256"
                                     % (relative, blob["server"]))
                        archive.writestr(safe_id + "/" + relative, blob["data"])
                os.replace(temporary, path)
            except Exception:
                try:
                    os.unlink(temporary)
                except OSError:
                    pass
                raise
            return path

    def stats(self):
        return {
            "port": self.port,
            "addons": len(self._entries),
            "relays": self.relays,
            "blossom": self.blossom,
            "sources": [s.get("npub") or s for s in self.sources] if isinstance(self.sources, list) else [],
            "snapshot": self._snapshot is not None,
        }


class SimpleNamespace:
    def __init__(self, bridge):
        self.relays = bridge.relays
        self.blossom = bridge.blossom
        self.sources = bridge.sources
        self.discover = bridge.discover
        self.tag = bridge.tag
        self.timeout = bridge.timeout
        self.log = bridge.log


def _token(value):
    value = str(value or "")
    return value if TOKEN_RE.match(value) else None


def create_handler(bridge):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.0"

        def log_message(self, fmt, *args):
            bridge.log("http: " + (fmt % args))

        def do_GET(self):
            route = urlparse(self.path).path
            try:
                body, content_type = self._route(route)
                status = 200
            except FileNotFoundError:
                body = json.dumps({"error": "not found", "path": route}).encode("utf-8")
                content_type = "application/json"
                status = 404
            except BridgeError as exc:
                body = json.dumps({"error": str(exc)}).encode("utf-8")
                content_type = "application/json"
                status = 404
            except Exception as exc:
                bridge.log("request error: %s" % exc)
                body = json.dumps({"error": str(exc)}).encode("utf-8")
                content_type = "application/json"
                status = 502
            try:
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except (ConnectionError, BrokenPipeError):
                self.close_connection = True

        def _route(self, route):
            if route == "/addons.xml":
                snapshot = bridge.addons_xml()
                if snapshot is None:
                    snapshot = build_addons_xml({})
                return snapshot, "application/xml; charset=utf-8"
            if route == "/addons.xml.md5":
                return (bridge.checksum() + "\n").encode("ascii"), "text/plain"
            if route == "/healthz":
                return json.dumps(bridge.stats()).encode("utf-8"), "application/json"
            parts = [part for part in route.split("/") if part]
            if len(parts) >= 2 and parts[0] == "zips":
                if len(parts) == 2:
                    candidate = parts[1]
                    if candidate.endswith(".zip"):
                        candidate = candidate[:-4]
                    addon_id = candidate
                else:
                    addon_id = parts[1]
                addon_id = _token(addon_id)
                if not addon_id:
                    raise BridgeError("invalid addon id")
                path = bridge.has_zip(addon_id)
                if path is None:
                    raise BridgeError("addon not found: %s" % addon_id)
                with open(path, "rb") as handle:
                    return handle.read(), "application/zip"
            if len(parts) >= 3 and parts[0] == "art":
                addon_id = _token(parts[1])
                if not addon_id:
                    raise BridgeError("invalid addon id")
                rel_path = unquote("/".join(parts[2:]))
                return bridge.art(addon_id, rel_path)
            raise FileNotFoundError(route)

    return Handler


def make_bridge(config, data_dir, log=None):
    return Bridge(config, data_dir, log=log)
