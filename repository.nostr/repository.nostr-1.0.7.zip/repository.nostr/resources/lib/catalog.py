import json
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor

import blossom
import protocol
import ngnostr

ID_RE = r"^[A-Za-z0-9._-]{1,64}$"


class CatalogError(Exception):
    pass


def _validate_token(value):
    import re
    if not value or not re.match(ID_RE, value):
        raise CatalogError("invalid addon id/version token: %r" % value)
    return value


def parse_addon_xml(data):
    try:
        root = ET.fromstring(data)
    except ET.ParseError as exc:
        raise CatalogError("addon.xml parse error: %s" % exc)
    if root.tag != "addon":
        raise CatalogError("addon.xml root is not <addon>")
    addon_id = _validate_token(root.attrib.get("id", ""))
    version = _validate_token(root.attrib.get("version", ""))
    name = root.attrib.get("name") or addon_id
    provider = root.attrib.get("provider-name") or ""
    assets = []
    for meta in root.findall("extension"):
        if meta.attrib.get("point") != "xbmc.addon.metadata":
            continue
        block = meta.find("assets")
        if block is None:
            continue
        for child in list(block):
            path = str(child.text or "").strip()
            if path:
                assets.append({"tag": child.tag, "path": path})
    element = ET.tostring(root, encoding="unicode").strip()
    return {
        "addon_id": addon_id,
        "version": version,
        "name": name,
        "provider": provider,
        "assets": assets,
        "element": element,
    }


def merge_servers(lists):
    result = []
    for values in lists:
        for value in values or []:
            raw = str(value or "").strip().rstrip("/")
            if raw and raw not in result:
                result.append(raw)
    return result


def addon_files_in_tree(manifest, limit=64):
    found = []
    for entry in manifest.get("tree", []):
        path = str(entry.get("path") or "")
        if path == "addon.xml" or path.endswith("/addon.xml"):
            found.append(entry)
            if len(found) >= limit:
                break
    return found


def prefix_for_addon(path):
    if path == "addon.xml":
        return ""
    return path[: -len("addon.xml")]


def tree_for_prefix(tree, prefix):
    if not prefix:
        return list(tree)
    selected = []
    for item in tree:
        path = str(item.get("path") or "")
        if path.startswith(prefix):
            selected.append(item)
    return selected


def build_entries(state, npub, log=None):
    manifest_desc = state.get("manifest")
    if not manifest_desc:
        raise CatalogError("state has no manifest")
    servers = merge_servers([
        state.get("blossomServers"),
        state.get("extraServers"),
        [manifest_desc.get("server")],
    ])
    manifest_result = blossom.download_blob(
        manifest_desc["hash"], servers, expected_size=manifest_desc.get("size")
    )
    manifest = json.loads(manifest_result["data"].decode("utf-8", "replace"))
    if manifest.get("version") != 1:
        raise CatalogError("unsupported manifest version")
    if not isinstance(manifest.get("tree"), list):
        raise CatalogError("manifest has no file tree")
    addon_files = addon_files_in_tree(manifest)
    if not addon_files:
        raise CatalogError("repository has no addon.xml")
    entries = []
    for addon_file in addon_files:
        prefix = prefix_for_addon(addon_file["path"])
        addon_servers = merge_servers([addon_file.get("servers"), servers])
        try:
            addon_result = blossom.download_blob(
                addon_file["sha256"], addon_servers, expected_size=addon_file.get("size")
            )
            info = parse_addon_xml(addon_result["data"])
        except Exception as exc:
            if log:
                log("skip addon.xml at %s: %s" % (addon_file["path"], exc))
            continue
        if prefix and not info["addon_id"].lower() in prefix.lower():
            log and log(
                "addon.xml at %s has id %s outside folder %s" % (
                    addon_file["path"], info["addon_id"], prefix
                )
            )
        if log:
            log("found addon %s %s via %s" % (info["addon_id"], info["version"], npub))
        entries.append({
            "addon_id": info["addon_id"],
            "version": info["version"],
            "name": info["name"],
            "provider": info["provider"],
            "assets": info.get("assets") or [],
            "element": info["element"],
            "owner": state["pubkey"],
            "npub": npub,
            "project": state["project"],
            "createdAt": state.get("createdAt") or 0,
            "prefix": prefix,
            "manifest": {"version": 1, "tree": manifest.get("tree", [])},
            "blossom": servers,
            "description": "",
        })
    return entries


def suppose_npub(pubkey_hex):
    try:
        return protocol.pubkey_to_npub(pubkey_hex)
    except Exception:
        return pubkey_hex


def discover(config):
    relays = config.relays
    if not relays:
        return []
    sources = config.sources
    tag = config.tag
    timeout = config.timeout
    entries = []
    if sources:
        grouped = {}
        restriction = []
        any_authors = []
        for source in sources:
            pubkey, project = source["pubkey"], source["project"]
            if project:
                restriction.append((pubkey, project))
            else:
                any_authors.append(pubkey)
                restriction.append((pubkey, None))
        filters = []
        if any_authors:
            filters.append(protocol.state_filter(sorted(set(any_authors))))
        project_map = {}
        for pubkey, project in restriction:
            if project is None:
                continue
            project_map.setdefault(pubkey, set()).add(project)
        for pubkey, projects in sorted(project_map.items()):
            filters.append(protocol.state_filter([pubkey], projects=sorted(projects)))
        if not filters:
            return []
        result = ngnostr.query_events(relays, filters, timeout=timeout)
        states = {}
        for event in result["events"]:
            state = protocol.parse_state_event(event)
            if not state:
                continue
            key = (state["pubkey"], state["project"])
            current = states.get(key)
            if current is None or state["createdAt"] > current["createdAt"]:
                states[key] = state
        selected = [
            state for (pubkey, project), state in states.items()
            if (pubkey, None) in restriction or (pubkey, project) in restriction
        ]
        npubs = {s["pubkey"]: suppose_npub(s["pubkey"]) for s in selected}
        entries = _build_entries(selected, npubs, config)
        return entries
    if not config.discover:
        return []
    announcement_result = ngnostr.query_events(
        relays, [protocol.announcement_filter([], tag=tag)], timeout=timeout
    )
    announcements = {}
    for event in announcement_result["events"]:
        if not protocol.announcement_has_tag(event, tag):
            continue
        parsed = protocol.parse_announcement_event(event)
        if not parsed:
            continue
        key = (parsed["pubkey"], parsed["project"])
        current = announcements.get(key)
        if current is None or parsed["createdAt"] > current["createdAt"]:
            announcements[key] = parsed
    if not announcements:
        return []
    authors = sorted({key[0] for key in announcements})
    state_result = ngnostr.query_events(relays, [protocol.state_filter(authors)], timeout=timeout)
    states = {}
    wanted = set(announcements.keys())
    for event in state_result["events"]:
        state = protocol.parse_state_event(event)
        if not state:
            continue
        key = (state["pubkey"], state["project"])
        if key not in wanted:
            continue
        states[key] = state
    npubs = {state["pubkey"]: suppose_npub(state["pubkey"]) for state in states.values()}
    descriptions = {
        key: announcement["description"]
        for key, announcement in announcements.items()
    }
    entries = _build_entries(list(states.values()), npubs, config)
    for entry in entries:
        entry["description"] = descriptions.get((entry["owner"], entry["project"]), "")
    return entries


def _build_entries(states, npubs, config):
    def work(state):
        try:
            return build_entries(state, npubs.get(state["pubkey"], state["pubkey"]), config.log)
        except Exception as exc:
            if config.log:
                config.log(
                    "skip %s/%s: %s" % (suppose_npub(state["pubkey"]), state["project"], exc)
                )
            return []

    workers = min(8, max(1, len(states)))
    with ThreadPoolExecutor(max_workers=workers) as pool:
        built_lists = list(pool.map(work, states))
    by_id = {}
    for built in built_lists:
        for entry in built:
            current = by_id.get(entry["addon_id"])
            if current is None or entry["createdAt"] > current["createdAt"]:
                by_id[entry["addon_id"]] = entry
    return sorted(by_id.values(), key=lambda entry: entry["addon_id"])
