# -*- coding: utf-8 -*-
"""Limpeza conservadora de APKs baixados pelo OnePlayVIP na inicialização do Kodi.

Roda como service leve no startup e encerra em seguida.
Não mexe em EPG, cache, favoritos, continue assistindo, player, proxy ou dados do usuário.
Compatível com Kodi 19+ / Python 3.
"""
import os

try:
    import xbmc
    import xbmcvfs
except Exception:
    xbmc = None
    xbmcvfs = None

ADDON_ID = 'plugin.video.oneplayvip'
APK_DOWNLOAD_DIRS = [
    '/storage/emulated/0/Download',
    '/sdcard/Download',
    '/storage/self/primary/Download',
]
APK_FILENAMES = [
    'OnePlayAlpha.apk',
    'OnePlayIbo.apk',
    'OnePlayXtream.apk',
]


def _log(message, level=None):
    try:
        if xbmc is not None:
            xbmc.log('[{}] {}'.format(ADDON_ID, message), level or xbmc.LOGDEBUG)
    except Exception:
        pass


def _is_android():
    try:
        return bool(xbmc is not None and xbmc.getCondVisibility('System.Platform.Android'))
    except Exception:
        return False


def _path_exists(path):
    try:
        if xbmcvfs is not None and xbmcvfs.exists(path):
            return True
    except Exception:
        pass
    try:
        return os.path.exists(path)
    except Exception:
        return False


def _delete_file(path):
    try:
        if xbmcvfs is not None and xbmcvfs.exists(path):
            return bool(xbmcvfs.delete(path))
    except Exception:
        pass
    try:
        if os.path.exists(path):
            os.remove(path)
            return True
    except Exception:
        pass
    return False


def cleanup_downloaded_apks_on_startup():
    # Fora do Android/Android TV não existe instalador APK; evita varredura e log desnecessário.
    if not _is_android():
        return []

    removed = []
    seen = set()
    for folder in APK_DOWNLOAD_DIRS:
        if not folder or folder in seen:
            continue
        seen.add(folder)
        for filename in APK_FILENAMES:
            path = os.path.join(folder, filename)
            if _path_exists(path) and _delete_file(path):
                removed.append(path)
    if removed:
        _log('Limpeza de APK no startup: {} arquivo(s) removido(s).'.format(len(removed)), getattr(xbmc, 'LOGINFO', None))
    return removed


if __name__ == '__main__':
    # Espera abortável: mais correta para services no Kodi 19+ do que sleep seco.
    try:
        if xbmc is not None:
            monitor = xbmc.Monitor()
            if monitor.waitForAbort(2.5):
                raise SystemExit
    except SystemExit:
        raise
    except Exception:
        try:
            if xbmc is not None:
                xbmc.sleep(2500)
        except Exception:
            pass
    cleanup_downloaded_apks_on_startup()
