# -*- coding: utf-8 -*-
import os
import socket
import threading
import sys
import time
import sys
PY3 = sys.version_info[0] == 3
if PY3:
    from urllib.parse import urlparse, parse_qs, quote, unquote, unquote_plus, quote_plus
    from http.server import BaseHTTPRequestHandler
    from http.server import HTTPServer
    from socketserver import ThreadingMixIn

    if sys.version_info >= (3, 7):
        from http.server import ThreadingHTTPServer
    else:
        # Criar ThreadingHTTPServer no Python 3 < 3.7
        class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
            pass
else:
    from urlparse import urlparse, parse_qs
    from urllib import quote, unquote, unquote_plus, quote_plus
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn

    # Criar ThreadingHTTPServer no Python 2
    class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
        pass
import re
import requests
import logging
import base64
from customdns import DNSOverride

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Evento para sinalizar parada do servidor
stop_event = threading.Event()

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('10.255.255.255', 1))
        local_ip = s.getsockname()[0]
    except Exception:
        local_ip = '127.0.0.1'
    finally:
        try:
            s.close()
        except:
            pass
    return local_ip

def log(msg):
    logger.debug(msg)

HOST_NAME = get_local_ip()
PORT_NUMBER = 57467

url_proxy = 'http://{}:{}/?url='.format(HOST_NAME, PORT_NUMBER)

global HEADERS_BASE, STOP_SERVER
HEADERS_BASE = {}
STOP_SERVER = False

class XtreamCodes:
    def set_headers(self, url):
        global HEADERS_BASE
        headers_default = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0',
            'Connection': 'keep-alive',
            'Accept': 'video/mp4,*/*',
            'Accept-Encoding': 'identity'
        }
        headers = {}
        if 'User-Agent' in url:
            try:
                user_agent = url.split('User-Agent=')[1].split('&')[0]
                user_agent = unquote_plus(user_agent) if PY3 else unquote(user_agent)
                if 'Mozilla' in user_agent:
                    headers['User-Agent'] = user_agent
            except (IndexError, KeyError):
                pass
        if 'Referer' in url:
            try:
                referer = url.split('Referer=')[1].split('&')[0]
                referer = unquote_plus(referer) if PY3 else unquote(referer)
                headers['Referer'] = referer
            except (IndexError, KeyError):
                pass
        if 'Origin' in url:
            try:
                origin = url.split('Origin=')[1].split('&')[0]
                origin = unquote_plus(origin) if PY3 else unquote(origin)
                headers['Origin'] = origin
            except (IndexError, KeyError):
                pass
        if headers:
            headers.update({'Connection': 'keep-alive', 'Accept': 'video/mp4,*/*'})
            HEADERS_ = headers
        else:
            HEADERS_ = headers_default
        if not HEADERS_BASE:
            HEADERS_BASE = HEADERS_

    def parse_url(self, url):
        parsed_url = urlparse(url)
        scheme = parsed_url.scheme
        host = parsed_url.hostname
        port = parsed_url.port
        return scheme, host, port

    def stream_video(self, self_server, video_url, request_data):
        try:
            video_url = video_url.split('|')[0] if '|' in video_url else video_url
            video_url = video_url.split('%7C')[0] if '%7C' in video_url else video_url
            log('Iniciando streaming para URL: {}'.format(video_url))
            DNSOverride()

            headers = HEADERS_BASE.copy()
            headers.update({
                'Accept': 'video/mp4,*/*',
                'Accept-Ranges': 'bytes',
                'Connection': 'keep-alive'
            })

            # Determinar o range solicitado
            content_length = 0
            start, end = self.get_range(request_data, content_length)
            log('Range solicitado: bytes={}-{}'.format(start, end if end != float('inf') else ''))

            if start > 0 or end < float('inf'):
                headers['Range'] = 'bytes={}-{}'.format(start, end if end != float('inf') else '')
            else:
                headers.pop('Range', None)

            # Requisição GET para obter conteúdo e metadados
            response = requests.get(video_url, headers=headers, stream=True, timeout=(3, 10), verify=False, allow_redirects=True)
            if response.status_code not in [200, 206]:
                log('Erro na requisição GET: status={}'.format(response.status_code))
                self_server.send_response(response.status_code)
                self_server.end_headers()
                return

            # Extrair Content-Type e Content-Length
            content_type = response.headers.get('Content-Type', 'video/mp4')
            if content_type == 'application/octet-stream':
                content_type = 'video/mp4'

            # Processar Content-Range
            if response.status_code == 206 and 'Content-Range' in response.headers:
                content_range = response.headers['Content-Range']
                try:
                    content_length = int(content_range.split('/')[-1])
                    range_start, range_end = map(int, content_range.split('bytes ')[1].split('/')[0].split('-'))
                    range_length = range_end - range_start + 1
                except Exception as e:
                    log('Erro ao processar Content-Range: {}'.format(e))
                    range_length = int(response.headers.get('Content-Length', 0))
                    content_range = 'bytes {}-{}/{}'.format(start, start + range_length - 1, content_length) if range_length else None
            else:
                range_length = int(response.headers.get('Content-Length', 0))
                content_length = range_length
                content_range = None
                range_start = 0
                range_end = range_length - 1 if range_length > 0 else 0

            # Validar range
            if content_length > 0 and (start >= content_length or start < 0):
                log('Range inválido: start={}, content_length={}'.format(start, content_length))
                self_server.send_response(416)
                self_server.send_header('Content-Range', 'bytes */{}'.format(content_length))
                self_server.end_headers()
                return

            # Enviar resposta
            self_server.send_response(206 if 'Range' in headers else 200)
            self_server.send_header('Content-Type', content_type)
            self_server.send_header('Content-Length', str(range_length))
            self_server.send_header('Accept-Ranges', 'bytes')
            if content_range:
                self_server.send_header('Content-Range', content_range)
            self_server.end_headers()
            log('Enviando resposta: status={}, Content-Length={}, Content-Range={}'.format(response.status_code, range_length, content_range))

            # Stream dos dados
            try:
                for chunk in response.iter_content(chunk_size=64*1024):
                    if STOP_SERVER or stop_event.is_set():
                        log('Streaming interrompido por STOP_SERVER ou stop_event')
                        break
                    try:
                        self_server.wfile.write(chunk)
                    except (ConnectionResetError, BrokenPipeError):
                        log('Cliente fechou a conexão durante o streaming')
                        break
                    except Exception as e:
                        log('Erro ao enviar chunk: {}'.format(e))
                        break
            except requests.exceptions.ChunkedEncodingError as e:
                log('Erro no streaming: {}'.format(e))
            except Exception as e:
                log('Erro geral no streaming: {}'.format(e))
            finally:
                response.close()

        except requests.exceptions.RequestException as e:
            log('Erro na requisição: {}'.format(e))
            self_server.send_response(502)
            self_server.end_headers()
        except Exception as e:
            log('Erro geral: {}'.format(e))
            self_server.send_response(500)
            self_server.end_headers()

    def get_range(self, request_data, content_length):
        range_header = None
        if PY3:
            for key in request_data:
                if key.lower() == 'range':
                    range_header = request_data[key]
                    break
        else:
            for key in request_data:
                if key.lower() == 'range':
                    range_header = request_data[key]
                    break
        if range_header:
            try:
                if PY3 and isinstance(range_header, bytes):
                    range_header = range_header.decode('utf-8')
                parts = range_header.split('-')
                start = int(parts[0].split('=')[-1])
                end = int(parts[1]) if parts[1] else (content_length - 1 if content_length > 0 else float('inf'))
                if end == float('inf') and content_length > 0:
                    end = content_length - 1
                return start, end
            except Exception as e:
                log('Erro ao processar range header: {}'.format(e))
                return 0, content_length - 1 if content_length > 0 else float('inf')
        return 0, content_length - 1 if content_length > 0 else float('inf')

class ProxyHandler(BaseHTTPRequestHandler, XtreamCodes):
    def do_HEAD(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()

    def do_GET(self):
        global HEADERS_BASE, STOP_SERVER
        if self.path == "/stop":
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(b"Server stopping...")
            STOP_SERVER = True
            stop_event.set()
            HEADERS_BASE = {}
            stop_t = threading.Thread(target=self._shutdown_server)
            if PY3:
                stop_t.daemon = True
            else:
                stop_t.setDaemon(True)
            stop_t.start()
        elif self.path == "/reset":
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(b"Server reset")
            HEADERS_BASE = {}
        elif self.path == '/check':
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(b"Hello, world!")
        else:
            url_path = unquote_plus(self.path)
            try:
                url_path = url_path.replace('VIDEO_TS.IFO', '')
            except:
                pass
            self.set_headers(url_path)
            url_parts = urlparse(url_path)
            query_params = parse_qs(url_parts.query)
            if 'url' in query_params:
                url = url_path.split('url=')[1]
                try:
                    url = url.split('|')[0]
                except:
                    pass
                try:
                    url = url.split('%7C')[0]
                except:
                    pass
            else:
                url = url_path
            if '.mp4' in url and not '.m3u8' in url and not '.ts' in url:
                log('URL: {}'.format(url))
                self.stream_video(self, url, self.headers)

    def _shutdown_server(self):
        try:
            self.server.shutdown()
            self.server.server_close()
            log('Servidor HTTP encerrado completamente')
        except Exception as e:
            log('Erro ao encerrar servidor: {}'.format(str(e)))

def monitor():
    try:
        try:
            from kodi_six import xbmc
        except:
            import xbmc
        monitor = xbmc.Monitor()
        while not monitor.waitForAbort(3) and not stop_event.is_set():
            pass
        log('Encerrando proxy server via monitor')
        url = 'http://{}:{}/stop'.format(HOST_NAME, PORT_NUMBER)
        try:
            requests.get(url, timeout=4)
        except:
            pass
        log('Proxy encerrado')
    except Exception as e:
        log('Erro no monitor: {}'.format(str(e)))

class Server:
    def __init__(self):
        self.server = ThreadingHTTPServer((HOST_NAME, PORT_NUMBER), ProxyHandler)
        self.server.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    def serve_forever(self):
        global STOP_SERVER
        try:
            self.server.serve_forever()
        except KeyboardInterrupt:
            self.stop_server()
        except Exception as e:
            log('Erro em serve_forever: {}'.format(str(e)))
            self.stop_server()

    def stop_server(self):
        try:
            self.server.shutdown()
            self.server.server_close()
            stop_event.set()
            log('Servidor HTTP encerrado')
        except Exception as e:
            log('Erro ao encerrar servidor: {}'.format(str(e)))

def loop_server():
    server = Server()
    server.serve_forever()

class XtreamProxy:
    def reset(self):
        try:
            url = 'http://{}:{}/reset'.format(HOST_NAME, PORT_NUMBER)
            requests.get(url, timeout=3)
            log('Proxy resetado')
        except Exception as e:
            log('Erro ao resetar proxy: {}'.format(str(e)))

    def check_service(self):
        try:
            url = 'http://{}:{}/check'.format(HOST_NAME, PORT_NUMBER)
            r = requests.head(url, timeout=3)
            return r.status_code == 200
        except:
            return False

    def start_(self):
        log('Iniciando Xtream Proxy - MP4RETRY')
        status = self.check_service()
        if not status:
            proxy_service = threading.Thread(target=loop_server)
            monitor_service = threading.Thread(target=monitor)
            if PY3:
                proxy_service.daemon = True
                monitor_service.daemon = True
            else:
                proxy_service.setDaemon(True)
                monitor_service.setDaemon(True)
            proxy_service.start()
            monitor_service.start()
            log('Proxy iniciado em: {}'.format(url_proxy))
            while not stop_event.is_set():
                time.sleep(1)
        else:
            self.reset()

    def start(self):
        threading.Thread(target=self.start_).start()

# if __name__ == '__main__':
#     XtreamProxy().start()
#     print('PROXY INICIADO TESTE')