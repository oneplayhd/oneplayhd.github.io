# -*- coding: utf-8 -*-
"""Resolvedor DNS alternativo conservador para o OnePlayVIP.

Baseado no dns.py enviado pelo usuário, mas adaptado para não instalar patch global
automaticamente no import. O patch só entra quando a configuração do addon permitir.
"""
import socket
import struct
import random
import logging
import sys
import json
import time
import os

try:
    from kodi_six import xbmc, xbmcaddon, xbmcvfs
except ImportError:
    import xbmc
    import xbmcaddon
    import xbmcvfs

PY2 = sys.version_info[0] == 2
ADDON_ = xbmcaddon.Addon()
TRANSLATE_ = xbmc.translatePath if PY2 else xbmcvfs.translatePath
profile = TRANSLATE_(ADDON_.getAddonInfo('profile'))
try:
    if not os.path.exists(profile):
        os.makedirs(profile)
except Exception:
    pass
CACHE_FILE = os.path.join(profile, 'dns_cache.json')

_DNS_PATCH_STATE = {
    'installed': False,
    'original_getaddrinfo': socket.getaddrinfo,
    'resolver': None,
}


def _safe_log(message, level=None):
    try:
        xbmc.log('[plugin.video.oneplayvip][dns] %s' % message, level if level is not None else xbmc.LOGDEBUG)
    except Exception:
        try:
            logging.debug(message)
        except Exception:
            pass


class customdns:
    def __init__(self, cache_file=CACHE_FILE, cache_ttl=3600, mode_logger=False):
        # DNS neutros primeiro; DNS filtrantes ficam no fim para reduzir falso bloqueio.
        self.dns_server = [
            '1.1.1.1',        # Cloudflare
            '1.0.0.1',        # Cloudflare
            '8.8.8.8',        # Google DNS
            '8.8.4.4',        # Google DNS
            '208.67.222.222', # OpenDNS
            '208.67.220.220', # OpenDNS
            '94.140.14.140',  # AdGuard
            '94.140.14.141',  # AdGuard
        ]
        self.original_getaddrinfo = _DNS_PATCH_STATE.get('original_getaddrinfo', socket.getaddrinfo)
        self.cache_file = cache_file
        self.cache_ttl = max(60, int(cache_ttl or 1800))
        self.query_timeout = 1.2
        self.max_servers_per_lookup = 4
        self.negative_ttl = 45
        self.negative_cache = {}
        self.cache = self._load_cache()
        self.mode_logger = bool(mode_logger)

    def _load_cache(self):
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'r') as f:
                    cache = json.load(f)
                current_time = time.time()
                clean = {}
                for domain, data in cache.items():
                    try:
                        if float(data.get('expires', 0)) > current_time and data.get('ip'):
                            clean[domain] = data
                    except Exception:
                        pass
                return clean
        except Exception as e:
            _safe_log('Erro ao carregar cache DNS: %s' % e, xbmc.LOGDEBUG)
        return {}

    def _save_cache(self):
        try:
            with open(self.cache_file, 'w') as f:
                json.dump(self.cache, f, indent=2)
        except Exception as e:
            _safe_log('Erro ao salvar cache DNS: %s' % e, xbmc.LOGDEBUG)

    def is_valid_ipv4(self, ip):
        try:
            socket.inet_aton(ip)
            return True
        except Exception:
            return False

    def is_valid_ipv6(self, ip):
        try:
            if hasattr(socket, 'inet_pton'):
                socket.inet_pton(socket.AF_INET6, ip)
                return True
        except Exception:
            pass
        return False

    def _normalize_domain(self, domain):
        try:
            value = str(domain or '').strip().strip('.').lower()
            if not value or len(value) > 253 or value.startswith('.') or '..' in value:
                return ''
            labels = value.split('.')
            if any((not label) or len(label.encode('idna')) > 63 for label in labels):
                return ''
            return value
        except Exception:
            return ''

    def _build_dns_query(self, domain):
        transaction_id = random.randint(0, 65535)
        flags = 0x0100
        header = struct.pack('>HHHHHH', transaction_id, flags, 1, 0, 0, 0)
        labels = []
        for part in domain.split('.'):
            encoded = part.encode('idna')
            labels.append(bytes([len(encoded)]) + encoded)
        qname = b''.join(labels) + b'\x00'
        return transaction_id, header + qname + struct.pack('>HH', 1, 1)  # A / IN

    def _skip_name(self, data, offset):
        steps = 0
        while offset < len(data) and steps < 128:
            steps += 1
            length = data[offset]
            if length == 0:
                return offset + 1
            if (length & 0xC0) == 0xC0:
                return offset + 2
            if length & 0xC0:
                return None
            offset += 1 + length
        return None

    def _parse_dns_response(self, data, expected_transaction_id=None):
        try:
            if not data or len(data) < 12:
                return None
            transaction_id, flags, question_count, answer_count = struct.unpack('>HHHH', data[:8])
            if expected_transaction_id is not None and transaction_id != expected_transaction_id:
                return None
            # QR=1 e RCODE=0: somente resposta DNS válida/no error.
            if not (flags & 0x8000) or (flags & 0x000F):
                return None
            offset = 12
            for _ in range(question_count):
                offset = self._skip_name(data, offset)
                if offset is None or offset + 4 > len(data):
                    return None
                offset += 4
            for _ in range(answer_count):
                offset = self._skip_name(data, offset)
                if offset is None or offset + 10 > len(data):
                    return None
                rtype, rclass, _ttl, rdlength = struct.unpack('>HHIH', data[offset:offset + 10])
                offset += 10
                if offset + rdlength > len(data):
                    return None
                if rtype == 1 and rclass == 1 and rdlength == 4:
                    return '.'.join(map(str, struct.unpack('>BBBB', data[offset:offset + 4])))
                offset += rdlength
        except Exception as e:
            if self.mode_logger:
                _safe_log('Erro ao interpretar resposta DNS: %s' % e, xbmc.LOGDEBUG)
        return None

    def resolve(self, domain, dns_custom):
        domain_clean = self._normalize_domain(domain)
        if not domain_clean or domain_clean in ('localhost',):
            return None
        now = time.time()
        negative_until = self.negative_cache.get(domain_clean, 0)
        if negative_until > now:
            return None
        if domain_clean in self.cache:
            try:
                data = self.cache[domain_clean]
                if float(data.get('expires', 0)) > now and data.get('ip'):
                    return data.get('ip')
                del self.cache[domain_clean]
            except Exception:
                pass
        s = None
        try:
            transaction_id, query = self._build_dns_query(domain_clean)
            if self.is_valid_ipv6(dns_custom):
                s = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
                addr = (dns_custom, 53, 0, 0)
            else:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                addr = (dns_custom, 53)
            s.settimeout(self.query_timeout)
            s.sendto(query, addr)
            data, _addr = s.recvfrom(4096)
            ip = self._parse_dns_response(data, expected_transaction_id=transaction_id)
            if ip:
                self.cache[domain_clean] = {'ip': ip, 'expires': now + self.cache_ttl}
                self._save_cache()
                if self.mode_logger:
                    _safe_log('DNS alternativo: %s -> %s via %s' % (domain_clean, ip, dns_custom), xbmc.LOGDEBUG)
                return ip
        except Exception as e:
            if self.mode_logger:
                _safe_log('Falha DNS %s via %s: %s' % (domain_clean, dns_custom, e), xbmc.LOGDEBUG)
        finally:
            try:
                if s:
                    s.close()
            except Exception:
                pass
        return None

    def _resolver(self, host, port, family=0, socktype=0, proto=0, flags=0):
        try:
            host_text = str(host or '').strip()
            if not host_text:
                return self.original_getaddrinfo(host, port, family, socktype, proto, flags)
            if self.is_valid_ipv4(host_text) or self.is_valid_ipv6(host_text):
                return self.original_getaddrinfo(host, port, family, socktype, proto, flags)
            if host_text.lower() in ('localhost',) or host_text.endswith('.local'):
                return self.original_getaddrinfo(host, port, family, socktype, proto, flags)
            # Para IPv6 explícito e Unix sockets, preserve a resolução do sistema.
            if family not in (0, getattr(socket, 'AF_UNSPEC', 0), socket.AF_INET):
                return self.original_getaddrinfo(host, port, family, socktype, proto, flags)
            for dns_server in self.dns_server[:self.max_servers_per_lookup]:
                ip = self.resolve(host_text, dns_server)
                if ip:
                    return [(socket.AF_INET, socktype or socket.SOCK_STREAM, proto or 6, '', (ip, port))]
            self.negative_cache[self._normalize_domain(host_text)] = time.time() + self.negative_ttl
        except Exception as e:
            if self.mode_logger:
                _safe_log('Erro no resolvedor para %s: %s' % (host, e), xbmc.LOGDEBUG)
        return self.original_getaddrinfo(host, port, family, socktype, proto, flags)



def install(cache_ttl=3600, mode_logger=False):
    """Instala o resolvedor alternativo no runtime Python atual."""
    try:
        if _DNS_PATCH_STATE.get('installed'):
            return True
        _DNS_PATCH_STATE['original_getaddrinfo'] = socket.getaddrinfo
        resolver = customdns(cache_file=CACHE_FILE, cache_ttl=cache_ttl, mode_logger=mode_logger)
        _DNS_PATCH_STATE['resolver'] = resolver
        socket.getaddrinfo = resolver._resolver
        _DNS_PATCH_STATE['installed'] = True
        if mode_logger:
            _safe_log('Resolvedor DNS alternativo ativado.', xbmc.LOGDEBUG)
        return True
    except Exception as e:
        _safe_log('Falha ao ativar resolvedor DNS alternativo: %s' % e, xbmc.LOGERROR)
        return False


def uninstall():
    """Restaura socket.getaddrinfo quando o recurso estiver desligado."""
    try:
        if _DNS_PATCH_STATE.get('installed'):
            socket.getaddrinfo = _DNS_PATCH_STATE.get('original_getaddrinfo', socket.getaddrinfo)
            _DNS_PATCH_STATE['installed'] = False
            _DNS_PATCH_STATE['resolver'] = None
        return True
    except Exception as e:
        _safe_log('Falha ao desativar resolvedor DNS alternativo: %s' % e, xbmc.LOGDEBUG)
        return False


def is_installed():
    return bool(_DNS_PATCH_STATE.get('installed'))
