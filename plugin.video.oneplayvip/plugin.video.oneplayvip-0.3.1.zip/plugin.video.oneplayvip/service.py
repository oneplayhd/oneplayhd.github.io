# -*- coding: utf-8 -*-
"""Service leve do OnePlayVIP no startup do Kodi.

Mantém a limpeza conservadora de APKs e prepara o EPG XMLTV em background
quando o EPG está habilitado. A navegação do addon fica lendo o índice pronto,
sem baixar XMLTV pesado ao abrir categorias de canais.
Compatível com Kodi 19+ / Python 3.
"""
import hashlib
import os
import time

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
except Exception:
    xbmc = None
    xbmcaddon = None
    xbmcvfs = None

try:
    import requests
except Exception:
    requests = None

try:
    from resources.lib import epg_runtime, storage_runtime, proxy as proxy_runtime, dns as dns_runtime
    from resources.lib.server_config import DNS_LIST_B64, get_base_url as external_get_base_url, get_current_server_choice as external_get_current_server_choice
except Exception:
    epg_runtime = None
    storage_runtime = None
    proxy_runtime = None
    dns_runtime = None
    DNS_LIST_B64 = []
    external_get_base_url = None
    external_get_current_server_choice = None

ADDON_ID = 'plugin.video.oneplayvip'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36'
HEADERS = {'User-Agent': USER_AGENT}
TRANSIENT_HTTP_STATUS = {429, 500, 502, 503, 504}

APK_DOWNLOAD_DIRS = [
    '/storage/emulated/0/Download',
    '/sdcard/Download',
    '/storage/self/primary/Download',
]
APK_FILENAMES = [
    'OnePlayAlpha.apk',
    'OnePlayIbo.apk',
    'OnePlayXtream.apk',
]

EPG_CACHE_DAYS = 1
EPG_TTL = EPG_CACHE_DAYS * 24 * 3600
EPG_INDEX_VERSION = 'oneplayvip_epg_xcpro_window_v3_service_watchdog'
EPG_INDEX_WINDOW_DAYS = 2
MAX_EPG_INDEX_FILES = 8
XMLTV_DEFAULT_OFFSET_SECS = -(3 * 3600)
EPG_BOUNDARY_TOLERANCE_SECS = 300
# Vigia conservador: verifica de hora em hora; download real continua diário/condicional.
EPG_SERVICE_CHECK_INTERVAL_SECS = 60 * 60
# Pedido criado pela UI é consumido pelo service residente, que mantém o
# contexto do addon. Dois segundos deixam a ativação perceptível sem polling
# agressivo de disco/rede.
EPG_SERVICE_REQUEST_POLL_SECS = 2
# Alterações reais do EPG recebem uma única execução após a UI persistir os
# valores. O health-check do proxy não pode disparar este caminho.
EPG_SETTINGS_DEBOUNCE_SECS = 2.0
EPG_REFRESH_MARGIN_SECS = 2 * 3600
EPG_MIN_FUTURE_COVERAGE_SECS = 12 * 3600
EPG_MIN_REFRESH_INTERVAL_SECS = 60 * 60

# Estado somente do processo service: evita repetição de mensagens e chamadas
# de stop quando ambos os proxies permanecem desligados.
_PROXY_SERVICE_STATE = {
    'enabled': None,
    'port': 0,
}


def _log(message, level=None):
    try:
        if xbmc is not None:
            xbmc.log('[{}] {}'.format(ADDON_ID, message), level or xbmc.LOGDEBUG)
    except Exception:
        pass


def _addon():
    if xbmcaddon is None:
        return None
    try:
        return xbmcaddon.Addon(ADDON_ID)
    except Exception:
        try:
            return xbmcaddon.Addon()
        except Exception:
            return None



def _log_i18n_runtime_probe(addon):
    """Registra a resolução real das labels pelo Kodi; não altera configurações."""
    try:
        if addon is None:
            _log('[I18N] Verificação não executada: addon indisponível.', getattr(xbmc, 'LOGWARNING', None))
            return
        category = str(addon.getLocalizedString(30000) or '').strip()
        proxy = str(addon.getLocalizedString(30001) or '').strip()
        stable = str(addon.getLocalizedString(30038) or '').strip()
        if category and proxy and stable:
            _log('[I18N] Labels resolvidas pelo Kodi: #30000="{}"; #30001="{}"; #30038="{}".'.format(category, proxy, stable), getattr(xbmc, 'LOGINFO', None))
        else:
            _log('[I18N] FALHA: uma ou mais labels de settings não foram resolvidas (#30000/#30001/#30038).', getattr(xbmc, 'LOGWARNING', None))
    except Exception as exc:
        _log('[I18N] Verificação finalizou com aviso: {}'.format(exc), getattr(xbmc, 'LOGWARNING', None))

def _is_android():
    try:
        return bool(xbmc is not None and xbmc.getCondVisibility('System.Platform.Android'))
    except Exception:
        return False


def _path_exists(path):
    try:
        if xbmcvfs is not None and xbmcvfs.exists(path):
            return True
    except Exception:
        pass
    try:
        return os.path.exists(path)
    except Exception:
        return False


def _delete_file(path):
    try:
        if xbmcvfs is not None and xbmcvfs.exists(path):
            return bool(xbmcvfs.delete(path))
    except Exception:
        pass
    try:
        if os.path.exists(path):
            os.remove(path)
            return True
    except Exception:
        pass
    return False


def cleanup_downloaded_apks_on_startup():
    # Fora do Android/Android TV não existe instalador APK; evita varredura e log desnecessário.
    if not _is_android():
        return []

    removed = []
    seen = set()
    for folder in APK_DOWNLOAD_DIRS:
        if not folder or folder in seen:
            continue
        seen.add(folder)
        for filename in APK_FILENAMES:
            path = os.path.join(folder, filename)
            if _path_exists(path) and _delete_file(path):
                removed.append(path)
    if removed:
        _log('Limpeza de APK no startup: {} arquivo(s) removido(s).'.format(len(removed)), getattr(xbmc, 'LOGINFO', None))
    return removed


def _safe_requests_get(url, **kw):
    if requests is None:
        raise RuntimeError('requests indisponível no Kodi')
    kw.setdefault('headers', HEADERS)
    kw.setdefault('timeout', 30)
    retries = max(0, int(kw.pop('retries', 2)))
    backoff = max(0.2, float(kw.pop('backoff', 1.0)))
    last_exc = None
    for attempt in range(retries + 1):
        try:
            r = requests.get(url, **kw)
            if r.status_code in TRANSIENT_HTTP_STATUS and attempt < retries:
                try:
                    r.close()
                except Exception:
                    pass
                time.sleep(backoff * (2 ** attempt))
                continue
            r.raise_for_status()
            return r
        except Exception as exc:
            last_exc = exc
            if attempt < retries:
                time.sleep(backoff * (2 ** attempt))
                continue
            raise last_exc


def _get_profile_dir(addon):
    try:
        return xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    except Exception:
        return os.path.join(os.path.expanduser('~'), '.kodi', 'userdata', 'addon_data', ADDON_ID)


def _get_username(addon):
    try:
        return (addon.getSetting('username') or '').strip()
    except Exception:
        return ''


def _get_password(addon):
    try:
        return (addon.getSetting('password') or '').strip()
    except Exception:
        return ''


def _get_enable_epg(addon):
    try:
        return (addon.getSetting('enable_epg') or 'false').lower() == 'true'
    except Exception:
        return False


def _epg_settings_signature(addon):
    """Assinatura mínima das configurações que realmente afetam o XMLTV."""
    if not _get_enable_epg(addon):
        return (False, '')
    try:
        return (True, _fingerprint(addon))
    except Exception:
        return (True, '')


def _epg_settings_change_requires_prepare(previous_signature, addon):
    """Retorna a assinatura atual e se a mudança exige preparar o EPG."""
    current_signature = _epg_settings_signature(addon)
    return current_signature, bool(current_signature != previous_signature and current_signature[0])


def _get_current_server_choice(addon):
    try:
        if external_get_current_server_choice:
            return external_get_current_server_choice(addon, dns_list=DNS_LIST_B64)
    except Exception:
        pass
    try:
        return max(0, int(addon.getSetting('server_choice') or '0'))
    except Exception:
        return 0


def _get_base_url(addon):
    try:
        if external_get_base_url:
            return (external_get_base_url(addon, dns_list=DNS_LIST_B64, log_fn=lambda message: _log(message, getattr(xbmc, 'LOGERROR', None))) or '').strip()
    except Exception:
        pass
    return ''


def _fingerprint(addon):
    base_url = (_get_base_url(addon) or '').strip().rstrip('/')
    username = _get_username(addon)
    password = _get_password(addon)
    raw = '{}|{}|{}'.format(base_url, username, password)
    return hashlib.sha1(raw.encode('utf-8')).hexdigest()


def _server_slot_scope_name(addon, server_idx=None):
    if storage_runtime is not None:
        try:
            return storage_runtime.server_slot_scope_name(lambda: _get_current_server_choice(addon), server_idx)
        except Exception:
            pass
    try:
        idx = _get_current_server_choice(addon) if server_idx is None else int(server_idx)
    except Exception:
        idx = 0
    if idx < 0:
        idx = 0
    return 'server_{}'.format(idx + 1)


def _server_slot_storage_path(profile_dir, addon, filename, server_idx=None):
    if storage_runtime is not None:
        try:
            return storage_runtime.server_slot_storage_path(profile_dir, filename, lambda: _get_current_server_choice(addon), server_idx)
        except Exception:
            pass
    return os.path.join(profile_dir, 'server_slot_storage', _server_slot_scope_name(addon, server_idx), filename)


def prepare_epg_xmltv_cache_on_startup(monitor=None):
    if epg_runtime is None or storage_runtime is None:
        _log('EPG service ignorado: runtime indisponível.', getattr(xbmc, 'LOGDEBUG', None))
        return False

    addon = _addon()
    if addon is None:
        return False
    if not _get_enable_epg(addon):
        return False

    username = _get_username(addon)
    password = _get_password(addon)
    base_url = _get_base_url(addon)
    if not (username and password and base_url):
        return False

    if monitor is not None:
        try:
            if monitor.abortRequested():
                return False
        except Exception:
            pass

    profile_dir = _get_profile_dir(addon)

    def ensure_profile_dir():
        return storage_runtime.ensure_profile_dir(profile_dir)

    def ensure_parent_dir(path):
        return storage_runtime.ensure_parent_dir(path)

    def load_json_file(path, default=None):
        return storage_runtime.load_json_file(path, default=default, profile_dir=profile_dir, log_fn=_log)

    def atomic_write_json(path, data, ensure_ascii=False, indent=None):
        return storage_runtime.atomic_write_json(path, data, profile_dir=profile_dir, ensure_ascii=ensure_ascii, indent=indent, log_fn=_log)

    def atomic_write_text(path, text, encoding='utf-8'):
        return storage_runtime.atomic_write_text(path, text, profile_dir=profile_dir, encoding=encoding)

    def server_slot_storage_path(filename, server_idx=None):
        return _server_slot_storage_path(profile_dir, addon, filename, server_idx)

    def epg_xml_storage_path():
        return server_slot_storage_path('epg_xmltv.xml')

    def epg_meta_storage_path():
        return server_slot_storage_path('epg_xmltv_meta.json')

    ctx = {
        'profile_dir': profile_dir,
        'username': username,
        'password': password,
        'epg_cache_days': EPG_CACHE_DAYS,
        'epg_ttl': EPG_TTL,
        'epg_index_version': EPG_INDEX_VERSION,
        'epg_index_window_days': EPG_INDEX_WINDOW_DAYS,
        'max_epg_index_files': MAX_EPG_INDEX_FILES,
        'xmltv_default_offset_secs': XMLTV_DEFAULT_OFFSET_SECS,
        'epg_boundary_tolerance_secs': EPG_BOUNDARY_TOLERANCE_SECS,
        'epg_refresh_margin_secs': EPG_REFRESH_MARGIN_SECS,
        'epg_min_future_coverage_secs': EPG_MIN_FUTURE_COVERAGE_SECS,
        'epg_min_refresh_interval_secs': EPG_MIN_REFRESH_INTERVAL_SECS,
        'honor_refresh_request': True,
        'log_fn': _log,
        'load_json_fn': load_json_file,
        'atomic_write_json_fn': atomic_write_json,
        'atomic_write_text_fn': atomic_write_text,
        'epg_meta_storage_path_fn': epg_meta_storage_path,
        'epg_xml_storage_path_fn': epg_xml_storage_path,
        'server_slot_storage_path_fn': server_slot_storage_path,
        'safe_delete_file_fn': storage_runtime.safe_delete_file,
        'ensure_profile_dir_fn': ensure_profile_dir,
        'ensure_parent_dir_fn': ensure_parent_dir,
        'safe_requests_get_fn': _safe_requests_get,
        'get_base_url_fn': lambda: base_url,
        'fingerprint_fn': lambda: _fingerprint(addon),
        'clear_desc_caches_fn': lambda: None,
        'current_server_scope_identity_fn': lambda: _server_slot_scope_name(addon),
        # Aqui o download é permitido porque service.py roda fora da navegação do usuário.
        'download_on_demand': True,
    }

    try:
        ensure_profile_dir()
        epg_runtime.epg_load_parsed(ctx, force=False)
        _log('EPG XMLTV preparado em background pelo service.py.', getattr(xbmc, 'LOGINFO', None))
        return True
    except Exception as exc:
        _log('Falha ao preparar EPG XMLTV no service.py: {}'.format(exc), getattr(xbmc, 'LOGWARNING', None))
        return False


def _epg_refresh_request_pending(addon):
    try:
        if addon is None or not _get_enable_epg(addon):
            return False
        profile_dir = _get_profile_dir(addon)
        request_path = _server_slot_storage_path(profile_dir, addon, 'epg_refresh_request.json')
        return bool(_path_exists(request_path))
    except Exception:
        return False


def _is_video_playing():
    """Evita disputar rede/CPU com reprodução ativa; o pedido fica pendente."""
    try:
        if xbmc is None:
            return False
        return bool(xbmc.Player().isPlayingVideo())
    except Exception:
        return False


_EPG_SERVICE_STATE = {
    'last_defer_log_at': 0.0,
}


def _prepare_pending_epg(monitor=None, reason='pedido_pendente'):
    """Executa EPG somente no service residente, que possui contexto do addon.

    A UI apenas grava o pedido no storage por servidor. Assim não usamos
    RunScript(service.py), que no Kodi 21 é iniciado sem addon id e perde os
    imports/resources do addon.
    """
    addon = _addon()
    if addon is None or not _get_enable_epg(addon):
        return False

    if _is_video_playing():
        now = time.time()
        if (now - float(_EPG_SERVICE_STATE.get('last_defer_log_at') or 0)) >= 60:
            _log('EPG pendente aguardando o fim da reprodução para não disputar buffer/rede.', getattr(xbmc, 'LOGDEBUG', None))
            _EPG_SERVICE_STATE['last_defer_log_at'] = now
        return False

    _log('EPG background processado pelo service residente: {}.'.format(reason), getattr(xbmc, 'LOGDEBUG', None))
    return bool(prepare_epg_xmltv_cache_on_startup(monitor=monitor))


def _wait_for_abort(monitor, seconds):
    try:
        if monitor is not None:
            return bool(monitor.waitForAbort(float(seconds)))
    except Exception:
        pass
    try:
        if xbmc is not None:
            xbmc.sleep(int(float(seconds) * 1000))
    except Exception:
        pass
    return False


def _is_custom_dns_enabled(addon):
    try:
        return bool(addon and (addon.getSetting('enable_custom_dns') or 'false').lower() == 'true')
    except Exception:
        return False


def _is_any_proxy_enabled(addon):
    """Respeita os dois controles independentes; sem chave, o proxy fica opt-in."""
    try:
        live = (addon.getSetting('proxy_live_enabled') or 'false').lower() == 'true'
        vod = (addon.getSetting('proxy_vod_enabled') or 'false').lower() == 'true'
        return bool(live or vod)
    except Exception:
        return False


def prepare_proxy_runtime_on_startup():
    """Mantém o listener local no service apenas quando Live ou VOD estão ativos.

    O plugin de navegação termina logo após setResolvedUrl; hospedar o proxy
    nele deixa VOD sujeito a corrida de encerramento. O service é o dono único
    do listener e publica a porta validada para as invocações de main.py.
    """
    addon = _addon()
    try:
        if dns_runtime is not None:
            if _is_custom_dns_enabled(addon):
                dns_runtime.install(cache_ttl=1800, mode_logger=False)
            else:
                dns_runtime.uninstall()
    except Exception as exc:
        _log('Configuração DNS do proxy finalizou com aviso: {}'.format(exc), getattr(xbmc, 'LOGDEBUG', None))

    try:
        if proxy_runtime is None:
            return False

        enabled = _is_any_proxy_enabled(addon)
        if not enabled:
            # Com default opt-in, não fica chamando stop/logando em cada ciclo.
            if _PROXY_SERVICE_STATE.get('enabled') is not False:
                try:
                    proxy_runtime.stop_proxy()
                except Exception:
                    pass
                _log('Proxy nativo em espera: VOD e canais ao vivo estão desativados.', getattr(xbmc, 'LOGDEBUG', None))
            _PROXY_SERVICE_STATE['enabled'] = False
            _PROXY_SERVICE_STATE['port'] = 0
            return True

        started = bool(proxy_runtime.start_proxy())
        if started:
            port = int(getattr(proxy_runtime, 'get_proxy_port', lambda: 0)() or 0)
            if 1024 <= port <= 65535:
                # O health-check é feito periodicamente, mas a confirmação é
                # registrada só no start/alteração de porta, não a cada 15 s.
                if (not _PROXY_SERVICE_STATE.get('enabled')) or int(_PROXY_SERVICE_STATE.get('port') or 0) != port:
                    _log('Proxy nativo OnePlayVIP pronto no service na porta dinâmica {}.'.format(port), getattr(xbmc, 'LOGINFO', None))
                _PROXY_SERVICE_STATE['enabled'] = True
                _PROXY_SERVICE_STATE['port'] = port
            else:
                _log('Proxy nativo OnePlayVIP iniciou sem publicar porta válida.', getattr(xbmc, 'LOGWARNING', None))
                _PROXY_SERVICE_STATE['enabled'] = False
                _PROXY_SERVICE_STATE['port'] = 0
                return False
        return started
    except Exception as exc:
        _log('Falha ao preparar proxy nativo OnePlayVIP: {}'.format(exc), getattr(xbmc, 'LOGWARNING', None))
        return False



def _create_service_monitor():
    """Monitor que acelera a reação a mudanças nas configurações do addon."""
    if xbmc is None:
        return None
    try:
        class _OnePlayServiceMonitor(xbmc.Monitor):
            def __init__(self):
                try:
                    super(_OnePlayServiceMonitor, self).__init__()
                except Exception:
                    pass
                # A mesma notificação do Kodi serve para proxy e EPG. O loop
                # decide qual subsistema precisa agir; não há polling de UI.
                self.settings_changed = False
                # Alias interno/legado: evita quebrar consumidores já auditados
                # que apenas observavam a reação do monitor do proxy.
                self.proxy_settings_changed = False

            def onSettingsChanged(self):
                self.settings_changed = True
                self.proxy_settings_changed = True

        return _OnePlayServiceMonitor()
    except Exception:
        try:
            return xbmc.Monitor()
        except Exception:
            return None

def run_service_loop():
    monitor = _create_service_monitor()

    _log_i18n_runtime_probe(_addon())

    # O proxy precisa estar pronto antes da primeira navegação/reprodução; EPG
    # continua com pausa leve para não disputar I/O no boot do Kodi.
    prepare_proxy_runtime_on_startup()
    if _wait_for_abort(monitor, 2.5):
        return

    cleanup_downloaded_apks_on_startup()
    if _wait_for_abort(monitor, 1.5):
        return

    try:
        prepare_epg_xmltv_cache_on_startup(monitor=monitor)
    except Exception as exc:
        _log('Service EPG inicial finalizou com aviso: {}'.format(exc), getattr(xbmc, 'LOGDEBUG', None))

    last_epg_check = time.time()
    last_epg_request_poll = 0.0
    last_proxy_check = time.time()
    # Guarda somente configurações que afetam o XMLTV. Assim, o health-check
    # periódico do proxy e alterações visuais não recriam o caminho do EPG.
    last_epg_settings_signature = _epg_settings_signature(_addon())
    epg_settings_due_at = 0.0
    try:
        while True:
            # Espera curta, sem polling de rede: quando a pessoa ativa Live/VOD
            # nas configurações, o listener do service fica disponível em até 1 s.
            if _wait_for_abort(monitor, 1):
                break
            now = time.time()
            settings_changed = bool(getattr(monitor, 'settings_changed', False))
            if settings_changed or (now - last_proxy_check) >= 15:
                prepare_proxy_runtime_on_startup()
                last_proxy_check = now

                # O mesmo monitor notifica qualquer ajuste do addon. Só agenda
                # EPG quando a configuração que o afeta mudou: habilitação ou
                # identidade do acesso/servidor. Um tick periódico do proxy, ou
                # mudança de DNS/tema/PIN, não deve reprocessar XMLTV.
                if settings_changed:
                    addon = _addon()
                    current_signature, should_prepare_epg = _epg_settings_change_requires_prepare(
                        last_epg_settings_signature, addon
                    )
                    last_epg_settings_signature = current_signature
                    if should_prepare_epg:
                        epg_settings_due_at = now + EPG_SETTINGS_DEBOUNCE_SECS
                    elif not current_signature[0]:
                        epg_settings_due_at = 0.0
                try:
                    monitor.settings_changed = False
                    monitor.proxy_settings_changed = False
                except Exception:
                    pass

            # Ativação/alteração vinda de settings: executa uma única vez após
            # a curta janela de persistência, sempre no contexto do service.
            if epg_settings_due_at and now >= epg_settings_due_at:
                try:
                    _prepare_pending_epg(monitor=monitor, reason='settings_changed')
                except Exception as exc:
                    _log('Service EPG por alteração de configuração finalizou com aviso: {}'.format(exc), getattr(xbmc, 'LOGDEBUG', None))
                last_epg_check = now
                epg_settings_due_at = 0.0

            # A navegação grava epg_refresh_request.json; o service residente
            # consome em até dois segundos. Não há RunScript avulso, portanto o
            # addon id e seus recursos permanecem válidos no Kodi 19-21.
            if (now - last_epg_request_poll) >= EPG_SERVICE_REQUEST_POLL_SECS:
                addon = _addon()
                if _epg_refresh_request_pending(addon):
                    processed_request = False
                    try:
                        processed_request = bool(_prepare_pending_epg(monitor=monitor, reason='request_file'))
                    except Exception as exc:
                        _log('Service EPG por pedido pendente finalizou com aviso: {}'.format(exc), getattr(xbmc, 'LOGDEBUG', None))
                    # Ao ativar o EPG, a UI cria o pedido de arquivo e o Monitor
                    # também notifica a mesma mudança. Se o pedido já foi atendido
                    # neste ciclo, não releia o XML/índice pela agenda atrasada.
                    # Em falha ou durante reprodução, mantém a agenda para não
                    # perder a recuperação posterior.
                    if processed_request:
                        epg_settings_due_at = 0.0
                    last_epg_check = now
                last_epg_request_poll = now

            if (now - last_epg_check) >= EPG_SERVICE_CHECK_INTERVAL_SECS:
                try:
                    prepare_epg_xmltv_cache_on_startup(monitor=monitor)
                except Exception as exc:
                    _log('Service EPG periódico finalizou com aviso: {}'.format(exc), getattr(xbmc, 'LOGDEBUG', None))
                last_epg_check = now
    finally:
        try:
            if proxy_runtime is not None:
                proxy_runtime.stop_proxy()
        except Exception:
            pass
        try:
            if dns_runtime is not None:
                dns_runtime.uninstall()
        except Exception:
            pass


if __name__ == '__main__':
    try:
        run_service_loop()
    except Exception as exc:
        _log('Service finalizou com aviso: {}'.format(exc), getattr(xbmc, 'LOGDEBUG', None))
