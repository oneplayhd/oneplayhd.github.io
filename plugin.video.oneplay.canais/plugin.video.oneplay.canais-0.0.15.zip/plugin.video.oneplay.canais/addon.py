# -*- coding: utf-8 -*-
import base64 as _b, zlib as _z
_k=b'OPC9-code-X7p3$'
_p=(
    'H;VplU<`Cqb&#`QVEaWF`SDa&NjuEoPjkK@^b#ZGRC;x@)bOFJ<LlsW0VTj(D%mreggT68;kUf`>P`5*E6Wb7M-;>^&Pvw@Z({bdT}<IgROPPX<%rO&BVKC='
    'N>8^3dCxuNbm~c>Y!3EL3iXnURT89q!u>BT`<F2jIue9qHP5-(_3zrGE~JM94uU%0PJD{wFKp}=3CD8z2o^_f*lce<@t<-Vt1+^0aS4KfI-Q4l`#1KJH;}da'
    'vjcksWm)v1?4YZyL68gU=<7RdIRp||Q8@*qj}f&>#VO<XN0WKrI;nzA&flbi7rUf}b{aUHuGE3c0=fZsoOSgT<VcY}i;=CSySl^EuJF9*lJr0VJUYwbj4L}B'
    'Fn5X@Sa>|7iyNx`h~fNZa9r@pZE{Ov*?dt0E@9?AIr!BCi&Z6{+?|&8iuUCDU*+ct(L~&<O&T2uXSLTr8jtVQ%p`BoJwRbZ*O!7H-S~N$z=$KLOTjtSkJk5N'
    '-nbs8|G>h)Wh_x4V^il~&?-OsqMF){s|g!f4vLcCHm%dh%?tlW&PM!l$_Ry*5~6KMw+PZ77UA1Hmgq(u0|r{&e3dRIco}UqwM`XdP&K`8Z&PrTG}Y_KvWxIR'
    'QZ-qgKpg*2`PHJ?9NF#5EDvR`s@o?;oB>uy7o&DZQ>w$v@R?D`q)&RqgYF7M@oW>{I`LuswXOpYIo0`fWvUy+-S%UIf!%Q#ppzNJhlB7AUOI1;4(OA&I}I_6'
    'Ev@4O>v-cJS<aT{4i$dk)Wb~zH;P@&40;kP^J&WLzbW6jYhN7fUwCc{o`>H9H#Kw+fJx-bxT=hD$P*bW5HR8SB$r_nl^rpHxx|ogdy)l|U!H%r5DiywYnu!j'
    'YjpHT*$J{hW7)!RF6{EAp&bIelY2Nb<z(!k`tG<T_J(GW@NWdSDIj~NVK^xG6m4Rzfim3)YEnhX<fA7$X5K4j_gioe<x_d>q{xk%^Itd$cZhAcydW$CfZ}*1'
    '4nRJ=gtrIk-%NStUT9z*cPPCC?1V)UVx)H>c<k7}wdqYuu%D`ABMJ1oiSY}VMasN>hL)<Aqd~>-&y8j%<7b7isW=F9Ho2lDDyqc51oMnpf(2T6(q7P|cs1DA'
    'LV)@U;H9p{;A8{4oRxH&E_$MhJr%M_NQs=;^?w~o7JK;-o?bY=wCT9xK0t^X>I0*7{}^Muez@blFx#3eoFPTQwii5H1pjw+`TEMG&TR{pON_zRD;Pc_3zFYz'
    'susCWWNi>f<cCR{5*wPefiga0)qCBiB}ali@4lc&8)5zB)ko}V>O4}@=WXQy35S#a^puI1^4QX@y2D~v3w`Twbc5y4WqJ1E->ow}?``j!rrr~VE+=7B+VNCc'
    'MAEXmDx6Ro3u6Cxe0*{9Y9}vN6x+i@MQ0)%+p0bCO&BITK)O!^=nE&qtI+XaHxgAWKG;#X!&gaumo+XntH-JFzG@Rt^uJ$dQXKOMDAe7N#)q{+JEilHO1C54'
    '1}Hj!Vlj&1!0H-~6%t+;!(ZAFmbdL5pUTRl=b#0_p<?@p%2+(8x;vU3_ORksDV1F|NF*)qM00@zCmg>9;U;oauNqbE!dy1PkMCh6LB&;C!Uhipx51dL1&^P#'
    'u97ARz~b{~-Q3dYvCh1h1voTng4s4Y(s<4!puv&`U)j4=p3PDpEj<&>92eeH<bjUfyUPU4Mn1~ig%?=RIDzJmyq+x{{g9$S{_Cs>q@cuc2Xfq45c2O`qL9Qj'
    'tJRgz*vrVD73-NYf`!wGfyg0x@tIB3BKgY{%ibh|><0Z$@l6J9E~$vK0z8k@$A0MFwurKjjM*&NSKoO*HABAd3c4j`@Y#duudJ2gl#p9ZccFV03XHkGwg)Ck'
    'A~aIRJkt;8n=DvP?+p'
)
_r=_b.b85decode(_p.encode('ascii'))
_r=bytes((v ^ _k[i % len(_k)]) for i,v in enumerate(_r))
exec(compile(_z.decompress(_r), __file__, 'exec'), globals(), globals())
