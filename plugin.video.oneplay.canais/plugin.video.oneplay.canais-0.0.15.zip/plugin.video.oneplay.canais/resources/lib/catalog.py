# -*- coding: utf-8 -*-
import base64 as _b, zlib as _z
_k=b'OPC9-code-X7p3$'
_p=(
    'H;V3V@(i?6byKfsu~G~NJ@M(P6@+Gi>=1?BYc)s-95ZfkNA1(}k&`juO7rr(!oy32!+;1^{4)`?kc~dh+>OT=D$8g4Ig)SYW)$7cwVV^(AIpr*1*)rz$)@vH'
    '0Q<;$m4wFr_i)9JqRPY*Gm)|(ZUz;cKMa`QK@t?-*$R&;QfkB?Mvf=CsNe-=z0m|L>aKL5gXFs!+yF+gABZPd>8DP0Q8}&wb9y>BpB=FehBt03ZUkP%BXuPQ'
    '^@A`G8m$4K1-5$<vRJ93*5`tMFlDjaHcK1R*7?Gy;ex+3iCWD1{HSN?5viaOgP?2()Hw6T&NSI5Q}5+x!rY~u?}~s*@dJK>xo{0(hnze*1SbJuDiviS&i_M2'
    'Yiukp+>^0KV<|c^(>`gW-s!t=nWqG>M-d4giaKu?+o;9@t%0}&b4hQdL5qQxN#zM_Su;yO&ND62S@dg=&tZG8HieKiuEy_<Fm({%=Z8rWbZARlb35>l6>tnL'
    '2F*e&CZ<X>50xIWN<)MM@yJ5?Np5wnWv>Yr1lu#q%dO~kHw<$k&eKVE;lZv)jHOWs*kmSH6Y?8l6;44ST6z^!X80PGf+QZr?hl|}ylec2ow?@Z?9G9AXwOOy'
    'z68sJ4iu5=u_w*5#eE?gOaWFkK0=F%GiDo3qQ8o*p~SLEHkS|P5%&EeKj9iqTv>Oe6-F3=ES>ja*{aEfpLeBd`Rnb3fB5^MPF${{aNB3hOo99Qxqk#csmq1>'
    'mWHW`${D+>F`DW$SJn9oq4Ne^uJYt=6_=@O`SZR4N^Av|n`KP^lOs2<)4qc7Y<$DPd1FuRoNkIQ`?d@YA@b7t*#$@c^Vu?YM=r%2-`k~{sM4dM1>JmA%ikN)'
    '3Ys`JB~vMojx6{~LC`5jsFSAES}HKgx(X$==5d`#2c3s3y3?Wwi;{g?I5h=G?8+H}Iah)v1$%6NUQ#p(RAp*nkq%A9RJ3>nC&G<^)<^yJSAm)TkZhwRbdB`y'
    'kd2{Rj-XmP0I}-}m^1*~W9W<(N<3apW@rF)e4&{9Emvv*kq>y(>mqSAJRxBaE{7}!pkx@<fX$++77t3-RP}fWk#6OBD=#E4c6)}SVz4OfWCCKjY_iW3AYyBv'
    '_KY;CtgkR1qin;vD{QJz<2AP$AXU(e15CgD#~Vd&ag8&|OIQA)(Dd3Nj=-l34Nl;;j=MzDpJ)if!{8S#`xJD@$)6LaTuhEkb4on4b15ZV&2QSycY1{W*bNPH'
    'R#@3p)AGD=bx7ZzSuhKsQTEK%gB;xYv!V4X!JBN%m^t7s>e1`tBVMHdrk!S=ZNH*-uUHYHRoW_hDZ;}I?^~H(YfH=dU&y?51V2G6+p5Ytip%oCw(DUrFOiBl'
    ';Q~kt74F6u^aSlaROcMC#e}o7>Y6^5AdDR!P7srX=YmYjsv9C$UyloyUsuNziKA&uT;U;_C_1s8_=OK$F+&Ib@FG-X2x(wJbT8^r0bxx5S*~~}2nhG9q?kKa'
    'O9^XLGxjPJ9}ZAH5P8d|4ESzG`)9CjeWYuZ2WZD#>jZme=roo9?R{1`t6!FRX{qWQURv%1(g${`W`R1;p~Fx2CMz)Qc>_?wFRdDEbfcCNSM3;$j^H)6u0C$P'
    'CYBs-C|`Py'
)
_r=_b.b85decode(_p.encode('ascii'))
_r=bytes((v ^ _k[i % len(_k)]) for i,v in enumerate(_r))
exec(compile(_z.decompress(_r), __file__, 'exec'), globals(), globals())
