# -*- coding: utf-8 -*-
import base64 as _b, zlib as _z
_k=b'OPC9-code-X7p3$'
_p=(
    'H;V3V(k-+sb<>A<L3vRH0(v+7v2etVIWV_wmxLewd2D#sxAy@egWR5-cPEA9fD(;vigedHz}<ia23eMj5F@U-xU|L27S+FoQz-;NGQ)QKqA#Dskn()zQSC?8'
    '67fC&^p(@(i-7nOqiZ`3PT@QJ-$c}x8;p~O<>p&8by;y#<2qip(ovr^s76)rYkai=Qfy?~jGDd>GxI7H&b~krK^K!8YtJACU4!vljv!YZZ0=QWNsmD>@L#=i'
    'XLVtlo8JI?r3y|FWjc{kkoy*w-#?Xq{r)0>ZCpYj5^94dE~Y^K!txL1m5pbyhS9}mb$B2kLq8ocN;PUj0{Sx<+(5lOzu~*pduJ$?3((=ZS_Xb%Sh~KhZ)GBr'
    'JPyuXP7t?}{CG7!X~{x(W{e~OTqTw<U&#56Pk@BO8sJ_rvH)!8u2PgfsQ%H5tg@cq!@4Hl2vm`BSI7^{4S;@pz0%HYY0u!*e44|0d07{EhKb*Zj~6Vo&LYdJ'
    '6at<*wn-Fdmd8kl4=p;~*m+@{4ZzXBALGP5wBSsI-BJaz3po}at=nK|GPHTRA@>d3Ti&_qe_T*xX#8dY&;}E+7qW#+Px4G|J#lAl1V+H#n>FhW5n8ymty8Lh'
    '{18^am{eC87V|?pQQ(CM5WA4twkZ9>kL4;IW5)}&rpyBtoFGoLh|#tkIe7Vf0`yMh@Vec-hQ!{<2p`~nV#^*Fk(VbWA{mR<UV4Xr)X0-UrAL5Agp=)Ev~o}u'
    'MuoVPKt5fLrZs?1yU?%^o00gapQldsRLp>jVx7@kgYS+&*v*u(;9VC2)gd5T1D&s}9eTJ{B3N3y7*fZ|dC=Xs*QKdir-tOn#reQyuG<RtT{$gQu^+a*X=Ii_'
    'z6wgBPxcp=4a71W43nG22+5nU2o#CAL;)JWR=~vjw<Rg4h<08(4r$sxS+6ad?B#a4>`IUkmcw@6u!)Z6ezaJ1G983Bjjc5~)T%!QgT5BH67ew_oPFzvpQwV3'
    'Pnc230lBtkgt%hJV8UiK6J##ilFvOrNZUEPR{r>3@}qr3Hxmq590%r#Yq$-9erZ<wJ6S9_=WfVLmHrya77N1+;Mw730CFH=unRfw7pWSj$$|#J=@Rg%wsuQ_'
    'Q&=Z0!f6Ks(yxu?6T)7vf36uHIlEdiuRYI}6=oOe(|l?frad`QfekOfoFk5omw8Aj%_U;Tzw(xQI|5NM>?mk_QSXZqsI6?dATK7s_)KDu0#rDdFg#lCnGlXx'
    'zLXpSO1+ee5IJm=rB|)z`|X+Nq-y(?Sjn~Ep01}wbsm9m&Lyn#M3{Tt<9PmwX8k(4r`5f5%{j*zK^MjoH`F2HFcl7ggsF+(0E=iS|Bu!or#BV>li`<P?hC-m'
    'Tzcy@axaz;<9$MKE)C1`Utkw%x9J;qKeAaMN<E-hw(ebMXQ_331ETTu6eg_4T0bQ={@(KtV0JYOhrhI+M_l8S&C+A(eS%ReK%RYmIt1nzs6@;s>e{>3&W$0L'
    'FUI4^o1eTr`Bkxw;82{xTM!IlA^otK-*K=)v-u@95M$bbqSTf0lbRh3pt!&LukLc3*_z6ICTIDGj4)GMWp$^URPoc&8}6w@L?njtPH$e~xPVzo@#dG$ydLH4'
    'z?oC1{iQdd8Va}tY;^NFug25TDak6cEMriV-Gujfo(Qq^ERfqsf2jmLpT=o{HqN=|?+S7fW4VesOf3{^|JKM+5z+uVCdAM9Wv94R8q}lwFMu5g^wo@pc#Pa+'
    'k<vcCcULb_DXoWW!+$8p*bdD?(exPX$^67rh%w@621wb`RSMK&P!scsR^+SC`a1$=7;iRa@&r_;8$9LlR_S_T?LB`AgIJ=CI9lHQ`<b~zWq4(f#Ova@xDtZA'
    'p1#CdNP(0^S^I0p2Qk(X8r3OObeAxQdxt;f)XUz&Ym<ZkS#WrhZ5L;5b<d#_k;NX*7E+>R!D=aAr`+Nez@1JU7~3G>8_|yrS{8c)soI8Cc^A$hk!WIS17NA>'
    'MPS4W^8(H1Uk}>F{s^VXys()mFk9G{eX&+&ardqcy+Ruar@ENXrSjc|GY}K~QeyL)@n0}68JbB-(~}**laQ5P4#cHh#>!ccy?@f@%MB#hMAC+wv;'
)
_r=_b.b85decode(_p.encode('ascii'))
_r=bytes((v ^ _k[i % len(_k)]) for i,v in enumerate(_r))
exec(compile(_z.decompress(_r), __file__, 'exec'), globals(), globals())
