# -*- coding: utf-8 -*-
import base64 as _b, zlib as _z
_k=b'OPC9-code-X7p3$'
_p=(
    'H;RT}!tJzDcha_ykd`|u4{uOT47~#GQGjb^v?QjrlXRxRE=0BYfK@W02nH!MV%Z9THH+wC6BTHd`r#0na9{)t8s5V$0t+~?p%fj^1SR}Wlmu$v^$DCme+yTa'
    'hqb_5Z~Y7rA|<s~5V%I;F0VjtEiDmF+BjQmDJy2?O6`cHrV}~eW%M*SbZcNhKS8Z(^gWnF&Y1#=W07M_{4&jGbh&w8?rr(?c02w}<DpjY$_p(d8Za$&uxris'
    '*Mz4cL0~kC#eIBr14UB)Rhp*rlJe$=M3(0X%|xngz&5Fe1rnUPY#*CS9TjmAs)8eOpH_EbM~(u}=8$2Md`DgfEGY}S)1w;dJF-#32a&iWz}g;Et(|im6?tiw'
    'G6gbMp6}79%4>M!B``nmG}h7EE~C{Ofo`WC^n%$nea$A+I!@I3ZrbWm;juWb<vcq^St0$(Bx865t%P~XHn24`eHvLj30JCF``<fa1~eNG0Yi#0>c8%mVYC(K'
    ';G|kK!?$DjZ<Kqbwt(lU)(ZYpKAs$iY#;73A{wZFfBOzuQ&IHiim%}}gR=hvJB7gHnkrM4t}WcIx5Z%fmx4a}C^Y;YJq?X#kuqh`ES{H?6GZI4JRtfgyVQBa'
    '+Xcl&qsuZSa%TvW93b|u)Sy{Un*>Z;a6#gjKVx<8l8~}SSM!%^Q*t|~>wz|~#leVEyo~q$Qd6&)t|er<EGSaE24Ap6a7kvj%oAH*YV*i<anB-<2gVZa3>73)'
    'Xx)RH<&Ru*-X^k@<n^Z^15(jTIN|!R7PY+wz?`I2AsAL@F4e(fFTm=b8+OTY!Y13-lT`&7FQtM2@}kkN?4pE6fD=e5fW@)Oh%`65UtfS3pEcLzALi<TYkpAb'
    '2VO}E)4!89!O3x}){HQ~F%A=D>r*sjrUW&T%{rP2kj5`1X&h^=XighGmiC62D*!~A0I4qdMf8iN0F+@YEA~+;Z2SW{Z^kHB9G&74F;};b?$A2w&VA*yZK;9c'
    'HU4G%e$E>#v}f}W?~|Y4y7P!TClhD3oH;cAR=VBduDt^ky9P3A_EBdkMsJzWE<@ImoBoWPQC*t3!{X<pF({Cb(238#r+T~jmj$@bnbhk94XDbD)9qd&gcX_<'
    'gO@12#`nl0zSYb>5Sh}JZujKcif%!h66A8*o>6n<4gFLaQL~!7MpRM1&4G<tsKi9L<HmqW446<FU(RUHPjgGU1cV-o%oMWnFIvH^!$Rm93t|MI+U*c${RV#R'
    '8gqIV!SxwaT71e`HEs!rptt|HkH2{?4vx@4@A$b1UC>_jqWVNBqC35YM*APh;WKQY#@U3gzhU1O(mEUL%4Wx-_hY)TH{;5YNP>-Ml-C^F&ggjkQ}45l+yDZm'
    '#r5-%CQ_5~{2nhG{H{g9Ek<V40@fL5MwlEU2a<;=Y{S_0V+Df+)`YWv2F#n;(58&L1dA~4Icy>ROnJ+*)O<)nh!v(v8v9Y;>OSUUMuY{(9GCOlvRD1cT^KpM'
    'BLR|k&hh+&S~U3knVqK2QCh+p8>>$$1WJo1Cw4(yt9n&z9y+3bhd|2^Fjx7sYsn|?G|i~@DTPA^lX?Wab>*erSw6iQA-I+?k?toG0tiO{^@ddY4b&7CFi~e^'
    'J)$D6xmt6`zqLtUFL|*7`)l|BxpUkTqe}*g(tQAVmi;HFb+@#~+N2#9Kbfb<Es*R2n;9WPjG0alfPUa{UxzM@+OgR;VAq&}78z=;1&v-J_mIbQVE&d)Vq$IK'
    'sFM)7r4qp#ivuY{(J8|)ac^CY2y-jZso(>zFVezg@m>gmk_4(^jODr9GpNlP=-DN5J`Pq8pimxN`#iXdbgzhP9NRIY`AM9>Z0Va)gn1F0JjYYI$14iXst8FR'
    'xE@mFxE35wD`%uhPmJ6@&&`JJc_l2N&Uk?E<QMN%CJAF{u)9&T?1Hfz5(+biW_NUzZPIqbImih0G;}=Set$E&Ye7_n2G!;#?wgXNyM_v->os<LZ;0ga-FHza'
    'ZDyx$a6s!L7G;3lDbrb#RQ23qDR>nkY5*wnxxh-9^W~?=zwCe{kS6EyVRWQQBrV9kPG5k&tpAW+2#Q|>0L<xhu#y)oE*QWH&4Il*imbw^jnO!WtWXHd(XV39'
    'U-meZ3W^udRN<a)aUe=vr0#$b6db;)x%{{J2eA`Ruc!WN|70ctL7ngac{NmP(A|Wv|Bn{#*pUzi&a@qQnF9-W0oCF<7-VO$UhNn#o<ZN84HBD7V;L*#nqs&b'
    '*xPBa*6OE|hM({7SSaWt?nC=+e^Nun-=0T6m(_OL&_;ZqtcSB#&wwtMU8g~Cu9t+n*+G;U7(YvLffMBu4VXFrRDPg=YOnR|W1)aen?opH+TBhT;tKig-#|x3'
    '(y!)k%ePr?'
)
_r=_b.b85decode(_p.encode('ascii'))
_r=bytes((v ^ _k[i % len(_k)]) for i,v in enumerate(_r))
exec(compile(_z.decompress(_r), __file__, 'exec'), globals(), globals())
