# -*- coding: utf-8 -*-
"""Primitivas compartilhadas do XC Pro.

Sem dependência do Kodi para que possam ser usadas tanto pelo plugin quanto pelo
serviço persistente e pelo proxy local.
"""

import hashlib
import json
import os
import re
import tempfile
import time
from urllib.parse import unquote


_FINGERPRINT_PREFIX = 'xcpro-login-v5:'
_SENSITIVE_QUERY = re.compile(r'(?i)([?&](?:username|user|password|pass|token|auth|key|signature)=)[^&\s]+')
_XTREAM_PATH = re.compile(r'(?i)/(live|movie|series)/[^/]+/[^/]+/')


def credential_fingerprint(host, username, password):
    """Identificador estável sem gravar credenciais em cache ou log."""
    raw = '{}\x00{}\x00{}'.format(host or '', username or '', password or '')
    digest = hashlib.sha256(raw.encode('utf-8', 'replace')).hexdigest()
    return _FINGERPRINT_PREFIX + digest


def redact_url(value):
    """Oculta credenciais Xtream e tokens antes de escrever em logs."""
    text = str(value or '')
    if not text:
        return ''
    # O proxy recebe URLs percent-encoded em ?url=. Decodificar antes de
    # mascarar evita que credenciais escapem para o kodi.log.
    try:
        text = unquote(text)
    except Exception:
        pass
    text = _SENSITIVE_QUERY.sub(r'\1***', text)
    text = _XTREAM_PATH.sub(lambda match: '/{}/***/***/'.format(match.group(1)), text)
    return text


def atomic_write_json(path, data):
    """Grava JSON por substituição atômica para não deixar cache corrompido."""
    directory = os.path.dirname(path) or '.'
    tmp_path = None
    try:
        if not os.path.isdir(directory):
            os.makedirs(directory)
        fd, tmp_path = tempfile.mkstemp(prefix='.xcpro_', suffix='.tmp', dir=directory)
        with os.fdopen(fd, 'w', encoding='utf-8') as file_obj:
            json.dump(data if data is not None else {}, file_obj, ensure_ascii=False)
            file_obj.flush()
            try:
                os.fsync(file_obj.fileno())
            except OSError:
                pass
        os.replace(tmp_path, path)
        return True
    except Exception:
        if tmp_path:
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        return False


def utc_now():
    return int(time.time())


def write_response_to_tempfile(response, directory, max_bytes):
    """Persiste resposta requests por streaming e devolve amostra para validação.

    Retorna ``(tmp_path, total_bytes, sample)``. Em erro, retorna ``(None, 0, b'')``.
    O chamador decide se a amostra é válida e faz ``os.replace`` apenas depois.
    """
    tmp_path = None
    try:
        content_length = int(response.headers.get('Content-Length') or 0)
        if content_length and content_length > max_bytes:
            return None, 0, b''
    except Exception:
        pass
    try:
        if not os.path.isdir(directory):
            os.makedirs(directory)
        fd, tmp_path = tempfile.mkstemp(prefix='.xcpro_epg_', suffix='.tmp', dir=directory)
        total = 0
        sample = bytearray()
        with os.fdopen(fd, 'wb') as file_obj:
            for chunk in response.iter_content(chunk_size=65536):
                if not chunk:
                    continue
                total += len(chunk)
                if total > max_bytes:
                    raise ValueError('resposta excede o limite permitido')
                if len(sample) < 1024:
                    sample.extend(chunk[:1024 - len(sample)])
                file_obj.write(chunk)
            file_obj.flush()
            try:
                os.fsync(file_obj.fileno())
            except OSError:
                pass
        if total <= 0:
            raise ValueError('resposta vazia')
        return tmp_path, total, bytes(sample)
    except Exception:
        if tmp_path:
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        return None, 0, b''
