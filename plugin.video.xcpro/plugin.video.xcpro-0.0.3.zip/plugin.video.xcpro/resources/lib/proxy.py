# -*- coding: utf-8 -*-
import socket
import threading
import time
import re
from urllib.parse import urlparse, unquote, urljoin, quote
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
import ssl
from collections import deque
import gzip
import zlib
import socketserver
#from http.server import HTTPServer, BaseHTTPRequestHandler, ThreadingHTTPServer
import http.client
from urllib.parse import urlsplit

import dnsresolver
from xcpro_core import redact_url

dnsresolver.install()

try:
    import xbmc
except Exception:
    xbmc = None

def log(msg, level=None):
    try:
        if xbmc:
            if level is None:
                level = xbmc.LOGINFO
            xbmc.log("[XC Pro Proxy] {}".format(redact_url(msg)), level)
        else:
            print("[XC Pro Proxy] {}".format(redact_url(msg)))
    except Exception:
        pass

# ==================== CONFIGURAÇÕES ====================
PROXY_PORT = 9097
CACHE_DURATION_SECONDS = 5
CACHE_MAX_CHUNKS = 250
MAX_RETRIES = 3
RETRY_DELAY = 0.4
BUFFER_SIZE = 32768
CHANNEL_TIMEOUT = 12
VOD_TIMEOUT = 20
MAX_CHANNEL_CACHES = 4
MAX_VOD_CACHES = 4

CHROME_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/130.0.0.0 Safari/537.36"
)

def get_origin(url):
    try:
        parsed = urlparse(url)
        if parsed.scheme and parsed.netloc:
            return "{}://{}".format(parsed.scheme, parsed.netloc)
    except Exception:
        pass
    return ''

# DNS é fornecido por dnsresolver.py e fica restrito aos hosts registrados pelo XC Pro.


# ==================== CACHE CIRCULAR PARA CANAIS ====================
class CircularBuffer:
    def __init__(self, max_seconds=5, max_chunks=250):
        # Sem maxlen: a remoção explícita mantém total_bytes correto.
        self.buffer = deque()
        self.timestamps = deque()
        self.max_seconds = max_seconds
        self.max_chunks = max_chunks
        self.total_bytes = 0
        self.stream_offset = 0
        self.lock = threading.Lock()
        self.last_update = 0
        self.last_access = time.time()
        self.stream_started = False

    def _trim_locked(self):
        cutoff = time.time() - self.max_seconds
        while self.timestamps and (len(self.buffer) > self.max_chunks or self.timestamps[0] < cutoff):
            removed = self.buffer.popleft()
            self.timestamps.popleft()
            self.total_bytes = max(0, self.total_bytes - len(removed))

    def touch(self):
        with self.lock:
            self.last_access = time.time()

    def add_chunk(self, chunk):
        if not chunk:
            return
        with self.lock:
            self.buffer.append(chunk)
            self.timestamps.append(time.time())
            self.total_bytes += len(chunk)
            self.stream_offset += len(chunk)
            self.last_update = time.time()
            self.last_access = self.last_update
            self._trim_locked()

    def get_recovery_chunks(self, duration=3):
        with self.lock:
            self.last_access = time.time()
            if not self.buffer:
                return []
            cutoff = time.time() - duration
            recovery = [chunk for chunk, ts in zip(self.buffer, self.timestamps) if ts >= cutoff]
            if not recovery:
                recovery = list(self.buffer)[-20:]
            return recovery

    def get_continuous_chunks(self, count=30):
        with self.lock:
            self.last_access = time.time()
            if not self.buffer:
                return []
            return list(self.buffer)[-count:]

    def reset_after_upstream_restart(self):
        with self.lock:
            self.buffer.clear()
            self.timestamps.clear()
            self.total_bytes = 0
            self.stream_offset = 0
            self.stream_started = False
            self.last_access = time.time()

    def clear(self):
        self.reset_after_upstream_restart()


# ==================== CACHE MP4 (para seek rapido) ====================
class MP4Cache:
    def __init__(self, max_chunks=250):
        self.chunks = {}
        self.max_chunks = max_chunks
        self.lock = threading.Lock()
        self.total_size = 0
        self.content_length = None
        self.last_access = time.time()

    def touch(self):
        with self.lock:
            self.last_access = time.time()

    def add_chunk(self, start_byte, data):
        if not data:
            return
        with self.lock:
            self.last_access = time.time()
            if start_byte not in self.chunks:
                self.chunks[start_byte] = data
                self.total_size += len(data)
                while len(self.chunks) > self.max_chunks:
                    oldest = min(self.chunks.keys())
                    self.total_size -= len(self.chunks[oldest])
                    del self.chunks[oldest]

    def get_range(self, start, end):
        with self.lock:
            self.last_access = time.time()
            keys = sorted(self.chunks.keys())
            if not keys:
                return None

            result = bytearray()
            pos = start

            while pos < end:
                found = False
                for chunk_start in keys:
                    chunk = self.chunks[chunk_start]
                    chunk_end = chunk_start + len(chunk)
                    if chunk_start <= pos < chunk_end:
                        offset = pos - chunk_start
                        take = min(end - pos, chunk_end - pos)
                        result.extend(chunk[offset:offset + take])
                        pos += take
                        found = True
                        break
                if not found:
                    return None

            return bytes(result)


# ==================== PROXY HANDLER ====================
class UnifiedProxy:
    def __init__(self):
        self.channel_caches = {}
        self.mp4_caches = {}
        self.strict_ssl_context = ssl.create_default_context()
        self.legacy_ssl_context = ssl.create_default_context()
        self.legacy_ssl_context.check_hostname = False
        self.legacy_ssl_context.verify_mode = ssl.CERT_NONE
        self.stream_lock = threading.Lock()
        self.cache_lock = threading.Lock()

    @staticmethod
    def _certificate_error(exc):
        reason = getattr(exc, 'reason', exc)
        return isinstance(reason, ssl.SSLCertVerificationError) or 'CERTIFICATE_VERIFY_FAILED' in str(reason)

    def _open_request(self, request, timeout):
        dnsresolver.register_url(request.full_url)
        if not request.full_url.lower().startswith('https://'):
            return urlopen(request, timeout=timeout)
        try:
            return urlopen(request, timeout=timeout, context=self.strict_ssl_context)
        except URLError as exc:
            # Compatibilidade pontual para fornecedores com certificado quebrado.
            if self._certificate_error(exc):
                log('Certificado TLS inválido; usando compatibilidade apenas nesta conexão.', getattr(xbmc, 'LOGWARNING', None))
                return urlopen(request, timeout=timeout, context=self.legacy_ssl_context)
            raise

    @staticmethod
    def get_local_ip():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(('1.1.1.1', 80))
            return s.getsockname()[0]
        except Exception:
            return '127.0.0.1'
        finally:
            s.close()

    def extract_url_from_path(self, path):
        # /?url=XXX (formato usado pelo Kodi)
        log('EXTRAINDO URL DE: {}'.format(path))
        if '/?url=' in path:
            url_part = path.split('/?url=', 1)[1]
            if '&' in url_part:
                url_part = url_part.split('&', 1)[0]
            if ' ' in url_part:
                url_part = url_part.split(' ', 1)[0]
            return unquote(url_part)

        # /tsdownloader?url=XXX
        if '/tsdownloader' in path and '?url=' in path:
            params = path.split('?', 1)[1]
            for param in params.split('&'):
                if param.startswith('url='):
                    return unquote(param[4:])

        # /http:// ou /https://
        if path.startswith('/http://') or path.startswith('/https://'):
            return unquote(path[1:])

        # http:// ou https:// direto
        if path.startswith('http://') or path.startswith('https://'):
            return unquote(path)

        return None

    @staticmethod
    def _cache_key(url):
        return re.sub(r'([?&](?:_=|timestamp=|t=|seq=)\d+)', '', url)

    @staticmethod
    def _prune_cache_map(mapping, limit):
        while len(mapping) >= limit:
            oldest_key = min(mapping, key=lambda key: getattr(mapping[key], 'last_access', 0))
            mapping.pop(oldest_key, None)

    def get_channel_cache(self, url):
        clean_url = self._cache_key(url)
        with self.stream_lock:
            if clean_url not in self.channel_caches:
                self._prune_cache_map(self.channel_caches, MAX_CHANNEL_CACHES)
                self.channel_caches[clean_url] = CircularBuffer(CACHE_DURATION_SECONDS, CACHE_MAX_CHUNKS)
            cache = self.channel_caches[clean_url]
            cache.touch()
            return cache

    def get_mp4_cache(self, url):
        clean_url = self._cache_key(url)
        with self.cache_lock:
            if clean_url not in self.mp4_caches:
                self._prune_cache_map(self.mp4_caches, MAX_VOD_CACHES)
                self.mp4_caches[clean_url] = MP4Cache(CACHE_MAX_CHUNKS)
            cache = self.mp4_caches[clean_url]
            cache.touch()
            return cache

    def fetch_channel_with_fallback(self, url, headers=None, range_header=None, cache=None, method='GET'):
        headers = headers or {}
        for attempt in range(MAX_RETRIES):
            origin = get_origin(url)
            req_headers = {
                'User-Agent': CHROME_UA,
                'Accept': '*/*',
                'Accept-Language': 'pt-BR,pt;q=0.9',
                'Connection': 'keep-alive',
            }
            if origin:
                req_headers['Origin'] = origin
                req_headers['Referer'] = origin + '/'
            for key, value in headers.items():
                if key.lower() not in ('host', 'connection', 'content-length', 'range', 'user-agent', 'accept-encoding'):
                    req_headers[key] = value
            if range_header:
                req_headers['Range'] = range_header
            try:
                req = Request(url, headers=req_headers, method=method)
                response = self._open_request(req, timeout=CHANNEL_TIMEOUT)
                status_code = response.getcode()
                content_encoding = response.headers.get('content-encoding', '').lower()
                if status_code not in (200, 206):
                    response.close()
                    return None, status_code, None
                return response, status_code, content_encoding
            except HTTPError as exc:
                if attempt < MAX_RETRIES - 1 and exc.code in (403, 406, 451, 500, 502, 503, 504, 523):
                    time.sleep(RETRY_DELAY * (attempt + 1))
                    continue
                return None, exc.code, None
            except Exception:
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_DELAY * (attempt + 1))
                    continue
                return None, 0, None
        return None, 0, None

    def rewrite_m3u8_urls(self, playlist_content, base_url, proxy_host):
        def proxify(raw_url):
            raw_url = raw_url.strip()
            if not raw_url or raw_url.startswith('#'):
                return raw_url
            try:
                absolute = urljoin(base_url + '/', raw_url)
                if absolute.startswith('http://127.0.0.1') or absolute.startswith('http://localhost'):
                    return absolute
                if absolute.startswith(('http://', 'https://')):
                    return 'http://{}/?url={}'.format(proxy_host, quote(absolute, safe=''))
            except Exception:
                pass
            return raw_url

        uri_attribute = re.compile(r'(?P<prefix>\bURI=)(?P<quote>["\'])(?P<value>.*?)(?P=quote)')

        def replace_uri(match):
            return '{}{}{}{}'.format(
                match.group('prefix'), match.group('quote'),
                proxify(match.group('value')), match.group('quote')
            )

        lines = []
        for line in playlist_content.split('\n'):
            line = line.rstrip()
            if line and not line.startswith('#'):
                line = proxify(line)
            elif line.startswith('#'):
                # Chaves AES, mapas de inicialização e playlists iframe também
                # precisam passar pelo proxy para herdar DNS/headers internos.
                line = uri_attribute.sub(replace_uri, line)
            lines.append(line)
        return '\n'.join(lines)

    def handle_channel_stream(self, url, headers, wfile, method='GET'):
        cache = self.get_channel_cache(url)
        response = None
        
        try:
            log("Iniciando stream de canal: {}".format(url[:80]))
            response, status_code, content_encoding = self.fetch_channel_with_fallback(url, headers, None, cache, method=method)
            
            if response is None:
                recovery_chunks = cache.get_recovery_chunks(CACHE_DURATION_SECONDS)
                if recovery_chunks:
                    # Enviar como MPEG-TS
                    wfile.write(b"HTTP/1.1 200 OK\r\n")
                    wfile.write(b"Content-Type: video/mp2t\r\n")
                    wfile.write(b"Access-Control-Allow-Origin: *\r\n")
                    wfile.write(b"Cache-Control: no-cache\r\n")
                    wfile.write(b"Connection: keep-alive\r\n\r\n")
                    
                    for chunk in recovery_chunks:
                        try:
                            wfile.write(chunk)
                            time.sleep(0.03)
                        except:
                            break
                else:
                    return
            
            if response and status_code in [200, 206]:
                content_type = response.headers.get('content-type', '').lower()
                content_url = response.geturl()

                if method == 'HEAD':
                    wfile.write('HTTP/1.1 {} OK\r\n'.format(status_code).encode())
                    wfile.write('Content-Type: {}\r\n'.format(content_type or 'application/octet-stream').encode())
                    if response.headers.get('content-length'):
                        wfile.write('Content-Length: {}\r\n'.format(response.headers['content-length']).encode())
                    wfile.write(b'Accept-Ranges: bytes\r\n')
                    wfile.write(b'Connection: close\r\n\r\n')
                    return

                if 'mpegurl' in content_type or '.m3u8' in content_url.lower():
                    raw_content = response.read()
                    
                    try:
                        if content_encoding == 'gzip':
                            content = gzip.decompress(raw_content)
                        elif content_encoding == 'deflate':
                            content = zlib.decompress(raw_content)
                        else:
                            content = raw_content
                    except:
                        content = raw_content
                    
                    try:
                        playlist_text = content.decode('utf-8', errors='ignore')
                        proxy_host = "127.0.0.1:{}".format(PROXY_PORT)
                        base_url = content_url.rsplit('/', 1)[0]
                        rewritten = self.rewrite_m3u8_urls(playlist_text, base_url, proxy_host)
                        
                        response.close()
                        
                        wfile.write(b"HTTP/1.1 200 OK\r\n")
                        wfile.write(b"Content-Type: application/vnd.apple.mpegurl\r\n")
                        wfile.write("Content-Length: {}\r\n".format(len(rewritten.encode('utf-8'))).encode())
                        wfile.write(b"Access-Control-Allow-Origin: *\r\n")
                        wfile.write(b"Cache-Control: no-cache\r\n\r\n")
                        wfile.write(rewritten.encode('utf-8'))
                        return
                    except Exception as e:
                        log("Erro M3U8: {}".format(e))
                        return
                
                # Stream contínuo
                wfile.write("HTTP/1.1 {} OK\r\n".format(206 if status_code == 206 else 200).encode())
                wfile.write(b"Content-Type: video/mp2t\r\n")
                wfile.write(b"Access-Control-Allow-Origin: *\r\n")
                wfile.write(b"Cache-Control: no-cache\r\n")
                wfile.write(b"Connection: keep-alive\r\n")
                
                if 'content-length' in response.headers:
                    wfile.write("Content-Length: {}\r\n".format(response.headers['content-length']).encode())
                
                wfile.write(b"\r\n")
                
                cache.stream_started = True
                consecutive_errors = 0
                
                while True:
                    try:
                        if response:
                            chunk = response.read(BUFFER_SIZE)
                            if chunk:
                                cache.add_chunk(chunk)
                                wfile.write(chunk)
                                consecutive_errors = 0
                            else:
                                break
                        else:
                            cache_chunks = cache.get_continuous_chunks(30)
                            if cache_chunks:
                                for chunk in cache_chunks:
                                    try:
                                        wfile.write(chunk)
                                        time.sleep(0.03)
                                    except:
                                        break
                            
                            try:
                                new_response, new_status, _ = self.fetch_channel_with_fallback(
                                    url, headers, "bytes={}-".format(cache.stream_offset), cache
                                )
                                if new_response and new_status == 206:
                                    if response:
                                        response.close()
                                    response = new_response
                                    continue
                                if new_response and new_status == 200:
                                    # O servidor ignorou Range: reinicia o buffer para não
                                    # repetir dados antigos com offset incorreto.
                                    cache.reset_after_upstream_restart()
                                    if response:
                                        response.close()
                                    response = new_response
                                    continue
                            except:
                                pass
                            
                            time.sleep(1)
                            
                    except (BrokenPipeError, socket.error):
                        break
                    except Exception as e:
                        consecutive_errors += 1
                        
                        if consecutive_errors >= 3:
                            try:
                                if response:
                                    response.close()
                                    response = None
                                
                                new_response, new_status, _ = self.fetch_channel_with_fallback(
                                    url, headers, "bytes={}-".format(cache.stream_offset), cache
                                )
                                if new_response and new_status == 206:
                                    response = new_response
                                    consecutive_errors = 0
                                    continue
                                if new_response and new_status == 200:
                                    cache.reset_after_upstream_restart()
                                    response = new_response
                                    consecutive_errors = 0
                                    continue
                            except:
                                pass
                        
                        if cache.get_continuous_chunks(20):
                            for chunk in cache.get_continuous_chunks(20):
                                try:
                                    wfile.write(chunk)
                                    time.sleep(0.03)
                                except:
                                    break
                
        except Exception as e:
            log("Erro handle_channel_stream: {}".format(e))
        finally:
            if response:
                try:
                    response.close()
                except:
                    pass

    def fetch_mp4_with_retry(self, url, range_header=None, method='GET'):
        for attempt in range(MAX_RETRIES):
            try:
                parsed = urlparse(url)
                referer = f"{parsed.scheme}://{parsed.netloc}/"

                headers = {
                    'User-Agent': CHROME_UA,
                    'Accept': 'video/mp4,video/*;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'pt-BR,pt;q=0.9',
                    'Accept-Encoding': 'identity',
                    'Connection': 'keep-alive',
                    'Referer': referer,
                    'Origin': f"{parsed.scheme}://{parsed.netloc}",
                }

                if range_header:
                    headers['Range'] = range_header

                req = Request(url, headers=headers, method=method)
                return self._open_request(req, timeout=VOD_TIMEOUT)

            except Exception as e:
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_DELAY)
                    continue
                log("Erro fetch MP4: {}".format(e))
                return None

    def _parse_range(self, range_header):
        if not range_header:
            return None
        match = re.search(r'bytes=(\d+)-(\d*)', range_header)
        if not match:
            return None
        start = int(match.group(1))
        end = int(match.group(2)) if match.group(2) else None
        return start, end

    def _parse_total_size(self, headers):
        content_range = headers.get('Content-Range', '') or headers.get('content-range', '')
        match = re.search(r"/(\d+)$", content_range)
        if match:
            return int(match.group(1))
        content_length = headers.get('Content-Length') or headers.get('content-length')
        if content_length and content_length.isdigit():
            return int(content_length)
        return None

    def _detect_mp4(self, url):
        lower = url.lower()
        if any(ext in lower for ext in ['.mp4', '.mkv', '.webm', '.f4v', '.mov', '.avi']):
            return True
        if '/play/' in lower:
            return True
        if 'xtream' in lower and ('/movie/' in lower or '/series/' in lower):
            return True
        return False

    def handle_mp4_stream(self, url, method, req_headers, wfile):
        cache = self.get_mp4_cache(url)
        range_header = req_headers.get('range')
        parsed_range = self._parse_range(range_header)

        if parsed_range and parsed_range[1] is not None:
            start, end = parsed_range
            cached = cache.get_range(start, end + 1)
            if cached:
                total = cache.content_length or '*'
                wfile.write("HTTP/1.1 206 Partial Content\r\n".encode())
                wfile.write(b"Content-Type: video/mp4\r\n")
                wfile.write(b"Accept-Ranges: bytes\r\n")
                wfile.write("Content-Length: {}\r\n".format(len(cached)).encode())
                wfile.write("Content-Range: bytes {}-{}/{}\r\n".format(start, start + len(cached) - 1, total).encode())
                wfile.write(b"Access-Control-Allow-Origin: *\r\n")
                wfile.write(b"\r\n")
                wfile.write(cached)
                return

        upstream = self.fetch_mp4_with_retry(url, range_header=range_header, method=method)

        if not upstream and range_header:
            upstream = self.fetch_mp4_with_retry(url, range_header='bytes=0-', method=method)

        if not upstream:
            return

        status = upstream.getcode()

        total_size = self._parse_total_size(upstream.headers)
        if total_size:
            cache.content_length = total_size

        wfile.write("HTTP/1.1 {} OK\r\n".format(status).encode())
        wfile.write("Content-Type: {}\r\n".format(upstream.headers.get('Content-Type', 'video/mp4')).encode())
        wfile.write(b"Accept-Ranges: bytes\r\n")
        if upstream.headers.get('Content-Length'):
            wfile.write("Content-Length: {}\r\n".format(upstream.headers.get('Content-Length')).encode())
        if upstream.headers.get('Content-Range'):
            wfile.write("Content-Range: {}\r\n".format(upstream.headers.get('Content-Range')).encode())
        wfile.write(b"Access-Control-Allow-Origin: *\r\n")
        wfile.write(b"\r\n")

        if method in ('HEAD', 'OPTIONS'):
            upstream.close()
            return

        pos = 0
        if status == 206:
            content_range = upstream.headers.get('Content-Range', '')
            match = re.search(r'bytes\s+(\d+)-', content_range)
            if match:
                pos = int(match.group(1))
            elif parsed_range:
                pos = parsed_range[0]

        try:
            while True:
                chunk = upstream.read(BUFFER_SIZE)
                if not chunk:
                    break
                cache.add_chunk(pos, chunk)
                pos += len(chunk)
                wfile.write(chunk)
        except (BrokenPipeError, socket.error):
            pass
        except Exception as e:
            log("Erro stream MP4: {}".format(e))
        finally:
            upstream.close()


# ==================== HANDLER HTTP ====================
class ProxyHandler(socketserver.StreamRequestHandler):
    proxy = UnifiedProxy()

    # --- mini API compatível com BaseHTTPRequestHandler (pra manter seu process_request igual) ---
    def send_response(self, code, message=None):
        if message is None:
            message = http.client.responses.get(code, "OK")
        self._resp_statusline = f"HTTP/1.1 {code} {message}\r\n"
        self._resp_headers = []

    def send_header(self, key, value):
        self._resp_headers.append((key, value))

    def end_headers(self):
        try:
            # garante conexão fechada (ffmpeg/kodi não precisa keep-alive aqui)
            has_conn = any(k.lower() == "connection" for k, _ in self._resp_headers)
            if not has_conn:
                self._resp_headers.append(("Connection", "close"))

            data = self._resp_statusline
            for k, v in self._resp_headers:
                data += f"{k}: {v}\r\n"
            data += "\r\n"
            self.wfile.write(data.encode("utf-8", "replace"))
        except Exception:
            pass

    def send_error(self, code, message=""):
        body = (f"{code} {message}").encode("utf-8", "replace")
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        try:
            self.wfile.write(body)
        except Exception:
            pass

    # --- parser HTTP tolerante + dispatch ---
    def handle(self):
        try:
            # lê request line
            raw = self.rfile.readline(65537)
            if not raw:
                return

            # se vier TLS por engano (começa com 0x16 0x03) ou HTTP/2 preface
            if raw.startswith(b"\x16\x03") or raw.startswith(b"PRI * HTTP/2.0"):
                self.send_error(400, "Bad Request")
                return

            line = raw.decode("iso-8859-1", "replace").rstrip("\r\n")
            # log("REQ_LINE: {}".format(line))

            parts = line.split(" ")
            if len(parts) < 2:
                self.send_error(400, "Bad Request")
                return

            self.command = parts[0].upper()

            # aceita tokens extras; tenta detectar HTTP/x.y no final
            if len(parts) >= 3 and parts[-1].startswith("HTTP/"):
                self.request_version = parts[-1]
                target = " ".join(parts[1:-1])
            else:
                self.request_version = "HTTP/1.1"
                target = " ".join(parts[1:])

            # absolute-form -> origin-form
            if target.startswith("http://") or target.startswith("https://"):
                try:
                    u = urlsplit(target)
                    target = (u.path or "/") + (("?" + u.query) if u.query else "")
                except Exception:
                    pass

            self.path = target

            # lê headers
            headers = {}
            while True:
                h = self.rfile.readline(65537)
                if not h or h in (b"\r\n", b"\n"):
                    break
                hs = h.decode("iso-8859-1", "replace")
                if ":" in hs:
                    k, v = hs.split(":", 1)
                    headers[k.strip().lower()] = v.strip()

            self.headers = headers  # dict (tem .items())

            # dispatch igual ao BaseHTTPRequestHandler
            if self.command == "OPTIONS":
                self.do_OPTIONS()
            elif self.command == "HEAD":
                self.do_HEAD()
            else:
                self.do_GET()

        except Exception as e:
            log("RAW socket handler erro: {}".format(e))
            try:
                self.send_error(500, "Internal Server Error")
            except Exception:
                pass

    def do_GET(self):
        self.process_request()

    def do_HEAD(self):
        self.process_request()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Range, Origin, Content-Type, Accept')
        self.send_header('Content-Length', '0')
        self.end_headers()

    # --- seu código original, praticamente igual ---
    def process_request(self):
        try:
            log("Requisição: {} {}".format(self.command, self.path))

            url = self.proxy.extract_url_from_path(self.path)

            if not url:
                html = """<html><body>
<h2>XC Pro Proxy Active</h2>
<p>Proxy funcionando na porta {}</p>
</body></html>""".format(PROXY_PORT).encode("utf-8")

                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Content-Length', str(len(html)))
                self.end_headers()
                self.wfile.write(html)
                return

            log("Proxy para URL: {}".format(url))

            headers = {}
            for key, value in self.headers.items():
                headers[key.lower()] = value

            if self.proxy._detect_mp4(url):
                self.proxy.handle_mp4_stream(url, self.command, headers, self.wfile)
            else:
                self.proxy.handle_channel_stream(url, headers, self.wfile, method=self.command)

        except Exception as e:
            log("Erro handle_request: {}".format(e))
            try:
                self.send_error(500, str(e))
            except Exception:
                pass


# ==================== SERVIDOR ====================
class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True
    
class UnifiedServer:
    def __init__(self, port=9090):
        global PROXY_PORT

        self.port = int(port)
        PROXY_PORT = self.port

        self.server = None
        self.running = False
        self.monitor = None

    def start(self, monitor=None):
        self.monitor = monitor
        self.running = True

        try:
            self.server = ThreadedTCPServer(("127.0.0.1", self.port), ProxyHandler)

            # importante para não travar o loop
            self.server.timeout = 1

            log("=== PROXY INICIADO em 127.0.0.1:{} ===".format(self.port))

            while self.running:

                if self.monitor and self.monitor.abortRequested():
                    log("abortRequested detectado, parando proxy...")
                    break

                try:
                    self.server.handle_request()

                except OSError as e:
                    log("Socket error: {}".format(e))

                except Exception as e:
                    log("Erro processando request: {}".format(e))

        except Exception as e:
            log("Erro no servidor: {}".format(e))

        finally:
            self.stop()

    def stop(self):
        self.running = False

        try:
            if self.server:
                try:
                    self.server.server_close()
                except Exception:
                    pass

                self.server = None

        except Exception as e:
            log("Erro ao fechar servidor: {}".format(e))

        log("Proxy finalizado")

    def is_running(self):
        return (
            self.running and
            self.server is not None
        )


if __name__ == '__main__':
    server = UnifiedServer(port=PROXY_PORT)
    try:
        print("Iniciando Proxy Unificado na porta {}".format(PROXY_PORT))
        server.start()
    except KeyboardInterrupt:
        print("Parando Proxy Unificado...")
        server.stop()