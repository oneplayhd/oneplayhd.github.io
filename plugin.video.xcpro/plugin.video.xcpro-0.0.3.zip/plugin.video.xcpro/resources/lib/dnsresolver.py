# -*- coding: utf-8 -*-
"""Resolvedor DNS interno e restrito aos hosts usados pelo XC Pro.

O Kodi mantém plugin e service em execuções distintas. Por isso este módulo é
carregado por ambos e substitui getaddrinfo apenas para hosts explicitamente
registrados pelo addon. Os demais addons/hosts continuam no DNS normal do
sistema.
"""

import ipaddress
import random
import socket
import struct
import threading
import time
from urllib.parse import urlsplit

try:
    import xbmc
except Exception:
    xbmc = None


DNS_SERVERS = ('1.1.1.1', '1.0.0.1', '8.8.8.8', '208.67.222.222')
DNS_TIMEOUT = 1.25
CACHE_TTL = 600
MAX_REGISTERED_HOSTS = 64


class ScopedDNSResolver:
    def __init__(self):
        self._original_getaddrinfo = socket.getaddrinfo
        self._installed = False
        self._enabled = True
        self._hosts = {}
        self._cache = {}
        self._lock = threading.RLock()
        self._logged_install = False

    def log(self, message, level=None):
        try:
            if xbmc:
                xbmc.log('[XC Pro DNS] {}'.format(message), xbmc.LOGINFO if level is None else level)
        except Exception:
            pass

    @staticmethod
    def _normalise_host(value):
        text = str(value or '').strip()
        if not text:
            return ''
        try:
            parsed = urlsplit(text if '://' in text else '//' + text)
            host = parsed.hostname or ''
        except Exception:
            host = text.split('/', 1)[0].split(':', 1)[0]
        return host.strip().rstrip('.').lower()

    @staticmethod
    def _is_ip(host):
        try:
            ipaddress.ip_address(host)
            return True
        except Exception:
            return False

    def install(self):
        with self._lock:
            if not self._installed:
                socket.getaddrinfo = self._getaddrinfo
                self._installed = True
            if not self._logged_install:
                self._logged_install = True
                self.log('DNS interno preparado para hosts do XC Pro.')

    def set_enabled(self, enabled):
        with self._lock:
            self._enabled = bool(enabled)

    def register_host(self, value):
        host = self._normalise_host(value)
        if not host or self._is_ip(host) or host in ('localhost',) or host.endswith('.local'):
            return host
        now = time.time()
        with self._lock:
            self._hosts[host] = now
            if len(self._hosts) > MAX_REGISTERED_HOSTS:
                oldest = sorted(self._hosts, key=self._hosts.get)[:len(self._hosts) - MAX_REGISTERED_HOSTS]
                for old in oldest:
                    self._hosts.pop(old, None)
        return host

    def register_url(self, value):
        return self.register_host(value)

    def _is_registered(self, host):
        host = self._normalise_host(host)
        with self._lock:
            return self._enabled and host in self._hosts

    @staticmethod
    def _encode_name(host):
        labels = host.strip('.').split('.')
        encoded = []
        for label in labels:
            raw = label.encode('idna')
            if not raw or len(raw) > 63:
                raise ValueError('hostname DNS inválido')
            encoded.append(bytes([len(raw)]) + raw)
        return b''.join(encoded) + b'\x00'

    @staticmethod
    def _decode_name(data, offset, depth=0):
        if depth > 16:
            raise ValueError('compressão DNS inválida')
        labels = []
        jumped = False
        original_offset = offset
        size = len(data)
        while offset < size:
            length = data[offset]
            if length == 0:
                offset += 1
                break
            if length & 0xC0 == 0xC0:
                if offset + 1 >= size:
                    raise ValueError('ponteiro DNS truncado')
                pointer = ((length & 0x3F) << 8) | data[offset + 1]
                name, _ = ScopedDNSResolver._decode_name(data, pointer, depth + 1)
                labels.append(name)
                offset += 2
                jumped = True
                break
            offset += 1
            if length > 63 or offset + length > size:
                raise ValueError('rótulo DNS inválido')
            labels.append(data[offset:offset + length].decode('ascii', 'ignore'))
            offset += length
        return '.'.join(part for part in labels if part), (offset if not jumped else offset)

    @classmethod
    def _build_query(cls, host, qtype):
        transaction_id = random.randint(0, 65535)
        header = struct.pack('>HHHHHH', transaction_id, 0x0100, 1, 0, 0, 0)
        packet = header + cls._encode_name(host) + struct.pack('>HH', qtype, 1)
        return transaction_id, packet

    @classmethod
    def _parse_answers(cls, data, transaction_id, wanted_type):
        if len(data) < 12:
            return []
        response_id, flags, qdcount, ancount, _, _ = struct.unpack('>HHHHHH', data[:12])
        if response_id != transaction_id or (flags & 0x000F) != 0:
            return []
        offset = 12
        try:
            for _ in range(qdcount):
                _, offset = cls._decode_name(data, offset)
                offset += 4
                if offset > len(data):
                    return []
            answers = []
            for _ in range(ancount):
                _, offset = cls._decode_name(data, offset)
                if offset + 10 > len(data):
                    return answers
                rtype, rclass, _ttl, rdlength = struct.unpack('>HHIH', data[offset:offset + 10])
                offset += 10
                rdata = data[offset:offset + rdlength]
                offset += rdlength
                if rclass != 1:
                    continue
                if rtype == 1 and wanted_type == 1 and len(rdata) == 4:
                    answers.append(socket.inet_ntop(socket.AF_INET, rdata))
                elif rtype == 28 and wanted_type == 28 and len(rdata) == 16:
                    answers.append(socket.inet_ntop(socket.AF_INET6, rdata))
            return answers
        except Exception:
            return []

    def _query(self, host, qtype):
        cache_key = (host, qtype)
        now = time.time()
        with self._lock:
            cached = self._cache.get(cache_key)
            if cached and cached['expires'] > now:
                return list(cached['answers'])
        for dns_server in DNS_SERVERS:
            sock = None
            try:
                transaction_id, query = self._build_query(host, qtype)
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.settimeout(DNS_TIMEOUT)
                sock.sendto(query, (dns_server, 53))
                data, _ = sock.recvfrom(4096)
                answers = self._parse_answers(data, transaction_id, qtype)
                if answers:
                    with self._lock:
                        self._cache[cache_key] = {'answers': tuple(answers), 'expires': now + CACHE_TTL}
                    return answers
            except Exception:
                continue
            finally:
                if sock is not None:
                    try:
                        sock.close()
                    except Exception:
                        pass
        return []

    def _lookup(self, host, family):
        if family == socket.AF_INET6:
            return self._query(host, 28)
        if family == socket.AF_INET:
            return self._query(host, 1)
        # Mantém prioridade IPv4 porque o proxy local e a maioria dos Xtreams
        # usados pelo addon trabalham em IPv4. Em redes IPv6-only, tenta AAAA.
        answers = self._query(host, 1)
        if answers:
            return answers
        return self._query(host, 28)

    def _getaddrinfo(self, host, port, family=0, type=0, proto=0, flags=0):
        # Mantém localhost, IPs e qualquer host não registrado fora do escopo.
        try:
            host_text = self._normalise_host(host)
        except Exception:
            host_text = ''
        if not host_text or self._is_ip(host_text) or not self._is_registered(host_text):
            return self._original_getaddrinfo(host, port, family, type, proto, flags)

        addresses = self._lookup(host_text, family)
        for address in addresses:
            try:
                return self._original_getaddrinfo(address, port, family, type, proto, flags)
            except Exception:
                continue
        # Falha do DNS interno nunca impede o fallback normal do sistema.
        return self._original_getaddrinfo(host, port, family, type, proto, flags)


_RESOLVER = ScopedDNSResolver()


def install():
    _RESOLVER.install()


def set_enabled(enabled):
    _RESOLVER.set_enabled(enabled)


def register_host(value):
    return _RESOLVER.register_host(value)


def register_url(value):
    return _RESOLVER.register_url(value)
