# -*- coding: utf-8 -*-
"""Serviço persistente do XC Pro.

Mantém o proxy local e o servidor de pareamento vivos fora das rotas do plugin.
Isso evita depender de threads criadas pelo default.py, que podem morrer quando a navegação termina.
"""

import datetime
import json
import os
import sys
import threading
import time
import urllib.parse
import xml.etree.ElementTree as ET

import requests

import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui

ADDON = xbmcaddon.Addon('plugin.video.xcpro')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
LIB_PATH = os.path.join(ADDON_PATH, 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.append(LIB_PATH)

from xcpro_core import atomic_write_json, credential_fingerprint, redact_url, write_response_to_tempfile
from profile_store import migrate_profile_layout
import dnsresolver

dnsresolver.install()
try:
    dnsresolver.set_enabled(ADDON.getSetting('internal_dns') != 'false')
except Exception:
    pass

from proxy import UnifiedServer
from webserver import PairingWebServer


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log('[XC Pro Service] {}'.format(redact_url(msg)), level)
    except Exception:
        pass


def get_int_setting(setting_id, default_value):
    try:
        value = ADDON.getSetting(setting_id)
        value = int(value) if value else int(default_value)
        if 1 <= value <= 65535:
            return value
    except Exception:
        pass
    return int(default_value)


def get_ports():
    return get_int_setting('proxy_port', 9097), get_int_setting('webserver_port', 9099)


def get_profile_path():
    profile = ADDON.getAddonInfo('profile')
    try:
        profile = xbmcvfs.translatePath(profile)
    except Exception:
        pass
    try:
        if not xbmcvfs.exists(profile):
            xbmcvfs.mkdirs(profile)
    except Exception:
        try:
            if not os.path.exists(profile):
                os.makedirs(profile)
        except Exception:
            pass
    return profile


PROFILE_PATH = get_profile_path()
PROFILE_LAYOUT = migrate_profile_layout(PROFILE_PATH, logger=lambda msg: log(msg, xbmc.LOGINFO))
EPG_XML_FILE = PROFILE_LAYOUT['epg_xml']
EPG_XML_INDEX_FILE = PROFILE_LAYOUT['epg_index']
EPG_XML_META_FILE = PROFILE_LAYOUT['epg_meta']
EPG_CACHE_FILE = PROFILE_LAYOUT['epg_stream_cache']
EPG_XML_TTL = 86400
EPG_WATCHDOG_INTERVAL = 3600
EPG_INDEX_PREVENTIVE_MARGIN = 7200
EPG_XML_INDEX_VERSION = 'xcpro_epg_xmltv_login_v5'
EPG_XML_MAX_BYTES = 128 * 1024 * 1024


def normalize_host(host):
    host = (host or '').strip()
    if not host:
        return ''
    if not host.startswith(('http://', 'https://')):
        host = 'http://' + host
    try:
        parsed = urllib.parse.urlparse(host)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname:
            return ''
        hostname = parsed.hostname
        if ':' in hostname and not hostname.startswith('['):
            hostname = '[{}]'.format(hostname)
        port = parsed.port
        netloc = '{}:{}'.format(hostname, port) if port else hostname
        return '{}://{}'.format(parsed.scheme, netloc).rstrip('/')
    except Exception:
        return ''


def _unwrap_playing_url(raw_url):
    """Remove cabeçalhos Kodi e wrappers locais sem alterar URLs diretas.

    Alguns addons entregam a URL Xtream diretamente; outros a entregam através
    do proxy local, tsdownloader ou uma rota plugin:// com o parâmetro ``url``.
    O tratamento é limitado a três camadas para evitar loop em URLs malformadas.
    """
    current = (raw_url or '').strip()
    if not current:
        return ''

    try:
        current = urllib.parse.unquote(current)
    except Exception:
        pass
    current = current.split('|', 1)[0].strip()

    for _ in range(3):
        if not current:
            break

        next_url = ''
        try:
            parsed = urllib.parse.urlsplit(current)
            hostname = (parsed.hostname or '').lower()
            is_local_wrapper = hostname in ('127.0.0.1', '::1', 'localhost')
            is_plugin_wrapper = (parsed.scheme or '').lower() == 'plugin'

            if is_local_wrapper or is_plugin_wrapper:
                query_values = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
                candidate = (query_values.get('url') or [''])[0]
                if candidate:
                    try:
                        candidate = urllib.parse.unquote(candidate)
                    except Exception:
                        pass
                    if candidate.startswith(('http://', 'https://')):
                        next_url = candidate
        except Exception:
            pass

        # Compatibilidade com o wrapper histórico do próprio proxy, que pode
        # chegar já decodificado ao Player do Kodi.
        if not next_url and '?url=' in current:
            try:
                candidate = current.split('?url=', 1)[1]
                candidate = urllib.parse.unquote(candidate)
                if candidate.startswith(('http://', 'https://')):
                    next_url = candidate
            except Exception:
                pass

        if not next_url or next_url == current:
            break
        current = next_url.split('|', 1)[0].strip()

    return current


def extract_xtream_credentials_from_playing_url(raw_url):
    """Extrai host/usuário/senha de uma reprodução Xtream válida.

    Mantém os dois formatos historicamente aceitos pelo XC Pro:
      * /live|movie|series/USUARIO/SENHA/ID
      * /USUARIO/SENHA/ID

    O segundo é usado por alguns addons e era aceito na versão 0.0.2. A função
    retorna três strings vazias quando a URL não tem estrutura Xtream utilizável.
    """
    candidate = _unwrap_playing_url(raw_url)
    if not candidate:
        return '', '', ''

    try:
        parsed = urllib.parse.urlsplit(candidate)
    except Exception:
        return '', '', ''

    if (parsed.scheme or '').lower() not in ('http', 'https') or not parsed.netloc:
        return '', '', ''

    host = normalize_host('{}://{}'.format(parsed.scheme, parsed.netloc))
    if not host:
        return '', '', ''

    parts = [part for part in (parsed.path or '').split('/') if part]
    if len(parts) >= 4 and parts[0].lower() in ('live', 'movie', 'series'):
        username, password = parts[1], parts[2]
    elif len(parts) >= 3:
        # Compatibilidade deliberada com a captura funcional da 0.0.2.
        username, password = parts[0], parts[1]
    else:
        return '', '', ''

    if not username or not password:
        return '', '', ''
    return host, username, password


def get_credentials():
    host = normalize_host(ADDON.getSetting('host'))
    username = (ADDON.getSetting('username') or '').strip()
    password = (ADDON.getSetting('password') or '').strip()
    try:
        dnsresolver.set_enabled(ADDON.getSetting('internal_dns') != 'false')
        if host:
            dnsresolver.register_url(host)
    except Exception:
        pass
    return host, username, password


def has_credentials():
    host, user, password = get_credentials()
    return bool(host and user and password)


def epg_fingerprint():
    host, user, password = get_credentials()
    return credential_fingerprint(host, user, password)


def safe_read_json(path, default=None):
    try:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as file_obj:
                return json.load(file_obj)
    except Exception:
        pass
    return {} if default is None else default


def safe_write_json(path, data):
    if atomic_write_json(path, data):
        return True
    log('Falha ao salvar JSON EPG {}'.format(path), xbmc.LOGWARNING)
    return False


def clear_epg_cache(reason=''):
    for path in (EPG_XML_FILE, EPG_XML_INDEX_FILE, EPG_XML_META_FILE, EPG_CACHE_FILE):
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception as exc:
            log('Falha ao remover cache EPG {}: {}'.format(path, exc), xbmc.LOGWARNING)
    if reason:
        log('Cache EPG limpo: {}'.format(reason), xbmc.LOGINFO)


def get_browser_headers(host=None):
    origin = ''
    try:
        parsed = urllib.parse.urlparse(host or '')
        if parsed.scheme and parsed.netloc:
            origin = '{}://{}'.format(parsed.scheme, parsed.netloc)
    except Exception:
        origin = ''

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
        'Accept': 'application/xml,text/xml,*/*',
        'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'Connection': 'close',
    }
    if origin:
        headers['Origin'] = origin
        headers['Referer'] = origin + '/'
    return headers


def build_epg_urls():
    host, user, password = get_credentials()
    if not host or not user or not password:
        return []
    params = urllib.parse.urlencode({'username': user, 'password': password})
    return [
        ('xmltv.php', '{}/xmltv.php?{}'.format(host, params)),
        ('epg.php', '{}/epg.php?{}'.format(host, params)),
    ]


def build_epg_url():
    urls = build_epg_urls()
    return urls[0][1] if urls else ''


def epg_xml_fresh():
    meta = safe_read_json(EPG_XML_META_FILE, {})
    if meta.get('fingerprint') != epg_fingerprint():
        return False
    fetched_at = int(meta.get('fetched_at') or 0)
    if not fetched_at or (time.time() - fetched_at) >= EPG_XML_TTL:
        return False
    try:
        return os.path.exists(EPG_XML_FILE) and os.path.getsize(EPG_XML_FILE) > 128
    except Exception:
        return False


def epg_index_needs_rebuild(index=None, preventive=True):
    index = index if isinstance(index, dict) else safe_read_json(EPG_XML_INDEX_FILE, {})
    if index.get('version') != EPG_XML_INDEX_VERSION:
        return True
    if index.get('fingerprint') != epg_fingerprint():
        return True
    generated_at = int(index.get('generated_at') or 0)
    if not generated_at or (time.time() - generated_at) >= EPG_XML_TTL:
        return True

    channels = index.get('channels')
    if not isinstance(channels, dict) or not channels:
        return True

    now_ts = int(time.time())
    window_start = int(index.get('window_start') or 0)
    window_end = int(index.get('window_end') or 0)
    if window_start and now_ts < window_start:
        return True
    if window_end and now_ts > window_end:
        return True
    if preventive and window_end and now_ts >= (window_end - EPG_INDEX_PREVENTIVE_MARGIN):
        return True

    return False


def epg_index_fresh():
    return not epg_index_needs_rebuild(preventive=False)


def normalize_epg_channel_id(value):
    return str(value or '').strip().lower()


def parse_xmltv_time(value):
    value = str(value or '').strip()
    if not value:
        return 0
    try:
        main = value.split(' ', 1)[0].strip()
        tz = value.split(' ', 1)[1].strip() if ' ' in value else ''
        if len(main) >= 14 and main[:14].isdigit():
            dt = datetime.datetime.strptime(main[:14], '%Y%m%d%H%M%S')
            if tz and len(tz) >= 5 and tz[0] in '+-' and tz[1:5].isdigit():
                sign = 1 if tz[0] == '+' else -1
                offset = sign * (int(tz[1:3]) * 3600 + int(tz[3:5]) * 60)
                return int(dt.replace(tzinfo=datetime.timezone(datetime.timedelta(seconds=offset))).timestamp())
            return int(time.mktime(dt.timetuple()))
        if 'T' in value:
            return int(datetime.datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp())
    except Exception:
        return 0
    return 0


def xml_child_text(element, child_name):
    try:
        child = element.find(child_name)
        if child is not None and child.text:
            return child.text.strip()
    except Exception:
        pass
    try:
        for child in list(element):
            tag = str(child.tag or '').split('}', 1)[-1]
            if tag == child_name and child.text:
                return child.text.strip()
    except Exception:
        pass
    return ''


def download_epg_xml():
    urls = build_epg_urls()
    if not urls:
        return False

    last_error = ''
    for label, url in urls:
        try:
            dnsresolver.register_url(url)
            response = requests.get(
                url, timeout=60, headers=get_browser_headers(get_credentials()[0]),
                allow_redirects=True, stream=True
            )
            if response.status_code != 200:
                last_error = 'HTTP {} em {}'.format(response.status_code, label)
                log('EPG background: {}'.format(last_error), xbmc.LOGWARNING)
                response.close()
                continue
            try:
                tmp_path, content_size, sample = write_response_to_tempfile(
                    response, PROFILE_PATH, EPG_XML_MAX_BYTES
                )
            finally:
                response.close()
            if not tmp_path:
                last_error = '{} veio vazio ou excedeu o limite de EPG'.format(label)
                log('EPG background rejeitado: {}'.format(last_error), xbmc.LOGWARNING)
                continue
            sample = sample.lower()
            if b'<tv' not in sample and b'<xmltv' not in sample and b'<epg' not in sample:
                try:
                    os.remove(tmp_path)
                except Exception:
                    pass
                last_error = '{} não parece XMLTV'.format(label)
                log('EPG background rejeitado: {}'.format(last_error), xbmc.LOGWARNING)
                continue
            try:
                os.replace(tmp_path, EPG_XML_FILE)
            except Exception:
                try:
                    if os.path.exists(EPG_XML_FILE):
                        os.remove(EPG_XML_FILE)
                    os.rename(tmp_path, EPG_XML_FILE)
                except Exception:
                    try:
                        os.remove(tmp_path)
                    except Exception:
                        pass
                    raise

            safe_write_json(EPG_XML_META_FILE, {
                'fingerprint': epg_fingerprint(),
                'fetched_at': int(time.time()),
                'size': content_size,
                'source': label,
            })

            try:
                if os.path.exists(EPG_XML_INDEX_FILE):
                    os.remove(EPG_XML_INDEX_FILE)
            except Exception:
                pass

            log('EPG background: XMLTV baixado via {} para o login atual ({} bytes).'.format(label, content_size))
            return True
        except Exception as exc:
            last_error = '{}: {}'.format(label, exc)
            log('EPG background: falha em {}: {}'.format(label, exc), xbmc.LOGWARNING)

    if last_error:
        log('EPG background: falha geral XMLTV: {}'.format(last_error), xbmc.LOGWARNING)
    return False


def build_epg_index():
    if not os.path.exists(EPG_XML_FILE):
        return False

    now_ts = int(time.time())
    start_day = datetime.datetime.fromtimestamp(now_ts).replace(hour=0, minute=0, second=0, microsecond=0)
    window_start = int(start_day.timestamp()) - 3600
    window_end = int((start_day + datetime.timedelta(days=2)).timestamp()) + 3600

    channels = {}
    total = 0
    try:
        for event, elem in ET.iterparse(EPG_XML_FILE, events=('end',)):
            tag = str(elem.tag or '').split('}', 1)[-1]
            if tag != 'programme':
                if tag not in ('title', 'desc'):
                    try:
                        elem.clear()
                    except Exception:
                        pass
                continue

            cid = normalize_epg_channel_id(elem.get('channel'))
            start = parse_xmltv_time(elem.get('start'))
            end = parse_xmltv_time(elem.get('stop') or elem.get('end'))
            if end <= start:
                end = start + 3600

            if cid and start > 0 and not (end < window_start or start > window_end):
                title = xml_child_text(elem, 'title')
                desc = xml_child_text(elem, 'desc')
                if title:
                    channels.setdefault(cid, []).append({
                        'start': start,
                        'end': end,
                        'title': title,
                        'desc': desc,
                    })
                    total += 1

            try:
                elem.clear()
            except Exception:
                pass

        for cid in list(channels.keys()):
            channels[cid].sort(key=lambda item: item.get('start') or 0)

        safe_write_json(EPG_XML_INDEX_FILE, {
            'version': EPG_XML_INDEX_VERSION,
            'fingerprint': epg_fingerprint(),
            'generated_at': int(time.time()),
            'window_start': window_start,
            'window_end': window_end,
            'channels': channels,
        })
        log('EPG background: índice pronto. canais={}, programas={}'.format(len(channels), total))
        return True
    except Exception as exc:
        log('EPG background: erro criando índice: {}'.format(exc), xbmc.LOGWARNING)
        return False


def ensure_epg_preloaded(reason='watchdog'):
    if not has_credentials():
        return False

    meta = safe_read_json(EPG_XML_META_FILE, {})
    if meta and meta.get('fingerprint') != epg_fingerprint():
        clear_epg_cache('login/servidor alterado')

    xml_ok = epg_xml_fresh()
    index = safe_read_json(EPG_XML_INDEX_FILE, {})
    index_needs_rebuild = epg_index_needs_rebuild(index, preventive=True)

    if xml_ok and not index_needs_rebuild:
        return True

    log('EPG watchdog: verificação acionada ({}) xml_ok={} index_rebuild={}'.format(reason, xml_ok, index_needs_rebuild), xbmc.LOGINFO)

    if not xml_ok:
        if not download_epg_xml():
            log('EPG watchdog: XMLTV indisponível; mantendo cache anterior se existir.', xbmc.LOGWARNING)
            return False

    if epg_index_needs_rebuild(preventive=True):
        return bool(build_epg_index())

    return True


class EPGBackgroundWorker:
    def __init__(self, monitor):
        self.monitor = monitor
        self.thread = None
        self.last_watchdog = 0
        self.last_fingerprint = ''

    def start(self):
        self.thread = threading.Thread(target=self.run)
        self.thread.daemon = True
        self.thread.start()

    def force_next_check(self):
        self.last_watchdog = 0

    def run(self):
        # Pequeno atraso para não brigar com boot do Kodi/proxy.
        self.monitor.waitForAbort(3)

        while not self.monitor.abortRequested():
            try:
                current_fp = epg_fingerprint()

                # Troca de login/servidor precisa ser detectada rápido,
                # mas sem baixar EPG toda hora.
                if current_fp != self.last_fingerprint:
                    if self.last_fingerprint:
                        clear_epg_cache('login/servidor alterado em background')
                    self.last_fingerprint = current_fp
                    self.force_next_check()

                now = time.time()

                # Watchdog real: checagem técnica a cada 1 hora.
                # A primeira execução no boot roda imediatamente.
                if now - self.last_watchdog >= EPG_WATCHDOG_INTERVAL:
                    self.last_watchdog = now
                    ensure_epg_preloaded('watchdog_1h')

            except Exception as exc:
                log('EPG watchdog: erro geral: {}'.format(exc), xbmc.LOGWARNING)

            # Loop leve: detecta troca de login rápido, mas só faz checagem pesada a cada 1h.
            if self.monitor.waitForAbort(30):
                break


class ExternalLoginPromptPolicy:
    """Política leve: no máximo uma pergunta por abertura real do player.

    A decisão (Sim, Não ou Cancelar) encerra a tentativa de importação da
    sessão corrente. A próxima abertura só volta a ser elegível depois que o
    player recebeu Stop/End ou ficou comprovadamente inativo.
    """
    def __init__(self):
        self.session_number = 0
        self._active = False
        self._decided = False

    def begin(self, force_new=False):
        if force_new or not self._active:
            self.session_number += 1
            self._active = True
            self._decided = False
        return self.session_number

    def end(self):
        was_active = self._active or self._decided
        self._active = False
        self._decided = False
        return was_active

    def reset(self):
        self._active = False
        self._decided = False

    def is_active(self):
        return self._active

    def needs_prompt(self):
        return self._active and not self._decided

    def mark_decided(self):
        if self._active:
            self._decided = True


class ExternalPlaybackSessionObserver(xbmc.Player):
    """Recebe eventos reais do VideoPlayer para delimitar uma abertura.

    O polling continua apenas como fallback para versões/players que não
    entregam callback. Os callbacks permitem liberar a próxima pergunta logo
    após Stop, sem depender de varrer URL de segmentos HLS.
    """
    def __init__(self):
        xbmc.Player.__init__(self)
        self._lock = threading.RLock()
        self._started_sequence = 0
        self._stopped_sequence = 0
        self._playing = False

    def _started(self):
        with self._lock:
            if not self._playing:
                self._started_sequence += 1
                self._playing = True

    def _stopped(self):
        with self._lock:
            self._stopped_sequence += 1
            self._playing = False

    def onPlayBackStarted(self):
        self._started()

    def onPlayBackStopped(self):
        self._stopped()

    def onPlayBackEnded(self):
        self._stopped()

    def onPlayBackError(self):
        self._stopped()

    def snapshot(self):
        with self._lock:
            return self._started_sequence, self._stopped_sequence, self._playing


class XCProServiceMonitor(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)
        self.settings_changed = False

    def onSettingsChanged(self):
        self.settings_changed = True
        log('Configurações alteradas; verificando portas/EPG dos serviços.')

class ServiceRuntime:
    def __init__(self, monitor):
        self.monitor = monitor
        self.proxy = None
        self.proxy_thread = None
        self.webserver = None
        self.webserver_thread = None
        self.monitor_url = True
        self.current_ports = (None, None)
        # Mantido vivo durante todo o serviço: recebe Start/Stop de qualquer
        # reprodução do Kodi sem interferir no player de outros addons.
        self.external_playback_observer = ExternalPlaybackSessionObserver()
        self.epg_worker = EPGBackgroundWorker(monitor)

    def start(self):
        proxy_port, webserver_port = get_ports()
        self.current_ports = (proxy_port, webserver_port)
        self.start_proxy(proxy_port)
        self.start_webserver(webserver_port)
        self.monitor_xtream_codes()
        self.epg_worker.start()

    def monitor_xtream_codes(self):
        """Importação opcional de login Xtream por uma única abertura do player.

        Regra operacional:
          * ao iniciar uma reprodução externa, pergunta uma única vez;
          * Não/Cancelar silencia a sessão atual por completo;
          * Stop/End libera a próxima abertura para uma nova pergunta;
          * Sim salva as credenciais e encerra definitivamente a captura até
            que elas sejam apagadas nas configurações.

        O monitor não reabre diálogo por troca de segmento HLS, alteração de
        URL interna nem por uma oscilação curta do VideoPlayer.
        """
        def enabled():
            try:
                return (ADDON.getSetting('scan_list') or '').strip().lower() == 'true'
            except Exception:
                return False

        def loop_scan():
            scan_was_enabled = None
            policy = ExternalLoginPromptPolicy()
            observer = self.external_playback_observer
            last_observer_start = 0
            last_observer_stop = 0
            idle_cycles = 0

            def finish_session(reason):
                nonlocal idle_cycles
                if policy.end():
                    log('Captura de login externo liberada para a próxima abertura ({})'.format(reason), xbmc.LOGDEBUG)
                idle_cycles = 0

            while self.monitor_url and not self.monitor.abortRequested():
                try:
                    scan_enabled = enabled()
                    if scan_enabled != scan_was_enabled:
                        scan_was_enabled = scan_enabled
                        if scan_enabled:
                            # Evita interpretar callbacks antigos como uma abertura nova
                            # depois que o usuário habilita a opção no meio do play.
                            last_observer_start, last_observer_stop, _ = observer.snapshot()
                            log('Captura de login de outros addons ativada; aguardando abertura do player.')
                        else:
                            log('Captura de login de outros addons desativada.', xbmc.LOGDEBUG)

                    if not scan_enabled:
                        policy.reset()
                        idle_cycles = 0
                        if self.monitor.waitForAbort(1.0):
                            break
                        continue

                    host_addon, username, password = get_credentials()
                    if host_addon or username or password:
                        policy.reset()
                        idle_cycles = 0
                        if self.monitor.waitForAbort(1.0):
                            break
                        continue

                    started_seq, stopped_seq, _ = observer.snapshot()
                    if stopped_seq != last_observer_stop:
                        last_observer_stop = stopped_seq
                        finish_session('Stop/End do player')

                    # Um callback de Start é a fronteira preferencial de uma nova
                    # tentativa. Não força parada, pausa ou reabertura do player.
                    if started_seq != last_observer_start:
                        last_observer_start = started_seq
                        policy.begin(force_new=True)
                        idle_cycles = 0
                        log('Nova abertura externa detectada; aguardando URL Xtream.', xbmc.LOGDEBUG)

                    player = xbmc.Player()
                    is_playing = bool(player.isPlaying())

                    if is_playing:
                        idle_cycles = 0
                        # Fallback para players que não entregam callbacks do Kodi
                        # ou para reprodução já em curso quando o serviço é iniciado.
                        if not policy.is_active():
                            policy.begin()
                            log('Abertura externa detectada por fallback; aguardando URL Xtream.', xbmc.LOGDEBUG)

                        # Depois de qualquer decisão, não consulta mais a URL nem
                        # abre diálogo até o Stop. Isso reduz a pressão sobre HLS e
                        # evita insistência durante um conteúdo em execução.
                        if policy.needs_prompt():
                            host, user, pass_ = extract_xtream_credentials_from_playing_url(
                                player.getPlayingFile() or ''
                            )
                            if host and user and pass_:
                                # Marca antes do diálogo: mesmo se o player oscilar
                                # enquanto a janela está aberta, a mesma abertura não
                                # recebe outro popup.
                                policy.mark_decided()
                                log('Login Xtream externo detectado; solicitando confirmação para importar.', xbmc.LOGDEBUG)
                                dialog = xbmcgui.Dialog()
                                if dialog.yesno(
                                    heading='XC Pro',
                                    message='Deseja adicionar esta lista ao XC Pro?',
                                    nolabel='Não',
                                    yeslabel='Sim'
                                ):
                                    ADDON.setSetting('host', host)
                                    ADDON.setSetting('username', user)
                                    ADDON.setSetting('password', pass_)
                                    try:
                                        dnsresolver.register_url(host)
                                    except Exception:
                                        pass
                                    log('Login Xtream externo confirmado e salvo.', xbmc.LOGINFO)
                                else:
                                    log('Login Xtream externo recusado/cancelado; silencioso até Stop/End desta reprodução.', xbmc.LOGDEBUG)
                    elif policy.is_active():
                        # Fallback seguro caso callbacks de Stop não cheguem. Duas
                        # leituras inativas consecutivas evitam confundir buffering
                        # pontual com encerramento real, mas não tornam a próxima
                        # abertura permanentemente bloqueada.
                        idle_cycles += 1
                        if idle_cycles >= 2:
                            finish_session('player inativo confirmado')

                except Exception as exc:
                    log('Monitor opcional de lista ignorou uma URL inválida: {}'.format(exc), xbmc.LOGDEBUG)

                if self.monitor.waitForAbort(1.0):
                    break
            log('Monitor opcional de URL do XC Pro finalizado.')

        thread_check = threading.Thread(target=loop_scan)
        thread_check.daemon = True
        thread_check.start()


    def start_proxy(self, port):
        try:
            self.proxy = UnifiedServer(port)
            self.proxy_thread = threading.Thread(target=self.proxy.start, args=(self.monitor,))
            self.proxy_thread.daemon = True
            self.proxy_thread.start()
            log('Proxy local iniciado na porta {}'.format(port))
        except Exception as exc:
            log('Falha ao iniciar proxy: {}'.format(exc), xbmc.LOGERROR)

    def start_webserver(self, port):
        try:
            self.webserver = PairingWebServer(port, self.monitor)
            self.webserver_thread = threading.Thread(target=self.webserver.start)
            self.webserver_thread.daemon = True
            self.webserver_thread.start()
            log('Pareamento iniciado na porta {}'.format(port))
        except Exception as exc:
            log('Falha ao iniciar pareamento: {}'.format(exc), xbmc.LOGERROR)

    def stop(self, final=True):
        try:
            if self.proxy:
                self.proxy.stop()
        except Exception:
            pass
        try:
            if self.webserver:
                self.webserver.stop()
        except Exception:
            pass
        if final:
            self.monitor_url = False
        self.proxy = None
        self.webserver = None

    def restart_if_ports_changed(self):
        try:
            dnsresolver.set_enabled(ADDON.getSetting('internal_dns') != 'false')
        except Exception:
            pass
        new_ports = get_ports()
        if new_ports == self.current_ports:
            return
        log('Portas alteradas de {} para {}; reiniciando serviços.'.format(self.current_ports, new_ports))
        self.stop(final=False)
        # Pequena janela para liberar sockets.
        self.monitor.waitForAbort(0.5)
        self.current_ports = new_ports
        self.start_proxy(new_ports[0])
        self.start_webserver(new_ports[1])


def main():
    monitor = XCProServiceMonitor()
    runtime = ServiceRuntime(monitor)
    runtime.start()

    while not monitor.abortRequested():
        if monitor.settings_changed:
            monitor.settings_changed = False
            runtime.restart_if_ports_changed()
            try:
                runtime.epg_worker.force_next_check()
            except Exception:
                pass
        if monitor.waitForAbort(1):
            break

    log('Encerrando serviço.')
    runtime.stop()


if __name__ == '__main__':
    main()
