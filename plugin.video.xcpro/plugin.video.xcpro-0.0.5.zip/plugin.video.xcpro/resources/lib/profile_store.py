# -*- coding: utf-8 -*-
"""Organização do perfil/addon_data do XC Pro.

Mantém compatibilidade com layouts antigos, mas direciona novos arquivos para
pastas previsíveis:
- cache/api/<action>/...
- cache/epg/...
- state/...
- favorites/...
- pairing/...
"""

import json
import os
import re
import shutil


def _ensure_dir(path):
    try:
        if not os.path.isdir(path):
            os.makedirs(path, exist_ok=True)
    except Exception:
        pass
    return path


def safe_segment(value, default='misc'):
    value = str(value or '').strip().lower()
    value = re.sub(r'[^a-z0-9_\-]+', '_', value)
    value = value.strip('._-')
    return value or default


def get_profile_paths(profile_path):
    profile_path = os.path.abspath(profile_path)
    cache_dir = os.path.join(profile_path, 'cache')
    epg_dir = os.path.join(cache_dir, 'epg')
    api_dir = os.path.join(cache_dir, 'api')
    state_dir = os.path.join(profile_path, 'state')
    favorites_dir = os.path.join(profile_path, 'favorites')
    pairing_dir = os.path.join(profile_path, 'pairing')
    return {
        'profile': profile_path,
        'cache': cache_dir,
        'api_cache': api_dir,
        'epg_cache': epg_dir,
        'state': state_dir,
        'favorites_dir': favorites_dir,
        'pairing': pairing_dir,
        'epg_stream_cache': os.path.join(epg_dir, 'stream_epg.json'),
        'epg_xml': os.path.join(epg_dir, 'xmltv.xml'),
        'epg_index': os.path.join(epg_dir, 'xmltv_index.json'),
        'epg_meta': os.path.join(epg_dir, 'xmltv_meta.json'),
        'search_state': os.path.join(state_dir, 'search_state.json'),
        'favorites': os.path.join(favorites_dir, 'favorites.json'),
        'pairing_qr': os.path.join(pairing_dir, 'xcpro_pairing_qr.png'),
    }


def ensure_profile_layout(profile_path):
    paths = get_profile_paths(profile_path)
    for key in ('cache', 'api_cache', 'epg_cache', 'state', 'favorites_dir', 'pairing'):
        _ensure_dir(paths[key])
    return paths


def _move_file(src, dst):
    try:
        if not os.path.isfile(src):
            return False
        _ensure_dir(os.path.dirname(dst))
        if os.path.exists(dst):
            try:
                if os.path.getsize(src) == os.path.getsize(dst):
                    os.remove(src)
                    return True
            except Exception:
                pass
            root, ext = os.path.splitext(dst)
            i = 1
            while os.path.exists('{}-old{}{}'.format(root, i, ext)):
                i += 1
            dst = '{}-old{}{}'.format(root, i, ext)
        shutil.move(src, dst)
        return True
    except Exception:
        return False


def _read_action_from_cache_file(path):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            payload = json.load(fh)
        if isinstance(payload, dict):
            return safe_segment(payload.get('action') or 'misc')
    except Exception:
        pass
    return 'misc'


def migrate_profile_layout(profile_path, logger=None):
    """Migra o addon_data antigo para a estrutura organizada.

    É idempotente: pode ser chamado no default.py e no service.py.
    """
    paths = ensure_profile_layout(profile_path)
    moved = 0

    def log(msg):
        if logger:
            try:
                logger(msg)
            except Exception:
                pass

    root_moves = {
        'epg_cache.json': paths['epg_stream_cache'],
        'epg_xmltv.xml': paths['epg_xml'],
        'epg_xmltv_index.json': paths['epg_index'],
        'epg_xmltv_meta.json': paths['epg_meta'],
        'search_state.json': paths['search_state'],
        'favorites.json': paths['favorites'],
        'xcpro_pairing_qr.png': paths['pairing_qr'],
    }
    for old_name, new_path in root_moves.items():
        if _move_file(os.path.join(profile_path, old_name), new_path):
            moved += 1

    old_api_dir = os.path.join(profile_path, 'api_cache')
    if os.path.isdir(old_api_dir):
        try:
            for name in list(os.listdir(old_api_dir)):
                src = os.path.join(old_api_dir, name)
                if not os.path.isfile(src):
                    continue
                action = _read_action_from_cache_file(src) if name.endswith('.json') else 'misc'
                dst = os.path.join(paths['api_cache'], action, name)
                if _move_file(src, dst):
                    moved += 1
            try:
                if not os.listdir(old_api_dir):
                    os.rmdir(old_api_dir)
            except Exception:
                pass
        except Exception:
            pass

    if moved:
        log('addon_data organizado/migrado: {} item(ns) movido(s).'.format(moved))
    return paths
