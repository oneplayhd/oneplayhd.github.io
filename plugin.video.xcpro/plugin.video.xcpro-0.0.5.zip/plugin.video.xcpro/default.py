# -*- coding: utf-8 -*-
"""XC Pro - rotas principais do addon Kodi.

Fluxo mantido conservador:
- Xtream Codes via player_api.php
- QR Code de pareamento usando skin XML
- Menus de canais, filmes, séries, busca, conta e troca de conta
- Playback resolvido por rota interna e proxy local persistente mantido pelo service.py
"""

import base64
import datetime
import json
import os
import re
import sys
import threading
import time
import urllib.parse
import hashlib
import shutil
import xml.etree.ElementTree as ET

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
LIB_PATH = os.path.join(ADDON_PATH, 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.append(LIB_PATH)

from xcpro_core import atomic_write_json, credential_fingerprint, redact_url, write_response_to_tempfile
from profile_store import ensure_profile_layout, get_profile_paths, migrate_profile_layout, safe_segment
import dnsresolver

dnsresolver.install()
try:
    dnsresolver.set_enabled(ADDON.getSetting('internal_dns') != 'false')
except Exception:
    pass

MENU_ICON_PATH = os.path.join(ADDON_PATH, 'resources', 'media', 'menu')

def get_local_ip():
    import socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(('8.8.8.8', 80))
        return sock.getsockname()[0]
    except Exception:
        return '127.0.0.1'
    finally:
        try:
            sock.close()
        except Exception:
            pass


def menu_icon(filename):
    return os.path.join(MENU_ICON_PATH, filename)


def is_remote_http_url(value):
    try:
        parsed = urllib.parse.urlparse(str(value or '').strip())
        return parsed.scheme in ('http', 'https') and bool(parsed.netloc)
    except Exception:
        return False


def should_proxy_asset_url(value):
    try:
        parsed = urllib.parse.urlparse(str(value or '').strip())
        host = (parsed.hostname or '').lower()
        return parsed.scheme in ('http', 'https') and host not in ('127.0.0.1', 'localhost', '::1')
    except Exception:
        return False


def proxy_asset_url(value):
    value = str(value or '').strip()
    if not value or not should_proxy_asset_url(value):
        return value
    try:
        dnsresolver.register_url(value)
    except Exception:
        pass
    try:
        return build_proxy_url(value, kind='art')
    except Exception:
        return value


def set_art_with_fallback(list_item, primary_icon=None, fallback_icon=None):
    icon = primary_icon or fallback_icon
    if not icon:
        return
    try:
        icon = proxy_asset_url(icon) if is_remote_http_url(icon) else icon
        list_item.setArt({'icon': icon, 'thumb': icon})
    except Exception:
        pass


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log('[XC Pro] {}'.format(redact_url(msg)), level)
    except Exception:
        pass


def get_int_setting(setting_id, default_value):
    try:
        value = ADDON.getSetting(setting_id)
        value = int(value) if value else int(default_value)
        if 1 <= value <= 65535:
            return value
    except Exception:
        pass
    return int(default_value)


def get_bool_setting(setting_id, default_value=False):
    try:
        raw = (ADDON.getSetting(setting_id) or '').strip().lower()
        if raw in ('true', '1', 'yes', 'on'):
            return True
        if raw in ('false', '0', 'no', 'off'):
            return False
    except Exception:
        pass
    return bool(default_value)


def get_nonnegative_int_setting(setting_id, default_value=0, max_value=999):
    try:
        value = ADDON.getSetting(setting_id)
        value = int(value) if value not in (None, '') else int(default_value)
        if 0 <= value <= int(max_value):
            return value
    except Exception:
        pass
    return int(default_value)


PROXY_PORT = get_int_setting('proxy_port', 9097)
WEBSERVER_PORT = get_int_setting('webserver_port', 9099)


def get_profile_path():
    profile = ADDON.getAddonInfo('profile')
    try:
        profile = xbmcvfs.translatePath(profile)
    except Exception:
        pass
    try:
        if not xbmcvfs.exists(profile):
            xbmcvfs.mkdirs(profile)
    except Exception:
        try:
            if not os.path.exists(profile):
                os.makedirs(profile)
        except Exception:
            pass
    return profile


PROFILE_PATH = get_profile_path()
PROFILE_LAYOUT = migrate_profile_layout(PROFILE_PATH, logger=lambda msg: log(msg, xbmc.LOGINFO))
EPG_CACHE_FILE = PROFILE_LAYOUT['epg_stream_cache']
EPG_CACHE_DURATION = 86400
EPG_XML_FILE = PROFILE_LAYOUT['epg_xml']
EPG_XML_INDEX_FILE = PROFILE_LAYOUT['epg_index']
EPG_XML_META_FILE = PROFILE_LAYOUT['epg_meta']
SEARCH_STATE_FILE = PROFILE_LAYOUT['search_state']
PAIRING_QR_FILE = PROFILE_LAYOUT['pairing_qr']
EPG_XML_TTL = 86400
EPG_XML_INDEX_VERSION = 'xcpro_epg_xmltv_login_v5'
EPG_XML_MAX_BYTES = 128 * 1024 * 1024
API_CACHE_VERSION = 'xcpro_api_cache_v1'
API_CACHE_TTL_BY_ACTION = {
    'get_live_categories': 21600,
    'get_vod_categories': 21600,
    'get_series_categories': 21600,
    'get_live_streams': 7200,
    'get_vod_streams': 7200,
    'get_vod_info': 21600,
    'get_series': 7200,
    'get_series_info': 21600,
}
XC_EPG_COLOR = 'FF2C7AA9'
EPG_HEADER_COLOR = 'gold'
FAVORITES_VERSION = 'xcpro_favorites_v1'
FAVORITES_FILE = PROFILE_LAYOUT['favorites']
# Enriquecimento conservador: evita martelar servidor em categorias enormes.
VOD_DETAIL_ENRICH_LIMIT = 40




def normalize_host(host):
    host = (host or '').strip()
    if not host:
        return ''
    if not host.startswith(('http://', 'https://')):
        host = 'http://' + host
    try:
        parsed = urllib.parse.urlparse(host)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname:
            return ''
        hostname = parsed.hostname
        if ':' in hostname and not hostname.startswith('['):
            hostname = '[{}]'.format(hostname)
        port = parsed.port
        netloc = '{}:{}'.format(hostname, port) if port else hostname
        return '{}://{}'.format(parsed.scheme, netloc).rstrip('/')
    except Exception:
        return ''


def get_credentials():
    host = normalize_host(ADDON.getSetting('host'))
    username = (ADDON.getSetting('username') or '').strip()
    password = (ADDON.getSetting('password') or '').strip()
    try:
        dnsresolver.set_enabled(ADDON.getSetting('internal_dns') != 'false')
        if host:
            dnsresolver.register_url(host)
    except Exception:
        pass
    return host, username, password


def has_credentials():
    host, user, password = get_credentials()
    return bool(host and user and password)


def quote_path(value):
    return urllib.parse.quote(str(value or ''), safe='')


def clean_extension(ext, default='mp4'):
    ext = str(ext or default).strip().strip('.')
    if not ext:
        ext = default
    # Evita extensão com query acidental ou caracteres indevidos.
    ext = ext.split('?', 1)[0].split('&', 1)[0].strip()
    if not ext:
        ext = default
    return ext


def build_stream_url(kind, stream_id, ext=None):
    host, user, password = get_credentials()
    if not host or not user or not password or not stream_id:
        return ''

    try:
        dnsresolver.register_url(host)
    except Exception:
        pass

    user_q = quote_path(user)
    pass_q = quote_path(password)
    stream_q = quote_path(stream_id)

    if kind == 'live':
        return '{}/live/{}/{}/{}.m3u8'.format(host, user_q, pass_q, stream_q)
    if kind == 'movie':
        return '{}/movie/{}/{}/{}.{}'.format(host, user_q, pass_q, stream_q, clean_extension(ext))
    if kind == 'series':
        return '{}/series/{}/{}/{}.{}'.format(host, user_q, pass_q, stream_q, clean_extension(ext))
    return ''


def build_proxy_url(native_url, kind=None):
    if not native_url:
        return ''
    params = {'url': native_url}
    if kind:
        params['kind'] = kind
    #return 'http://127.0.0.1:{}/?{}'.format(PROXY_PORT, urllib.parse.urlencode(params))
    return 'http://{}:{}/?{}'.format(get_local_ip(), PROXY_PORT, urllib.parse.urlencode(params))


def build_play_url(kind, stream_id, ext=None):
    proxy_kind = 'vod' if kind in ('movie', 'series') else 'live'
    return build_proxy_url(build_stream_url(kind, stream_id, ext), kind=proxy_kind)


def build_play_route(kind, stream_id, ext=None):
    if kind == 'live':
        return build_url({'mode': 'play_live', 'stream_id': stream_id})
    if kind == 'movie':
        return build_url({'mode': 'play_movie', 'stream_id': stream_id, 'ext': clean_extension(ext)})
    if kind == 'series':
        return build_url({'mode': 'play_series', 'stream_id': stream_id, 'ext': clean_extension(ext)})
    return ''


def resolve_playback(kind, stream_id, ext=None):
    url = build_play_url(kind, stream_id, ext)
    li = xbmcgui.ListItem(path=url)
    li.setProperty('IsPlayable', 'true')
    try:
        if kind == 'live':
            li.setMimeType('application/vnd.apple.mpegurl')
            li.setContentLookup(False)
            configure_live_inputstream(li)
            try:
                programs = get_epg_fast_for_stream({'stream_id': stream_id}, limit=4, xml_index=load_epg_xml_index(build_if_missing=False), allow_remote_fallback=True)
                current, nextp = epg_lookup_current_next(programs)
                plot = build_live_epg_plot(
                    current=current,
                    nextp=nextp,
                    include_desc=True,
                    show_now_next=True,
                    now_next_color=XC_EPG_COLOR,
                )
                if plot:
                    safe_set_video_info(li, {'plot': plot})
            except Exception as exc:
                log('Erro ao aplicar EPG no player live {}: {}'.format(stream_id, exc), xbmc.LOGWARNING)
        else:
            li.setContentLookup(True)
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, bool(url), li)


def safe_float(value):
    try:
        if value in (None, ''):
            return None
        return float(value)
    except Exception:
        return None


def safe_int(value):
    try:
        if value in (None, ''):
            return None
        return int(value)
    except Exception:
        return None


def decode_base64(text):
    if not text:
        return ''
    try:
        # Alguns Xtreams entregam title/desc base64, outros já entregam texto comum.
        decoded = base64.b64decode(str(text)).decode('utf-8')
        return decoded or str(text)
    except Exception:
        return str(text)


def color(text, color_name):
    if text is None:
        text = ''
    color_name = color_name or XC_EPG_COLOR
    return '[COLOR {0}]{1}[/COLOR]'.format(color_name, text)


def clean_text_value(value):
    if value in (None, ''):
        return ''
    try:
        if isinstance(value, (list, tuple)):
            value = ', '.join([str(v).strip() for v in value if str(v).strip()])
        elif isinstance(value, dict):
            value = value.get('name') or value.get('title') or ''
        value = decode_base64(value).strip()
        if value.lower() in ('none', 'null', 'n/a', 'na', 'sem informação', 'sem informacao'):
            return ''
        return value
    except Exception:
        return ''


def first_text(data, *keys):
    if not isinstance(data, dict):
        return ''
    for key in keys:
        value = clean_text_value(data.get(key))
        if value:
            return value
    return ''


def extract_year_from_text(value):
    value = clean_text_value(value)
    if not value:
        return None
    try:
        match = re.search(r'(19|20)\d{2}', value)
        if match:
            return int(match.group(0))
    except Exception:
        pass
    return None


def build_vod_video_info(item, media_type='movie'):
    info = {}
    if not isinstance(item, dict):
        return info

    title = first_text(item, 'name', 'title')
    if title:
        info['title'] = title

    plot = first_text(item, 'plot', 'description', 'desc', 'overview', 'short_description', 'storyline')
    if plot:
        info['plot'] = plot

    genre = first_text(item, 'genre', 'genres', 'category_name')
    if genre:
        info['genre'] = genre

    director = first_text(item, 'director')
    if director:
        info['director'] = director

    # Campos como cast/duration variam muito entre servidores Xtream e podem quebrar
    # xbmcgui.ListItem.setInfo em algumas versões/skins quando chegam como string.
    # Para produção conservadora, mantemos a sinopse e metadados estáveis.
    duration = safe_int(item.get('duration_secs') or item.get('duration_seconds'))
    if duration is not None:
        info['duration'] = duration

    rating = safe_float(item.get('rating') or item.get('rating_5based') or item.get('vote_average'))
    if rating is not None:
        info['rating'] = rating

    released = first_text(item, 'releaseDate', 'releasedate', 'release_date', 'premiered', 'aired')
    if released:
        info['premiered'] = released
        info['aired'] = released

    year = safe_int(item.get('year')) or extract_year_from_text(released)
    if year is not None:
        info['year'] = year

    if media_type:
        info['mediatype'] = media_type

    return info


def has_vod_plot(item):
    """Indica se o item/listagem trouxe sinopse útil sem fazer consulta extra."""
    return bool(first_text(item, 'plot', 'description', 'desc', 'overview', 'short_description', 'storyline'))


def merge_nonempty_dicts(*dicts):
    merged = {}
    for data in dicts:
        if not isinstance(data, dict):
            continue
        for key, value in data.items():
            if value in (None, ''):
                continue
            merged[key] = value
    return merged


def merge_vod_detail_payload(base_item, detail_payload):
    """Une get_vod_streams + get_vod_info de forma tolerante aos formatos Xtream."""
    if not isinstance(base_item, dict):
        base_item = {}
    if not isinstance(detail_payload, dict):
        return dict(base_item)

    info = detail_payload.get('info') if isinstance(detail_payload.get('info'), dict) else {}
    movie_data = detail_payload.get('movie_data') if isinstance(detail_payload.get('movie_data'), dict) else {}
    # Ordem proposital: item da listagem preserva ID/ext/categoria; movie_data completa dados; info sobrescreve metadados ricos.
    merged = merge_nonempty_dicts(base_item, movie_data, info)

    if 'name' not in merged and base_item.get('name'):
        merged['name'] = base_item.get('name')
    if 'stream_id' not in merged and base_item.get('stream_id') is not None:
        merged['stream_id'] = base_item.get('stream_id')
    if 'container_extension' not in merged and base_item.get('container_extension'):
        merged['container_extension'] = base_item.get('container_extension')
    return merged


def maybe_enrich_movie_item(item, allow_network=False):
    """Busca get_vod_info só quando necessário e seguro."""
    if not isinstance(item, dict):
        return item, False
    if has_vod_plot(item) or not allow_network:
        return item, False
    stream_id = item.get('stream_id')
    if stream_id in (None, ''):
        return item, False

    detail = fetch_api('get_vod_info', {'vod_id': stream_id}, timeout=6, retries=1)
    enriched = merge_vod_detail_payload(item, detail)
    return enriched, bool(has_vod_plot(enriched))


def sanitize_video_info(info):
    if not isinstance(info, dict):
        return {}
    clean = {}
    text_keys = ('title', 'plot', 'genre', 'director', 'premiered', 'aired', 'mediatype', 'tvshowtitle')
    for key in text_keys:
        value = info.get(key)
        if value not in (None, ''):
            clean[key] = str(value)
    if info.get('rating') is not None:
        rating = safe_float(info.get('rating'))
        if rating is not None:
            clean['rating'] = rating
    if info.get('year') is not None:
        year = safe_int(info.get('year'))
        if year is not None:
            clean['year'] = year
    if info.get('duration') is not None:
        duration = safe_int(info.get('duration'))
        if duration is not None:
            clean['duration'] = duration
    return clean


def _call_tag_method(tag, names, value):
    if value in (None, ''):
        return False
    if isinstance(names, str):
        names = (names,)
    for name in names:
        func = getattr(tag, name, None)
        if not callable(func):
            continue
        try:
            func(value)
            return True
        except Exception:
            continue
    return False


def apply_video_info_tag(list_item, info):
    # Kodi 20/21 recomenda InfoTagVideo no lugar de ListItem.setInfo().
    # Mantemos fallback para Kodi/skins antigas para não quebrar compatibilidade.
    try:
        tag = list_item.getVideoInfoTag()
    except Exception:
        tag = None
    if not tag:
        return False

    applied = False
    applied |= _call_tag_method(tag, 'setTitle', info.get('title'))
    applied |= _call_tag_method(tag, 'setPlot', info.get('plot'))
    applied |= _call_tag_method(tag, 'setMediaType', info.get('mediatype'))
    applied |= _call_tag_method(tag, 'setTvShowTitle', info.get('tvshowtitle'))
    applied |= _call_tag_method(tag, ('setPremiered', 'setFirstAired'), info.get('premiered') or info.get('aired'))

    if info.get('genre'):
        genre_value = [g.strip() for g in str(info.get('genre')).split(',') if g.strip()] or [str(info.get('genre'))]
        applied |= _call_tag_method(tag, ('setGenres', 'setGenre'), genre_value)
    if info.get('director'):
        directors = [d.strip() for d in str(info.get('director')).split(',') if d.strip()] or [str(info.get('director'))]
        applied |= _call_tag_method(tag, ('setDirectors', 'setDirector'), directors)
    if info.get('rating') is not None:
        applied |= _call_tag_method(tag, 'setRating', float(info.get('rating')))
    if info.get('year') is not None:
        applied |= _call_tag_method(tag, 'setYear', int(info.get('year')))
    if info.get('duration') is not None:
        applied |= _call_tag_method(tag, 'setDuration', int(info.get('duration')))
    return bool(applied)


def safe_set_video_info(list_item, info):
    info = sanitize_video_info(info)
    if not info:
        return
    if apply_video_info_tag(list_item, info):
        return
    try:
        list_item.setInfo('video', info)
    except Exception as exc:
        log('Falha ao aplicar metadados de vídeo: {}'.format(exc), xbmc.LOGWARNING)
        # Fallback mínimo: sinopse/título são os campos que interessam para VOD/Séries.
        fallback = {}
        if info.get('title'):
            fallback['title'] = info.get('title')
        if info.get('plot'):
            fallback['plot'] = info.get('plot')
        if fallback:
            try:
                list_item.setInfo('video', fallback)
            except Exception:
                pass


def enrich_vod_art(list_item, item, fallback_icon):
    if not isinstance(item, dict):
        set_art_with_fallback(list_item, fallback_icon=fallback_icon)
        return
    icon = (
        item.get('stream_icon') or item.get('cover') or item.get('cover_big') or
        item.get('movie_image') or item.get('poster') or item.get('image')
    )
    set_art_with_fallback(list_item, icon, fallback_icon)
    try:
        fanart = item.get('fanart') or item.get('backdrop') or item.get('backdrop_path')
        if isinstance(fanart, (list, tuple)):
            fanart = fanart[0] if fanart else ''
        if fanart:
            fanart = proxy_asset_url(fanart) if is_remote_http_url(fanart) else str(fanart)
            list_item.setArt({'fanart': str(fanart)})
    except Exception:
        pass


def build_url(query):
    return BASE_URL + '?' + urllib.parse.urlencode(query)


def end_directory(succeeded=True):
    try:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=succeeded)
    except TypeError:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
    except Exception:
        pass


def notify(title, message, level=xbmcgui.NOTIFICATION_INFO, duration=3000):
    try:
        xbmcgui.Dialog().notification(title, message, level, duration)
    except Exception:
        pass


def get_browser_headers(host=None):
    """Cabeçalhos conservadores para evitar bloqueio 403 em servidores/WAF sensíveis."""
    origin = ''
    try:
        parsed = urllib.parse.urlparse(host or '')
        if parsed.scheme and parsed.netloc:
            origin = '{}://{}'.format(parsed.scheme, parsed.netloc)
    except Exception:
        origin = ''

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
        'Accept': 'application/json,text/plain,*/*',
        'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'Connection': 'close',
    }
    if origin:
        headers['Origin'] = origin
        headers['Referer'] = origin + '/'
    return headers


# -----------------------------------------------------------------------------
# Cache leve / manutenção / status
# -----------------------------------------------------------------------------


def ensure_dir(path):
    try:
        if not xbmcvfs.exists(path):
            xbmcvfs.mkdirs(path)
    except Exception:
        try:
            if not os.path.exists(path):
                os.makedirs(path)
        except Exception:
            pass
    return path


def api_cache_dir(action=None):
    base = ensure_dir(PROFILE_LAYOUT['api_cache'])
    if action:
        return ensure_dir(os.path.join(base, safe_segment(action)))
    return base


def safe_filename(value):
    value = str(value or '')
    try:
        digest = hashlib.sha1(value.encode('utf-8')).hexdigest()
    except Exception:
        digest = str(abs(hash(value)))
    return digest + '.json'


def api_cache_key(action, extra_params=None):
    host, user, password = get_credentials()
    payload = {
        'version': API_CACHE_VERSION,
        'fingerprint': credential_fingerprint(host, user, password),
        'action': action or '',
        'params': extra_params or {},
    }
    try:
        raw = json.dumps(payload, sort_keys=True, ensure_ascii=False)
    except Exception:
        raw = '{}|{}|{}'.format(action or '', credential_fingerprint(host, user, password), extra_params or '')
    return safe_filename(raw)


def api_cache_path(action, extra_params=None):
    return os.path.join(api_cache_dir(action), api_cache_key(action, extra_params))


def api_cache_enabled():
    return get_bool_setting('api_cache_enabled', True)


def api_cache_ttl(action):
    try:
        return int(API_CACHE_TTL_BY_ACTION.get(action or '', 0) or 0)
    except Exception:
        return 0


def save_api_cache(action, extra_params, data):
    if not api_cache_enabled() or not action or data is None:
        return
    ttl = api_cache_ttl(action)
    if ttl <= 0:
        return
    payload = {
        'version': API_CACHE_VERSION,
        'stored_at': int(time.time()),
        'action': action,
        'params': extra_params or {},
        'data': data,
    }
    try:
        safe_write_json(api_cache_path(action, extra_params), payload)
    except Exception as exc:
        log('Falha ao salvar cache API {}: {}'.format(action, exc), xbmc.LOGDEBUG)


def load_api_cache(action, extra_params=None, allow_stale=False):
    if not api_cache_enabled() or not action:
        return None
    ttl = api_cache_ttl(action)
    if ttl <= 0:
        return None
    payload = safe_read_json(api_cache_path(action, extra_params), {})
    if not isinstance(payload, dict) or payload.get('version') != API_CACHE_VERSION:
        return None
    if payload.get('action') != action:
        return None
    try:
        age = int(time.time()) - int(payload.get('stored_at') or 0)
    except Exception:
        age = ttl + 1
    if allow_stale or age <= ttl:
        return payload.get('data')
    return None


def clear_api_cache():
    path = api_cache_dir()
    removed = 0
    try:
        for root, dirs, files in os.walk(path):
            for name in files:
                if name.endswith('.json'):
                    try:
                        os.remove(os.path.join(root, name))
                        removed += 1
                    except Exception:
                        pass
    except Exception:
        pass
    return removed


def clear_runtime_cache():
    removed = 0
    for path in (EPG_CACHE_FILE, EPG_XML_FILE, EPG_XML_INDEX_FILE, EPG_XML_META_FILE):
        try:
            if os.path.exists(path):
                os.remove(path)
                removed += 1
        except Exception:
            pass
    removed += clear_api_cache()
    try:
        clear_epg_runtime_memory()
    except Exception:
        pass
    notify('Manutenção', 'Cache limpo com sucesso.', xbmcgui.NOTIFICATION_INFO)
    log('Manutenção concluiu limpeza de cache: {} arquivo(s).'.format(removed))
    end_directory()


def format_account_expiry_datetime(exp_date):
    if exp_date in (None, '', 0, '0'):
        return ''
    try:
        return time.strftime('%d/%m/%Y %H:%M', time.localtime(int(exp_date)))
    except Exception:
        return str(exp_date)


def days_until_expire(exp_date):
    try:
        exp_ts = int(exp_date)
        if exp_ts <= 0:
            return None
        now_date = datetime.datetime.now().date()
        exp_date_obj = datetime.datetime.fromtimestamp(exp_ts).date()
        return (exp_date_obj - now_date).days
    except Exception:
        return None


def account_status_is_active(user_info):
    if not isinstance(user_info, dict):
        return False
    auth_value = user_info.get('auth')
    if str(auth_value).strip() in ('1', 'true', 'True'):
        return True
    status = str(user_info.get('status') or '').strip().lower()
    if status in ('active', 'ativo', 'enabled', 'online'):
        return True
    return bool(user_info.get('username') and (user_info.get('exp_date') or user_info.get('max_connections') or user_info.get('active_cons') is not None))


def status_color_and_label(user_info):
    raw = str((user_info or {}).get('status') or '').strip()
    if account_status_is_active(user_info):
        return 'green', raw.upper() if raw else 'ATIVO'
    if raw:
        return 'red', raw.upper()
    return 'red', 'NÃO VALIDADO'


def expire_marker_path():
    return os.path.join(get_profile_path(), 'expire_warning_marker.json')


def maybe_show_expire_warning(account_data=None):
    warning_days = get_nonnegative_int_setting('expire_warning_days', 4, 30)
    if warning_days <= 0:
        return
    data = account_data if isinstance(account_data, dict) else fetch_api(None, timeout=4, retries=1)
    if not isinstance(data, dict):
        return
    user_info = data.get('user_info') if isinstance(data.get('user_info'), dict) else {}
    if not account_status_is_active(user_info):
        return
    remaining = days_until_expire(user_info.get('exp_date'))
    if remaining is None or remaining < 0 or remaining > warning_days:
        return

    marker = safe_read_json(expire_marker_path(), {})
    today_key = datetime.datetime.now().strftime('%Y-%m-%d')
    host, user, password = get_credentials()
    key = credential_fingerprint(host, user, password)
    if isinstance(marker, dict) and marker.get('date') == today_key and marker.get('key') == key:
        return

    exp_label = format_account_expiry_datetime(user_info.get('exp_date'))
    if remaining == 0:
        line = 'Seu acesso vence hoje.'
    elif remaining == 1:
        line = 'Seu acesso vence amanhã.'
    else:
        line = 'Seu acesso vence em {} dias.'.format(remaining)
    xbmcgui.Dialog().ok(
        'AVISO DE VENCIMENTO',
        '{}\n\nVencimento: [B]{}[/B]'.format(line, exp_label or 'não informado')
    )
    safe_write_json(expire_marker_path(), {'date': today_key, 'key': key, 'remaining': remaining})


def category_counts_enabled():
    return get_bool_setting('category_counts_enabled', True)


def build_category_count_map(content_endpoint):
    if not category_counts_enabled():
        return {}
    data = load_api_cache(content_endpoint, None, allow_stale=False)
    if data is None:
        data = fetch_api(content_endpoint, timeout=15)
    if not isinstance(data, list):
        return {}
    id_key = 'series_id' if content_endpoint == 'get_series' else 'stream_id'
    counts = {}
    for row in data:
        if not isinstance(row, dict):
            continue
        category_id = str(row.get('category_id') or '').strip()
        item_id = row.get(id_key)
        if not category_id or item_id is None:
            continue
        counts.setdefault(category_id, set()).add(str(item_id))
    return {cid: len(ids) for cid, ids in counts.items()}


def format_category_label(name, category_id, counts_map):
    if not counts_map:
        return name, ''
    try:
        total = int(counts_map.get(str(category_id), 0) or 0)
    except Exception:
        total = 0
    label = '{} ({})'.format(name, total)
    plot = 'Esta categoria possui {} {}.'.format(total, 'item' if total == 1 else 'itens')
    return label, plot


# -----------------------------------------------------------------------------
# Favoritos locais por conta
# -----------------------------------------------------------------------------


def favorite_icon_for_item(item, fallback=''):
    if not isinstance(item, dict):
        return fallback or ''
    return (
        item.get('stream_icon') or item.get('cover') or item.get('cover_big') or
        item.get('movie_image') or item.get('poster') or item.get('image') or
        fallback or ''
    )


def favorites_account_key():
    host, user, password = get_credentials()
    if host and user and password:
        return credential_fingerprint(host, user, password)
    return 'default'


def load_favorites_payload():
    payload = safe_read_json(FAVORITES_FILE, {})
    if not isinstance(payload, dict) or payload.get('version') != FAVORITES_VERSION:
        return {'version': FAVORITES_VERSION, 'accounts': {}}
    accounts = payload.get('accounts')
    if not isinstance(accounts, dict):
        payload['accounts'] = {}
    return payload


def save_favorites_payload(payload):
    if not isinstance(payload, dict):
        payload = {'version': FAVORITES_VERSION, 'accounts': {}}
    payload['version'] = FAVORITES_VERSION
    if not isinstance(payload.get('accounts'), dict):
        payload['accounts'] = {}
    return safe_write_json(FAVORITES_FILE, payload)


def get_favorites_items():
    payload = load_favorites_payload()
    items = payload.get('accounts', {}).get(favorites_account_key(), [])
    return items if isinstance(items, list) else []


def set_favorites_items(items):
    payload = load_favorites_payload()
    payload.setdefault('accounts', {})[favorites_account_key()] = items if isinstance(items, list) else []
    return save_favorites_payload(payload)


def normalize_favorite_type(fav_type):
    fav_type = str(fav_type or '').strip().lower()
    if fav_type in ('live', 'movie', 'series', 'episode'):
        return fav_type
    return ''


def favorite_key(fav_type, stream_id=None, series_id=None, ext=None):
    fav_type = normalize_favorite_type(fav_type)
    if not fav_type:
        return ''
    if fav_type == 'series':
        obj_id = str(series_id or '').strip()
    else:
        obj_id = str(stream_id or '').strip()
    if not obj_id:
        return ''
    ext_part = clean_extension(ext or 'mp4') if fav_type in ('movie', 'episode') else ''
    return '{}:{}:{}'.format(fav_type, obj_id, ext_part)


def is_favorite(fav_type, stream_id=None, series_id=None, ext=None):
    key = favorite_key(fav_type, stream_id=stream_id, series_id=series_id, ext=ext)
    if not key:
        return False
    for item in get_favorites_items():
        if isinstance(item, dict) and item.get('key') == key:
            return True
    return False


def favorite_add_url(fav_type, label, stream_id=None, series_id=None, ext=None, icon=None):
    query = {
        'mode': 'favorite_add',
        'fav_type': fav_type,
        'label': label or 'Sem Nome',
    }
    if stream_id is not None:
        query['stream_id'] = stream_id
    if series_id is not None:
        query['series_id'] = series_id
    if ext:
        query['ext'] = clean_extension(ext)
    if icon:
        query['icon'] = icon
    return build_url(query)


def favorite_remove_url(key):
    return build_url({'mode': 'favorite_remove', 'key': key or ''})


def apply_favorite_context(list_item, fav_type, label, stream_id=None, series_id=None, ext=None, icon=None):
    key = favorite_key(fav_type, stream_id=stream_id, series_id=series_id, ext=ext)
    if not key:
        return
    try:
        if is_favorite(fav_type, stream_id=stream_id, series_id=series_id, ext=ext):
            list_item.addContextMenuItems([
                ('Remover dos Favoritos', 'RunPlugin({})'.format(favorite_remove_url(key)))
            ], replaceItems=False)
        else:
            list_item.addContextMenuItems([
                ('Adicionar aos Favoritos', 'RunPlugin({})'.format(
                    favorite_add_url(fav_type, label, stream_id=stream_id, series_id=series_id, ext=ext, icon=icon)
                ))
            ], replaceItems=False)
    except Exception:
        pass



def current_container_path():
    try:
        return xbmc.getInfoLabel('Container.FolderPath') or ''
    except Exception:
        return ''


def is_favorites_container_active():
    path = current_container_path()
    return 'plugin.video.xcpro' in path and 'mode=favorites' in path


def refresh_favorites_container_only():
    # Favoritos são dados locais; não recarregue categorias/listas pesadas quando
    # o usuário adiciona/remove via menu de contexto fora da tela Favoritos.
    # Só atualiza a tela quando ela própria é a lista de Favoritos.
    if not is_favorites_container_active():
        return
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass

def add_favorite_from_params(params):
    fav_type = normalize_favorite_type(params.get('fav_type'))
    label = clean_text_value(params.get('label')) or 'Sem Nome'
    stream_id = str(params.get('stream_id') or '').strip()
    series_id = str(params.get('series_id') or '').strip()
    ext = clean_extension(params.get('ext') or 'mp4') if fav_type in ('movie', 'episode') else ''
    icon = str(params.get('icon') or '').strip()
    key = favorite_key(fav_type, stream_id=stream_id, series_id=series_id, ext=ext)
    if not key:
        notify('Favoritos', 'Não foi possível adicionar este item.', xbmcgui.NOTIFICATION_WARNING)
        return

    items = [item for item in get_favorites_items() if isinstance(item, dict) and item.get('key') != key]
    record = {
        'key': key,
        'type': fav_type,
        'label': label,
        'stream_id': stream_id,
        'series_id': series_id,
        'ext': ext,
        'icon': icon,
        'added_at': int(time.time()),
    }
    items.insert(0, record)
    if set_favorites_items(items):
        notify('Favoritos', 'Adicionado aos favoritos.', xbmcgui.NOTIFICATION_INFO)
    else:
        notify('Favoritos', 'Falha ao salvar favorito.', xbmcgui.NOTIFICATION_WARNING)
    # Não força atualização da listagem ao adicionar favorito; evita reabrir
    # a categoria atual e reconsultar conteúdos/API sem necessidade.


def remove_favorite_from_params(params):
    key = str(params.get('key') or '').strip()
    if not key:
        return
    old_items = get_favorites_items()
    new_items = [item for item in old_items if not (isinstance(item, dict) and item.get('key') == key)]
    if len(new_items) != len(old_items) and set_favorites_items(new_items):
        notify('Favoritos', 'Removido dos favoritos.', xbmcgui.NOTIFICATION_INFO)
    refresh_favorites_container_only()


def clear_all_favorites():
    if not xbmcgui.Dialog().yesno('Favoritos', 'Deseja limpar todos os favoritos desta conta?'):
        return
    set_favorites_items([])
    notify('Favoritos', 'Favoritos limpos.', xbmcgui.NOTIFICATION_INFO)
    refresh_favorites_container_only()


def show_favorites():
    items = get_favorites_items()
    valid_count = 0

    if not items:
        li = xbmcgui.ListItem(label='[COLOR gray]Nenhum favorito salvo ainda[/COLOR]')
        set_art_with_fallback(li, fallback_icon=menu_icon('favorites.png'))
        safe_set_video_info(li, {'plot': 'Use o menu de contexto em canais, filmes, séries ou episódios para adicionar favoritos.'})
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, build_url({'mode': 'noop'}), li, isFolder=False)
        end_directory()
        return

    for fav in items:
        if not isinstance(fav, dict):
            continue
        fav_type = normalize_favorite_type(fav.get('type'))
        label = clean_text_value(fav.get('label')) or 'Sem Nome'
        stream_id = fav.get('stream_id')
        series_id = fav.get('series_id')
        ext = fav.get('ext') or 'mp4'
        icon = fav.get('icon') or ''
        key = fav.get('key') or favorite_key(fav_type, stream_id=stream_id, series_id=series_id, ext=ext)

        if fav_type == 'live' and stream_id:
            url = build_play_route('live', stream_id)
            prefix = '[COLOR red]CANAL:[/COLOR] '
            is_folder = False
            fallback = menu_icon('live.png')
        elif fav_type == 'movie' and stream_id:
            url = build_play_route('movie', stream_id, ext)
            prefix = '[COLOR blue]FILME:[/COLOR] '
            is_folder = False
            fallback = menu_icon('movies.png')
        elif fav_type == 'episode' and stream_id:
            url = build_play_route('series', stream_id, ext)
            prefix = '[COLOR green]EPISÓDIO:[/COLOR] '
            is_folder = False
            fallback = menu_icon('series.png')
        elif fav_type == 'series' and series_id:
            url = build_url({'mode': 'series_info', 'series_id': series_id})
            prefix = '[COLOR green]SÉRIE:[/COLOR] '
            is_folder = True
            fallback = menu_icon('series.png')
        else:
            continue

        li = xbmcgui.ListItem(label=prefix + label)
        set_art_with_fallback(li, icon, fallback)
        if not is_folder:
            li.setProperty('IsPlayable', 'true')
        try:
            li.addContextMenuItems([
                ('Remover dos Favoritos', 'RunPlugin({})'.format(favorite_remove_url(key)))
            ], replaceItems=False)
        except Exception:
            pass
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=is_folder)
        valid_count += 1

    if valid_count:
        li_clear = xbmcgui.ListItem(label='[COLOR orange]Limpar todos os favoritos[/COLOR]')
        set_art_with_fallback(li_clear, fallback_icon=menu_icon('settings.png'))
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, build_url({'mode': 'favorites_clear'}), li_clear, isFolder=False)
    else:
        li_empty = xbmcgui.ListItem(label='[COLOR gray]Favoritos inválidos ou antigos[/COLOR]')
        set_art_with_fallback(li_empty, fallback_icon=menu_icon('favorites.png'))
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, build_url({'mode': 'noop'}), li_empty, isFolder=False)

    end_directory()


def configure_live_inputstream(list_item):
    # Opcional, mas recomendado por padrão quando o ffmpegdirect existe.
    # Se o módulo não estiver instalado, o player padrão do Kodi continua sendo usado.
    if not get_bool_setting('force_ffmpegdirect_live', True):
        return
    try:
        if xbmc.getCondVisibility('System.HasAddon(inputstream.ffmpegdirect)'):
            list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
            list_item.setProperty('inputstreamaddon', 'inputstream.ffmpegdirect')
            list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
            log('inputstream.ffmpegdirect aplicado ao Live quando disponível.', xbmc.LOGDEBUG)
    except Exception as exc:
        log('Não foi possível aplicar ffmpegdirect opcional: {}'.format(exc), xbmc.LOGDEBUG)


# -----------------------------------------------------------------------------
# API Xtream Codes
# -----------------------------------------------------------------------------


def fetch_api(action=None, extra_params=None, timeout=10, retries=2):
    host, user, password = get_credentials()
    if not host or not user or not password:
        return None

    cached = load_api_cache(action, extra_params, allow_stale=False) if action else None
    if cached is not None:
        return cached

    params = {
        'username': user,
        'password': password,
    }
    if action:
        params['action'] = action
    if extra_params:
        params.update(extra_params)

    url = '{}/player_api.php?{}'.format(host, urllib.parse.urlencode(params))
    last_error = None

    try:
        total_retries = max(1, int(retries))
    except Exception:
        total_retries = 2

    for attempt in range(total_retries):
        try:
            dnsresolver.register_url(url)
            response = requests.get(url, timeout=timeout, headers=get_browser_headers(host), allow_redirects=True)
            if response.status_code != 200:
                last_error = 'HTTP {}'.format(response.status_code)
                log('Resposta API HTTP {} em {}'.format(response.status_code, action or 'account'), xbmc.LOGWARNING)
                if response.status_code in (500, 502, 503, 504) and attempt + 1 < total_retries:
                    time.sleep(0.35)
                    continue
                break
            data = response.json()
            save_api_cache(action, extra_params, data)
            return data
        except Exception as exc:
            last_error = str(exc)
            log('Erro de requisição na API ({}), tentativa {}: {}'.format(action or 'account', attempt + 1, exc), xbmc.LOGWARNING if attempt == 0 else xbmc.LOGERROR)
            if attempt + 1 < total_retries:
                time.sleep(0.35)
                continue

    stale = load_api_cache(action, extra_params, allow_stale=True) if action else None
    if stale is not None:
        log('Usando cache antigo para {} após falha: {}'.format(action, last_error), xbmc.LOGWARNING)
        return stale
    return None

# -----------------------------------------------------------------------------
# EPG XMLTV diário / cache local
# -----------------------------------------------------------------------------


_EPG_XML_INDEX_MEMORY = None
_EPG_XML_INDEX_MEMORY_TS = 0


def safe_read_json(path, default=None):
    try:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as file_obj:
                data = json.load(file_obj)
                return data
    except Exception as exc:
        log('Falha ao ler JSON {}: {}'.format(path, exc), xbmc.LOGWARNING)
    return {} if default is None else default


def safe_write_json(path, data):
    if atomic_write_json(path, data):
        return True
    log('Falha ao salvar JSON {}'.format(path), xbmc.LOGWARNING)
    return False




def search_state_fingerprint():
    try:
        host, user, password = get_credentials()
        return credential_fingerprint(host, user, password)
    except Exception:
        return ''


def load_search_state():
    data = safe_read_json(SEARCH_STATE_FILE, {})
    if not isinstance(data, dict):
        return {}
    current_fp = search_state_fingerprint()
    stored_fp = data.get('fingerprint') or ''
    if stored_fp and current_fp and stored_fp != current_fp:
        return {}
    return data


def save_search_state(data):
    if not isinstance(data, dict):
        data = {}
    data['fingerprint'] = search_state_fingerprint()
    safe_write_json(SEARCH_STATE_FILE, data)


def remember_search_query(query, results=None):
    query = str(query or '').strip()
    if not query:
        return
    state = load_search_state()
    state['last_query'] = query
    if results is not None:
        # Cache leve dos resultados da Pesquisa Global para retorno pós-Stop.
        # Evita reconsultar todo o catálogo e evita reabrir teclado ao voltar.
        if isinstance(results, list):
            state['last_results'] = results
        else:
            state['last_results'] = []
    save_search_state(state)


def mark_search_resume(query=None):
    query = str(query or '').strip()
    state = load_search_state()
    if not query:
        query = str(state.get('last_query') or '').strip()
    if not query:
        return
    state['last_query'] = query
    state['resume_once'] = True
    save_search_state(state)


def pop_search_resume():
    state = load_search_state()
    query = str(state.get('last_query') or '').strip()
    if state.get('resume_once') and query:
        state['resume_once'] = False
        save_search_state(state)
        cached_results = state.get('last_results')
        if isinstance(cached_results, list):
            return {'query': query, 'results': cached_results}
        return {'query': query}
    return None


def clear_search_resume():
    state = load_search_state()
    if state.get('resume_once'):
        state['resume_once'] = False
        save_search_state(state)

def normalize_epg_channel_id(value):
    value = str(value or '').strip()
    if not value:
        return ''
    # Normalização conservadora: minúsculas e sem espaços nas pontas.
    return value.lower()


def extract_xml_text(element, child_name):
    if element is None:
        return ''
    try:
        child = element.find(child_name)
        if child is not None and child.text:
            return child.text.strip()
    except Exception:
        pass
    # fallback para XML com namespace
    try:
        for child in list(element):
            tag = str(child.tag or '').split('}', 1)[-1]
            if tag == child_name and child.text:
                return child.text.strip()
    except Exception:
        pass
    return ''


def parse_xmltv_time(value):
    value = str(value or '').strip()
    if not value:
        return 0
    # Exemplos XMLTV:
    # 20260607190000 -0300
    # 20260607190000 +0000
    # 2026-06-07T19:00:00Z
    try:
        main = value.split(' ', 1)[0].strip()
        tz = value.split(' ', 1)[1].strip() if ' ' in value else ''
        if len(main) >= 14 and main[:14].isdigit():
            dt = datetime.datetime.strptime(main[:14], '%Y%m%d%H%M%S')
            if tz and len(tz) >= 5 and (tz[0] in '+-') and tz[1:5].isdigit():
                sign = 1 if tz[0] == '+' else -1
                offset = sign * (int(tz[1:3]) * 3600 + int(tz[3:5]) * 60)
                return int(dt.replace(tzinfo=datetime.timezone(datetime.timedelta(seconds=offset))).timestamp())
            return int(time.mktime(dt.timetuple()))
        if 'T' in value:
            return int(datetime.datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp())
    except Exception:
        return 0
    return 0


def build_epg_xml_urls():
    host, user, password = get_credentials()
    if not host or not user or not password:
        return []
    params = urllib.parse.urlencode({'username': user, 'password': password})
    return [
        ('xmltv.php', '{}/xmltv.php?{}'.format(host, params)),
        ('epg.php', '{}/epg.php?{}'.format(host, params)),
    ]


def build_epg_xml_url():
    urls = build_epg_xml_urls()
    return urls[0][1] if urls else ''


def epg_meta_fingerprint():
    host, user, password = get_credentials()
    return credential_fingerprint(host, user, password)


def clear_epg_runtime_memory():
    global _EPG_XML_INDEX_MEMORY, _EPG_XML_INDEX_MEMORY_TS
    _EPG_XML_INDEX_MEMORY = None
    _EPG_XML_INDEX_MEMORY_TS = 0


def clear_epg_xml_cache(reason=''):
    clear_epg_runtime_memory()
    for path in (EPG_XML_FILE, EPG_XML_INDEX_FILE, EPG_XML_META_FILE, EPG_CACHE_FILE):
        try:
            if path and os.path.exists(path):
                os.remove(path)
        except Exception as exc:
            log('Falha ao limpar cache EPG {}: {}'.format(path, exc), xbmc.LOGWARNING)
    if reason:
        log('Cache EPG limpo: {}'.format(reason), xbmc.LOGINFO)


def epg_cache_belongs_to_current_login():
    meta = safe_read_json(EPG_XML_META_FILE, {})
    return bool(meta.get('fingerprint') == epg_meta_fingerprint())


def ensure_epg_cache_login_scope():
    if not has_credentials():
        return False
    meta = safe_read_json(EPG_XML_META_FILE, {})
    if meta and meta.get('fingerprint') != epg_meta_fingerprint():
        clear_epg_xml_cache('login/servidor alterado')
        return False
    return True


def epg_xml_file_is_fresh():
    meta = safe_read_json(EPG_XML_META_FILE, {})
    if meta.get('fingerprint') != epg_meta_fingerprint():
        return False
    fetched_at = int(meta.get('fetched_at') or 0)
    if not fetched_at or (time.time() - fetched_at) >= EPG_XML_TTL:
        return False
    try:
        return os.path.exists(EPG_XML_FILE) and os.path.getsize(EPG_XML_FILE) > 128
    except Exception:
        return False


def download_epg_xml_if_needed(force=False):
    # Se trocou login/servidor, nunca reaproveita XML antigo.
    ensure_epg_cache_login_scope()

    if not force and epg_xml_file_is_fresh():
        return True

    urls = build_epg_xml_urls()
    if not urls:
        return False

    current_fp = epg_meta_fingerprint()
    had_current_xml = epg_cache_belongs_to_current_login() and os.path.exists(EPG_XML_FILE)
    last_error = ''

    for label, url in urls:
        try:
            dnsresolver.register_url(url)
            response = requests.get(
                url, timeout=45, headers=get_browser_headers(get_credentials()[0]),
                allow_redirects=True, stream=True
            )
            if response.status_code != 200:
                last_error = 'HTTP {} em {}'.format(response.status_code, label)
                log('EPG XML não baixado: {}'.format(last_error), xbmc.LOGWARNING)
                response.close()
                continue
            try:
                tmp_path, content_size, sample = write_response_to_tempfile(
                    response, get_profile_path(), EPG_XML_MAX_BYTES
                )
            finally:
                response.close()
            if not tmp_path:
                last_error = '{} veio vazio ou excedeu o limite de EPG'.format(label)
                log('EPG XML rejeitado: {}'.format(last_error), xbmc.LOGWARNING)
                continue
            sample = sample.lower()
            if b'<tv' not in sample and b'<xmltv' not in sample and b'<epg' not in sample:
                try:
                    os.remove(tmp_path)
                except Exception:
                    pass
                last_error = '{} não parece XMLTV'.format(label)
                log('EPG XML rejeitado: {}'.format(last_error), xbmc.LOGWARNING)
                continue
            try:
                os.replace(tmp_path, EPG_XML_FILE)
            except Exception:
                try:
                    if os.path.exists(EPG_XML_FILE):
                        os.remove(EPG_XML_FILE)
                    os.rename(tmp_path, EPG_XML_FILE)
                except Exception:
                    try:
                        os.remove(tmp_path)
                    except Exception:
                        pass
                    raise

            safe_write_json(EPG_XML_META_FILE, {
                'fingerprint': current_fp,
                'fetched_at': int(time.time()),
                'size': content_size,
                'source': label,
            })

            try:
                if os.path.exists(EPG_XML_INDEX_FILE):
                    os.remove(EPG_XML_INDEX_FILE)
            except Exception:
                pass
            clear_epg_runtime_memory()
            log('EPG XMLTV salvo para o login atual via {}: {} bytes'.format(label, content_size))
            return True
        except Exception as exc:
            last_error = '{}: {}'.format(label, exc)
            log('Falha ao baixar EPG XML em {}: {}'.format(label, exc), xbmc.LOGWARNING)

    if last_error:
        log('Falha geral ao baixar XMLTV: {}'.format(last_error), xbmc.LOGWARNING)
    return bool(had_current_xml and os.path.exists(EPG_XML_FILE) and os.path.getsize(EPG_XML_FILE) > 128)


def epg_index_is_fresh(index):
    if not isinstance(index, dict):
        return False
    if index.get('version') != EPG_XML_INDEX_VERSION:
        return False
    if index.get('fingerprint') != epg_meta_fingerprint():
        return False
    generated_at = int(index.get('generated_at') or 0)
    if not generated_at or (time.time() - generated_at) >= EPG_XML_TTL:
        return False

    channels = index.get('channels')
    if not isinstance(channels, dict) or not channels:
        return False

    now_ts = int(time.time())
    window_start = int(index.get('window_start') or 0)
    window_end = int(index.get('window_end') or 0)
    if window_start and now_ts < window_start:
        return False
    if window_end and now_ts > window_end:
        return False

    return True


def build_epg_xml_index():
    if not download_epg_xml_if_needed(False):
        return {}

    if not os.path.exists(EPG_XML_FILE):
        return {}

    now_ts = int(time.time())
    # janela de hoje + uma margem curta para madrugada/próximo dia
    start_day = datetime.datetime.fromtimestamp(now_ts).replace(hour=0, minute=0, second=0, microsecond=0)
    window_start = int(start_day.timestamp()) - 3600
    window_end = int((start_day + datetime.timedelta(days=2)).timestamp()) + 3600

    channels = {}
    count = 0
    try:
        for event, elem in ET.iterparse(EPG_XML_FILE, events=('end',)):
            tag = str(elem.tag or '').split('}', 1)[-1]
            if tag != 'programme':
                # evita crescimento de memória em XML grande sem apagar filhos antes do programme fechar
                if tag not in ('title', 'desc'):
                    try:
                        elem.clear()
                    except Exception:
                        pass
                continue

            cid = normalize_epg_channel_id(elem.get('channel'))
            start = parse_xmltv_time(elem.get('start'))
            end = parse_xmltv_time(elem.get('stop') or elem.get('end'))
            if start <= 0:
                try:
                    elem.clear()
                except Exception:
                    pass
                continue
            if end <= start:
                end = start + 3600

            # guarda somente janela útil para as telas do Kodi
            if end < window_start or start > window_end:
                try:
                    elem.clear()
                except Exception:
                    pass
                continue

            title = extract_xml_text(elem, 'title')
            desc = extract_xml_text(elem, 'desc')
            if cid and title:
                channels.setdefault(cid, []).append({
                    'start': start,
                    'end': end,
                    'title': title,
                    'desc': desc,
                })
                count += 1

            try:
                elem.clear()
            except Exception:
                pass

        for cid in list(channels.keys()):
            channels[cid].sort(key=lambda item: item.get('start') or 0)

        index = {
            'version': EPG_XML_INDEX_VERSION,
            'fingerprint': epg_meta_fingerprint(),
            'generated_at': int(time.time()),
            'window_start': window_start,
            'window_end': window_end,
            'channels': channels,
        }
        safe_write_json(EPG_XML_INDEX_FILE, index)
        log('Índice EPG XML criado: canais={}, programas={}'.format(len(channels), count))
        return index
    except Exception as exc:
        log('Falha ao criar índice EPG XML: {}'.format(exc), xbmc.LOGWARNING)
        return {}


def load_epg_xml_index(build_if_missing=False):
    global _EPG_XML_INDEX_MEMORY, _EPG_XML_INDEX_MEMORY_TS

    ensure_epg_cache_login_scope()

    now = time.time()
    if epg_index_is_fresh(_EPG_XML_INDEX_MEMORY) and (now - _EPG_XML_INDEX_MEMORY_TS) < 300:
        return _EPG_XML_INDEX_MEMORY

    index = safe_read_json(EPG_XML_INDEX_FILE, {})
    if not epg_index_is_fresh(index) and build_if_missing:
        index = build_epg_xml_index()

    if epg_index_is_fresh(index):
        _EPG_XML_INDEX_MEMORY = index
        _EPG_XML_INDEX_MEMORY_TS = now
        return index

    return {}


def epg_programs_from_xml_index(index, epg_channel_id, limit=12):
    cid = normalize_epg_channel_id(epg_channel_id)
    if not cid or not isinstance(index, dict):
        return []
    channels = index.get('channels') if isinstance(index.get('channels'), dict) else {}
    programs = channels.get(cid) or []
    if not programs:
        # fallback leve: alguns provedores alteram caixa ou prefixos
        for key, value in channels.items():
            if key == cid or key.endswith(cid) or cid.endswith(key):
                programs = value or []
                break

    now_ts = int(time.time())
    out = []
    for program in programs:
        try:
            end = int(program.get('end') or 0)
            start = int(program.get('start') or 0)
        except Exception:
            continue
        if end and end < now_ts - 300:
            continue
        out.append(program)
        if len(out) >= int(limit or 12):
            break
    return out


def get_epg_fast_for_stream(item, limit=12, xml_index=None, allow_remote_fallback=True):
    """EPG rápido: tenta XMLTV local diário; fallback remoto só quando necessário."""
    if not isinstance(item, dict):
        return []
    epg_channel_id = item.get('epg_channel_id') or item.get('epg_id') or item.get('channel_id')
    if epg_channel_id:
        programs = epg_programs_from_xml_index(xml_index or load_epg_xml_index(), epg_channel_id, limit=limit)
        if programs:
            return programs

    if not allow_remote_fallback:
        return []

    stream_id = item.get('stream_id')
    if stream_id is None:
        return []
    return normalize_epg_programs(get_epg(stream_id, limit=limit))


# -----------------------------------------------------------------------------
# QR Code / pareamento
# -----------------------------------------------------------------------------


def build_pairing_qr_url(pairing_url, size=500):
    return 'https://api.qrserver.com/v1/create-qr-code/?size={0}x{0}&margin=20&data={1}'.format(
        int(size), urllib.parse.quote(pairing_url, safe='')
    )


def download_pairing_qr(pairing_url):
    qr_url = build_pairing_qr_url(pairing_url)
    qr_path = PAIRING_QR_FILE
    try:
        dnsresolver.register_url(qr_url)
        response = requests.get(qr_url, timeout=10)
        if response.status_code == 200 and response.content:
            with open(qr_path, 'wb') as file_obj:
                file_obj.write(response.content)
            return qr_path
        log('Falha ao baixar QR Code: HTTP {}'.format(response.status_code), xbmc.LOGWARNING)
    except Exception as exc:
        log('Erro ao baixar QR Code de pareamento: {}'.format(exc), xbmc.LOGWARNING)
    return None


class QRCodeDialog(xbmcgui.WindowXMLDialog):
    """Janela XML do QR Code usando resources/skins/Default/1080i/QRCodeDialog.xml."""

    qr_path = ''
    _watching = False

    def onInit(self):
        try:
            xbmcgui.Window(10000).clearProperty('xcpro_pairing_saved')
            if self.qr_path:
                self.getControl(1001).setImage(self.qr_path)
            self.setFocusId(1002)
            self._watching = True
            watcher = threading.Thread(target=self._watch_pairing_saved)
            watcher.daemon = True
            watcher.start()
        except Exception as exc:
            log('Erro ao preparar janela XML do QR Code: {}'.format(exc), xbmc.LOGWARNING)

    def _watch_pairing_saved(self):
        """Fecha a janela automaticamente quando o celular salva as credenciais."""
        try:
            while self._watching and not xbmc.Monitor().abortRequested():
                if xbmcgui.Window(10000).getProperty('xcpro_pairing_saved') == '1':
                    try:
                        xbmc.executebuiltin('Dialog.Close(all,true)')
                    except Exception:
                        pass
                    try:
                        self.close()
                    except Exception:
                        pass
                    break
                xbmc.sleep(500)
        except Exception:
            pass

    def close(self):
        self._watching = False
        try:
            xbmcgui.WindowXMLDialog.close(self)
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id == 1002:
            self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = 0
        if action_id in (9, 10, 92):
            self.close()


def show_qr_skin_dialog(qr_path):
    if not qr_path:
        return False
    try:
        dialog = QRCodeDialog('QRCodeDialog.xml', ADDON_PATH, 'Default', '1080i')
        dialog.qr_path = qr_path
        dialog.doModal()
        del dialog
        return True
    except Exception as exc:
        log('Erro ao abrir janela XML do QR Code: {}'.format(exc), xbmc.LOGWARNING)
        return False


def get_pairing_token():
    try:
        return xbmcgui.Window(10000).getProperty('xcpro_pairing_token').strip()
    except Exception:
        return ''


def get_pairing_url():
    token = get_pairing_token()
    if not token:
        return ''
    return 'http://{}:{}/?token={}'.format(
        get_local_ip(), WEBSERVER_PORT, urllib.parse.quote(token, safe='')
    )


def reset_pairing_menu_refresh_state():
    try:
        window = xbmcgui.Window(10000)
        window.clearProperty('xcpro_pairing_refresh_attempts')
        window.clearProperty('xcpro_pairing_refresh_last')
    except Exception:
        pass


def schedule_pairing_menu_refresh(delay=1.8, max_attempts=8):
    """Atualiza a tela inicial quando o service publica o token do QR.

    O service.py sobe o pareamento em thread própria. Quando o addon é aberto
    rápido demais, a primeira listagem pode ser criada antes da propriedade
    xcpro_pairing_token existir. Sem refresh, o usuário fica preso em
    "Iniciando pareamento local..." até navegar para fora e voltar.
    """
    try:
        window = xbmcgui.Window(10000)
        attempts = int(window.getProperty('xcpro_pairing_refresh_attempts') or '0')
        now = time.time()
        last = float(window.getProperty('xcpro_pairing_refresh_last') or '0')
        if attempts >= int(max_attempts):
            return
        if now - last < 1.0:
            return
        window.setProperty('xcpro_pairing_refresh_attempts', str(attempts + 1))
        window.setProperty('xcpro_pairing_refresh_last', str(now))

        def _refresh_later():
            try:
                time.sleep(float(delay))
                # Recarrega a listagem atual. Se o token já foi publicado, o
                # botão QR aparece; se ainda não, a rotina agenda nova tentativa.
                xbmc.executebuiltin('Container.Refresh')
            except Exception:
                pass

        worker = threading.Thread(target=_refresh_later)
        worker.daemon = False
        worker.start()
    except Exception as exc:
        log('Refresh automático do pareamento ignorado: {}'.format(exc), xbmc.LOGDEBUG)


def show_pairing_instruction():
    pairing_url = get_pairing_url()

    if pairing_url:
        reset_pairing_menu_refresh_state()
        li_pair = xbmcgui.ListItem(label='[COLOR yellow]Configurar pelo celular (QR Code)[/COLOR]')
        # Ícone local/padrão no menu. O QR real só aparece dentro da janela de pareamento.
        li_pair.setArt({'icon': menu_icon('settings.png'), 'thumb': menu_icon('settings.png')})
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url=build_url({'mode': 'show_qr_dialog', 'pairing_url': pairing_url}),
            listitem=li_pair,
            isFolder=False,
        )
    else:
        schedule_pairing_menu_refresh()

        li_wait = xbmcgui.ListItem(label='[COLOR orange]Iniciando pareamento local...[/COLOR]')
        li_wait.setArt({'icon': menu_icon('settings.png'), 'thumb': menu_icon('settings.png')})
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url=build_url({'mode': 'noop'}),
            listitem=li_wait,
            isFolder=False,
        )

        li_refresh = xbmcgui.ListItem(label='Atualizar status do pareamento')
        li_refresh.setArt({'icon': menu_icon('settings.png'), 'thumb': menu_icon('settings.png')})
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url=build_url({'mode': 'refresh_pairing'}),
            listitem=li_refresh,
            isFolder=False,
        )

    li_manual = xbmcgui.ListItem(label='Configurar manualmente pelo Kodi')
    li_manual.setArt({'icon': menu_icon('settings.png'), 'thumb': menu_icon('settings.png')})
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=build_url({'mode': 'open_settings'}),
        listitem=li_manual,
        isFolder=False,
    )

    end_directory()


def show_qr_dialog(pairing_url=None, qr_url=None):
    pairing_url = pairing_url or get_pairing_url()
    if not pairing_url:
        xbmcgui.Dialog().ok(
            'Pareamento de Login - XC Pro',
            'O serviço de pareamento ainda está iniciando. Aguarde alguns segundos e abra o QR Code novamente.'
        )
        return

    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        qr_path = download_pairing_qr(pairing_url)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    if qr_path and show_qr_skin_dialog(qr_path):
        return

    xbmcgui.Dialog().ok(
        'Pareamento de Login - XC Pro',
        'Não foi possível abrir o QR Code agora.\n\n'
        'Acesse pelo navegador do celular:\n'
        '[B]{}[/B]'.format(pairing_url),
    )


# -----------------------------------------------------------------------------
# Menus
# -----------------------------------------------------------------------------


def show_main_menu():
    if not has_credentials():
        show_pairing_instruction()
        return

    try:
        maybe_show_expire_warning()
    except Exception as exc:
        log('Aviso de vencimento ignorado: {}'.format(exc), xbmc.LOGDEBUG)

    items = [
        ('Canais Ao Vivo', 'live_categories', menu_icon('live.png'), True),
        ('Filmes (VOD)', 'movie_categories', menu_icon('movies.png'), True),
        ('Séries', 'series_categories', menu_icon('series.png'), True),
        ('Favoritos', 'favorites', menu_icon('favorites.png'), True),
        ('Busca Global', 'search', menu_icon('search.png'), True),
        ('Minha Conta / Status', 'account_status', menu_icon('account.png'), False),
        ('Limpar Cache / Manutenção', 'clear_cache', menu_icon('settings.png'), False),
        ('Trocar Conta / Parear QR', 're_pair', menu_icon('settings.png'), False),
    ]

    for title, mode, icon, is_folder in items:
        li = xbmcgui.ListItem(label=title)
        set_art_with_fallback(li, fallback_icon=icon)
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url=build_url({'mode': mode}),
            listitem=li,
            isFolder=is_folder,
        )

    end_directory()


def add_category_items(categories, mode, icon, counts_map=None):
    count = 0
    counts_map = counts_map or {}
    for cat in categories or []:
        category_id = cat.get('category_id')
        category_name = cat.get('category_name') or 'Sem Nome'
        if category_id is None:
            continue
        label, plot = format_category_label(category_name, category_id, counts_map)
        li = xbmcgui.ListItem(label=label)
        set_art_with_fallback(li, fallback_icon=icon)
        if plot:
            safe_set_video_info(li, {'plot': plot})
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url=build_url({'mode': mode, 'category_id': category_id}),
            listitem=li,
            isFolder=True,
        )
        count += 1
    return count


def show_live_categories():
    categories = fetch_api('get_live_categories')
    counts_map = build_category_count_map('get_live_streams')
    if not add_category_items(categories, 'live_streams', menu_icon('live.png'), counts_map):
        notify('Aviso', 'Nenhuma categoria de canais encontrada.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def show_movie_categories():
    categories = fetch_api('get_vod_categories')
    counts_map = build_category_count_map('get_vod_streams')
    if not add_category_items(categories, 'movie_streams', menu_icon('movies.png'), counts_map):
        notify('Aviso', 'Nenhuma categoria de filmes encontrada.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def show_series_categories():
    categories = fetch_api('get_series_categories')
    counts_map = build_category_count_map('get_series')
    if not add_category_items(categories, 'series_list', menu_icon('series.png'), counts_map):
        notify('Aviso', 'Nenhuma categoria de séries encontrada.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def show_live_streams(category_id):
    streams = fetch_api('get_live_streams', {'category_id': category_id})
    count = 0
    for item in streams or []:
        stream_id = item.get('stream_id')
        if stream_id is None:
            continue
        item_name = item.get('name') or 'Sem Nome'
        label = item_name
        epg_title = item.get('epg_title') or ''
        if epg_title:
            label = '{} [COLOR gray]({})[/COLOR]'.format(label, decode_base64(epg_title))

        li = xbmcgui.ListItem(label=label)
        set_art_with_fallback(li, item.get('stream_icon'), menu_icon('live.png'))
        apply_favorite_context(li, 'live', item_name, stream_id=stream_id, icon=item.get('stream_icon'))
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, build_play_route('live', stream_id), li, isFolder=False)
        count += 1

    if not count:
        notify('Aviso', 'Nenhum canal encontrado nesta categoria.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def show_movie_streams(category_id):
    streams = fetch_api('get_vod_streams', {'category_id': category_id})
    total_streams = len(streams) if isinstance(streams, list) else 0
    allow_detail_enrich = 0 < total_streams <= VOD_DETAIL_ENRICH_LIMIT
    count = 0
    plot_from_list = 0
    plot_final = 0
    detail_hits = 0

    for item in streams or []:
        stream_id = item.get('stream_id')
        if stream_id is None:
            continue

        if has_vod_plot(item):
            plot_from_list += 1

        meta_item, enriched_with_plot = maybe_enrich_movie_item(item, allow_network=allow_detail_enrich)
        if enriched_with_plot:
            detail_hits += 1
        if has_vod_plot(meta_item):
            plot_final += 1

        item_name = meta_item.get('name') or item.get('name') or 'Sem Nome'
        ext = clean_extension(meta_item.get('container_extension') or item.get('container_extension') or 'mp4')
        li = xbmcgui.ListItem(label=item_name)
        enrich_vod_art(li, meta_item, menu_icon('movies.png'))
        apply_favorite_context(li, 'movie', item_name, stream_id=stream_id, ext=ext, icon=favorite_icon_for_item(meta_item))

        info = build_vod_video_info(meta_item, 'movie')
        if info:
            safe_set_video_info(li, info)

        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            build_play_route('movie', stream_id, ext),
            li,
            isFolder=False,
        )
        count += 1

    if count:
        if allow_detail_enrich:
            log('VOD metadados categoria {}: itens={} sinopse_lista={} sinopse_final={} detalhes_com_sinopse={}'.format(category_id, count, plot_from_list, plot_final, detail_hits), xbmc.LOGINFO)
        else:
            log('VOD metadados categoria {}: itens={} sinopse_lista={} sinopse_final={} detalhes_pulados=limite_{}'.format(category_id, count, plot_from_list, plot_final, VOD_DETAIL_ENRICH_LIMIT), xbmc.LOGINFO)

    if not count:
        notify('Aviso', 'Nenhum filme encontrado nesta categoria.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def show_series_list(category_id):
    series = fetch_api('get_series', {'category_id': category_id})
    count = 0
    plot_count = 0
    for item in series or []:
        series_id = item.get('series_id')
        if series_id is None:
            continue

        if has_vod_plot(item):
            plot_count += 1

        item_name = item.get('name') or 'Sem Nome'
        li = xbmcgui.ListItem(label=item_name)
        enrich_vod_art(li, item, menu_icon('series.png'))
        apply_favorite_context(li, 'series', item_name, series_id=series_id, icon=favorite_icon_for_item(item))

        info = build_vod_video_info(item, 'tvshow')
        if info:
            safe_set_video_info(li, info)

        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            build_url({'mode': 'series_info', 'series_id': series_id}),
            li,
            isFolder=True,
        )
        count += 1

    if count:
        log('Séries metadados categoria {}: itens={} sinopse_lista={}'.format(category_id, count, plot_count), xbmc.LOGINFO)
    if not count:
        notify('Aviso', 'Nenhuma série encontrada nesta categoria.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def show_series_info(series_id):
    data = fetch_api('get_series_info', {'series_id': series_id})
    episodes = data.get('episodes') if isinstance(data, dict) else None
    if not episodes:
        notify('Aviso', 'Sem episódios disponíveis.', xbmcgui.NOTIFICATION_WARNING)
        end_directory()
        return

    def sort_key(value):
        try:
            return int(value)
        except Exception:
            return 0

    series_info = data.get('info') if isinstance(data.get('info'), dict) else {}
    series_plot = first_text(series_info, 'plot', 'description', 'desc', 'overview')
    try:
        log('Série detalhe {}: temporadas={} sinopse_serie={}'.format(series_id, len(episodes.keys()) if isinstance(episodes, dict) else 0, 'sim' if series_plot else 'nao'), xbmc.LOGINFO)
    except Exception:
        pass

    count = 0
    for season_num in sorted(episodes.keys(), key=sort_key):
        label = 'Temporada {}'.format(season_num)
        li = xbmcgui.ListItem(label=label)
        set_art_with_fallback(li, series_info.get('cover') or series_info.get('cover_big'), menu_icon('series.png'))
        season_info = build_vod_video_info(series_info, 'season')
        if series_plot and 'plot' not in season_info:
            season_info['plot'] = series_plot
        if season_info:
            safe_set_video_info(li, season_info)
        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            build_url({'mode': 'series_episodes', 'series_id': series_id, 'season_num': season_num}),
            li,
            isFolder=True,
        )
        count += 1

    if not count:
        notify('Aviso', 'Sem temporadas disponíveis.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def show_series_episodes(series_id, season_num):
    data = fetch_api('get_series_info', {'series_id': series_id})
    episodes = data.get('episodes') if isinstance(data, dict) else None
    eps = []
    if isinstance(episodes, dict):
        eps = episodes.get(str(season_num), []) or []

    count = 0
    episode_plot_count = 0
    for ep in eps:
        stream_id = ep.get('id')
        if stream_id is None:
            continue

        title = 'Episódio {} - {}'.format(ep.get('episode_num', 'X'), ep.get('title') or 'Sem Título')
        ext = clean_extension(ep.get('container_extension') or 'mp4')
        li = xbmcgui.ListItem(label=title)
        info = ep.get('info') if isinstance(ep.get('info'), dict) else {}
        thumb = info.get('movie_image') or info.get('cover_big') or info.get('cover')
        set_art_with_fallback(li, thumb, menu_icon('series.png'))
        apply_favorite_context(li, 'episode', title, stream_id=stream_id, ext=ext, icon=thumb)
        if info:
            video_info = {}
            ep_plot = first_text(info, 'plot', 'description', 'desc', 'overview')
            if ep_plot:
                episode_plot_count += 1
                video_info['plot'] = ep_plot
            if info.get('rating'):
                rating = safe_float(info.get('rating'))
                if rating is not None:
                    video_info['rating'] = rating
            if video_info:
                safe_set_video_info(li, video_info)

        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            build_play_route('series', stream_id, ext),
            li,
            isFolder=False,
        )
        count += 1

    if count:
        log('Episódios metadados série {} temporada {}: itens={} sinopse_episodio={}'.format(series_id, season_num, count, episode_plot_count), xbmc.LOGINFO)
    if not count:
        notify('Aviso', 'Nenhum episódio encontrado.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


# -----------------------------------------------------------------------------
# Conta/configurações
# -----------------------------------------------------------------------------


def show_account_status():
    host, user, _ = get_credentials()
    data = fetch_api(None)
    dialog = xbmcgui.Dialog()

    if isinstance(data, dict) and isinstance(data.get('user_info'), dict):
        user_info = data.get('user_info') or {}
        color_name, status_label = status_color_and_label(user_info)
        exp_label = format_account_expiry_datetime(user_info.get('exp_date'))
        remaining = days_until_expire(user_info.get('exp_date'))

        lines = [
            'Servidor: [B]{}[/B]'.format(host or 'não informado'),
            'Usuário: [B]{}[/B]'.format(user or 'não informado'),
            'Status: [COLOR {}][B]{}[/B][/COLOR]'.format(color_name, status_label),
        ]
        if exp_label:
            lines.append('Vencimento: [B]{}[/B]'.format(exp_label))
        if remaining is not None:
            if remaining < 0:
                lines.append('Dias restantes: [COLOR red][B]VENCIDO[/B][/COLOR]')
            else:
                lines.append('Dias restantes: [B]{}[/B]'.format(remaining))
        if user_info.get('active_cons') is not None and user_info.get('max_connections') is not None:
            lines.append('Conexões: [B]{}/{}[/B]'.format(user_info.get('active_cons'), user_info.get('max_connections')))
        if user_info.get('created_at'):
            created = format_account_expiry_datetime(user_info.get('created_at'))
            if created:
                lines.append('Criado em: {}'.format(created))

        dialog.ok('XC Pro Status', '\n'.join(lines))
    else:
        dialog.ok(
            'XC Pro Status',
            'Não foi possível validar a conta agora.\n\n'
            'Servidor: {}\n'
            'Usuário: {}\n'
            'Status: [COLOR red]ERRO DE CONEXÃO OU CREDENCIAIS[/COLOR]'.format(host or 'não informado', user or 'não informado'),
        )

def open_settings():
    old_fingerprint = epg_meta_fingerprint()
    ADDON.openSettings()
    host, user, password = get_credentials()
    if host and ADDON.getSetting('host') != host:
        ADDON.setSetting('host', host)

    if old_fingerprint != epg_meta_fingerprint():
        clear_epg_xml_cache('configuração manual alterada')

    if host and user and password:
        account = fetch_api(timeout=8)
        if isinstance(account, dict) and account.get('user_info'):
            notify('XC Pro', 'Configuração manual validada.', xbmcgui.NOTIFICATION_INFO)
        else:
            notify('XC Pro', 'Dados salvos, mas o servidor não validou a conexão.', xbmcgui.NOTIFICATION_WARNING, 5000)
    xbmc.executebuiltin('Container.Refresh')


def clear_account_and_pair():
    if not xbmcgui.Dialog().yesno('XC Pro', 'Deseja limpar a conta atual e configurar novamente?'):
        return
    ADDON.setSetting('host', '')
    ADDON.setSetting('username', '')
    ADDON.setSetting('password', '')
    clear_epg_xml_cache('conta removida')
    notify('XC Pro', 'Conta removida. Abra o QR Code para parear novamente.', xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')


# -----------------------------------------------------------------------------
# Busca global
# -----------------------------------------------------------------------------


def build_search_results(raw_q):
    raw_q = str(raw_q or '').strip()
    search_term = raw_q.lower()
    results = []
    movie_list_plot_count = 0
    movie_final_plot_count = 0
    movie_detail_hits = 0

    if not search_term:
        return results

    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        live_streams = fetch_api('get_live_streams')
        for stream in live_streams or []:
            name = stream.get('name') or ''
            if search_term in name.lower() and stream.get('stream_id') is not None:
                results.append({
                    'type': 'live',
                    'title': name,
                    'stream_id': stream.get('stream_id'),
                    'icon': stream.get('stream_icon', ''),
                })

        movies = fetch_api('get_vod_streams')
        movie_matches = []
        for movie in movies or []:
            name = movie.get('name') or ''
            if search_term in name.lower() and movie.get('stream_id') is not None:
                movie_matches.append(movie)

        allow_movie_detail = len(movie_matches) <= VOD_DETAIL_ENRICH_LIMIT
        for movie in movie_matches:
            name = movie.get('name') or ''
            if has_vod_plot(movie):
                movie_list_plot_count += 1
            meta_movie = movie
            enriched_with_plot = False
            if allow_movie_detail:
                meta_movie, enriched_with_plot = maybe_enrich_movie_item(movie, allow_network=True)
                if enriched_with_plot:
                    movie_detail_hits += 1
            if has_vod_plot(meta_movie):
                movie_final_plot_count += 1
            results.append({
                'type': 'movie',
                'title': name,
                'stream_id': movie.get('stream_id'),
                'icon': movie.get('stream_icon', ''),
                'ext': movie.get('container_extension') or 'mp4',
                'info': build_vod_video_info(meta_movie, 'movie'),
                'raw': meta_movie,
            })

        series_list = fetch_api('get_series')
        for serie in series_list or []:
            name = serie.get('name') or ''
            if search_term in name.lower() and serie.get('series_id') is not None:
                results.append({
                    'type': 'series',
                    'title': name,
                    'series_id': serie.get('series_id'),
                    'icon': serie.get('cover', ''),
                    'info': build_vod_video_info(serie, 'tvshow'),
                })
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    if movie_matches:
        if allow_movie_detail:
            log('Busca global metadados termo "{}": filmes={} sinopse_lista={} sinopse_final={} detalhes_com_sinopse={}'.format(raw_q, len(movie_matches), movie_list_plot_count, movie_final_plot_count, movie_detail_hits), xbmc.LOGINFO)
        else:
            log('Busca global metadados termo "{}": filmes={} sinopse_lista={} sinopse_final={} detalhes_pulados=limite_{}'.format(raw_q, len(movie_matches), movie_list_plot_count, movie_final_plot_count, VOD_DETAIL_ENRICH_LIMIT), xbmc.LOGINFO)
    log('Busca global termo "{}": resultados={}'.format(raw_q, len(results)), xbmc.LOGINFO)
    return results


def render_search_results(raw_q, results):
    raw_q = str(raw_q or '').strip()
    xbmcplugin.setPluginCategory(ADDON_HANDLE, 'Pesquisa: {}'.format(raw_q))

    li_new = xbmcgui.ListItem(label='[B]Nova pesquisa[/B]')
    set_art_with_fallback(li_new, menu_icon('search.png'), menu_icon('search.png'))
    safe_set_video_info(li_new, {'plot': 'Abrir o teclado para fazer uma nova pesquisa global.'})
    # Usa token ignorado pela rota apenas para forçar o Kodi a abrir a pasta,
    # sem deixar a tela marcada como "new=1". Se o usuário reproduzir algo e der Stop,
    # o retorno consome resume_once/cache e não abre teclado de novo.
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, build_url({'mode': 'search', 'new_token': str(int(time.time() * 1000))}), li_new, isFolder=True)

    if not results:
        notify('Busca', "Nenhum resultado para '{}'".format(raw_q), xbmcgui.NOTIFICATION_INFO)
        end_directory()
        return

    for result in results:
        result_type = result['type']
        if result_type == 'live':
            url = build_url({'mode': 'play_live', 'stream_id': result['stream_id'], 'from_search': '1', 'search_q': raw_q})
            li = xbmcgui.ListItem(label='[COLOR red]CANAL:[/COLOR] {}'.format(result['title']))
            is_folder = False
        elif result_type == 'movie':
            url = build_url({'mode': 'play_movie', 'stream_id': result['stream_id'], 'ext': result.get('ext') or 'mp4', 'from_search': '1', 'search_q': raw_q})
            li = xbmcgui.ListItem(label='[COLOR blue]FILME:[/COLOR] {}'.format(result['title']))
            is_folder = False
        else:
            url = build_url({'mode': 'series_info', 'series_id': result['series_id'], 'from_search': '1', 'search_q': raw_q})
            li = xbmcgui.ListItem(label='[COLOR green]SÉRIE:[/COLOR] {}'.format(result['title']))
            is_folder = True

        fallback = menu_icon('live.png') if result_type == 'live' else (menu_icon('movies.png') if result_type == 'movie' else menu_icon('series.png'))
        set_art_with_fallback(li, result.get('icon'), fallback)
        if result_type == 'live':
            apply_favorite_context(li, 'live', result.get('title'), stream_id=result.get('stream_id'), icon=result.get('icon'))
        elif result_type == 'movie':
            apply_favorite_context(li, 'movie', result.get('title'), stream_id=result.get('stream_id'), ext=result.get('ext') or 'mp4', icon=result.get('icon'))
        elif result_type == 'series':
            apply_favorite_context(li, 'series', result.get('title'), series_id=result.get('series_id'), icon=result.get('icon'))
        if result.get('info'):
            try:
                safe_set_video_info(li, result.get('info'))
            except Exception:
                pass
        if not is_folder:
            li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=is_folder)

    end_directory()


def search_global():
    current_params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    raw_q = (current_params.get('q') or '').strip()
    cached_results = None
    resumed = None

    if not raw_q:
        resumed = pop_search_resume()
        if isinstance(resumed, dict):
            raw_q = str(resumed.get('query') or '').strip()
            if isinstance(resumed.get('results'), list):
                cached_results = resumed.get('results')
        elif resumed:
            raw_q = str(resumed or '').strip()

    if raw_q and isinstance(cached_results, list):
        log('Busca global retorno cache termo "{}": resultados={}'.format(raw_q, len(cached_results)), xbmc.LOGINFO)
        render_search_results(raw_q, cached_results)
        return

    if not raw_q:
        keyboard = xbmc.Keyboard('', 'Digite o termo para buscar')
        keyboard.doModal()

        if not keyboard.isConfirmed():
            # Se cancelar a nova pesquisa, preserva a última lista em vez de deixar pasta vazia.
            state = load_search_state()
            last_q = str(state.get('last_query') or '').strip()
            last_results = state.get('last_results')
            if last_q and isinstance(last_results, list):
                render_search_results(last_q, last_results)
            else:
                end_directory()
            return

        raw_q = keyboard.getText().strip()
        if not raw_q:
            state = load_search_state()
            last_q = str(state.get('last_query') or '').strip()
            last_results = state.get('last_results')
            if last_q and isinstance(last_results, list):
                render_search_results(last_q, last_results)
            else:
                end_directory()
            return

    results = build_search_results(raw_q)
    remember_search_query(raw_q, results)
    render_search_results(raw_q, results)

# -----------------------------------------------------------------------------
# EPG
# -----------------------------------------------------------------------------


def get_epg(stream_id, limit=5):
    epg_cache = {}
    if os.path.exists(EPG_CACHE_FILE):
        try:
            with open(EPG_CACHE_FILE, 'r', encoding='utf-8') as file_obj:
                epg_cache = json.load(file_obj)
        except Exception:
            epg_cache = {}

    cache_key = 'epg_{}_{}'.format(stream_id, limit)
    current_time = time.time()

    cached = epg_cache.get(cache_key)
    if isinstance(cached, dict) and (current_time - cached.get('timestamp', 0)) < EPG_CACHE_DURATION:
        return cached.get('data') or []

    epg_data = None
    attempts = [
        ('get_short_epg', {'stream_id': stream_id, 'limit': limit}),
        ('get_simple_data_table', {'stream_id': stream_id}),
        ('get_epg_for_stream', {'stream_id': stream_id}),
    ]

    for action, params in attempts:
        epg_data = fetch_api(action, params)
        if epg_data:
            break

    processed_data = []
    if isinstance(epg_data, list):
        processed_data = epg_data
    elif isinstance(epg_data, dict):
        if isinstance(epg_data.get('epg_listings'), list):
            processed_data = epg_data.get('epg_listings')
        elif isinstance(epg_data.get('data'), list):
            processed_data = epg_data.get('data')
        else:
            for value in epg_data.values():
                if isinstance(value, list):
                    processed_data = value
                    break
            if not processed_data and epg_data:
                processed_data = [epg_data]

    if processed_data:
        epg_cache[cache_key] = {'timestamp': current_time, 'data': processed_data}
        if len(epg_cache) > 100:
            for old_key in sorted(epg_cache, key=lambda key: epg_cache[key].get('timestamp', 0))[:-100]:
                epg_cache.pop(old_key, None)
        try:
            with open(EPG_CACHE_FILE, 'w', encoding='utf-8') as file_obj:
                json.dump(epg_cache, file_obj)
        except Exception as exc:
            log('Erro ao salvar cache EPG: {}'.format(exc), xbmc.LOGWARNING)

    return processed_data


def extract_program_title(program):
    if not isinstance(program, dict):
        return ''
    title = program.get('title') or program.get('name') or program.get('event') or program.get('event_name') or ''
    return decode_base64(title).strip()


def extract_program_desc(program):
    if not isinstance(program, dict):
        return ''
    desc = program.get('description') or program.get('desc') or program.get('plot') or ''
    return decode_base64(desc).strip()


def normalize_epoch_seconds(value):
    if value in (None, ''):
        return 0
    try:
        if isinstance(value, (int, float)):
            return int(value)
        raw = str(value).strip()
        if not raw:
            return 0
        if raw.isdigit():
            return int(raw)

        # Formatos comuns: ISO, Xtream e XMLTV básico.
        cleaned = raw.replace('Z', '+00:00')
        try:
            return int(datetime.datetime.fromisoformat(cleaned).timestamp())
        except Exception:
            pass

        for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%d/%m/%Y %H:%M:%S', '%d/%m/%Y %H:%M', '%Y%m%d%H%M%S'):
            try:
                return int(datetime.datetime.strptime(raw[:len(datetime.datetime.now().strftime(fmt))], fmt).timestamp())
            except Exception:
                continue

        # XMLTV às vezes vem como 20260607190000 +0000.
        compact = raw.split()[0]
        if compact.isdigit() and len(compact) >= 14:
            return int(datetime.datetime.strptime(compact[:14], '%Y%m%d%H%M%S').timestamp())
    except Exception:
        return 0
    return 0


def normalize_epg_program(program):
    if not isinstance(program, dict):
        return None
    title = extract_program_title(program)
    desc = extract_program_desc(program)
    start = normalize_epoch_seconds(
        program.get('start_timestamp') or program.get('start') or program.get('start_time') or program.get('start_date')
    )
    end = normalize_epoch_seconds(
        program.get('end_timestamp') or program.get('stop_timestamp') or program.get('end') or program.get('stop') or program.get('end_time')
    )
    if end <= start and start > 0:
        end = start + 3600
    return {
        'title': title,
        'desc': desc,
        'start': start,
        'end': end,
        'raw': program,
    }


def normalize_epg_programs(epg_data):
    programs = []
    for program in epg_data or []:
        normalized = normalize_epg_program(program)
        if normalized and (normalized.get('title') or normalized.get('desc') or normalized.get('start')):
            programs.append(normalized)
    programs.sort(key=lambda item: item.get('start') or 0)
    return programs


def epg_format_range(program):
    if not program:
        return ''
    start = int(program.get('start') or 0)
    end = int(program.get('end') or 0)
    if start <= 0:
        return ''
    if end <= start:
        end = start + 3600
    return '{} - {}'.format(
        datetime.datetime.fromtimestamp(start).strftime('%H:%M'),
        datetime.datetime.fromtimestamp(end).strftime('%H:%M'),
    )


def epg_lookup_current_next(programs):
    now = int(time.time())
    current = None
    nextp = None

    for index, program in enumerate(programs or []):
        start = int(program.get('start') or 0)
        end = int(program.get('end') or 0)
        if start and end and start <= now < end:
            current = program
            if index + 1 < len(programs):
                nextp = programs[index + 1]
            break
        if start and start > now:
            nextp = program
            if index - 1 >= 0:
                prev = programs[index - 1]
                prev_end = int(prev.get('end') or 0)
                if prev_end >= now:
                    current = prev
            break

    if not current and programs:
        # Alguns servidores entregam get_short_epg começando no programa atual sem timestamp útil.
        first = programs[0]
        if not first.get('start') or first.get('start') <= now:
            current = first
            if len(programs) > 1:
                nextp = programs[1]

    return current, nextp


def build_live_epg_plot(current=None, nextp=None, include_desc=True, day_schedule=None, compact=False, show_now_next=True, now_next_color=None, current_color=None, next_color=None, schedule_color=None, schedule_header_color=None, schedule_current_color=None):
    """Formato de exibição do EPG leve, mantendo o runtime conservador do XC Pro."""
    parts = []

    if current_color is None:
        current_color = now_next_color
    if next_color is None:
        next_color = now_next_color

    if show_now_next and current:
        current_title = str(current.get('title') or '').strip()
        current_desc = str(current.get('desc') or '').strip()
        current_range = epg_format_range(current)
        if current_range and current_title:
            current_line = 'Agora: {} | {}'.format(current_range, current_title)
        elif current_title:
            current_line = 'Agora: {}'.format(current_title)
        else:
            current_line = ''
        if current_line:
            parts.append(color(current_line, current_color or XC_EPG_COLOR))
        if include_desc and current_desc:
            parts.append(current_desc)

    if show_now_next and nextp:
        next_title = str(nextp.get('title') or '').strip()
        next_desc = str(nextp.get('desc') or '').strip()
        next_range = epg_format_range(nextp)
        if current and (next_title or (include_desc and next_desc)) and not compact:
            parts.append('')
        if next_range and next_title:
            next_line = 'Próximo: {} | {}'.format(next_range, next_title)
        elif next_title:
            next_line = 'Próximo: {}'.format(next_title)
        else:
            next_line = ''
        if next_line:
            parts.append(color(next_line, next_color or XC_EPG_COLOR))
        if include_desc and next_desc:
            parts.append(next_desc)

    schedule_lines = []
    now_ts = int(time.time())
    for program in day_schedule or []:
        title = str(program.get('title') or '').strip()
        when = epg_format_range(program)
        if when and title:
            line = '{} | {}'.format(when, title)
        elif title:
            line = title
        else:
            line = ''
        if not line:
            continue

        start = int(program.get('start') or 0)
        end = int(program.get('end') or 0)
        is_current = bool(start and (start <= now_ts < (end if end > start else start + 3600)))

        if is_current and schedule_current_color:
            schedule_lines.append(color(line, schedule_current_color))
        elif schedule_color:
            schedule_lines.append(color(line, schedule_color))
        else:
            schedule_lines.append(line)

    if schedule_lines:
        if parts and not compact:
            parts.append('')
        header = 'Grade do dia'
        if schedule_header_color:
            header = color(header, schedule_header_color)
        elif compact:
            header = color(header, EPG_HEADER_COLOR)
        parts.append(header)
        parts.extend(schedule_lines)

    return '\n'.join(parts).strip()


def show_live_streams_with_epg(category_id):
    streams = fetch_api('get_live_streams', {'category_id': category_id})
    if not streams:
        notify('Aviso', 'Nenhum canal encontrado.', xbmcgui.NOTIFICATION_WARNING)
        end_directory()
        return

    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    count = 0
    try:
        # Navegação rápida: categoria só lê o índice pronto.
        # O download/parse do XMLTV inteiro fica no service.py em background.
        xml_index = load_epg_xml_index(build_if_missing=False)
        allow_remote_fallback = False

        for item in streams:
            stream_id = item.get('stream_id')
            if stream_id is None:
                continue

            name = item.get('name') or 'Sem Nome'
            label = name
            programs = []
            current = None
            nextp = None
            try:
                programs = get_epg_fast_for_stream(
                    item,
                    limit=12,
                    xml_index=xml_index,
                    allow_remote_fallback=allow_remote_fallback,
                )
                current, nextp = epg_lookup_current_next(programs)
                current_title = str((current or {}).get('title') or '').strip()
                if current_title:
                    label = '{} - {}'.format(name, color(current_title, XC_EPG_COLOR))
            except Exception as exc:
                log('Erro ao aplicar EPG rápido no canal {}: {}'.format(item.get('name'), exc), xbmc.LOGWARNING)

            li = xbmcgui.ListItem(label=label)
            set_art_with_fallback(li, item.get('stream_icon'), menu_icon('live.png'))

            info_labels = {'title': name}
            plot = build_live_epg_plot(
                current=current,
                nextp=nextp,
                include_desc=False,
                day_schedule=programs,
                compact=True,
                show_now_next=False,
                schedule_current_color=XC_EPG_COLOR,
                schedule_header_color=EPG_HEADER_COLOR,
            )
            if plot:
                info_labels['plot'] = plot
            elif current:
                desc = current.get('desc') or ''
                if desc:
                    info_labels['plot'] = desc
            if current and current.get('title'):
                info_labels['tvshowtitle'] = current.get('title')
            if info_labels:
                safe_set_video_info(li, info_labels)

            li.setProperty('IsPlayable', 'true')
            full_epg_url = build_url({
                'mode': 'show_full_epg',
                'stream_id': stream_id,
                'stream_name': item.get('name') or 'Canal',
                'epg_channel_id': item.get('epg_channel_id') or '',
            })
            li.addContextMenuItems([
                ('Ver Programação Completa', 'Container.Update({})'.format(full_epg_url))
            ])
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, build_play_route('live', stream_id), li, isFolder=False)
            count += 1
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    if not count:
        notify('Aviso', 'Nenhum canal disponível nesta categoria.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def format_epg_time(start_time):
    ts = normalize_epoch_seconds(start_time)
    if ts:
        return datetime.datetime.fromtimestamp(ts).strftime('%H:%M')
    if not start_time:
        return ''
    try:
        value = str(start_time)
        if len(value) >= 5:
            return value[:5]
    except Exception:
        return ''
    return ''


def show_full_epg(stream_id, stream_name, epg_channel_id=None):
    """Lista a programação completa como uma pasta real do Kodi.

    Ajuste conservador:
    - usa o índice XMLTV salvo quando existir;
    - se o índice ainda não existir, tenta construir uma vez apenas nesta tela;
    - mantém fallback antigo por stream_id;
    - não usa RunPlugin, porque esta função monta diretório/listagem.
    """
    stream_name = stream_name or 'Canal'
    programs = []

    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        if epg_channel_id:
            # Primeiro caminho: índice já pronto em background.
            index = load_epg_xml_index(build_if_missing=False)
            programs = epg_programs_from_xml_index(index, epg_channel_id, limit=48)

            # Se o usuário pediu programação completa e o índice ainda não existe,
            # tenta construir usando XMLTV local/atual. Isso não afeta abertura das categorias.
            if not programs:
                index = load_epg_xml_index(build_if_missing=True)
                programs = epg_programs_from_xml_index(index, epg_channel_id, limit=48)

        if not programs and stream_id:
            epg_data = get_epg(stream_id, limit=48)
            programs = normalize_epg_programs(epg_data)
    except Exception as exc:
        log('Erro ao carregar Programação Completa de {}: {}'.format(stream_name, exc), xbmc.LOGWARNING)
        programs = []
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    if not programs:
        notify('EPG', 'Sem informação de programação para {}'.format(stream_name or 'este canal'), xbmcgui.NOTIFICATION_WARNING)
        end_directory()
        return

    try:
        xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    except Exception:
        pass

    count = 0
    now_ts = int(time.time())
    for program in programs:
        if not isinstance(program, dict):
            continue

        title = str(program.get('title') or 'Sem título').strip() or 'Sem título'
        description = str(program.get('desc') or '').strip()
        formatted_time = epg_format_range(program) or format_epg_time(program.get('start'))
        label = '{} | {}'.format(formatted_time, title) if formatted_time else title

        try:
            start_int = int(program.get('start') or 0)
            end_int = int(program.get('end') or 0)
        except Exception:
            start_int, end_int = 0, 0

        is_current = bool(start_int and start_int <= now_ts < (end_int if end_int > start_int else start_int + 3600))
        if is_current:
            label = color(label, XC_EPG_COLOR)

        li = xbmcgui.ListItem(label=label)
        set_art_with_fallback(li, fallback_icon=menu_icon('live.png'))

        info = {
            'title': title,
            'tvshowtitle': stream_name,
        }
        if description:
            info['plot'] = description
        if start_int:
            info['aired'] = time.strftime('%Y-%m-%d', time.localtime(start_int))
        safe_set_video_info(li, info)

        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            build_url({'mode': 'noop'}),
            li,
            isFolder=False
        )
        count += 1

    if not count:
        notify('EPG', 'Nenhum programa encontrado para {}'.format(stream_name or 'este canal'), xbmcgui.NOTIFICATION_WARNING)
    end_directory()


# -----------------------------------------------------------------------------
# Playback por rota da busca
# -----------------------------------------------------------------------------


def maybe_mark_search_resume_from_params():
    try:
        current_params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        if str(current_params.get('from_search') or '').lower() in ('1', 'true', 'yes', 'on'):
            mark_search_resume(current_params.get('search_q') or current_params.get('q') or '')
    except Exception as exc:
        log('Falha ao marcar retorno da busca: {}'.format(exc), xbmc.LOGDEBUG)


def play_live_stream(stream_id):
    maybe_mark_search_resume_from_params()
    resolve_playback('live', stream_id)


def play_movie_stream(stream_id, ext='mp4'):
    maybe_mark_search_resume_from_params()
    resolve_playback('movie', stream_id, ext)


def play_series_stream(stream_id, ext='mp4'):
    maybe_mark_search_resume_from_params()
    resolve_playback('series', stream_id, ext)


# -----------------------------------------------------------------------------
# Router
# -----------------------------------------------------------------------------


def main():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    mode = params.get('mode')

    if not mode:
        show_main_menu()
    elif mode == 'live_categories':
        show_live_categories()
    elif mode == 'live_streams':
        show_live_streams_with_epg(params.get('category_id'))
    elif mode == 'movie_categories':
        show_movie_categories()
    elif mode == 'movie_streams':
        show_movie_streams(params.get('category_id'))
    elif mode == 'series_categories':
        show_series_categories()
    elif mode == 'series_list':
        show_series_list(params.get('category_id'))
    elif mode == 'series_info':
        show_series_info(params.get('series_id'))
    elif mode == 'series_episodes':
        show_series_episodes(params.get('series_id'), params.get('season_num'))
    elif mode == 'account_status':
        show_account_status()
    elif mode == 'favorites':
        show_favorites()
    elif mode == 'favorite_add':
        add_favorite_from_params(params)
    elif mode == 'favorite_remove':
        remove_favorite_from_params(params)
    elif mode == 'favorites_clear':
        clear_all_favorites()
    elif mode == 'clear_cache':
        clear_runtime_cache()
    elif mode == 'show_qr_dialog':
        show_qr_dialog(params.get('pairing_url'), params.get('qr_url'))
    elif mode == 'open_settings':
        open_settings()
    elif mode == 'refresh_pairing':
        reset_pairing_menu_refresh_state()
        xbmc.executebuiltin('Container.Refresh')
        end_directory(succeeded=False)
    elif mode == 're_pair':
        clear_account_and_pair()
    elif mode == 'search':
        search_global()
    elif mode == 'show_full_epg':
        show_full_epg(params.get('stream_id'), params.get('stream_name'), params.get('epg_channel_id'))
    elif mode == 'noop':
        end_directory()
    elif mode == 'play_live':
        play_live_stream(params.get('stream_id'))
    elif mode == 'play_movie':
        play_movie_stream(params.get('stream_id'), params.get('ext') or 'mp4')
    elif mode == 'play_series':
        play_series_stream(params.get('stream_id'), params.get('ext') or 'mp4')
    else:
        log('Modo desconhecido: {}'.format(mode), xbmc.LOGWARNING)
        show_main_menu()


if __name__ == '__main__':
    main()
