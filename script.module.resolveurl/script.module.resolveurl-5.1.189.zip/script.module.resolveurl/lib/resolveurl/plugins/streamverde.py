# -*- coding: utf-8 -*-

from resolveurl.resolver import ResolveUrl, ResolverError
from resolveurl import common
import re


class StreamingVerdeResolver(ResolveUrl):
    name = "StreamingVerde"
    domains = ["streamingverde.com"]
    pattern = r'(?://|\.)(streamingverde\.com)/p\.php/?.*?[?&]id=([#0-9a-zA-Z_-]+)'

    def __init__(self):
        self.net = common.Net()

    def get_url(self, host, media_id):
        media_id = media_id.replace('#', '')
        return f"https://{host}/p.php?id={media_id}"

    def get_media_url(self, host, media_id):
        media_id = media_id.replace('#', '')
        page_url = self.get_url(host, media_id)

        headers = {
            'User-Agent': common.RAND_UA,
            'Referer': page_url,
            'Accept': '*/*'
        }

        html = self.net.http_GET(page_url, headers=headers).content

        stream_match = re.search(r'videoSource\s*=\s*[\'"]([^\'"]+)', html, re.I)
        if not stream_match:
            raise ResolverError("videoSource não encontrado")

        stream_url = stream_match.group(1)
        if not stream_url.startswith("http"):
            stream_url = f"https://{host}/" + stream_url.lstrip("/")

        return stream_url
