# -*- coding: utf-8 -*-
import base64 as _b, zlib as _z
_k=b'OPC9-code-X7p3$'
_p=(
    'H;R^T;1RS^b(5<e#`&ci*5}m;?R?!2Yc8Y6(7QKu_y9>+TPP(zo)fS$gd=CrzT}s`H!84ZwlAMA-@<G1{K8yWF*@1rf5_jWQVbbac`i;&I?Ea4RXFnEcxQ&T'
    'RrIF?IumTIyU<Z)`RF@-!srJTo_IgjWEPA@ECD6<ptEmNWAFLJ=b_a4K49^8UZ)!4ApOeua=gP8Rj7L$>km_vXGM+*o@s0O4Iw%~j>{3vdPK?I+Pr(C1_Y5j'
    'd8D)Inr#+rQcUqhc^dXYG1>gj;u%FUO)B*vExS3T9a6-?4{7?{Jin8Hy6e?jtE6NFzr2twTx^AH7657n7w~Z7=l<SqZf;Tfn#(4j|LWGfO4L4sRs1niLRY%D'
    'vb*~0?}VK0Sy*KZ2AjAB0r!1rR*S64uYczowo!_1k4bgoV$iuA>6!k*dRgUq(C$=imA4Zqu+E?64FT6p(}+}~^nWa4%rP<Os(ovEh2m$X&%y|7&E7#K;S5Tz'
    '_GRCDnE>eE{){Rl0+dck=O04FwGvG->hv1Xe_B#e_My_<h9OHJk_Dgo!1^k-POF9#{P2X{PuW4cuS-s~03vK+WwZKe6U&HHUno9(8q;>fy3@F>6ydWao}HEr'
    'WZaxQ(h7*pdK+()6A=Px$#W9utda#iwdMHDp4>W^2TdFigfrb+)9T=4_ShqKUgdPEsrV2F!NzdJJekX!{GtvJw3_;%`?0e&J1p-;0z=7lcmL(g+5@!OOVgYD'
    '($wC<{i_g5ahF@Wqx;Jx=P=VgOf5;G3rPs97JwRkGr8ncR<2?o!FVt4k!=S(KF5EWAAlXXHqfQ`CC<V7$$>8h!VP0q%nB<A@Ji%LO)m~Bly_P;^KR+qM7xkk'
    '+;CZ-v#naSWD<l0)}`hUFv3Ll97N)fM}H>2YXTASF`gJDPo_}G6Hh2JK<(g`d-%l5`CBW$2;XT(y*ASO7#i8*=V3Q`pJ#hRZ<q8yB^?IR2q3@~o=cPoOiw$;'
    'vFP2*7u_p)Iw*8<-sKFYU5{!U!O(L}7v#zpwO%)iF=p@24xHxZe?9JqsrYx}JTNtiID#YDKpSf0rqLOboU>2+Z3Dt5O$gVPWUWPFQ82^d9@Z!bjkF|IVdU-l'
    '=S1+P|LPTScC~<db3Oe}nPooSR8w=PT3!fmBZyHv;Tl6o*t1VIMk5*rQw(4#-C;$a`1e}eSX=FyP~M>=?y&C`%muqbG+an#-4olKf=l-<R9pSl0;_!j#L==N'
    'EAp(4PQQsE)lKNqXL(0BW2z!U#V&-OD67}^`0~DsPK*0(HTN)a3ha(M!r0IrjZWA^)RSJ5uFO(SCW&6dj0A|UNBZUz&&KTqGi6c8@vunkl940?&@~C2{BL)F'
    'q$ch{g_}06mt8T58ll2*J!?;Aj7Daua;tyw-NEwDBCW$FqeUkxKQdyG?oSv-<-=1N!3gF)KGNgbMZJG(Nc0yUg$;MGuIO3Y(jDMkf)Spgyyd0r;EgOk6qngz'
    's8PHVC!RiF4UUpem>TD(Y#DIbAx5YK$Awygg!-OI^`*;Wk6L|RWx^1wlZ_0BtaAH6B-$aAgr*k@>Wd(2Ref%8lsfHG$2P8kh6?%xA9t&+Vy_Fp%RhGAs|4W{'
    '@mfc`2mn!GM1ROX8b2>o!hBdk!hZ'
)
_r=_b.b85decode(_p.encode('ascii'))
_r=bytes((v ^ _k[i % len(_k)]) for i,v in enumerate(_r))
exec(compile(_z.decompress(_r), __file__, 'exec'), globals(), globals())
