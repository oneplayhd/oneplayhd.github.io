# -*- coding: utf-8 -*-
import base64 as _b, zlib as _z
_k=b'OPC9-code-X7p3$'
_p=(
    'H;RU1auBpqcT$g#u$C*`eo;_nE%n@nD!<j4R=$bJd(KKt_yt8j%BS!%FVEuMcM>niD;Sg4*Iz}SPZ`21Kq&SN_OuY=l7yeHGV(?(94w+5Fw0{VZwkQ~D&EdS'
    'CyiKDsMjRuZ|ZMS^j`*gt?>+TqU5NIm}^Fpe8D5lN1;4>fGYQU^Lnbg@_JK1IG?k5c>r%(=@eobE+uWn%3&iX>^0Tn?jHFO?yV?$Qa(ECrqZToh=d9=xpnq%'
    '^f8g2dN2cgZKENPC;miQYVJqJ)t|d1SCKoyf!?($9d51WjHp`Shlzb>3W}d0atKQdW9CKI+^fNJTa|Zdav3e0f=|^=O4^WG-O~}yJVqly^T6VXcjI!JLvU_*'
    'LNoJ-1pc+X1m^NYpi8l~8cbpZ!%cChgQq?-k9xjj1)n%oj1WGy;`kQTfnqh&MA(;NeH8jDbz#_|Kn(kC1r4o1GW(Sd$N}n09aTzQumk`wkbjFe_IKg`_#vi;'
    'v8Bv}TuWTYggjx8h<fBwr7q>F4cq4BMq$6?S&`}KkT$k>yBA%e|Ez;_1=AHM3bA=25@pVA#TX~ARASKkmI>!s<UGl9T3tU2%H5)wbX5R!c(lc2K>~TuOz>NK'
    '?DYCRyG@4fxGD-RlLvVvE>ww~YVu7aEQ$}*wJC_nwcp}8sf{Ow>c0?{$AmJ^f+>|fICF1_`?R2^hGc!g8x<WUycu({MWh%&e5+ATN7?lGs6g>5u*l&NO7{o@'
    '+%5xd%oP6)8H@8Ea9i4n4=wiS{QP?OX(m?V>)aa<tP&|u>3huz-25}qcI@pJb><KIfNirv^<3YtBrUts>)P_^4r(zmA?o3#FlNp&leG}R0|S73CG_24Oql%|'
    'zjbEEnEP-zXZa5m3<xN?S)z5Jh+H}s)8H5q9yDGmF*%8fQ-7@su3yyihCU51eX;!4Nf+!W5+2S?)`^`z^w2(mPTeYd8tV2_>QQbQkh5qA9a9~jS5FEIT!EdD'
    '07_m8K<V}=Ti$1qqBINC-_tGUHg1ej(ZV=ByzAuks!@cD6S$OZ^Aax7?x7K%-8rB2x8*|=2lgOh7Od+Tw9HAWP*|$k{u&=)avtX0iJz2Efd{&Aq3NX~>jVPO'
    'rN;?Q8;Xg`r+4`9z{4Nctz&Oa8Jgeyr^lo)E0CHejT-)T>XTpFBzR7}c3|l&UTnz8gIw0``u53hvYs7VM!}^{JH$oB0L_Rqov?Sp;r!>yx>HZNX0#`d+RB)P'
    '`ec;-7Y2dq`@!9*uDFsamKG2cM;Rxk&!4#bsD<B~<>`<TN@v|*pQ)zxfgg<ZXk`ivf`F@d7sMhVU<3)`4J@>zBm$EB3^2^bJ?Csl*#n1pgx#ekapi0{8zL?e'
    'Gc{73i0A=@ExMFRz$TUR!v}m4bS@7Q@nQ8Xwl)V)3}X_m@t)-xiOUJpFeX9K^UQa3|1=*b))1L?_U<2omgtO2-o2GP_p?MY8NsNut^)c}6Z=Vo?&&(L9{Tn5'
    'or_+2DwGU?lT^t8x3t~B`U+9YpVptM!CL;owu8A2%SEo1^7a2q7yn)<s*p0_?>Z<evu@z|#koJ%Q!=?{9l69z2g8D(O+Y>c`p_@9gGD1v2=$^Ky9m9LP2Z4_'
    'k_=O0xP^;|@v7E@@IXo9phE6at%RfedBPA-KlB|`A5ZBOWM1Midt0k(5i!M}0y25@zQcj-O;jawJnlHd^l*_DPncybOp7mUwyDC7u{Bg!!3C+Bcil|l6tW&%'
    'W&f5+Dxc!hYzdc+s(7#zNHbnXut{dK5J`sPhx)7gSLCW@t;o1npj!X}|I9GNtZ|6)GgpIWIAyU>ssz$Ps5hE&_lXqVEnpj%uqWf9st`q<!qk76WT`=xm^RIL'
    'KwK6gOb*8hGTLOeT`*tm%ovU(HwwiH)D=GO+=7U|EZXc)!%E^Q;%Jn)q%+D^yNeIME0s{6$`K|%e~D+DI~)f%4HkqAM_xsk6RbJW9qiRsk~RLAcZrJWmId_d'
    '=9IULnK31EQ5V?g7qe|1LhJ9`R$lM%X&mY~R3VQQott^e0S^bSNY{yx!^YN8j)x`*z(3LSR5kx!@n#MyN2QhC7r3_HB;ut$`mp-hJeG^s$70y6hC1=KNq*{F'
    '5C(g!<-xob%BJ<Oc|vwwNNJ9jSrGh65vI=qz(W5Vz!R}ujpm&nylsA6^0PyfAhMPm<ipUw0|cNuEmUo2-(5B<9y-7(>ZqZ&PL!bL%rp)~Jn`g~;%t2v2$ltf'
    'F5$bbl(^iy-wl8Y!am<JMKwP<q<*Ys0Se^UOCq@%$-7M!Oxn%MB3R=@VBq2(*NrG+a2pI>Iym(rKV^Mc>g81~qQddEe5XcSX#^3-%Qb2}vDU&c)upYm-4TV0'
    'B3P2d_bdsnz0bf19S{|%?=xoYJV^NiHWV9uds*nl)B(4FY=Bgwzxc3i{Wl%-T$7|zDU5sf=!m0X%dp~<R$_W=V2P9GuHSrx2OjvC${+>_VTDqj8t1uA6|PiN'
    '84?JRUuiLo%B1>fg7A;LFaC40-d3B0!3{N%p!ayoR$lNWo)~oCvCzRO7mjmgJoyUVTdpK?txM7hMl`T7503>~Lp6ZB*$vf@%jf_iyy&gS@442l`Hl?jY~8kv'
    'qBD4U+)F)9o$b;ju$G$)?G}z%ljIrLj_}Aay;c9-^k|yfk)uV)OLvOL?6XH(Am2dLD~m%ShSb9vbW@88gc78sl$Kg1b>u4Mll&%t#cIWO{0Oac0-Zqqgch2*'
    'Ax-CwZihns_j%Cw#jp6iob*r@rz{@RdX=|b90|}W9rUd8EG83NCv+?&6&zwrw@9_TxZ72uow-X|7qFel*}|v{xh-_DtBrPVTgtdL^CkIUYy;ekQ>ra^aF&O}'
    'dI5P}7^B0ROf#SX{vv_FCOX2-HWB)aSm_5fR{Z5jNPy3$R9X@%u54umb7n)^YvcEQp<@#ew!VbLocmdp_^}db{C&w7jEAX~AR}aoxHd~`_u!NE!B^jFhr#j~'
    'I;K4;c;pi!w4Kn=8Y&a6<f%38knW@4=C6z%?eMB7K#gy*+x+|Woh?p#`4zu~kebSoPcWa2h`TpzuKcpMcbouPPT+{0jAkX`sCa#K$}<z%!yTZOSA&VfuFUyp'
    'k*R37jeg*{&4!Zdta6Y&1I_VNATygF>_l_$>^~ZN<-tG5^gE=*a-Hg_PI%3qXzyA}I>>z`I<SUyj)=}VRc)h=J&hgovK|yVI6LleTlU2=(u5l#?4L^HwJbrt'
    '+)x`_<epRW@O)Df#5L_L@GVVZ2TEXWL(0^Xcf&9qnkp1V+=l'
)
_r=_b.b85decode(_p.encode('ascii'))
_r=bytes((v ^ _k[i % len(_k)]) for i,v in enumerate(_r))
exec(compile(_z.decompress(_r), __file__, 'exec'), globals(), globals())
