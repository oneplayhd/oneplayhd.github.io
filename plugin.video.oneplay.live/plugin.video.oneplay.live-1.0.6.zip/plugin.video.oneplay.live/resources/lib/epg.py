# -*- coding: utf-8 -*-
import base64 as _b, zlib as _z
_k=b'OPC9-code-X7p3$'
_p=(
    'H;VRP@C~z4bCbuAP$M9ll<^D0WiD0BFCb*M2DF#fpilPxa%_2|YxFcBao$P{YblFVkZhafZ=CjeI*)@^|3tPIO-HN@{($__RP}w|A5&Ob@?k4a6QjUh3K0(S'
    '!NS4)lk{IgKx@Je-?!g7R>-sco$iNhw>aAJsV5^B84fOy3LHbkY|Z@dsFv$sdg5&ZW||o=n0!A~@I7((Bh|1~jRol65_E@7GkcFdj;xJ~f0G+8{80&AYE28S'
    'fk$lXEKPf~iSyxJr~nc2218z-mQh)snzM4soR}rTs=oJdCvZJ7*jZLBRhM%QKmZXe?(#tWI~E@0D?&+2o{^kcOGn*t9RJjT+rYhKyU)jV=eN-N!L3eB=-gGz'
    '&Ff(2qs8evsogO$h=lJ%P@fW%f-?4auCw5tN2e$h`4g3)(?W_!P1S-KGen>hSCbJRQoEq~&qPRht^|DIB6M=f7v>lP9(&Z~onLB8o&o`zh)W)Apn|GZ+wH1L'
    ';};n(F53?d-b7kaNMs{3a(!+g2PB66gB6~nm9W%-&RHVwMcy-c_O9^x+L1tDOSA|RqhosZyMh+Wrev}>!Bm?oXne;z+}`2$yG%B{$}eVbFFd2u>p-SNjtE%g'
    '57!sFKK3W^14NKUz7~}qitSNB3Sl|#Xp&$ouxGygNA}3>okIgnaYS;QV9(0Pju<TvQ$5JafAs$Oztf@||KWgQCOn~imm8$6u@fl#QtlZ|Fe3+10gpp2W4g86'
    'H0=smgko|tb@TH~m%x4yG(;WQFu~p=0o@*AuYWI~P|%I93Vj00^-{1@iEpU=)h1NRL484q7lZOTEpE#$!SSDHrO2+dVmtxq5u1}e#VYB@#e|{QA_NmWU_5{x'
    'L2%r8Rz^;gvf1WXrV+Xt-(sg_0*@V`L8)@hK#{mX`Q9~j$6t<))%kliDQt$g%m%`Y&V<4t`ukfIy>yPcV23Pk8-8Oq%T@y9zu2C^L@4nRPhYR0gw}&z?0g*!'
    '^#Ve?Iu99<)m9|F6rYx$`;jFf8|34El$maj3jBvk{C@cX6J{tNJUXWMDsEnl$1GP!s-V}IBw06UEsyVaGnApdd%JJlK_#N*IggH&(Mb5nzCI`3P)UQ?1t3Hv'
    'JwPOB%l<N20UD-yOGPiX7%RjMW{n8WQ1$wC2lUyl06BsGFc;quvvA386~JF1xtc*Oz&G$%J)e0{1K~NRGSn#@^9I+|(O%Qd;DN--seQN4<f(|-=owccMIF9F'
    '1AuIuBLmg^1)qq?BTz91nh&3+EHvuLYqx*nNZe^RL7UoGd2^Wwmr{NPki$J7^`&&L6l_(P9S!X0{+#-bwQm5)r2<g|wPS$Pi~PEQ*L1TCbzzipwl--$!L7!4'
    '_S=@A=lxA(l@s9G)h8CpJUEoy1u9Wuxq|l;OY6Q1cR)ceJ?%Kji=x3xG8q3KJvePQngtas!=`l)*SqQKj$8X?R3<k$o;|JF!zovct}t=3&BMRGJcVrH_pC!W'
    'VP7w!!^&a86%!p}<JL2Fz{&7te@AO+YN28pp9A$HeS|WA%B<HbaLwy!SP7MgH1oA!;8EMv7=;C5g2YI1N;iifRU<6*VQNtG!hT+5oKyY@_oc);o6&I{IAK%('
    'Y&A4&yCWxY_0dd$(pG>~rd$cPrjDUDO{-|>!wPiX@|n->tlwJ6V>Xri$51NfHL!R@7f4{^AM6#GxTgGQV7R{eN9@CJ%(0OP17}wFnI!JRxF~9QQk!br=cj>p'
    'H)SBLR36A*j;nUTs#f8lT<Ag@6>|;<J70K_<sqfywry)_@$Eg>ASU-+D&Lj^Z<`adh6XQg5M4rIRmyYpif|7XD$Ugk4O+X2GeTQx9z3kN95&|c{76-#2z)kf'
    'uz$j7Fq+{6B{<LV)W^kmgT$7^ULt0Hq8?Vfrv_+=sf|7IVtEFM7?UzIrR*sGP2@f4N}f6!)Q-LDSOSGqe+++WXIH(-k(8_SfrT88$uR`jYxh|<ZujB`O6Hq}'
    'pWz10<_4(ITe<C^s#@%nxmqjsC=15N*AIz~VYJ)%{A{xp7A%P%N??iNTNH6s4D-u&sy@@Ay9vFBZzu3uQoCUwJ{L~z;yqIA6aJMF6D7ibDi~nGwAuJ#k#$~L'
    'D%aS1crW&hcJdB@^X>C&M*emJkTcsq80LKs`s7v^$^5xprT^<Zmk#2}zuSX@=1H&PlWd<ASv}jS;)+s{p|nTg@hYILTjHvvrN6l1<1NP6#KPt@eEzH)^TH+v'
    'y|}LZG~G)v{gZQGVN`=O!GH`{C6tnN5cW`7)bVkcoXd5zcpl)w$VP&;6_lb<eL9_d`lbSdk?>S)JJ-%YvjD64dCLP4Qw7cJmgg$^rV}2<7v?`dJ%^64QfIVR'
    'F(iGfkkXT7H2Z)tXs;*EZHM+*Rpi+9*P}oeK0z_Iu;w;!$Wdt)yWIyK(3o_xk|4ZxyZ0bL5g$+rCqN~)V%FL@ebiI_WD`bVa%O_2tNCM`SQVBb32T*E;|g7*'
    'h)x4ezVk!dm{4;iDT#btCAb2t_{e0NzfzBKRcMSHaj?3pv>W$|GazR0CMPmPdCb)(?xAriFJS&|&090IM*YahiJwZL_m$fTsG#bm$P5ehxC3yj29T<uO``i7'
    'm5hujrr1#rKN+^i<dtD)Xm22+Q3$Z&Y2Axe)ZQjMK!o9={@kG%m6<6y=RSJ@EYGqBNJpq?S(Z}m?pS;u6~3)s#uc_-hYooY=Q*(a5(GmK;={!LRlI{u7IL_W'
    '6gYoETXZpj6n04r9yx56`yo*!{Y_}e@>0&DLlO;4PZslj;Gi~F8qDN0U1tAJM3-UQfW^sD95!Lp$)mL(x2-5bZm@~xn@1p3A6m#8yus9TWmELC2+*EA-WhF2'
    '43sXBoSb?ij>TJ)`Ymx~dQF7PvM=gPzF!^Czj$z-6_~46Au(aUX!D7hXoNetPbglh<a_~1T{^3X&PvQcx)FQr&7#uTgXb$!vzgNJf+JpDojtQrh4Y853&BY_'
    'xP5vB^{t&p-r&Q$WiDpfm)yVGL171aa`lc-l>Ta~!V}O>K){8g%~plL*hlRwJ*nXxgKETfDWqGCHK2Kyc8^!&o@C~jihO^HNiRm@Oh}g(Ato_a1yi(FHYMO+'
    '-zLXdiNjL*2v%_4gI@QLqhd^*cr+EZPw)J2B^v1WCS)a<HAX&L6@V5wn;Y{GN<7Y^XSKL6bdb<YyHDtk<#_'
)
_r=_b.b85decode(_p.encode('ascii'))
_r=bytes((v ^ _k[i % len(_k)]) for i,v in enumerate(_r))
exec(compile(_z.decompress(_r), __file__, 'exec'), globals(), globals())
