OnePlay Live 1.0.6 — V4 IDENTIDADE E APRESENTAÇÃO
CANDIDATO PERICIADO

O OnePlay Live reúne canais de TV, programação e eventos esportivos em uma
interface própria. A edição V4 mantém a evolução temporal da V3, aprovada
em teste real, e padroniza os textos públicos de apresentação.

CATÁLOGO
- Canais organizados por uma categoria editorial principal.
- Capas e informações de programação disponíveis no painel de informações.
- Inclusão e remoção de canais acompanhadas pelo catálogo dinâmico.
- A lista de canais e seus identificadores de reprodução permanecem intactos.

EVENTOS
- Partidas futuras entram na grade 20 minutos antes do horário programado.
- Eventos iniciados permanecem disponíveis durante sua janela temporal.
- Eventos com término informado têm tolerância de 20 minutos após o fim.
- Sem término confiável, aplica-se o limite de segurança de 6 horas.
- Eventos sem horário definido não entram na grade temporal.
- Uma transmissão abre diretamente o canal; várias abrem uma sublista.
- Eventos sem canal associado não recebem fontes inventadas.
- Sem eventos elegíveis, aparece: Não há eventos disponíveis no momento.
- A disponibilidade é reavaliada a cada nova entrada no menu Eventos.
- Metadados de competição, confronto, imagens e descrição são normalizados.

PROGRAMAÇÃO E REPRODUÇÃO
- Programação atual e próximos programas conforme disponibilidade.
- Capas e informações do canal também são apresentadas durante reprodução.
- A preparação da transmissão utiliza feedback visual imediato.
- O motor, o proxy local, a resolução de mídia, o failover e a trava de
  abertura continuam com os contratos da base aprovada.
- Stop encerra a sessão sem reconexão automática.
- O retorno à grade preserva o comportamento de cache aprovado.

IDENTIDADE
- Nome: OnePlay Live.
- ID: plugin.video.oneplay.live.
- Versão interna: 1.0.6.
- Ícone e fanart próprios.
- Títulos, gêneros, descrições, textos de pastas e metadados públicos não
  exibem identificações da infraestrutura utilizada.
- O código funcional e o catálogo continuam protegidos no pacote.

STATUS
A V3 de Eventos foi aprovada pelo usuário em teste real da janela vazia.
A V4 é uma revisão editorial sobre essa base, pendente de validação final
em Kodi real. A 1.0.5 permanece como base homologada subjacente.
