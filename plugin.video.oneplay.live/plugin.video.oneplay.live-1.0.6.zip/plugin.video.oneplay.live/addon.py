# -*- coding: utf-8 -*-
# OnePlay Live 1.0.4: retorno sem refresh + feedback imediato + trava transacional.
_opl_early_dlg = None
_opl_lock_owned = False
_opl_lock_path = None
_opl_lock_token = None
_opl_mode_play = False
try:
    import sys as _opl_sys, time as _opl_time, builtins as _opl_builtins
    import os as _opl_os, json as _opl_json, uuid as _opl_uuid
    import xbmcgui as _opl_xbmcgui, xbmc as _opl_xbmc, xbmcaddon as _opl_xbmcaddon, xbmcvfs as _opl_xbmcvfs
    from urllib.parse import parse_qsl as _opl_parse_qsl
    _opl_query = _opl_sys.argv[2] if len(_opl_sys.argv) > 2 else ''
    _opl_pairs = dict(_opl_parse_qsl(_opl_query.lstrip('?'), keep_blank_values=True))
    _opl_mode_play = _opl_pairs.get('mode') == 'play'
    if _opl_mode_play:
        _opl_channel_id = str(_opl_pairs.get('channel_id') or '').strip()
        _opl_channel_name = str(_opl_pairs.get('channel_name') or '').strip()
        _opl_profile = _opl_xbmcvfs.translatePath(_opl_xbmcaddon.Addon().getAddonInfo('profile'))
        _opl_xbmcvfs.mkdirs(_opl_profile)
        _opl_lock_path = _opl_os.path.join(_opl_profile, 'startup.lock')
        _opl_now = _opl_time.time()
        _opl_stale_seconds = 180.0
        # Remove somente lock claramente órfão/antigo.
        if _opl_os.path.exists(_opl_lock_path):
            try:
                _opl_age = max(0.0, _opl_now - _opl_os.path.getmtime(_opl_lock_path))
            except Exception:
                _opl_age = 0.0
            if _opl_age > _opl_stale_seconds:
                try:
                    _opl_os.remove(_opl_lock_path)
                    _opl_xbmc.log('[ONEPLAY LIVE] lock startup órfão removido age=%.1fs' % _opl_age, _opl_xbmc.LOGWARNING)
                except Exception:
                    pass
        _opl_lock_token = _opl_uuid.uuid4().hex
        _opl_payload = {
            'token': _opl_lock_token,
            'channel_id': _opl_channel_id,
            'name': _opl_channel_name,
            'created': _opl_now,
            'updated': _opl_now,
        }
        try:
            _opl_fd = _opl_os.open(_opl_lock_path, _opl_os.O_CREAT | _opl_os.O_EXCL | _opl_os.O_WRONLY)
        except FileExistsError:
            _opl_active_name = ''
            try:
                with open(_opl_lock_path,'r',encoding='utf-8') as _opl_fh:
                    _opl_active = _opl_json.load(_opl_fh)
                _opl_active_name = str(_opl_active.get('name') or _opl_active.get('channel_id') or '').strip()
            except Exception:
                pass
            _opl_msg = ('Aguarde. %s ainda está sendo preparado.' % _opl_active_name) if _opl_active_name else 'Aguarde. Outra transmissão ainda está sendo preparada.'
            try:
                _opl_xbmcgui.Dialog().notification('OnePlay Live', _opl_msg, _opl_xbmcgui.NOTIFICATION_INFO, 4000, sound=False)
            except Exception:
                pass
            _opl_xbmc.log('[ONEPLAY LIVE] abertura bloqueada por startup ativo solicitado=%s ativo=%s' % (_opl_channel_id,_opl_active_name or '?'), _opl_xbmc.LOGWARNING)
            raise SystemExit(0)
        else:
            try:
                _opl_os.write(_opl_fd, _opl_json.dumps(_opl_payload,ensure_ascii=False,separators=(',',':')).encode('utf-8'))
            finally:
                _opl_os.close(_opl_fd)
            _opl_lock_owned = True
            _opl_builtins._oneplay_live_startup_lock = (_opl_lock_path, _opl_lock_token)
            _opl_early_dlg = _opl_xbmcgui.DialogProgressBG()
            _opl_early_dlg.create('AGUARDE...', 'Preparando transmissão...')
            _opl_builtins._oneplay_live_early_wait = (_opl_early_dlg, _opl_time.monotonic())
            _opl_xbmc.log('[ONEPLAY LIVE] lock startup adquirido id=%s; AGUARDE bootstrap imediato' % _opl_channel_id, _opl_xbmc.LOGDEBUG)
except SystemExit:
    raise
except Exception as _opl_exc:
    try:
        _opl_xbmc.log('[ONEPLAY LIVE] bootstrap/lock falhou: %s' % _opl_exc, _opl_xbmc.LOGWARNING)
    except Exception:
        pass

import base64 as _b, zlib as _z
_k=b'OPC9-code-X7p3$'
_p=(
    'H;R^HatyQFbW(?SF%vB79oGbMv*-qBaJln7QMfEiif65%S`g7`_ih{Zsb~H0UNwt2-II(kwoW!#ru+PG5-JGdacD6>o!3@o3Sh{Ct4;%5QYUnYGGD#8N^*Eb'
    '<c<CKjn3oj#)q)~Z5}oF9ZTXKL@rt7t32)Vr?M=TJIYCU`!TY`(cbE2z7v@h8xzW(5APeXOm#+zP^y+!ay+wzFcpO+6WMFl!`aW_twztg)R#7`-v2-$j49oa'
    'RF1?7aj{JK-^0o=RDq|f^uQCvsFCQuCe%{0=9^WoUQ&qxEw~l?kRj<wl-U=z)l}&Hs>ya|vm~%Zoub5E7&{zzf?+cH$ZC>pEAwNa-9E1Vvbn}?PJl`*$*;dN'
    '0aex<+#a1@WWt+f|3qt9ms^&S5fvbTgGCFrv5q+5+MdZao(;tk)KsXQN1w$KTXAqe;Arfa6nD2qF*0vLiJM-!ivD4O<xu(f4RDBzCQ<(MkxS&Sw>}i-#-N{!'
    '#F2oLU;=<iyRJSKr`iT$K^Q`;RO@?Fd2*_SMrl(|JL&u78q>oM11382VCFn+_5Dc<GIULk^RUIA?jN{boJ15ohKq*&9eP$xScvW9quDGYj%U}$_8f!q2j?P>'
    'E5*R<+*%DcG`V^?^1JB^b~=o)fcya=xhP4mqXj}<DkqwYApZzTEor%LGHuS+jEF@!85cKf#3hOlBe}wMtXKF9$y&IQdcF~^gEP^-?~ep_xu2lAs2_=A(5;7O'
    'veTAL8P%)-&>8KAATa%Zp$tmNWFlMz$ByquphtW}Y%r;ZGanl3GEEp|e1BO6-C~+|Sc6G!#P<Wkbp!)(AhvojHxXCozfHflT&13yRNFB;>@$LyoMhs<(LXjJ'
    '@gJ()O60pW<@@jgk5ohs6$GT7S6{v_htTnv&db`=m<x-vJ2zKdfVay~f3uJ$=KH>L;cqUuL=K~&8XfK>Nkzifd;N1-u8Z_x{2fcnc24@5!p!@<-aQ=HK}7(`'
    'rcOC>eA5;^A}*-lex}tp&WX+X_}E`sUMW+#<Y`t0uV--I1{0<xnRuP?4rigCBjit`)v4`m#UCJZDoV}<2pA-bJUG?YCUSym&mcN%4yxMtCb1RrkTWta|142s'
    '?s=UuWP#Me8hK8l99%I&4Z92QdO}OzhLgf}E2_DN_~q)Nvw|-@8~-h~fSM<Yjkrciu7PWb>9iY3?F&7%#i|hA59g`rM8fZ1Dik09K&$PPyxj}wj$~GQ(bf4*'
    'jA%gYdLN@)PI#SmB&u!!>(94fmbnI_%Sh!_(5^CH`@Q&3VaK+YkdLh)Pb-eEk+o;3N7I7sRU{nmN;gRfAh#l{=$#2>`C$%~A>vDgd)JN#h`y9x!B%rMgzyf;'
    'RXhU!ovqYZ{8I4Yr>lOT3`n|;Qu*WLD@t)#7CLXqTCPSzKT#J}Rs49NJ1CZQB4FvDC7IUx$Dl!a^);&7_|f$zb24gp)jZ*ymR7R{!C9zP42mT?p@vB}eS@_w'
    'Zi6|`5I-{`kxUtz<!bo`z0;PxocW9~QDe$KWKb}}nyG13Lu&yEqV{Vx9N;zp^}c813$S<6G+OrlNLT}?8o;_h`63sjW*D0qAZ0<w1-jWgLVlpH8sVae0H{H^'
    'z=K9u{bbCDj}PA|=7Q|`pdQr`Y&+H62{js#cBQ}nD5Sdee$@b$tdmymveF<$5d_c+EO$bu<@LaVr_T15QC1|OKS=BD#W8Fx_V!u%LcJ%Hg*x3l60WX!{%_xA'
    'O@@79lrw0Uyp1rYs|Oc>@qJ$dVR|*{ZN2>io#a_uF~=UaN+n&JB}GLy|Lo@@BoGk^^VHB5du&%(DZ#D1K<uwzB<@uPYkI|_m@&r;hw$IQ4>F}L_T_}j6DTI8'
    '^>haHV3@lD7@_eL^JOEv=N}OZqmm0+Q&=<`!z&TE+U?hs@FpT~F%JeQG224Z&%|}~t;Z`KV}A!RL2wToB?<g-ef5nADbv&5E!F#&NK%#9q33o5?Gl8P*hyyO'
    '@%p)ShqSPKy9^aT#1*_=K_e=2gVOt|fzA8?S3bzib+nM5EwkFv5?VASt`I0IsmhaQQHDA74O%jeizM?Iin5eXzcO5Ci))+jBT{2i&9lQ1&v+&GGB2p&;YyR~'
    'j)nfPP`1X~JnwK_+1n-R0jl{^`}@l~ysJf7DZ3&JJXJ6aADce-st@3mmbf_dMjT$D{||#~CcPhORknoXxHfIcb$E<*S@fA_%Ou|>Us$||i|K?qfhFjVq2aIg'
    'kpnl0tXQw_a32-zr0t55j=qZog7k)V!pzpcxQ=HZ8rrkX-Qf<;_IvnGLNuUiZyA;$(?nTW$ZRj63MG2Idto)25He7qO>9Qqu@XEA+HCyK#ct|5gsn#jC%Ql4'
    'o{tg%)Yi*b@Am|ZG|4&z5TffFReibB$_CxDEbG1n#R)pAU***=24{io`eo!Xr*kRA%W8i2&6#i4Qd33^3VPpj9e*a5tHPOgS(Vnso~ZV-gDh<6PzJDqiGt8{'
    'O)LdR{N;%Mbg0@snf7Tc{)l^Ub|!z70~zyP4oG-+!RW<V0>=Td!gm9@liX&1`!>vy))Ge~E<Sj1fJ?=b1Ic&G+(nEP8ZQtEEJ&T@hAogRUG$b1h|D*op_iU('
    '1_*A-60V#1#;-9YSJbyGdDW_P6G@Q-?*r1A+|-$}&!i@ch%t4E<bc{01CW}wvO(Ju_<O%VB*I9y+ql!O`hD{I3k|4#yZn1T=|a=}ZwmW@;0iIvrSdY#7c5<4'
    '#chMzW)n4Fa7(bv@#XhM0GeIhP54B_npy53)jT=d>Y?^@WZapwR|eb`WM;MH3>{^;Vp(?`!PJ85M?E_<2Oxl<jMF~6lk3#1?^M;hWrNpH2$HZk^#klg5Y;xi'
    '9|gFv@FdZn%2bcp8UVRotrtvdUqjsatSOSx=tPp5Wb>78N7uQle(1-0uj9cM9gatSOqMMMpr1Vqq%SwvcS3gm>>vV1#Y>ql3*@okXwx`8tFziNplphTV3boj'
    '2*JlOeg6YG*e+r2+SvtSq}WW_^93_kQ}QHh^|nGJn66GOf9jPDjuaorZj-nLN5VwOxUV1UweX5|w{=%zay<5hUQtGI$TQXt>S@ej@cCVhvXJytf5Z-bZEYw-'
    'M~M`^3-(#6F@=)l#7TvOVDGH#s=kH0+?n~G>gBQP{%V_)0gDx1tf7sfr*F&x!z`oJgj!_gdR=}F{fqoAgomEDNNwSEGzd9U?Vkow5?hFgqVZlQsjhQUV%-$O'
    '1dc4P`*jc<Mo0)xn$2^7yh}qTfi+)|lFLG|tm^&+;x<PqJ;i&YZ=9gPK%Zs1{5OHdg`Q1}$|H8O2V{pAh~E=+|FLGcBCUd`&oo?bYjGzJ%j*@Q%|*W{l@Zzm'
    '<p8>@@kd=F14aDX(2yrfXo1Y?jB`xW+YWW!ko+h8xfM9U08GY>BBQ>rfCU8Wa4IBtStm3_C!ZFCW;gkeJ^Noyn6WAbZu>@fo!!PgB$g<fD+kMIekx$if6}pD'
    'f_VBEx$6SNpWQI~i!m1pJXUNv-_tD>Y@Vjpz|VV34XWX63hMGdPI#(`xyJH8QXf!wdqcI-bA<euo!z^<5*M2sIbEDgdYz%8+)N|pV^6_=R&jIRT{zZboe1`Y'
    'o5u$H2`IC^{a%%P7aLpQr%TvPO0OC)ieFTbmPcA;hpJV(#orm3rwoM3h{gkVhfEB=uZQFXfrLQ~?)XFtE53{hqa;+xa=HnZNcEk}53cRK<I2bhg4Y8=n?zKV'
    'wA)QOhjuc^ydz7f%mik)D%{^rjI9v40LIyBLz=awlH?9-G&GJI?7+9sQTk|~g{`@Ym7^~<lF+Rl_tWxv=ZM)BY+Qygy+q5VGolvZJQw}qx~>lM#bZtYk8R4K'
    'vBdsj6jd#1jUb_&xK$h!vD?S!@r3M^Hy5-*E|6hoIUpbt^v<`7j#>5<S7YsfXa*06Jl@6hd;'
)
_r=_b.b85decode(_p.encode('ascii'))
_r=bytes((v ^ _k[i % len(_k)]) for i,v in enumerate(_r))
exec(compile(_z.decompress(_r), __file__, 'exec'), globals(), globals())
