# -*- coding: utf-8 -*-
from __future__ import unicode_literals

"""Providers VOD MegaEmbed/NHD integrados ao OnePlay Matrix.

Escopo e contratos:
* MegaEmbed (mgeb.top): fonte dublada por TMDB/IMDb conforme documentação;
* NHD (nhdapi.com): fonte legendada, com compatibilidade para o endpoint
  ``/embed/...`` documentado e para ``/movie``/``/tv`` atualmente publicado;
* o JSON MegaEmbed é usado apenas como índice de cobertura TMDB e respeita o
  cache declarado de 2 horas; formato inesperado nunca derruba a resolução;
* links de embed HTML nunca são entregues ao VideoPlayer Kodi como mídia;
* somente URLs de mídia extraídas/validadas entram na lista de fontes;
* não cria player, proxy, porta ou serviço: a reprodução continua no pipeline
  VOD homologado da Matrix (proxy/Range/headers/Stop);
* falha, timeout, mudança de HTML ou ausência de uma destas fontes nunca afeta
  FrostStream/FenixFlix/SuperStream/Overflix/BestCine/Cotonet/HDHub.
"""

import base64
import html
import ipaddress
import json
import re
import time
try:
    from urllib.parse import parse_qs, unquote, urljoin, urlparse
except ImportError:  # pragma: no cover
    from urllib import unquote
    from urlparse import parse_qs, urljoin, urlparse

try:
    import requests as _requests
except Exception:  # pragma: no cover
    _requests = None

try:
    from resources.lib import cache_store as _cache_store
except Exception:  # pragma: no cover
    _cache_store = None


MGEB_ROOT = 'https://mgeb.top'
NHD_ROOT = 'https://nhdapi.com'
MGEB_PROVIDER_NAME = 'MegaEmbed'
NHD_PROVIDER_NAME = 'NHD'
USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/152.0.0.0 Safari/537.36'
)
BASE_HEADERS = {
    'User-Agent': USER_AGENT,
    'Accept': 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
    'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.7,en;q=0.6',
    'Cache-Control': 'no-cache',
}
REQUEST_TIMEOUT = (2.0, 4.5)
PROBE_TIMEOUT = (1.5, 3.0)
MGEB_REQUEST_TIMEOUT = (3.0, 6.0)
MGEB_PROBE_TIMEOUT = (2.0, 4.0)
PAGE_MAX_BYTES = 2 * 1024 * 1024
COVERAGE_MAX_BYTES = 5 * 1024 * 1024
COVERAGE_TTL_SECONDS = 2 * 60 * 60
MAX_NESTED_PAGES = 3
MAX_DIRECT_CANDIDATES = 12
MAX_STREAMS_PER_PROVIDER = 5
HLS_PROBE_MAX_BYTES = 128 * 1024
HLS_MEDIA_PROBE_BYTES = 8192
# Um único contrato multi-plataforma. Logs Windows já mostraram resolução válida
# chegando a ~7,5 s, enquanto Android também precisa de margem. O teto não é
# espera fixa: qualquer sucesso retorna imediatamente.
MGEB_BUDGET_SECONDS = 11.0
NHD_BUDGET_SECONDS = 6.0
NETWORK_COOLDOWN_SECONDS = 30
RATE_LIMIT_COOLDOWN_SECONDS = 60
SERVER_COOLDOWN_SECONDS = 30
HEALTH_NAMESPACE = 'vod_mgeb_nhd_provider_health_v1'
COVERAGE_NAMESPACE = 'vod_mgeb_coverage_v1'
TMDB_RE = re.compile(r'^\d+$')
IMDB_RE = re.compile(r'^tt\d{5,}$', re.I)
MEDIA_SUFFIX_RE = re.compile(r'(?i)\.(?:m3u8|mpd|mp4|mkv|webm|avi|mov|m4v|ts)(?:$|[?#&])')
HLS_CHILD_SUFFIX_RE = re.compile(r'(?i)\.(?:ts|m4s|m4a|aac)(?:$|[?#&])')
HLS_CHILD_QUERY_KEYS = frozenset(('file', 'segment', 'seg', 'chunk', 'frag', 'fragment'))

# Padrões deliberadamente simples. O objetivo não é executar JavaScript do
# provider, apenas reconhecer URLs de mídia já materializadas na resposta.
_ATTR_SOURCE_RE = re.compile(
    r'''(?is)(?:src|file|source|url|hls|playlist|manifest)\s*[:=]\s*["']([^"']{8,4096})["']'''
)
_HTML_SOURCE_RE = re.compile(
    r'''(?is)<(?:source|video|iframe)[^>]+(?:src|data-src)\s*=\s*["']([^"']{4,4096})["']'''
)
_HTML_LINK_RE = re.compile(
    r'''(?is)<a[^>]+href\s*=\s*["']([^"']{4,4096})["']'''
)
_ABSOLUTE_URL_RE = re.compile(r'''(?i)https?:\\?/\\?/[^\s"'<>\\]{8,4096}''')
_PROTOCOL_RELATIVE_RE = re.compile(r'''(?i)(?<!:)//[^\s"'<>]{8,4096}''')
_ATOB_RE = re.compile(r'''(?is)atob\(\s*["']([A-Za-z0-9+/=_-]{20,8192})["']\s*\)''')
_IFRAME_RE = re.compile(r'''(?is)<iframe[^>]+(?:src|data-src)\s*=\s*["']([^"']{4,4096})["']''')


def _safe_text(value):
    try:
        if isinstance(value, bytes):
            return value.decode('utf-8', 'replace')
        return str(value or '')
    except Exception:
        return ''


def _valid_tmdb(value):
    return bool(TMDB_RE.match(_safe_text(value).strip()))


def _valid_imdb(value):
    return bool(IMDB_RE.match(_safe_text(value).strip()))


def _safe_http_url(value, base_url=''):
    """Normaliza uma URL sem reescrever a query assinada/tokenizada.

    URLs MegaEmbed podem carregar credenciais efêmeras no próprio query-string.
    Aplicar ``unquote()`` à URL inteira muda a representação bruta de tokens
    (por exemplo ``%2F``/``%3D``) e, em casos com ``%26``/``%23``, pode até
    transformar dados internos do token em separador de query/fragmento.

    Só decodificamos uma vez quando a *URL inteira* ainda não é HTTP válida e
    aparenta estar percent-encoded (``https%3A%2F%2F...``). Uma URL HTTP já
    válida conserva seu path/query exatamente como extraídos do player.
    """
    value = html.unescape(_safe_text(value)).strip().strip('"\'')
    if not value:
        return ''
    value = value.replace('\\/', '/').replace('\\u002F', '/').replace('\\u002f', '/')
    value = value.replace('\\u003A', ':').replace('\\u003a', ':')
    value = value.replace('\\x2F', '/').replace('\\x2f', '/').replace('\\x3A', ':').replace('\\x3a', ':')
    if value.startswith('//'):
        value = 'https:' + value
    elif base_url and value.startswith('/'):
        value = urljoin(base_url, value)

    def _parsed_http(candidate):
        try:
            parsed_value = urlparse(candidate)
            if (parsed_value.scheme or '').lower() in ('http', 'https') and parsed_value.hostname:
                return parsed_value
        except Exception:
            pass
        return None

    parsed = _parsed_http(value)
    if parsed is None and re.search(r'(?i)https?%3a%2f%2f', value):
        try:
            decoded = unquote(value)
        except Exception:
            decoded = value
        parsed = _parsed_http(decoded)
        if parsed is not None:
            value = decoded
    if parsed is None:
        return ''

    try:
        host = parsed.hostname.strip().lower().rstrip('.')
        if host == 'localhost' or host.endswith('.localhost') or host.endswith('.local'):
            return ''
        try:
            ip_value = ipaddress.ip_address(host)
            if not ip_value.is_global:
                return ''
        except ValueError:
            pass
        return value
    except Exception:
        return ''


def _kind_from_url(value, content_type=''):
    text = _safe_text(value).lower()
    content_type = _safe_text(content_type).lower()
    if '.m3u8' in text or 'mpegurl' in content_type:
        return 'hls'
    if '.mpd' in text or 'dash+xml' in content_type:
        return 'dash'
    if re.search(r'(?i)\.(?:mp4|mkv|webm|avi|mov|m4v|ts)(?:$|[?#&])', text):
        return 'progressive'
    if content_type.startswith('video/') or content_type.startswith('audio/') or 'octet-stream' in content_type:
        return 'progressive'
    return 'unknown'



def _is_hls_child_segment_url(value):
    """Reconhece filhos HLS que nunca representam o VOD completo.

    O MegaEmbed pode materializar no HTML/JS URLs internas como
    ``/includes/hls.php?...&file=<token>.ts``. Esses endpoints devolvem um
    único segmento MPEG-TS/fMP4. A assinatura binária é válida, mas promover
    esse filho como ``progressive`` faria o Kodi tocar somente alguns segundos.

    A regra é deliberadamente estreita: não rejeita todo ``.ts`` direto. Só
    marca como filho quando a própria query identifica um arquivo/segmento
    fragmentário (como o ``file=.ts`` observado no ``hls.php`` capturado).
    Assim MP4/progressive, TS direto e HLS raiz continuam intactos.
    """
    value = _safe_http_url(value)
    if not value:
        return False
    try:
        parsed = urlparse(value)
        query = parse_qs(parsed.query or '', keep_blank_values=True)
    except Exception:
        return False

    for raw_key, raw_values in query.items():
        key = _safe_text(raw_key).strip().lower()
        if key not in HLS_CHILD_QUERY_KEYS:
            continue
        for raw_item in raw_values or ():
            item = _safe_text(raw_item).strip().lower()
            if HLS_CHILD_SUFFIX_RE.search(item):
                return True

    return False


def _is_playercdn_media_gateway_url(value):
    """Reconhece o gateway de mídia ``playercdn.xyz/includes/hls.php``.

    Capturas reais do MegaEmbed mostraram o mesmo endpoint entregando:
    * filho HLS/TS quando ``file=...ts``;
    * VOD progressivo completo quando ``file=...mp4``.

    Em ambos os casos o navegador usa política ``no-referrer``. O parâmetro
    ``url=`` é opaco e qualquer ``referer=`` necessário já viaja na própria
    query-string; por isso não devemos inventar Referer/Origin HTTP.
    """
    value = _safe_http_url(value)
    if not value:
        return False
    try:
        parsed = urlparse(value)
        host = (parsed.hostname or '').strip().lower().rstrip('.')
        path = (parsed.path or '').strip().lower()
        if not (host == 'playercdn.xyz' or host.endswith('.playercdn.xyz')):
            return False
        if path != '/includes/hls.php':
            return False
        query = parse_qs(parsed.query or '', keep_blank_values=True)
        keys = set(_safe_text(key).strip().lower() for key in query.keys())
        return 'url' in keys and 'file' in keys
    except Exception:
        return False


def _is_aws_sigv4_presigned_url(value):
    """Reconhece URL pré-assinada AWS SigV4/R2 sem tocar na query.

    O contrato observado no MegaEmbed usa autenticação inteiramente na URL
    (X-Amz-*). A detecção olha somente os nomes dos parâmetros e o algoritmo;
    não registra, reconstrói ou normaliza credenciais/assinaturas.
    """
    value = _safe_http_url(value)
    if not value:
        return False
    try:
        parsed = urlparse(value)
        query = parse_qs(parsed.query or '', keep_blank_values=True)
        keys = set(_safe_text(key).strip().lower() for key in query.keys())
        required = {
            'x-amz-algorithm',
            'x-amz-credential',
            'x-amz-date',
            'x-amz-signedheaders',
            'x-amz-signature',
        }
        if not required.issubset(keys):
            return False
        algorithm = _safe_text((query.get('X-Amz-Algorithm') or query.get('x-amz-algorithm') or [''])[0]).strip().upper()
        return algorithm.startswith('AWS4-')
    except Exception:
        return False


def _is_self_authenticated_progressive_url(value):
    """Detecta progressive cuja autorização/contexto já viaja na própria URL.

    Contratos observados:
    * MP4 com ``username`` + ``token``;
    * gateway ``*.playercdn.xyz/includes/hls.php?url=...&file=...mp4``;
    * URL AWS SigV4/R2 pré-assinada com ``X-Amz-*``.

    Esses contratos foram capturados com política ``no-referrer``. A função
    reconhece apenas a estrutura; nunca extrai, registra, reconstrói ou
    persiste os valores sensíveis/opacos.
    """
    value = _safe_http_url(value)
    if not value or _kind_from_url(value, '') != 'progressive':
        return False
    if _is_playercdn_media_gateway_url(value) or _is_aws_sigv4_presigned_url(value):
        return True
    try:
        parsed = urlparse(value)
        query = parse_qs(parsed.query or '', keep_blank_values=True)
    except Exception:
        return False
    keys = set(_safe_text(key).strip().lower() for key in query.keys())
    return 'username' in keys and 'token' in keys


def _media_request_headers(url, referer, transport=False):
    """Cabeçalhos do candidato sem misturar autenticação por URL com embed.

    ``transport=True`` inclui os controles usados somente durante probe.
    """
    headers = {
        'User-Agent': USER_AGENT,
        'Accept': '*/*',
    }
    if not _is_self_authenticated_progressive_url(url):
        headers['Referer'] = referer
        try:
            parsed = urlparse(referer)
            if parsed.scheme in ('http', 'https') and parsed.netloc:
                headers['Origin'] = '{}://{}'.format(parsed.scheme, parsed.netloc)
        except Exception:
            pass
    if transport:
        headers['Accept-Encoding'] = 'identity'
        headers['Connection'] = 'close'
    return headers

def _availability_state_from_http(status):
    """Classifica disponibilidade sem transformar HTTP transitório em incompatibilidade."""
    try:
        status = int(status or 0)
    except Exception:
        status = 0
    if status in (401, 403):
        return 'bloqueado-http-{}'.format(status)
    if status == 429:
        return 'limitado-http-429'
    if status in (404, 408, 410, 425):
        return 'offline-http-{}'.format(status)
    if status >= 500 or status <= 0:
        return 'offline-http-{}'.format(status or 'erro')
    if status >= 400:
        return 'indeterminado-http-{}'.format(status)
    return 'online'


def _is_android_runtime():
    """Detecta Android pelo próprio Kodi, com fallbacks não destrutivos.

    ``System.Platform.Android`` é uma condição pública do Kodi. Os fallbacks
    existem apenas para harness/ambientes onde ``xbmc`` não possa ser importado.
    """
    try:
        import xbmc
        if bool(xbmc.getCondVisibility('System.Platform.Android')):
            return True
    except Exception:
        pass
    try:
        import sys
        if callable(getattr(sys, 'getandroidapilevel', None)):
            return True
    except Exception:
        pass
    try:
        import os
        return bool(os.environ.get('ANDROID_ARGUMENT') or os.environ.get('ANDROID_ROOT'))
    except Exception:
        return False


def _audit_excerpt(items, limit=6):
    """Resumo diagnóstico sem URL, query, token ou credencial."""
    clean = []
    for item in list(items or [])[:max(1, int(limit or 6))]:
        value = _safe_text(item).replace('\n', ' ').replace('\r', ' ').strip()
        if not value:
            continue
        # Os itens de audit atuais são estados/contadores. Ainda assim, evita
        # que uma mudança futura faça URL inteira escapar para o kodi.log.
        value = re.sub(r'(?i)https?://\S+', '<url>', value)
        value = re.sub(r'(?i)(token|signature|credential|username)=([^&\s]+)', r'\1=<redacted>', value)
        clean.append(value[:180])
    return ','.join(clean)


class EmbedVodProvider(object):
    def __init__(self, provider='mgeb', requests_module=None, cache_api=None,
                 logger=None, clock=None, monotonic=None, root_url=None):
        provider = _safe_text(provider).strip().lower()
        if provider not in ('mgeb', 'nhd'):
            raise ValueError('provider-invalido')
        self.provider = provider
        self.requests = requests_module or _requests
        self.cache = cache_api if cache_api is not None else _cache_store
        self.logger = logger
        self.clock = clock or time.time
        self.monotonic = monotonic or time.monotonic
        self.root_url = (root_url or (MGEB_ROOT if provider == 'mgeb' else NHD_ROOT)).rstrip('/')
        self.is_android = bool(_is_android_runtime()) if provider == 'mgeb' else False
        self.session = None
        if self.requests is not None:
            try:
                self.session = self.requests.Session()
                self.session.headers.update(BASE_HEADERS)
            except Exception:
                self.session = None

    @property
    def provider_name(self):
        return MGEB_PROVIDER_NAME if self.provider == 'mgeb' else NHD_PROVIDER_NAME

    @property
    def audio_label(self):
        return 'Dublado' if self.provider == 'mgeb' else 'Legendado'

    def _log(self, message, level=1):
        if self.logger is None:
            return
        try:
            self.logger(message, level)
        except TypeError:
            try:
                self.logger(message)
            except Exception:
                pass
        except Exception:
            pass

    def _health_key(self):
        return '{}_cooldown'.format(self.provider)

    def _cooldown_state(self):
        if self.cache is None:
            return ''
        try:
            record = self.cache.get_record(HEALTH_NAMESPACE, self._health_key())
            if record and self.cache.is_fresh(record, int(self.clock())):
                value = record.get('value') or {}
                return _safe_text(value.get('reason')).strip() or 'cooldown'
        except Exception:
            pass
        return ''

    def _remember_cooldown(self, reason, ttl):
        if self.cache is None:
            return
        try:
            self.cache.set_record(
                HEALTH_NAMESPACE, self._health_key(),
                {'reason': _safe_text(reason).strip() or 'provider-indisponivel'},
                max(1, int(ttl or NETWORK_COOLDOWN_SECONDS))
            )
        except Exception:
            pass

    @staticmethod
    def _series_numbers(season, episode):
        try:
            season_value = int(season)
            episode_value = int(episode)
            if season_value < 0 or episode_value < 1:
                return None
            return season_value, episode_value
        except Exception:
            return None

    def _identifier(self, tmdb_id, imdb_id):
        tmdb_id = _safe_text(tmdb_id).strip()
        imdb_id = _safe_text(imdb_id).strip()
        if _valid_tmdb(tmdb_id):
            return tmdb_id, 'tmdb'
        # A documentação MegaEmbed declara IMDb. A documentação pública atual
        # do NHD também aceita IMDb, então o fallback é seguro nos dois modos.
        if _valid_imdb(imdb_id):
            return imdb_id, 'imdb'
        return '', ''

    def _embed_candidates(self, media_type, identifier, season=None, episode=None):
        media_type = _safe_text(media_type).strip().lower()
        if not identifier:
            return []
        if media_type == 'series':
            pair = self._series_numbers(season, episode)
            if pair is None:
                return []
            season_value, episode_value = pair
        if self.provider == 'mgeb':
            # MegaEmbed é um provider de EMBED, não uma API de mídia direta.
            # O contrato documentado principal não força player. Mantemos o
            # endpoint padrão como primeira tentativa e só usamos players
            # explícitos como fallback de compatibilidade. Isso evita ficar
            # preso a uma implementação JS específica (ex.: vidstack).
            if media_type == 'movie':
                base = '{}/embed/{}'.format(self.root_url, identifier)
                return [
                    base,
                    base + '?player=clappr',
                    base + '?player=vidstack',
                ]
            if media_type == 'series':
                base_slash = '{}/embed/{}/{}/{}'.format(
                    self.root_url, identifier, season_value, episode_value)
                base_dash = '{}/embed/{}-{}-{}'.format(
                    self.root_url, identifier, season_value, episode_value)
                return [
                    base_slash,
                    base_dash,
                    base_slash + '?player=clappr',
                    base_slash + '?player=vidstack',
                ]
            return []

        # NHD: a documentação pública atual usa /movie e /tv. O contrato
        # histórico /embed/... permanece apenas como fallback de compatibilidade,
        # para não gastar o budget primeiro numa rota legada.
        if media_type == 'movie':
            # A página /dl é o contrato público voltado a links diretos e não
            # depende da execução do player JavaScript. Para um resolvedor
            # server-side como o Matrix ela é a tentativa de maior sinal.
            return [
                '{}/dl/movie/{}'.format(self.root_url, identifier),
                '{}/movie/{}'.format(self.root_url, identifier),
                '{}/embed/movie/{}'.format(self.root_url, identifier),
            ]
        if media_type == 'series':
            return [
                '{}/dl/tv/{}/{}/{}'.format(self.root_url, identifier, season_value, episode_value),
                '{}/tv/{}/{}/{}'.format(self.root_url, identifier, season_value, episode_value),
                '{}/embed/tv/{}/{}/{}'.format(self.root_url, identifier, season_value, episode_value),
            ]
        return []

    def _coverage_key(self, media_type):
        return 'movie' if media_type == 'movie' else 'series'

    def _coverage_endpoint(self, media_type):
        return '{}/api/{}'.format(self.root_url, self._coverage_key(media_type))

    @classmethod
    def _collect_tmdb_ids(cls, payload, out=None, depth=0):
        if out is None:
            out = set()
        if depth > 6:
            return out
        if isinstance(payload, (list, tuple)):
            for item in payload:
                if isinstance(item, (str, int)) and _valid_tmdb(item):
                    out.add(_safe_text(item).strip())
                elif isinstance(item, (dict, list, tuple)):
                    cls._collect_tmdb_ids(item, out, depth + 1)
            return out
        if not isinstance(payload, dict):
            return out
        for key, value in payload.items():
            key_text = _safe_text(key).strip().lower()
            if key_text in ('tmdb', 'tmdb_id', 'tmdbid', 'id') and _valid_tmdb(value):
                out.add(_safe_text(value).strip())
                continue
            if depth == 0 and _valid_tmdb(key):
                out.add(_safe_text(key).strip())
            if key_text in ('data', 'results', 'items', 'movies', 'series', 'ids', 'tmdb_ids', 'tmdbids'):
                cls._collect_tmdb_ids(value, out, depth + 1)
            elif isinstance(value, (dict, list, tuple)):
                cls._collect_tmdb_ids(value, out, depth + 1)
        return out

    def _read_response_bytes(self, response, max_bytes, deadline=None):
        chunks = []
        total = 0
        iterator = None
        try:
            iterator = response.iter_content(chunk_size=65536)
        except Exception:
            iterator = None
        if iterator is None:
            if deadline is not None and self.monotonic() >= deadline:
                raise TimeoutError('budget-esgotado')
            raw = getattr(response, 'content', b'') or b''
            if deadline is not None and self.monotonic() >= deadline:
                raise TimeoutError('budget-esgotado')
            if len(raw) > max_bytes:
                raise ValueError('resposta-grande')
            return raw
        for chunk in iterator:
            if deadline is not None and self.monotonic() >= deadline:
                raise TimeoutError('budget-esgotado')
            if not chunk:
                continue
            total += len(chunk)
            if total > max_bytes:
                raise ValueError('resposta-grande')
            chunks.append(chunk)
            if deadline is not None and self.monotonic() >= deadline:
                raise TimeoutError('budget-esgotado')
        return b''.join(chunks)

    def _request_timeout(self, deadline, probe=False):
        if self.provider == 'mgeb':
            base = MGEB_PROBE_TIMEOUT if probe else MGEB_REQUEST_TIMEOUT
        else:
            base = PROBE_TIMEOUT if probe else REQUEST_TIMEOUT
        if deadline is None:
            return base
        remaining = float(deadline - self.monotonic())
        if remaining <= 0.20:
            raise TimeoutError('budget-esgotado')
        return (min(base[0], max(0.20, remaining)),
                min(base[1], max(0.20, remaining)))

    def _get(self, url, headers=None, max_bytes=PAGE_MAX_BYTES, deadline=None):
        if self.session is None:
            raise RuntimeError('cliente-http-indisponivel')
        merged = dict(BASE_HEADERS)
        if headers:
            merged.update(headers)
        response = self.session.get(
            url, headers=merged, timeout=self._request_timeout(deadline),
            allow_redirects=True, stream=True
        )
        try:
            status = int(getattr(response, 'status_code', 0) or 0)
            if status == 429:
                self._remember_cooldown('http-429', RATE_LIMIT_COOLDOWN_SECONDS)
            elif status >= 500 or status <= 0:
                self._remember_cooldown('http-{}'.format(status or 'erro'), SERVER_COOLDOWN_SECONDS)
            if status < 200 or status >= 400:
                return status, '', _safe_text(getattr(response, 'url', '') or url), {}
            raw = self._read_response_bytes(response, max_bytes, deadline=deadline)
            encoding = _safe_text(getattr(response, 'encoding', '')).strip() or 'utf-8'
            try:
                text = raw.decode(encoding, 'replace')
            except Exception:
                text = raw.decode('utf-8', 'replace')
            return status, text, _safe_text(getattr(response, 'url', '') or url), dict(getattr(response, 'headers', {}) or {})
        finally:
            try:
                response.close()
            except Exception:
                pass

    def _coverage_ids(self, media_type, deadline=None):
        if self.provider != 'mgeb' or self.cache is None:
            return None
        key = self._coverage_key(media_type)
        try:
            record = self.cache.get_record(COVERAGE_NAMESPACE, key)
            if record and self.cache.is_fresh(record, int(self.clock())):
                value = record.get('value') or {}
                ids = value.get('ids') if isinstance(value, dict) else None
                if isinstance(ids, list):
                    return set(_safe_text(item).strip() for item in ids if _valid_tmdb(item))
        except Exception:
            pass
        try:
            status, text, _, _ = self._get(self._coverage_endpoint(media_type), max_bytes=COVERAGE_MAX_BYTES, deadline=deadline)
            if status != 200 or not text:
                return None
            payload = json.loads(text)
            ids = self._collect_tmdb_ids(payload)
            # Um conjunto vazio/ínfimo é tratado como formato desconhecido, não
            # como cobertura zero. Assim uma mudança da API não causa falso negativo.
            if len(ids) < 5:
                return None
            try:
                self.cache.set_record(
                    COVERAGE_NAMESPACE, key,
                    {'ids': sorted(ids), 'count': len(ids)},
                    COVERAGE_TTL_SECONDS
                )
            except Exception:
                pass
            return ids
        except Exception as exc:
            self._log('índice de cobertura indisponível: {}.'.format(exc.__class__.__name__), 1)
            return None

    @staticmethod
    def _decoded_variants(text):
        source = html.unescape(_safe_text(text))
        variants = [source]
        normalized = source.replace('\\/', '/').replace('\\u002F', '/').replace('\\u002f', '/')
        normalized = normalized.replace('\\u003A', ':').replace('\\u003a', ':')
        normalized = normalized.replace('\\x2F', '/').replace('\\x2f', '/').replace('\\x3A', ':').replace('\\x3a', ':')
        if normalized != source:
            variants.append(normalized)
        for match in _ATOB_RE.finditer(source):
            token = match.group(1)
            try:
                padding = '=' * ((4 - len(token) % 4) % 4)
                decoded = base64.b64decode((token + padding).encode('ascii')).decode('utf-8', 'replace')
                if decoded:
                    variants.append(decoded)
            except Exception:
                continue
        return variants

    @classmethod
    def _extract_direct_candidates(cls, text, page_url):
        candidates = []
        seen = set()
        variants = cls._decoded_variants(text)
        # ``src=`` também aparece em iframe. Esses destinos são páginas de
        # player e devem entrar na fila de navegação, nunca no VideoPlayer.
        iframe_values = set()
        for variant in variants:
            for match in _IFRAME_RE.finditer(variant):
                value = _safe_http_url(match.group(1), page_url)
                if value:
                    iframe_values.add(value)

        def add(raw, strong=False):
            value = _safe_http_url(raw, page_url)
            if not value or value in seen or value in iframe_values:
                return
            # Links de navegação/player não são mídia. Candidato sem extensão só
            # entra se veio de uma chave forte (file/src/hls/url) e será sondado.
            lower = value.lower()
            page_host = (urlparse(page_url).hostname or '').lower()
            target_host = (urlparse(value).hostname or '').lower()
            obvious_embed = ('/embed/' in lower or '/movie/' in lower or '/tv/' in lower) and target_host in (
                'mgeb.top', 'www.mgeb.top', 'nhdapi.com', 'www.nhdapi.com'
            )
            if obvious_embed:
                return
            if not MEDIA_SUFFIX_RE.search(lower) and not strong:
                return
            seen.add(value)
            candidates.append(value)

        for variant in variants:
            for match in _ATTR_SOURCE_RE.finditer(variant):
                add(match.group(1), strong=True)
            for match in _HTML_SOURCE_RE.finditer(variant):
                raw = match.group(1)
                # iframe será tratado como página; source/video como candidato.
                context = variant[max(0, match.start() - 32):match.start() + 20].lower()
                add(raw, strong=('iframe' not in context))
            for match in _HTML_LINK_RE.finditer(variant):
                raw = match.group(1)
                context = variant[max(0, match.start() - 80):min(len(variant), match.end() + 160)].lower()
                strong = bool(MEDIA_SUFFIX_RE.search(_safe_text(raw).lower()) or
                              any(token in context for token in ('download', 'baixar', '1080', '720', '480', 'stream')))
                if strong:
                    add(raw, strong=True)
            for match in _ABSOLUTE_URL_RE.finditer(variant):
                add(match.group(0), strong=False)
            if len(candidates) >= MAX_DIRECT_CANDIDATES:
                break
        return candidates[:MAX_DIRECT_CANDIDATES]

    @classmethod
    def _extract_nested_pages(cls, text, page_url):
        pages = []
        seen = set()
        for variant in cls._decoded_variants(text):
            for match in _IFRAME_RE.finditer(variant):
                value = _safe_http_url(match.group(1), page_url)
                if not value or value in seen:
                    continue
                if MEDIA_SUFFIX_RE.search(value.lower()):
                    continue
                seen.add(value)
                pages.append(value)
                if len(pages) >= MAX_NESTED_PAGES:
                    return pages
        return pages

    def _read_probe_body(self, response, limit=HLS_PROBE_MAX_BYTES, deadline=None):
        parts = []
        total = 0
        iterator = response.iter_content(chunk_size=4096)
        for chunk in iterator:
            if deadline is not None and self.monotonic() >= deadline:
                raise TimeoutError('budget-esgotado')
            if not chunk:
                continue
            remain = max(0, int(limit) - total)
            if remain <= 0:
                break
            piece = chunk[:remain]
            parts.append(piece)
            total += len(piece)
            if total >= int(limit):
                break
            if deadline is not None and self.monotonic() >= deadline:
                raise TimeoutError('budget-esgotado')
        return b''.join(parts)

    @staticmethod
    def _looks_like_ts(data):
        try:
            data = bytes(data or b'')
        except Exception:
            return False
        if len(data) < 376:
            return False
        for packet in (188, 192, 204):
            max_offset = min(packet, max(0, len(data) - packet * 2))
            for offset in range(max_offset + 1):
                points = (offset, offset + packet, offset + packet * 2)
                if all(point < len(data) and data[point] == 0x47 for point in points):
                    return True
        return False

    @staticmethod
    def _looks_like_binary_media(data, content_type='', source_url=''):
        try:
            data = bytes(data or b'')
        except Exception:
            return False
        if not data:
            return False
        clean = data.lstrip()
        lower = clean[:512].lower()
        ctype = _safe_text(content_type).split(';', 1)[0].strip().lower()
        url_lower = _safe_text(source_url).lower()

        # Assinaturas independentes do MIME. Isso preserva CDNs que marcam
        # fMP4/TS incorretamente (o log real mostrou inclusive font/woff2).
        if EmbedVodProvider._looks_like_ts(data):
            return True
        head = data[:128]
        if ((len(head) >= 12 and head[4:8] == b'ftyp') or b'moof' in head or
                b'styp' in head or head.startswith(b'\x1aE\xdf\xa3') or
                head.startswith(b'ID3')):
            return True
        if len(head) >= 2 and head[0] == 0xff and (head[1] & 0xf0) == 0xf0:
            return True

        # HTML/JSON/XML/texto de erro nunca é segmento de vídeo, mesmo com 200.
        if (lower.startswith(b'<!doctype') or lower.startswith(b'<html') or
                lower.startswith(b'{') or lower.startswith(b'[') or
                lower.startswith(b'<?xml')):
            return False
        if any(token in ctype for token in ('text/html', 'application/json', 'application/xml')):
            return False
        if ctype.startswith('video/') or ctype.startswith('audio/'):
            return True

        # text/plain só passa se uma assinatura binária acima já aprovou. Foi
        # exatamente esse MIME que gerou 502/playlist inválida no teste real.
        if ctype.startswith('text/'):
            return False

        # Segmentos AES ou hosts opacos podem vir como octet-stream sem uma
        # assinatura reconhecível. Aceita somente quando o payload é de fato
        # binário; uma página de erro ASCII continua reprovada.
        sample = data[:512]
        printable = sum(1 for value in sample if value in (9, 10, 13) or 32 <= value <= 126)
        binary_ratio = 1.0 - (float(printable) / float(max(1, len(sample))))
        suffix_hint = bool(re.search(r'(?i)\.(?:ts|m4s|mp4|aac|m4a|webm|mkv)(?:$|[?#&])', url_lower))
        if binary_ratio >= 0.30 and (suffix_hint or 'octet-stream' in ctype or not ctype):
            return True
        return False

    @staticmethod
    def _hls_primary_target(playlist_text, playlist_url):
        """Retorna (tipo, url) do caminho que o player tende a usar primeiro.

        Master playlist: escolhe a variante de maior BANDWIDTH, que é a escolha
        típica do FFmpeg/Kodi quando não há limitação explícita. Media playlist:
        escolhe o primeiro segmento real. Não executa JavaScript nem baixa o
        conteúdo inteiro.
        """
        lines = [_safe_text(line).strip() for line in _safe_text(playlist_text).splitlines()]
        variants = []
        media_uris = []
        pending_bandwidth = None
        pending_stream = False
        for line in lines:
            if not line:
                continue
            upper = line.upper()
            if upper.startswith('#EXT-X-STREAM-INF'):
                pending_stream = True
                pending_bandwidth = 0
                match = re.search(r'(?i)(?:AVERAGE-)?BANDWIDTH\s*=\s*(\d+)', line)
                if match:
                    try:
                        pending_bandwidth = int(match.group(1))
                    except Exception:
                        pending_bandwidth = 0
                continue
            if line.startswith('#'):
                continue
            target = _safe_http_url(urljoin(playlist_url, line), playlist_url)
            if not target:
                pending_stream = False
                pending_bandwidth = None
                continue
            if pending_stream:
                variants.append((int(pending_bandwidth or 0), target))
                pending_stream = False
                pending_bandwidth = None
            else:
                media_uris.append(target)
        if variants:
            variants.sort(key=lambda item: item[0], reverse=True)
            return 'playlist', variants[0][1]
        if media_uris:
            return 'segment', media_uris[0]
        return '', ''

    def _probe_hls_path(self, playlist_text, playlist_url, headers, deadline=None, depth=0):
        if depth > 2:
            return False
        text = _safe_text(playlist_text).lstrip('\ufeff\r\n\t ')
        if not text.startswith('#EXTM3U'):
            return False
        target_type, target_url = self._hls_primary_target(text, playlist_url)
        if not target_type or not target_url:
            return False

        child_headers = dict(headers or {})
        child_headers.pop('Range', None)
        child_headers['Referer'] = playlist_url
        try:
            parsed = urlparse(playlist_url)
            if parsed.scheme in ('http', 'https') and parsed.netloc:
                child_headers['Origin'] = '{}://{}'.format(parsed.scheme, parsed.netloc)
        except Exception:
            pass

        response = None
        try:
            if target_type == 'segment':
                child_headers['Range'] = 'bytes=0-{}'.format(HLS_MEDIA_PROBE_BYTES - 1)
            response = self.session.get(
                target_url, headers=child_headers,
                timeout=self._request_timeout(deadline, probe=True),
                allow_redirects=True, stream=True
            )
            status = int(getattr(response, 'status_code', 0) or 0)
            if status not in (200, 206):
                return False
            response_headers = dict(getattr(response, 'headers', {}) or {})
            content_type = _safe_text(response_headers.get('Content-Type')).lower()
            effective_url = _safe_text(getattr(response, 'url', '') or target_url)
            limit = HLS_PROBE_MAX_BYTES if target_type == 'playlist' else HLS_MEDIA_PROBE_BYTES
            payload = self._read_probe_body(response, limit=limit, deadline=deadline)
            stripped = payload.lstrip()

            if target_type == 'playlist':
                child_text = _safe_text(payload)
                if not child_text.lstrip('\ufeff\r\n\t ').startswith('#EXTM3U'):
                    return False
                return self._probe_hls_path(
                    child_text, effective_url, child_headers,
                    deadline=deadline, depth=depth + 1
                )

            # Alguns manifests apontam para mais uma playlist sem extensão.
            if stripped.startswith(b'#EXTM3U'):
                return self._probe_hls_path(
                    _safe_text(payload), effective_url, child_headers,
                    deadline=deadline, depth=depth + 1
                )
            return self._looks_like_binary_media(payload, content_type, effective_url)
        except Exception:
            return False
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass

    def _probe_candidate(self, url, referer, deadline=None, deep_hls=True):
        """Sonda capacidade e disponibilidade separadamente.

        Retorna ``(ok, kind, content_type, state)``. ``offline-*`` e
        ``bloqueado-*`` significam formato potencialmente suportável que não
        pôde ser confirmado agora; ``incompativel-*`` é reservado a resposta
        estruturalmente incompatível com mídia direta.
        """
        if self.session is None:
            return False, 'unknown', '', 'offline-sem-http'
        if self.provider == 'mgeb' and _is_hls_child_segment_url(url):
            return False, 'hls-segment', '', 'segmento-hls-filho'
        headers = _media_request_headers(url, referer, transport=True)
        response = None
        try:
            guessed_kind = _kind_from_url(url, '')
            request_headers = dict(headers)
            if guessed_kind != 'hls':
                request_headers['Range'] = 'bytes=0-{}'.format(HLS_MEDIA_PROBE_BYTES - 1)
            response = self.session.get(
                url, headers=request_headers, timeout=self._request_timeout(deadline, probe=True),
                allow_redirects=True, stream=True
            )
            status = int(getattr(response, 'status_code', 0) or 0)
            if status not in (200, 206):
                return False, guessed_kind or 'unknown', '', _availability_state_from_http(status)
            response_headers = dict(getattr(response, 'headers', {}) or {})
            content_type = _safe_text(response_headers.get('Content-Type')).lower()
            effective_url = _safe_text(getattr(response, 'url', '') or url)
            kind = _kind_from_url(effective_url, content_type)
            payload = self._read_probe_body(
                response,
                limit=HLS_PROBE_MAX_BYTES if kind == 'hls' else HLS_MEDIA_PROBE_BYTES,
                deadline=deadline
            )
            probe = payload.lstrip()
            is_hls = kind == 'hls' or probe.startswith(b'#EXTM3U')
            if is_hls:
                playlist_text = _safe_text(payload)
                if not playlist_text.lstrip('\ufeff\r\n\t ').startswith('#EXTM3U'):
                    return False, 'hls', content_type, 'incompativel-manifesto-hls'
                if not deep_hls:
                    return True, 'hls', content_type, 'online'
                if not self._probe_hls_path(
                        playlist_text, effective_url, request_headers,
                        deadline=deadline, depth=0):
                    # O manifesto raiz é HLS válido: a capacidade já está
                    # provada. Falha em variante/segmento é disponibilidade,
                    # token ou timing, não "formato não suportado".
                    return False, 'hls', content_type, 'offline-hls-filho'
                return True, 'hls', content_type, 'online'
            if kind == 'dash' or (probe.startswith(b'<?xml') and b'<MPD' in probe[:8192]):
                if b'<MPD' in probe[:8192] or 'dash+xml' in content_type:
                    return True, 'dash', content_type, 'online'
                return False, 'dash', content_type, 'incompativel-manifesto-dash'
            if kind == 'progressive':
                if self._looks_like_binary_media(payload, content_type, effective_url):
                    return True, 'progressive', content_type, 'online'
                return False, 'progressive', content_type, 'incompativel-conteudo'
            # URL opaca pode continuar sendo mídia se os bytes provarem isso.
            if self._looks_like_binary_media(payload, content_type, effective_url):
                return True, 'progressive', content_type, 'online'
            return False, 'unknown', content_type, 'incompativel-conteudo'
        except TimeoutError:
            return False, guessed_kind if 'guessed_kind' in locals() else 'unknown', '', 'offline-budget-timeout'
        except Exception as exc:
            return False, guessed_kind if 'guessed_kind' in locals() else 'unknown', '', 'offline-{}'.format(exc.__class__.__name__)
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass

    def _resolve_embed_url(self, embed_url, identifier_kind, deadline=None):
        queue = [(embed_url, self.root_url + '/')]
        visited = set()
        candidates = []
        audit = []
        while queue and len(visited) < (1 + MAX_NESTED_PAGES):
            page_url, referer = queue.pop(0)
            if page_url in visited:
                continue
            visited.add(page_url)
            try:
                status, text, final_url, _ = self._get(page_url, headers={'Referer': referer}, deadline=deadline)
            except Exception as exc:
                audit.append('page-{}:offline-{}'.format(len(visited), exc.__class__.__name__))
                continue
            if status != 200 or not text:
                state = _availability_state_from_http(status)
                if status == 200 and not text:
                    state = 'sem-conteudo'
                audit.append('page-{}:{}'.format(len(visited), state))
                continue
            direct = self._extract_direct_candidates(text, final_url)
            if self.provider == 'mgeb' and direct:
                media_direct = []
                child_segments = 0
                for url in direct:
                    if _is_hls_child_segment_url(url):
                        child_segments += 1
                        continue
                    media_direct.append(url)
                if child_segments:
                    audit.append('page-{}:segmentos-filho-ignorados={}'.format(len(visited), child_segments))
                direct = media_direct
            for url in direct:
                if all(item[0] != url for item in candidates):
                    candidates.append((url, final_url))
            if candidates:
                # Não abre cascata adicional depois que já há mídia explícita.
                break
            for nested in self._extract_nested_pages(text, final_url):
                if nested not in visited and all(item[0] != nested for item in queue):
                    queue.append((nested, final_url))
                    if len(queue) + len(visited) >= (1 + MAX_NESTED_PAGES):
                        break

        streams = []
        seen = set()
        for index, (candidate, referer) in enumerate(candidates[:MAX_DIRECT_CANDIDATES]):
            if candidate in seen:
                continue
            ok, kind, content_type, probe_state = self._probe_candidate(
                candidate, referer, deadline=deadline,
                deep_hls=(self.provider != 'mgeb')
            )
            if not ok:
                audit.append('cand-{}:{}'.format(index + 1, probe_state or 'indeterminado'))
                continue
            audit.append('cand-{}:online-{}'.format(index + 1, kind))
            seen.add(candidate)
            try:
                parsed = urlparse(candidate)
                host = (parsed.hostname or '').lower()
                origin = '{}://{}'.format(parsed.scheme, parsed.netloc) if parsed.scheme and parsed.netloc else ''
            except Exception:
                host = ''
                origin = ''
            headers = _media_request_headers(candidate, referer, transport=False)
            label = '{} • {}'.format(self.audio_label, self.provider_name)
            stream = {
                'name': label,
                'title': label,
                'description': '{} • {}'.format(self.audio_label, kind.upper() if kind != 'progressive' else 'Arquivo direto'),
                'url': candidate,
                '__vod_kind': kind,
                '__vod_source_family': self.provider_name,
                '__vod_source_host': host,
                '__vod_playable': True,
                '__vod_caution': False,
                '__vod_caution_reasons': (),
                '__vod_raw_title': label,
                '__vod_raw_name': self.provider_name,
                '__vod_target_type': 'url',
                '__vod_target_value': candidate,
                '__request_rank': (70 if self.provider == 'mgeb' else 72) + index,
                '__request_label': '{}-{}'.format(self.provider, identifier_kind or 'id'),
                '__vod_provider_id_kind': identifier_kind or 'id',
                '__vod_provider': self.provider_name,
                '__vod_request_headers': headers,
                '__vod_probe_content_type': content_type,
            }
            streams.append(stream)
            if len(streams) >= MAX_STREAMS_PER_PROVIDER:
                break
        return streams, audit

    def resolve(self, media_type, tmdb_id='', imdb_id='', season=None, episode=None):
        media_type = _safe_text(media_type).strip().lower()
        if media_type not in ('movie', 'series'):
            return {'streams': [], 'reason': 'tipo inválido', 'audit': ['tipo-invalido']}
        if media_type == 'series' and self._series_numbers(season, episode) is None:
            return {'streams': [], 'reason': 'episódio inválido', 'audit': ['episodio-invalido']}
        if self.session is None:
            return {'streams': [], 'reason': 'cliente HTTP indisponível', 'audit': ['sem-http']}

        cooldown = self._cooldown_state()
        if cooldown:
            return {
                'streams': [],
                'reason': '{} temporariamente em cooldown'.format(self.provider_name),
                'audit': ['cooldown:{}'.format(cooldown)],
            }

        primary_id, primary_kind = self._identifier(tmdb_id, imdb_id)
        if not primary_id:
            return {'streams': [], 'reason': 'TMDB/IMDb exato ausente', 'audit': ['sem-id']}

        identifiers = [(primary_id, primary_kind)]
        imdb_clean = _safe_text(imdb_id).strip()
        if primary_kind == 'tmdb' and _valid_imdb(imdb_clean):
            identifiers.append((imdb_clean, 'imdb'))

        audit = []
        if self.provider == 'mgeb':
            budget_seconds = MGEB_BUDGET_SECONDS
        else:
            budget_seconds = NHD_BUDGET_SECONDS
        deadline = self.monotonic() + budget_seconds

        # O JSON /api/movie|series é um índice global com cache declarado de
        # 2 horas, mas não deve ficar no caminho crítico de cada clique. Em um
        # addon Kodi cada abertura pode nascer em novo invocador Python; baixar
        # esse índice antes do embed acrescenta latência e uma falha dele não
        # significa ausência da mídia. A partir daqui cobertura é apenas dica
        # POSITIVA quando já existe cache fresco; nunca bloqueia TMDB/IMDb.
        if self.provider == 'mgeb' and primary_kind == 'tmdb' and self.cache is not None:
            try:
                key = self._coverage_key(media_type)
                record = self.cache.get_record(COVERAGE_NAMESPACE, key)
                if record and self.cache.is_fresh(record, int(self.clock())):
                    value = record.get('value') or {}
                    ids = value.get('ids') if isinstance(value, dict) else None
                    if isinstance(ids, list):
                        cached_ids = set(_safe_text(item).strip() for item in ids if _valid_tmdb(item))
                        audit.append('coverage-cache={}'.format(len(cached_ids)))
                        if primary_id in cached_ids:
                            audit.append('coverage-hit')
                        else:
                            audit.append('coverage-miss-nao-bloqueante')
            except Exception:
                audit.append('coverage-cache-indisponivel')

        started = self.clock()
        try:
            for identifier, identifier_kind in identifiers:
                if self.monotonic() >= deadline:
                    audit.append('budget-esgotado')
                    break
                for candidate_index, embed_url in enumerate(self._embed_candidates(
                        media_type, identifier, season=season, episode=episode)):
                    if self.monotonic() >= deadline:
                        audit.append('budget-esgotado')
                        break
                    streams, candidate_audit = self._resolve_embed_url(
                        embed_url, identifier_kind, deadline=deadline
                    )
                    audit.extend('{}-u{}:{}'.format(identifier_kind, candidate_index + 1, item)
                                 for item in candidate_audit[:8])
                    if streams:
                        for stream in streams:
                            stream['__vod_provider_id'] = identifier
                            stream['__vod_provider_id_kind'] = identifier_kind
                            stream['__request_label'] = '{}-{}'.format(self.provider, identifier_kind)
                        elapsed = max(0.0, float(self.clock()) - float(started))
                        self._log('{} resolveu {} por {}: {} fonte(s) em {:.2f}s.'.format(
                            self.provider_name, media_type, identifier_kind.upper(), len(streams), elapsed), 1)
                        return {'streams': streams, 'reason': '', 'audit': audit + [('mgeb-plausivel' if self.provider == 'mgeb' else 'nhd-estrito'), 'ok={}'.format(len(streams))]}
            if self.provider == 'mgeb':
                self._log('MegaEmbed sem fonte | plataforma={} | budget={:.1f}s | audit={}'.format(
                    'android' if self.is_android else 'nao-android', budget_seconds, _audit_excerpt(audit)), 1)
            return {
                'streams': [],
                'reason': '{} sem URL de mídia reproduzível'.format(self.provider_name),
                'audit': audit + [('mgeb-plausivel' if self.provider == 'mgeb' else 'nhd-estrito'), 'sem-midia-direta'],
            }
        except TimeoutError:
            # Budget local esgotado não é evidência de servidor offline e não
            # deve colocar o provider em cooldown persistente.
            if self.provider == 'mgeb':
                self._log('MegaEmbed budget esgotado | plataforma={} | budget={:.1f}s | audit={}'.format(
                    'android' if self.is_android else 'nao-android', budget_seconds, _audit_excerpt(audit)), 1)
            return {
                'streams': [],
                'reason': '{} excedeu o budget local desta consulta'.format(self.provider_name),
                'audit': audit + ['budget-timeout'],
            }
        except Exception as exc:
            self._remember_cooldown(exc.__class__.__name__, NETWORK_COOLDOWN_SECONDS)
            self._log('{} indisponível nesta consulta: {}.'.format(self.provider_name, exc.__class__.__name__), 1)
            return {
                'streams': [],
                'reason': '{} indisponível nesta consulta'.format(self.provider_name),
                'audit': audit + ['erro:{}'.format(exc.__class__.__name__)],
            }


_MGEB_PROVIDER = None
_NHD_PROVIDER = None


def _kodi_logger(component):
    def _log(message, level=1):
        try:
            from resources.lib.common import log, log_debug
            log('[VOD][{}] {}'.format(component, message), level=level)
            log_debug(message, component=component)
        except Exception:
            pass
    return _log


def get_mgeb_provider():
    global _MGEB_PROVIDER
    if _MGEB_PROVIDER is None:
        _MGEB_PROVIDER = EmbedVodProvider(provider='mgeb', logger=_kodi_logger('MegaEmbed'))
    return _MGEB_PROVIDER


def get_nhd_provider():
    global _NHD_PROVIDER
    if _NHD_PROVIDER is None:
        _NHD_PROVIDER = EmbedVodProvider(provider='nhd', logger=_kodi_logger('NHD'))
    return _NHD_PROVIDER


def reset_default_providers_for_tests():
    global _MGEB_PROVIDER, _NHD_PROVIDER
    _MGEB_PROVIDER = None
    _NHD_PROVIDER = None
