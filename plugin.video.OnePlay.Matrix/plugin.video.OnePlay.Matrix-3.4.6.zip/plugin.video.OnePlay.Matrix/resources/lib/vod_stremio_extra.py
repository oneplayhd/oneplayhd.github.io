# -*- coding: utf-8 -*-
from __future__ import unicode_literals

"""Providers Stremio adicionais, isolados do pipeline VOD homologado.

Escopo: BestCine e Cotonet. O módulo somente consulta ``stream/*.json`` e
normaliza URLs HTTP/HTTPS. Reprodução, proxy, Range, HLS/DASH, legendas e Stop
continuam sob o pipeline já homologado da Matrix.

Contratos conservadores:
* IMDb exato como identificador comum;
* BestCine: movie + series;
* Cotonet: movie apenas (manifest v7.3.0 declara ``types=[movie]`` e prefixo tt);
* uma requisição por provider, sem retry automático;
* no máximo 12 streams HTTP/HTTPS válidos por provider;
* falha/timeout/cooldown de um provider nunca afeta os demais.
"""

import re
import time
try:
    from urllib.parse import urlparse
except ImportError:  # pragma: no cover
    from urlparse import urlparse

try:
    import requests as _requests
except Exception:  # pragma: no cover
    _requests = None

try:
    from resources.lib import cache_store as _cache_store
except Exception:  # pragma: no cover
    _cache_store = None


BESTCINE_ROOT = (
    'https://bestcine.dpdns.org/'
    'qualities=4k,1080p,720p,sd,cam%7Ca=dub,leg,esp%7Ctv=none'
)
COTONET_ROOT = 'https://cotonetnet-cotonet.hf.space'
USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/151.0.0.0 Safari/537.36'
)
REQUEST_TIMEOUT = (2.0, 5.0)
MAX_STREAMS = 12
IMDB_RE = re.compile(r'^tt\d{5,}$', re.I)
NETWORK_COOLDOWN_SECONDS = 30
RATE_LIMIT_COOLDOWN_SECONDS = 60
SERVER_COOLDOWN_SECONDS = 30


def _safe_text(value):
    try:
        return str(value or '').strip()
    except Exception:
        return ''


def _is_timeout_exception(exc):
    """Timeout é local à consulta; não deve bloquear outros títulos/episódios."""
    return 'timeout' in (exc.__class__.__name__ if exc is not None else '').lower()


class StremioExtraProvider(object):
    def __init__(self, provider_name, root, media_types, requests_module=None,
                 cache_api=None, logger=None, clock=None, request_timeout=REQUEST_TIMEOUT,
                 max_streams=MAX_STREAMS):
        self.provider_name = _safe_text(provider_name) or 'Extra'
        self.provider_key = re.sub(r'[^a-z0-9]+', '-', self.provider_name.lower()).strip('-') or 'extra'
        self.root = _safe_text(root).rstrip('/')
        self.media_types = set(media_types or ())
        self.requests = requests_module or _requests
        self.cache = cache_api if cache_api is not None else _cache_store
        self.logger = logger
        self.clock = clock or time.time
        self.request_timeout = request_timeout
        self.max_streams = max(1, min(24, int(max_streams or MAX_STREAMS)))
        self.health_namespace = 'vod_{}_provider_health_v1'.format(self.provider_key)

    def _log(self, message, level=1):
        if self.logger is None:
            return
        try:
            self.logger(message, level)
        except TypeError:
            try:
                self.logger(message)
            except Exception:
                pass
        except Exception:
            pass

    def _cooldown_state(self):
        if self.cache is None:
            return ''
        try:
            record = self.cache.get_record(self.health_namespace, 'cooldown')
            if record and self.cache.is_fresh(record, int(self.clock())):
                value = record.get('value') or {}
                return _safe_text(value.get('reason')) or 'cooldown'
        except Exception:
            pass
        return ''

    def _remember_cooldown(self, reason, ttl):
        if self.cache is None:
            return
        try:
            self.cache.set_record(
                self.health_namespace, 'cooldown',
                {'reason': _safe_text(reason) or 'provider-indisponivel'},
                max(1, int(ttl or NETWORK_COOLDOWN_SECONDS))
            )
        except Exception:
            pass

    @staticmethod
    def _valid_imdb(imdb_id):
        return bool(IMDB_RE.match(_safe_text(imdb_id)))

    def _build_api_url(self, media_type, imdb_id, season=None, episode=None):
        media_type = _safe_text(media_type).lower()
        imdb_id = _safe_text(imdb_id)
        if media_type not in self.media_types or not self._valid_imdb(imdb_id):
            return ''
        if media_type == 'movie':
            return '{}/stream/movie/{}.json'.format(self.root, imdb_id)
        if media_type != 'series':
            return ''
        try:
            season_value = int(season)
            episode_value = int(episode)
        except Exception:
            return ''
        if season_value < 0 or episode_value < 1:
            return ''
        return '{}/stream/series/{}:{}:{}.json'.format(
            self.root, imdb_id, season_value, episode_value
        )

    @staticmethod
    def _infer_kind(raw_stream, source_url):
        pieces = [source_url]
        if isinstance(raw_stream, dict):
            pieces.extend(_safe_text(raw_stream.get(key)) for key in (
                'name', 'title', 'description', 'type'
            ))
        probe = ' '.join(pieces).lower()
        if '.m3u8' in probe or re.search(r'(^|[^a-z0-9])hls([^a-z0-9]|$)', probe):
            return 'hls'
        if '.mpd' in probe or re.search(r'(^|[^a-z0-9])dash([^a-z0-9]|$)', probe):
            return 'dash'
        if any(ext in probe for ext in ('.mp4', '.mkv', '.webm', '.avi', '.mov', '.m4v', '.ts')):
            return 'progressive'
        return 'unknown'

    @staticmethod
    def _request_headers(raw_stream):
        hints = raw_stream.get('behaviorHints') if isinstance(raw_stream, dict) else None
        proxy_headers = hints.get('proxyHeaders') if isinstance(hints, dict) else None
        request = proxy_headers.get('request') if isinstance(proxy_headers, dict) else None
        if not isinstance(request, dict):
            return {'User-Agent': USER_AGENT}
        safe = {'User-Agent': USER_AGENT}
        allowed = {
            'user-agent': 'User-Agent', 'referer': 'Referer', 'origin': 'Origin',
            'accept': 'Accept', 'accept-language': 'Accept-Language',
            'cookie': 'Cookie', 'authorization': 'Authorization',
            'x-api-key': 'X-Api-Key', 'x-auth-token': 'X-Auth-Token',
        }
        for key, value in request.items():
            normalized = allowed.get(_safe_text(key).lower())
            text = _safe_text(value)
            if normalized and text and len(text) <= 4096:
                safe[normalized] = text
        return safe

    def _normalize_streams(self, raw_streams, imdb_id):
        if not isinstance(raw_streams, list):
            return [], ['streams-invalidos']
        normalized = []
        audit = []
        seen = set()
        rejected = 0
        for raw in raw_streams:
            if len(normalized) >= self.max_streams:
                audit.append('limite={}'.format(self.max_streams))
                break
            if not isinstance(raw, dict):
                rejected += 1
                continue
            source_url = _safe_text(raw.get('url'))
            try:
                parsed = urlparse(source_url)
            except Exception:
                rejected += 1
                continue
            if (parsed.scheme or '').lower() not in ('http', 'https') or not parsed.netloc:
                rejected += 1
                continue
            dedupe_key = source_url
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            raw_name = _safe_text(raw.get('name'))
            raw_title = _safe_text(raw.get('title'))
            raw_description = _safe_text(raw.get('description'))
            readable = ' '.join(x for x in (raw_name, raw_title, raw_description) if x).strip()
            kind = self._infer_kind(raw, source_url)
            hints = raw.get('behaviorHints') if isinstance(raw.get('behaviorHints'), dict) else {}
            not_web_ready = bool(hints.get('notWebReady'))
            reasons = []
            if kind == 'unknown':
                reasons.append('link-opaco')
            if not_web_ready:
                reasons.append('not-web-ready')
            normalized.append({
                'name': readable or self.provider_name,
                'title': raw_title or raw_name or self.provider_name,
                'description': readable or self.provider_name,
                'url': source_url,
                '__vod_kind': kind,
                '__vod_source_family': 'Stremio',
                '__vod_source_host': (parsed.hostname or '').lower(),
                '__vod_playable': True,
                '__vod_caution': bool(reasons),
                '__vod_caution_reasons': tuple(reasons),
                '__vod_raw_title': raw_title,
                '__vod_raw_name': raw_name,
                '__vod_target_type': 'url',
                '__vod_target_value': source_url,
                '__request_rank': 70 + len(normalized),
                '__request_label': '{}-imdb'.format(self.provider_key),
                '__vod_provider_id': _safe_text(imdb_id),
                '__vod_provider_id_kind': 'imdb',
                '__vod_provider': self.provider_name,
                '__vod_request_headers': self._request_headers(raw),
            })
        if rejected:
            audit.append('rejeitados={}'.format(rejected))
        audit.append('http={}'.format(len(normalized)))
        return normalized, audit

    def resolve(self, media_type, imdb_id, season=None, episode=None):
        media_type = _safe_text(media_type).lower()
        if media_type not in self.media_types:
            return {
                'streams': [],
                'reason': '{} não declara {}.'.format(self.provider_name, media_type or 'tipo'),
                'audit': ['tipo-nao-suportado'],
            }
        api_url = self._build_api_url(media_type, imdb_id, season, episode)
        if not api_url:
            return {'streams': [], 'reason': 'IMDb/episódio inválido ou ausente', 'audit': ['sem-id']}
        if self.requests is None:
            return {'streams': [], 'reason': 'cliente HTTP indisponível', 'audit': ['sem-http']}
        cooldown = self._cooldown_state()
        if cooldown:
            self._log('{} em cooldown temporário: {}.'.format(self.provider_name, cooldown), 1)
            return {'streams': [], 'reason': 'provider temporariamente em cooldown', 'audit': ['cooldown']}

        response = None
        try:
            response = self.requests.get(
                api_url,
                headers={'User-Agent': USER_AGENT, 'Accept': 'application/json'},
                timeout=self.request_timeout,
            )
            status = int(getattr(response, 'status_code', 0) or 0)
            if status != 200:
                if status == 429:
                    self._remember_cooldown('http-429', RATE_LIMIT_COOLDOWN_SECONDS)
                elif status >= 500 or status <= 0:
                    self._remember_cooldown('http-{}'.format(status or 'erro'), SERVER_COOLDOWN_SECONDS)
                return {
                    'streams': [],
                    'reason': '{} respondeu HTTP {}'.format(self.provider_name, status or 'desconhecido'),
                    'audit': ['http-{}'.format(status or 'erro')],
                }
            try:
                payload = response.json()
            except Exception:
                return {'streams': [], 'reason': 'resposta JSON inválida', 'audit': ['json-invalido']}
            if not isinstance(payload, dict):
                return {'streams': [], 'reason': 'resposta fora do contrato', 'audit': ['payload-invalido']}
            streams, audit = self._normalize_streams(payload.get('streams'), imdb_id)
            if streams:
                self._log('{} resolveu {} por IMDb: {} fonte(s).'.format(
                    self.provider_name, media_type, len(streams)), 1)
                return {'streams': streams, 'reason': '', 'audit': audit}
            return {
                'streams': [],
                'reason': '{} sem fonte HTTP compatível nesta consulta'.format(self.provider_name),
                'audit': audit or ['sem-stream'],
            }
        except Exception as exc:
            if not _is_timeout_exception(exc):
                self._remember_cooldown(exc.__class__.__name__, NETWORK_COOLDOWN_SECONDS)
            self._log('{} indisponível nesta consulta: {}.'.format(
                self.provider_name, exc.__class__.__name__), 1)
            return {
                'streams': [],
                'reason': '{} indisponível nesta consulta'.format(self.provider_name),
                'audit': ['erro-rede:{}'.format(exc.__class__.__name__)],
            }
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass


_DEFAULT_BESTCINE = None
_DEFAULT_COTONET = None


def _kodi_logger(provider_name):
    def _log(message, level=1):
        try:
            from resources.lib.common import log, log_debug
            log('[VOD Extra] {}'.format(message), level=level)
            log_debug(message, component=provider_name)
        except Exception:
            pass
    return _log


def get_bestcine_provider():
    global _DEFAULT_BESTCINE
    if _DEFAULT_BESTCINE is None:
        _DEFAULT_BESTCINE = StremioExtraProvider(
            'BestCine', BESTCINE_ROOT, ('movie', 'series'),
            logger=_kodi_logger('BestCine')
        )
    return _DEFAULT_BESTCINE


def get_cotonet_provider():
    global _DEFAULT_COTONET
    if _DEFAULT_COTONET is None:
        _DEFAULT_COTONET = StremioExtraProvider(
            'Cotonet', COTONET_ROOT, ('movie',),
            logger=_kodi_logger('Cotonet')
        )
    return _DEFAULT_COTONET


def reset_default_providers_for_tests():
    global _DEFAULT_BESTCINE, _DEFAULT_COTONET
    _DEFAULT_BESTCINE = None
    _DEFAULT_COTONET = None
