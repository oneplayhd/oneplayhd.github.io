
# -*- coding: utf-8 -*-
"""Textos públicos do OnePlay Live. Não modifica identificadores, URLs ou cabeçalhos de transporte."""
import re

_SOURCE_URL = re.compile(
    r'(?i)(?<![A-Za-z0-9_])(?:https?://)?(?:[A-Za-z0-9-]+\.)*'
    r'embedtv\.lat(?::\d+)?(?:/[^\s<>\[\]{}"\'`]+)?'
)
_SOURCE_NAME = re.compile(r'(?i)\bembedtv(?:[-_][a-z0-9]+)*\b')
_SOURCE_PATH = re.compile(r'(?i)(?<![\w])/api/(?:channels|events|epg_all)(?![\w])')
_EMPTY_ATTRIBUTION = re.compile(
    r'(?i)(?:fonte|origem|provedor|fornecedor|site oficial|'
    r'dispon[ií]vel em|assista em|acesse em)'
)

def _plain_text(value, depth=0):
    if depth > 5 or value is None or isinstance(value, bool):
        return ''
    if isinstance(value, dict):
        for key in ('name','title','label','shortName','displayName','text','value',
                    'event','competition','league','tournament'):
            if key in value:
                result=_plain_text(value[key],depth+1)
                if result:
                    return result
        return ''
    if isinstance(value,(list,tuple)):
        parts=[]
        for entry in value[:16]:
            result=_plain_text(entry,depth+1)
            if result and result not in parts:
                parts.append(result)
        return ', '.join(parts)
    if not isinstance(value,(str,int,float)):
        return ''
    text=str(value)
    return ''.join(c for c in text if c=='\n' or (ord(c)>=32 and ord(c)!=127))

def public_text(value, multiline=False):
    """Remove referências de origem exclusivamente de campos de apresentação."""
    text=_plain_text(value)
    if not text:
        return ''
    text=_SOURCE_URL.sub('',text)
    text=_SOURCE_NAME.sub('',text)
    text=_SOURCE_PATH.sub('',text)
    lines=[]
    for raw_line in text.splitlines():
        line=' '.join(raw_line.split()).strip(' \t•|:;,–—-')
        if line and not _EMPTY_ATTRIBUTION.fullmatch(line):
            lines.append(line)
    result='\n'.join(lines) if multiline else ' '.join(lines)
    return result[:8192 if multiline else 2048]
