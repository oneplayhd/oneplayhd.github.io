# -*- coding: utf-8 -*-
"""Artwork remoto dos canais.

A resolucao e deliberadamente visual: ela nao participa do contrato de
playback. Se uma imagem remota nao existir, a reproducao do canal
permanece intacta.
"""

BASE = 'https://d1r94zrla0glo-cloudfront.vercel.app/sinalpublico/'
LOGO = BASE + 'logo/'
EMBED = BASE + 'foto/embed/'

# URLs especificas confirmadas pelo usuario para casos em que o slug simples
# nao bate com o nome da marca no servidor de imagens.
EXACT_URLS = {
    'bandsports': LOGO + 'band-sports.png',
    'caze1': EMBED + 'cazetv.png',
    'caze2': EMBED + 'cazetv.png',
    'caze3': EMBED + 'cazetv.png',
    'ufcfightpass': LOGO + 'ufc.png',
    '24h_naruto': EMBED + '24h.png',
    '24h_dragonball': EMBED + '24h.png',
    '24h_simpsons': EMBED + '24h.png',
    '24h_chaves': EMBED + '24h.png',
    '24h_odeiachris': EMBED + '24h.png',
    'pt_abola': 'https://ringiersportsmediagroup.com/wp-content/uploads/2023/07/abola.png',
    'adultswim': LOGO + 'adult-swim.png',
    'aie': LOGO + 'aee.png',
    'aee': LOGO + 'aee.png',
    'animalplanet': LOGO + 'animal-planet.png',
    'bandnews': LOGO + 'band-news.png',
    'pt_benficatv': 'https://upload.wikimedia.org/wikipedia/commons/d/d2/Logo_Benfica_TV.png',
    'cartoonnetwork': LOGO + 'cartoon-network.png',
    'cnnbrasil': LOGO + 'cnn.png',
    'curta': EMBED + 'curta.png',
    'discoverychannel': LOGO + 'discovery.png',
    'discoveryhh': LOGO + 'discovery-home-and-health.png',
    'discoveryscience': LOGO + 'discovery-science.png',
    'discoverytheather': LOGO + 'discovery-theater.png',
    'discoveryturbo': LOGO + 'discovery-turbo.png',
    'discoveryworld': LOGO + 'discovery-world.png',
    'disneyplus1': EMBED + 'disneyplus.png',
    'disneyplus2': EMBED + 'disneyplus.png',
    'disneyplus3': EMBED + 'disneyplus.png',
    'fishtv': LOGO + 'fish-tv.png',
    'foodnetwork': LOGO + 'food-network.png',
    'primevideo': LOGO + 'prime-video.png',
    'primevideo2': LOGO + 'prime-video.png',
    'primevideo3': LOGO + 'prime-video.png',
    'primevideo4': LOGO + 'prime-video.png',
    'pt_eleven1': 'https://upload.wikimedia.org/wikipedia/commons/d/d6/Logo_Eleven_Sports_2020.png',
    'pt_eleven2': 'https://upload.wikimedia.org/wikipedia/commons/d/d6/Logo_Eleven_Sports_2020.png',
    'pt_eleven3': 'https://upload.wikimedia.org/wikipedia/commons/d/d6/Logo_Eleven_Sports_2020.png',
    'pt_sportv1': 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Logo_SportTV.svg/960px-Logo_SportTV.svg.png',
    'pt_sportv2': 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Logo_SportTV.svg/960px-Logo_SportTV.svg.png',
    'pt_sportv3': 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Logo_SportTV.svg/960px-Logo_SportTV.svg.png',
    'pt_sportv4': 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Logo_SportTV.svg/960px-Logo_SportTV.svg.png',
    'pt_sportv5': 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Logo_SportTV.svg/960px-Logo_SportTV.svg.png',
    'pt_sportv6': 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Logo_SportTV.svg/960px-Logo_SportTV.svg.png',
    'pt_sportv7': 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Logo_SportTV.svg/960px-Logo_SportTV.svg.png',
    'record': LOGO + 'record-tv.png',
    'recordsp': LOGO + 'record-tv.png',
    'recordmg': LOGO + 'record-tv.png',
    'recordrj': LOGO + 'record-tv.png',
    'sbtnews': 'https://voxnews.com.br/wp-content/uploads/2025/10/SBT_news.jpg',
    'sportynet': LOGO + 'sportynet.png',
    'sportynetplus1': LOGO + 'sportynet.png',
    'sportynetplus2': LOGO + 'sportynet.png',
    'sportynetplus3': LOGO + 'sportynet.png',
    'studiouniversal': LOGO + 'studio-universal.png',
    'tcaction': LOGO + 'tc-action.png',
    'tccult': LOGO + 'tc-cult.png',
    'tcfun': LOGO + 'tc-fun.png',
    'tcpipoca': LOGO + 'tc-pipoca.png',
    'tcpremium': LOGO + 'tc-premium.png',
    'tctouch': LOGO + 'tc-touch.png',
    'tntnovelas': LOGO + 'tnt-novelas.png',
    'tntseries': LOGO + 'tnt-series.png',
}

# Alguns IDs do catalogo usam underscore, enquanto a arte usa o nome colado.
NORMALIZED_EXACT_URLS = {
    'telecineaction': LOGO + 'tc-action.png',
    'telecinecult': LOGO + 'tc-cult.png',
    'telecinefun': LOGO + 'tc-fun.png',
    'telecinepipoca': LOGO + 'tc-pipoca.png',
    'telecinepremium': LOGO + 'tc-premium.png',
    'telecinetouch': LOGO + 'tc-touch.png',
    'tc_action': LOGO + 'tc-action.png',
    'tc_cult': LOGO + 'tc-cult.png',
    'tc_fun': LOGO + 'tc-fun.png',
    'tc_pipoca': LOGO + 'tc-pipoca.png',
    'tc_premium': LOGO + 'tc-premium.png',
    'tc_touch': LOGO + 'tc-touch.png',
}


def _family_slug(channel_id):
    cid = (channel_id or '').strip().lower()
    if not cid:
        return ''

    if cid.startswith('globo') and cid != 'globonews':
        return 'globo'
    if cid in ('bandsp', 'bandrj'):
        return 'band'
    if cid in ('recordnews',):
        return 'recordnews'
    if cid in ('sbtsp', 'sbtrj'):
        return 'sbt'
    if cid in ('cartoonito',):
        return 'cartoonito'
    if cid in ('discoverykids',):
        return 'discovery-kids'
    if cid in ('band',):
        return 'band'
    if cid in ('sbt',):
        return 'sbt'

    families = (
        ('sportv', 'sportv'),
        ('espn', 'espn'),
        ('premiere', 'premiere'),
        ('globonews', 'globonews'),
        ('paramountplus', 'paramountplus'),
        ('max', 'max'),
        ('tnt', 'tnt'),
    )
    for prefix, slug in families:
        if cid.startswith(prefix):
            return slug

    if cid.startswith('pt_'):
        cid = cid[3:]
    if cid.startswith('24h_'):
        return '24h'
    return cid.replace('_', '-')


def logo_url(channel_id):
    cid = (channel_id or '').strip().lower()
    if not cid:
        return ''
    if cid in EXACT_URLS:
        return EXACT_URLS[cid]
    if cid in NORMALIZED_EXACT_URLS:
        return NORMALIZED_EXACT_URLS[cid]
    slug = _family_slug(cid)
    return (LOGO + slug + '.png') if slug else ''



def local_fallback(channel_id):
    """Arte fixa empacotada; não depende de rede nem participa do playback."""
    try:
        import os
        import xbmcaddon
        import xbmcvfs
        root = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
        opaque = __import__('hashlib').sha256(('opc9-art:' + (channel_id or '')).encode('utf-8')).hexdigest()[:24] + '.png'
        path = os.path.join(root, 'resources', 'oneplay_live', 'artwork', 'channels', opaque)
        return path if xbmcvfs.exists(path) else ''
    except Exception:
        return ''

# URLs da própria API que retornaram HTTP 404 no teste real de 08/09/2026.
# A regra é por URL exata, não por ID: se a API mudar a URL do canal, a nova
# imagem volta a ser utilizada automaticamente.
_KNOWN_BROKEN_API_ART_URLS = {
    'https://img.faz-o-eli.online/eleven.png',
    'https://img.faz-o-eli.online/globodf.prev.png',
    'https://img.faz-o-eli.online/globomg.prev.png',
    'https://img.faz-o-eli.online/pt_abola.prev.png',
    'https://img.faz-o-eli.online/pt_benficatv.png',
    'https://img.faz-o-eli.online/pt_canal11.prev.png',
    'https://img.faz-o-eli.online/pt_eleven1.prev.png',
    'https://img.faz-o-eli.online/pt_eleven3.prev.png',
    'https://img.faz-o-eli.online/pt_sportv6.prev.png',
}


def _valid_remote_image(url):
    value = str(url or '').strip()
    if not value.startswith(('https://','http://')):
        return ''
    if value in _KNOWN_BROKEN_API_ART_URLS:
        return ''
    # A API atual possui um registro pt_canal11 com /\.png; isso não é uma capa
    # utilizável. Nesse caso, `preview` da própria API é preferido antes do
    # fallback local.
    try:
        from urllib.parse import urlparse
        path = (urlparse(value).path or '').strip()
        if path in ('', '/', '/.png', '.png') or path.endswith('/.png'):
            return ''
    except Exception:
        return ''
    return value


def artwork_for(channel):
    if isinstance(channel, dict):
        channel_id = channel.get('id', '')
        api_image = _valid_remote_image(channel.get('image'))
        api_preview = _valid_remote_image(channel.get('preview'))
    else:
        channel_id = channel or ''
        api_image = ''
        api_preview = ''

    # A capa principal continua vindo de `image` da API. Se aquela URL exata
    # estiver comprovadamente quebrada, usamos a arte local do mesmo canal antes
    # de tentar preview como capa. O preview permanece fanart somente quando válido.
    fallback = local_fallback(channel_id)
    primary = api_image or fallback or api_preview
    display_preview = api_preview or primary
    return {
        'remote': primary,
        'preview': display_preview,
        'fallback': fallback,
        'from_api': bool(api_image),
    }
