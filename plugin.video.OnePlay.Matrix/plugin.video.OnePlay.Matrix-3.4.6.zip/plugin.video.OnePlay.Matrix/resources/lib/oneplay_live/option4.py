# -*- coding: utf-8 -*-
"""Catálogo/resolvedor isolado da Opção 4 do OnePlay Live.

Contrato público de entrada:
    https://embed.bugoumods.com/?api=1&t=live&c=all

A integração trata essa URL apenas como raiz dinâmica. O payload pode ser JSON,
M3U ou HTML/JS; URLs de canal/mídia publicadas pela própria resposta são
normalizadas e entregues ao resolvedor homologado, que continua exigindo HLS
válido + primeiro segmento antes de iniciar o player.

Não executa JavaScript remoto, não fixa CDN/host final, não contorna login,
anti-bot ou DRM e não persiste resultados negativos entre tentativas.
"""
import hashlib
import html
from html.parser import HTMLParser
import json
import os
import re
import time
from urllib.parse import parse_qs, urljoin, urlparse
from urllib.request import Request

import xbmc
import xbmcaddon
import xbmcvfs

from .proxy import cloudflare_urlopen
from .source_contract import (
    BROWSER_UA, is_safe_public_url, media_headers, page_headers,
)
from .storage import write_json_atomic

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
API_URL = 'https://embed.bugoumods.com/?api=1&t=live&c=all'
API_ORIGIN = 'https://embed.bugoumods.com/'
MAX_PAYLOAD_BYTES = 4 * 1024 * 1024
MAX_CACHE_BYTES = 3 * 1024 * 1024
CACHE_TTL = 5 * 60
_CACHE_FILE = os.path.join(PROFILE, 'oneplay_live_option4_catalog.json')
_MEMO = None
_MEMO_DEADLINE = 0.0

# Nomes estruturais de categoria adulta. A classificação nunca usa substring
# do nome do canal; assim "Adult Swim" continua sendo canal normal.
_ADULT_CATEGORY_MARKERS = (
    'xxx', 'adulto', 'adultos', 'adult', 'onlyfans', '+18', '18+', 'porno', 'pornô',
)


def _log(message, warning=False):
    xbmc.log('[ONEPLAY LIVE] OPCAO4 %s' % message,
             xbmc.LOGWARNING if warning else xbmc.LOGINFO)


def _clean_text(value, limit=240):
    value = html.unescape(str(value or ''))
    value = re.sub(r'<[^>]+>', ' ', value)
    value = ' '.join(value.split()).strip()
    return value[:limit]


def _slug(value, limit=96):
    value = _clean_text(value, 240).casefold()
    # Mantém ASCII estável sem dependência externa.
    table = str.maketrans({
        'á':'a','à':'a','ã':'a','â':'a','ä':'a','é':'e','è':'e','ê':'e','ë':'e',
        'í':'i','ì':'i','î':'i','ï':'i','ó':'o','ò':'o','õ':'o','ô':'o','ö':'o',
        'ú':'u','ù':'u','û':'u','ü':'u','ç':'c','ñ':'n'
    })
    value = value.translate(table)
    value = re.sub(r'[^a-z0-9]+', '-', value).strip('-')
    return value[:limit]


def _safe_url(value, base=API_URL):
    value = html.unescape(str(value or '').strip())
    if not value:
        return ''
    try:
        value = urljoin(base, value)
    except Exception:
        return ''
    return value if is_safe_public_url(value) else ''


def _is_adult_category(value):
    text = _clean_text(value, 120).casefold()
    if not text:
        return False
    return any(marker in text for marker in _ADULT_CATEGORY_MARKERS)


def _normalize_category(value):
    value = _clean_text(value, 100) or 'Geral'
    return 'adulto' if _is_adult_category(value) else value


def _looks_direct_media(url, hint=''):
    hint = str(hint or '').lower()
    if hint in ('m3u8', 'hls', 'stream', 'stream_url', 'play_url', 'media_url', 'src'):
        return True
    try:
        path = (urlparse(url).path or '').lower()
    except Exception:
        return False
    return path.endswith(('.m3u8', '.m3u', '.txt'))


def _looks_navigation_only(url):
    """Descarta links que só trocam categoria da própria API."""
    try:
        p = urlparse(url)
        if (p.hostname or '').lower() != 'embed.bugoumods.com':
            return False
        if (p.path or '/') not in ('', '/'):
            return False
        q = parse_qs(p.query or '')
        keys = set(q)
        if keys and keys.issubset({'api', 't', 'c', 'page', 'search', 'q'}):
            return not any(k in q for k in ('id', 'channel', 'ch', 'stream', 'play'))
    except Exception:
        pass
    return False


def _row_url(raw):
    direct_keys = ('m3u8', 'hls', 'stream_url', 'play_url', 'media_url', 'stream', 'src')
    page_keys = ('api_url', 'source_page', 'embed', 'embed_url', 'player', 'player_url', 'href', 'link', 'url')
    for key in direct_keys + page_keys:
        value = raw.get(key) if isinstance(raw, dict) else None
        if isinstance(value, dict):
            value = value.get('url') or value.get('src') or value.get('href')
        url = _safe_url(value)
        if not url:
            continue
        if _looks_navigation_only(url):
            continue
        return url, ('stream' if key in direct_keys else 'page')
    return '', ''


def _row_categories(raw, category_hint=''):
    values = []
    if isinstance(raw, dict):
        for key in ('categories', 'groups', 'genres'):
            obj = raw.get(key)
            if isinstance(obj, list):
                values.extend(obj)
        for key in ('category', 'categoria', 'category_name', 'group', 'group_title', 'genre'):
            obj = raw.get(key)
            if obj:
                values.append(obj)
    if category_hint:
        values.append(category_hint)
    out = []
    for value in values:
        if isinstance(value, dict):
            value = value.get('name') or value.get('title') or value.get('label') or value.get('slug')
        cat = _normalize_category(value)
        if cat and cat not in out:
            out.append(cat)
    return out or ['Geral']


def _normalize_rows(rows):
    out = []
    by_id = {}
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        name = _clean_text(
            row.get('name') or row.get('nome') or row.get('title') or row.get('channel_name') or
            row.get('stream_name') or row.get('label'), 160)
        url, kind = _row_url(row)
        if not name or not url:
            continue

        raw_id = row.get('id') or row.get('slug') or row.get('channel_id') or row.get('stream_id') or row.get('tvg_id')
        cid = _slug(raw_id or name)
        if not cid:
            cid = 'op4-' + hashlib.sha1((name + '|' + url).encode('utf-8')).hexdigest()[:16]

        categories = _row_categories(row, row.get('_category_hint') or '')
        category = categories[0]
        image = _safe_url(row.get('image') or row.get('capa') or row.get('logo') or row.get('icon') or row.get('stream_icon') or row.get('tvg_logo'))
        epg_id = _clean_text(row.get('epg_id') or row.get('tvg_id') or raw_id or cid, 120)

        existing = by_id.get(cid)
        if existing is not None:
            # Mesmo ID em mais de uma categoria: preserva um único canal e
            # acumula as categorias, como já ocorre na Opção 1.
            if existing.get('api_url') == url or existing.get('name') == name:
                for cat in categories:
                    if cat not in existing['categories']:
                        existing['categories'].append(cat)
                continue
            cid = (cid[:78] + '-' + hashlib.sha1(url.encode('utf-8')).hexdigest()[:12]).strip('-')

        item = {
            'id': cid,
            'epg_id': epg_id or cid,
            'name': name,
            'categories': list(categories),
            'category': category,
            'description': _clean_text(row.get('description') or row.get('descricao') or row.get('plot') or '', 500),
            'image': image,
            'preview': '',
            'api_url': url,
            'source_page': url,
            'stream_url': url if kind == 'stream' else '',
            'headers': {},
            '_option4_url_kind': kind,
            '_oneplay_source': 'option4',
        }
        by_id[cid] = item
        out.append(item)

    # Evita aceitar como catálogo uma página de navegação com meia dúzia de
    # links genéricos, mas permite APIs menores em manutenção/teste.
    if out and len(out) > 5000:
        raise ValueError('quantidade de canais excedeu limite: %d' % len(out))
    return out


def _json_rows(obj, category_hint='', depth=0):
    if depth > 6:
        return []
    rows = []
    if isinstance(obj, list):
        for item in obj:
            if isinstance(item, dict):
                url, _ = _row_url(item)
                name = item.get('name') or item.get('nome') or item.get('title') or item.get('channel_name') or item.get('stream_name') or item.get('label')
                if url and name:
                    clone = dict(item)
                    if category_hint and not any(clone.get(k) for k in ('category', 'categoria', 'category_name', 'group', 'group_title', 'genre', 'categories')):
                        clone['_category_hint'] = category_hint
                    rows.append(clone)
                else:
                    rows.extend(_json_rows(item, category_hint, depth + 1))
            elif isinstance(item, list):
                rows.extend(_json_rows(item, category_hint, depth + 1))
        return rows
    if not isinstance(obj, dict):
        return rows

    container_name = ''
    if any(key in obj for key in ('channels', 'live', 'streams', 'items', 'results', 'list')):
        container_name = obj.get('name') or obj.get('title') or obj.get('label') or ''
    own_category = _clean_text(
        obj.get('category_name') or obj.get('group_title') or obj.get('category') or obj.get('categoria') or obj.get('group') or
        container_name or category_hint,
        100)
    url, _ = _row_url(obj)
    name = obj.get('name') or obj.get('nome') or obj.get('title') or obj.get('channel_name') or obj.get('stream_name') or obj.get('label')
    if url and name:
        clone = dict(obj)
        if own_category and not any(clone.get(k) for k in ('category', 'categoria', 'category_name', 'group', 'group_title', 'genre', 'categories')):
            clone['_category_hint'] = own_category
        return [clone]

    preferred = ('channels', 'live', 'streams', 'items', 'results', 'data', 'list', 'content')
    seen = set()
    for key in preferred:
        if key in obj:
            rows.extend(_json_rows(obj.get(key), own_category, depth + 1))
            seen.add(key)
    for key, value in obj.items():
        if key in seen or key in ('meta', 'status', 'message', 'pagination'):
            continue
        if isinstance(value, (list, dict)):
            hint = own_category
            if isinstance(value, list) and not hint and key not in ('categories', 'channels', 'live', 'streams', 'items', 'results', 'data', 'list', 'content'):
                hint = _clean_text(key, 100)
            rows.extend(_json_rows(value, hint, depth + 1))
    return rows


def _extract_balanced_json_arrays(text):
    rows = []
    pattern = re.compile(r'\b(?:channels|liveChannels|live_channels|streams|items|results|data)\s*[:=]\s*', re.I)
    for match in pattern.finditer(text or ''):
        start = (text or '').find('[', match.end())
        if start < 0 or start - match.end() > 80:
            continue
        depth = 0
        quote = ''
        escaped = False
        for pos in range(start, min(len(text), start + MAX_PAYLOAD_BYTES)):
            char = text[pos]
            if quote:
                if escaped:
                    escaped = False
                elif char == '\\':
                    escaped = True
                elif char == quote:
                    quote = ''
                continue
            if char in ('"', "'"):
                quote = char
            elif char == '[':
                depth += 1
            elif char == ']':
                depth -= 1
                if depth == 0:
                    raw = text[start:pos + 1]
                    try:
                        obj = json.loads(raw)
                    except Exception:
                        break
                    rows.extend(_json_rows(obj))
                    break
        if rows:
            break
    return rows


def _parse_m3u(text):
    rows = []
    current = None
    attr_re = re.compile(r'([\w-]+)="([^"]*)"')
    for line in (text or '').splitlines():
        line = line.strip()
        if line.startswith('#EXTINF:'):
            attrs = dict(attr_re.findall(line))
            name = line.split(',', 1)[1].strip() if ',' in line else attrs.get('tvg-name', '')
            current = {
                'id': attrs.get('tvg-id') or attrs.get('tvg-name') or name,
                'name': name or attrs.get('tvg-name') or 'Canal',
                'category': attrs.get('group-title') or 'Geral',
                'image': attrs.get('tvg-logo') or '',
                'tvg_id': attrs.get('tvg-id') or '',
                '_kind_hint': 'stream',
            }
        elif line and not line.startswith('#') and current is not None:
            current['stream_url'] = line
            rows.append(current)
            current = None
    return rows


class _HTMLCatalogParser(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.rows = []
        self._category = 'Geral'
        self._heading_tag = ''
        self._heading_parts = []
        self._anchor = None
        self._anchor_parts = []

    @staticmethod
    def _attrs(attrs):
        return {str(k or '').lower(): str(v or '') for k, v in attrs}

    def handle_starttag(self, tag, attrs):
        tag = str(tag or '').lower()
        attrs = self._attrs(attrs)
        if tag in ('h2', 'h3'):
            self._heading_tag = tag
            self._heading_parts = []
        if tag != 'a':
            if self._anchor is not None and tag == 'img':
                if not self._anchor.get('image'):
                    self._anchor['image'] = attrs.get('src') or attrs.get('data-src') or ''
                if not self._anchor.get('name'):
                    self._anchor['name'] = attrs.get('alt') or attrs.get('title') or ''
            return

        href = attrs.get('href') or attrs.get('data-href') or attrs.get('data-url') or attrs.get('data-src') or ''
        url = _safe_url(href)
        if not url or _looks_navigation_only(url):
            self._anchor = None
            self._anchor_parts = []
            return
        name = attrs.get('data-name') or attrs.get('data-title') or attrs.get('title') or attrs.get('aria-label') or ''
        category = attrs.get('data-category') or attrs.get('data-group') or self._category
        self._anchor = {
            'name': name,
            'href': url,
            'category': category,
            'image': attrs.get('data-image') or attrs.get('data-logo') or '',
        }
        self._anchor_parts = []

    def handle_data(self, data):
        if self._heading_tag:
            self._heading_parts.append(str(data or ''))
        if self._anchor is not None:
            self._anchor_parts.append(str(data or ''))

    def handle_endtag(self, tag):
        tag = str(tag or '').lower()
        if self._heading_tag and tag == self._heading_tag:
            label = _clean_text(' '.join(self._heading_parts), 100)
            # Cabeçalhos genéricos não viram categoria.
            if label and label.casefold() not in ('grade de canais', 'canais ao vivo', 'stream flix', 'streamflix'):
                self._category = label
            self._heading_tag = ''
            self._heading_parts = []
        if tag == 'a' and self._anchor is not None:
            name = _clean_text(self._anchor.get('name') or ' '.join(self._anchor_parts), 160)
            if name and name.casefold() not in ('entrar', 'criar conta', 'api free', 'api vip', 'telegram', 'gerar link da api'):
                self._anchor['name'] = name
                self.rows.append(self._anchor)
            self._anchor = None
            self._anchor_parts = []


def _parse_payload(data, content_type=''):
    text = data.decode('utf-8', 'ignore').lstrip('\ufeff')
    stripped = text.lstrip()
    rows = []

    if '#EXTM3U' in text[:4096]:
        rows = _parse_m3u(text)
    if not rows and (stripped.startswith('{') or stripped.startswith('[') or 'json' in str(content_type).lower()):
        try:
            rows = _json_rows(json.loads(stripped))
        except Exception:
            rows = []
    if not rows:
        rows = _extract_balanced_json_arrays(text)
    if not rows and '<' in text and '>' in text:
        parser = _HTMLCatalogParser()
        try:
            parser.feed(text)
            parser.close()
            rows = parser.rows
        except Exception:
            rows = []
    return _normalize_rows(rows)


def _fetch_live():
    headers = page_headers(page_url=API_URL, parent_url=API_ORIGIN)
    headers['User-Agent'] = BROWSER_UA
    headers['Accept'] = 'application/json,text/plain;q=0.9,*/*;q=0.8'
    headers['Sec-Fetch-Dest'] = 'document'
    headers['Sec-Fetch-Site'] = 'none'
    headers['Referer'] = API_ORIGIN
    request = Request(API_URL, headers=headers, method='GET')
    with cloudflare_urlopen(request, timeout=12, allow_native_fallback=True) as response:
        data = response.read(MAX_PAYLOAD_BYTES + 1)
        if len(data) > MAX_PAYLOAD_BYTES:
            raise ValueError('payload excedeu limite')
        content_type = getattr(response, 'headers', {}).get('Content-Type', '')
        channels = _parse_payload(data, content_type)
        _log('API resposta bytes=%d tipo=%s canais_reconhecidos=%d' % (len(data), content_type or '-', len(channels)))
    if not channels:
        raise ValueError('catálogo sem canais reconhecíveis')
    return {'channels': channels, 'fetched_at': int(time.time())}


def _read_cache(fresh_only=False):
    try:
        if fresh_only and time.time() - os.path.getmtime(_CACHE_FILE) > CACHE_TTL:
            return None
        with open(_CACHE_FILE, 'rb') as fh:
            raw = fh.read(MAX_CACHE_BYTES + 1)
        if len(raw) > MAX_CACHE_BYTES:
            return None
        obj = json.loads(raw.decode('utf-8'))
        channels = obj.get('channels') if isinstance(obj, dict) else None
        if not isinstance(channels, list):
            return None
        normalized = _normalize_rows(channels)
        return {'channels': normalized, 'fetched_at': int(obj.get('fetched_at') or 0)}
    except Exception:
        return None


def _write_cache(payload):
    try:
        xbmcvfs.mkdirs(PROFILE)
        write_json_atomic(_CACHE_FILE, payload, MAX_CACHE_BYTES)
    except Exception as exc:
        _log('cache não pôde ser atualizado: %s' % exc, True)


def _payload(force=False):
    global _MEMO, _MEMO_DEADLINE
    now = time.monotonic()
    if not force and _MEMO is not None and now < _MEMO_DEADLINE:
        return _MEMO
    if not force:
        fresh = _read_cache(True)
        if fresh is not None:
            _MEMO = fresh
            _MEMO_DEADLINE = now + CACHE_TTL
            return fresh
    try:
        live = _fetch_live()
        _write_cache(live)
        _MEMO = live
        _MEMO_DEADLINE = now + CACHE_TTL
        _log('catálogo atualizado canais=%d' % len(live.get('channels') or []))
        return live
    except Exception as exc:
        _log('catálogo online indisponível: %s' % exc, True)
    stale = _read_cache(False)
    if stale is not None:
        _MEMO = stale
        _MEMO_DEADLINE = now + min(CACHE_TTL, 60)
        _log('usando cache anterior canais=%d' % len(stale.get('channels') or []), True)
        return stale
    _MEMO = {'channels': []}
    _MEMO_DEADLINE = now + 20
    return _MEMO


def source_for(channel):
    if not isinstance(channel, dict):
        return None
    url = _safe_url(channel.get('stream_url') or channel.get('api_url') or channel.get('source_page'))
    if not url:
        return None
    direct = bool(channel.get('stream_url')) or _looks_direct_media(url, channel.get('_option4_url_kind'))
    if direct:
        h = media_headers(page_url=API_URL)
        return {
            'name': 'opcao4-api-media',
            'url': url,
            'playlist_headers': dict(h),
            'resource_headers': dict(h),
            'allow_html_resolve': False,
            'allow_native_dns_fallback': True,
            'source_kind': 'derived-media',
        }

    page_h = page_headers(page_url=url, parent_url=API_URL)
    page_h['Referer'] = API_URL
    resource_h = media_headers(page_url=url)
    return {
        'name': 'opcao4-api-page',
        'url': url,
        'playlist_headers': page_h,
        'resource_headers': resource_h,
        'allow_html_resolve': True,
        'allow_native_dns_fallback': True,
        'max_html_depth': 2,
        'preserve_navigation_referer': True,
        'source_kind': 'derived-page',
    }


class Catalog(object):
    def __init__(self):
        self._channels = list((_payload(False) or {}).get('channels') or [])

    def channels(self):
        return list(self._channels)

    def categories(self):
        present = []
        for channel in self._channels:
            for name in channel.get('categories') or [channel.get('category') or 'Geral']:
                if name and name not in present:
                    present.append(str(name))
        # Adulto sempre fica por último e protegido pela camada integrada.
        normal = sorted([x for x in present if x != 'adulto'], key=lambda x: x.casefold())
        return normal + (['adulto'] if 'adulto' in present else [])

    def category_description(self, category):
        if str(category or '') == 'adulto':
            return 'Conteúdo adulto disponível na Opção 4.'
        return 'Canais disponíveis na Opção 4.'

    def by_category(self, category):
        return [c for c in self._channels if category in (c.get('categories') or [c.get('category')])]

    def get(self, channel_id):
        wanted = str(channel_id or '').strip().lower()
        for channel in self._channels:
            if str(channel.get('id') or '').strip().lower() == wanted:
                return channel
        return None

    def refresh_get(self, channel_id):
        global _MEMO, _MEMO_DEADLINE
        try:
            live = _fetch_live()
            _write_cache(live)
            _MEMO = live
            _MEMO_DEADLINE = time.monotonic() + CACHE_TTL
            _log('catálogo forçado atualizado canais=%d' % len(live.get('channels') or []))
            wanted = str(channel_id or '').strip().lower()
            for channel in live.get('channels') or []:
                if str(channel.get('id') or '').strip().lower() == wanted:
                    return channel
        except Exception as exc:
            _log('refresh live falhou id=%s: %s' % (channel_id, exc), True)
        return None
