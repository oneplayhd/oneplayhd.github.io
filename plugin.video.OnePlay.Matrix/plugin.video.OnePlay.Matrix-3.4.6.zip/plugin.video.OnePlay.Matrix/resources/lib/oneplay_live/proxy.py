# -*- coding: utf-8 -*-
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.client import HTTPResponse
from urllib.error import HTTPError
from urllib.parse import parse_qs, quote, urljoin, urlparse, urlencode
from urllib.request import Request, urlopen as _native_urlopen
from contextlib import contextmanager
import re
import hashlib
import threading
import time
import socket
import struct
import os
import ssl
import json

UPSTREAM_ATTEMPTS = 2
UPSTREAM_BACKOFF = 0.15
SEGMENT_ATTEMPTS = 3
SEGMENT_BACKOFF = 0.25
SEGMENT_RETRY_HTTP = (404, 408, 410, 425, 429, 500, 502, 503, 504)
PLAYLIST_MAX_BYTES = 4 * 1024 * 1024
FORMAT_PROBE_BYTES = 4096
FORMAT_PROBE_TIMEOUT = 6
FORMAT_SUSPECT_EXTENSIONS = ('.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.svg', '.ico', '.woff', '.woff2', '.css', '.txt', '.js')

PLAYLIST_MIME = 'application/vnd.apple.mpegurl'
URI_ATTR_RE = re.compile(r'URI=("|\')([^"\']+)(\1)')

DNS_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'


def _dns_log(message, warning=False):
    try:
        import xbmc
        xbmc.log('[ONEPLAY LIVE] DNS %s' % message, xbmc.LOGWARNING if warning else xbmc.LOGINFO)
    except Exception:
        pass


class CloudflareDNSResolver(object):
    """DNS privado ao add-on, sem alterar a configuracao DNS do dispositivo.

    Replica o contrato homologado do Meu Futebol: A/IPv4 via 1.1.1.1/1.0.0.1,
    primeiro UDP, depois TCP e por ultimo DoH direto aos IPs Cloudflare. Para
    hostname externo o modo e estrito: se Cloudflare falhar, nao cai no DNS da
    rede. O patch de getaddrinfo existe somente durante cada abertura HTTP do
    OnePlay e e restaurado logo depois.
    """

    SERVERS = ('1.1.1.1', '1.0.0.1')
    CACHE_TTL_MIN = 60
    CACHE_TTL_MAX = 1800
    UDP_TIMEOUT = 2.0
    TCP_TIMEOUT = 3.5
    DOH_TIMEOUT = (3, 6)

    def __init__(self):
        self._native_getaddrinfo = socket.getaddrinfo
        self._cache = {}
        self._cache_lock = threading.RLock()
        self._patch_lock = threading.RLock()
        self._patch_depth = 0
        self._scope_state = threading.local()
        self._scope_native_getaddrinfo = self._native_getaddrinfo
        self._resolving = threading.local()
        self._logged_active = False

    @staticmethod
    def _host_text(host):
        if isinstance(host, bytes):
            try:
                return host.decode('idna')
            except Exception:
                return host.decode('utf-8', 'ignore')
        return str(host or '')

    @staticmethod
    def _is_ip_literal(host):
        try:
            socket.inet_pton(socket.AF_INET, host)
            return True
        except Exception:
            pass
        try:
            socket.inet_pton(socket.AF_INET6, host)
            return True
        except Exception:
            return False

    def _skip_name(self, packet, offset):
        seen = 0
        length = len(packet)
        while offset < length:
            if seen > 128:
                raise ValueError('Loop de nome DNS')
            seen += 1
            size = packet[offset]
            if size == 0:
                return offset + 1
            if size & 0xC0 == 0xC0:
                if offset + 1 >= length:
                    raise ValueError('Ponteiro DNS truncado')
                return offset + 2
            if size & 0xC0:
                raise ValueError('Label DNS invalido')
            offset += 1 + size
        raise ValueError('Nome DNS truncado')

    def _build_query(self, host):
        labels = []
        for label in host.rstrip('.').split('.'):
            raw = label.encode('idna')
            if not raw or len(raw) > 63:
                raise ValueError('Hostname DNS invalido')
            labels.append(bytes([len(raw)]) + raw)
        question = b''.join(labels) + b'\x00' + struct.pack('!HH', 1, 1)
        query_id = struct.unpack('!H', os.urandom(2))[0]
        return query_id, struct.pack('!HHHHHH', query_id, 0x0100, 1, 0, 0, 0) + question

    def _parse_response(self, packet, query_id):
        if not packet or len(packet) < 12:
            return [], self.CACHE_TTL_MIN
        response_id, flags, qdcount, ancount, _, _ = struct.unpack('!HHHHHH', packet[:12])
        if response_id != query_id or (flags & 0x8000) == 0 or (flags & 0x000F):
            return [], self.CACHE_TTL_MIN
        offset = 12
        for _ in range(qdcount):
            offset = self._skip_name(packet, offset)
            offset += 4
            if offset > len(packet):
                return [], self.CACHE_TTL_MIN
        addresses = []
        ttl_values = []
        for _ in range(ancount):
            offset = self._skip_name(packet, offset)
            if offset + 10 > len(packet):
                break
            rtype, rclass, ttl, rdlength = struct.unpack('!HHIH', packet[offset:offset + 10])
            offset += 10
            rdata_end = offset + rdlength
            if rdata_end > len(packet):
                break
            if rtype == 1 and rclass == 1 and rdlength == 4:
                addresses.append(socket.inet_ntoa(packet[offset:rdata_end]))
                ttl_values.append(ttl)
            offset = rdata_end
        ttl = min(ttl_values) if ttl_values else self.CACHE_TTL_MIN
        ttl = max(self.CACHE_TTL_MIN, min(int(ttl), self.CACHE_TTL_MAX))
        return addresses, ttl

    @staticmethod
    def _recv_exact(sock, amount):
        data = b''
        while len(data) < amount:
            block = sock.recv(amount - len(data))
            if not block:
                return b''
            data += block
        return data

    def _query_udp(self, server, packet, query_id):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.settimeout(self.UDP_TIMEOUT)
            sock.sendto(packet, (server, 53))
            response, _ = sock.recvfrom(8192)
            return self._parse_response(response, query_id)
        finally:
            try:
                sock.close()
            except Exception:
                pass

    def _query_tcp(self, server, packet, query_id):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sock.settimeout(self.TCP_TIMEOUT)
            sock.connect((server, 53))
            payload = struct.pack('!H', len(packet)) + packet
            sock.sendall(payload)
            header = self._recv_exact(sock, 2)
            if not header:
                return [], self.CACHE_TTL_MIN
            size = struct.unpack('!H', header)[0]
            response = self._recv_exact(sock, size)
            return self._parse_response(response, query_id)
        finally:
            try:
                sock.close()
            except Exception:
                pass

    def _query_doh(self, host):
        request_path = '/dns-query?{}'.format(urlencode({'name': host, 'type': 'A'}))
        request = (
            'GET {} HTTP/1.1\r\n'
            'Host: cloudflare-dns.com\r\n'
            'Accept: application/dns-json\r\n'
            'Accept-Encoding: identity\r\n'
            'User-Agent: {}\r\n'
            'Connection: close\r\n\r\n'
        ).format(request_path, DNS_USER_AGENT).encode('ascii', 'ignore')
        for server in self.SERVERS:
            raw_sock = None
            tls_sock = None
            try:
                raw_sock = socket.create_connection((server, 443), self.DOH_TIMEOUT[1])
                context = ssl.create_default_context()
                tls_sock = context.wrap_socket(raw_sock, server_hostname='cloudflare-dns.com')
                raw_sock = None
                tls_sock.settimeout(self.DOH_TIMEOUT[1])
                tls_sock.sendall(request)
                # Decode HTTP framing (including chunked) before parsing JSON.
                with HTTPResponse(tls_sock) as response:
                    response.begin()
                    if response.status != 200:
                        continue
                    body = response.read(1024 * 1024 + 1)
                if len(body) > 1024 * 1024:
                    raise ValueError('Resposta DoH grande demais')
                payload = json.loads(body.decode('utf-8', 'replace'))
                ips = []
                ttls = []
                for answer in payload.get('Answer') or []:
                    if answer.get('type') == 1 and answer.get('data'):
                        ip = str(answer.get('data'))
                        if self._is_ip_literal(ip):
                            ips.append(ip)
                            ttls.append(answer.get('TTL') or self.CACHE_TTL_MIN)
                if ips:
                    ttl = min(ttls) if ttls else self.CACHE_TTL_MIN
                    return ips, max(self.CACHE_TTL_MIN, min(int(ttl), self.CACHE_TTL_MAX))
            except Exception as exc:
                _dns_log('DoH direto indisponivel em %s: %s' % (server, str(exc)), warning=True)
            finally:
                for candidate in (tls_sock, raw_sock):
                    try:
                        if candidate:
                            candidate.close()
                    except Exception:
                        pass
        return [], self.CACHE_TTL_MIN

    def resolve(self, host):
        host = self._host_text(host).strip().rstrip('.').lower()
        if not host or self._is_ip_literal(host) or host in ('localhost', 'localhost.localdomain') or host.endswith('.local'):
            return []
        now = time.time()
        with self._cache_lock:
            cached = self._cache.get(host)
            if cached and cached[0] > now:
                return list(cached[1])
        if getattr(self._resolving, 'active', False):
            return []
        self._resolving.active = True
        try:
            query_id, packet = self._build_query(host)
            for server in self.SERVERS:
                try:
                    addresses, ttl = self._query_udp(server, packet, query_id)
                    if addresses:
                        self._save_cache(host, addresses, ttl)
                        return addresses
                except Exception:
                    pass
            for server in self.SERVERS:
                try:
                    addresses, ttl = self._query_tcp(server, packet, query_id)
                    if addresses:
                        self._save_cache(host, addresses, ttl)
                        return addresses
                except Exception:
                    pass
            addresses, ttl = self._query_doh(host)
            if addresses:
                self._save_cache(host, addresses, ttl)
                return addresses
        finally:
            self._resolving.active = False
        return []

    def _save_cache(self, host, addresses, ttl):
        with self._cache_lock:
            self._cache[host] = (time.time() + ttl, tuple(addresses))

    def _patched_getaddrinfo(self, host, port, family=0, type=0, proto=0, flags=0):
        if not getattr(self._scope_state, 'depth', 0):
            return self._scope_native_getaddrinfo(host, port, family, type, proto, flags)
        if getattr(self._resolving, 'active', False):
            return self._native_getaddrinfo(host, port, family, type, proto, flags)
        host_text = self._host_text(host)
        if not host_text or self._is_ip_literal(host_text) or host_text in ('localhost', 'localhost.localdomain') or host_text.endswith('.local'):
            return self._native_getaddrinfo(host, port, family, type, proto, flags)
        if family == socket.AF_INET6:
            raise socket.gaierror(socket.EAI_NONAME, 'Cloudflare DNS: IPv6 nao disponivel neste fluxo')
        addresses = self.resolve(host_text)
        if not addresses:
            raise socket.gaierror(socket.EAI_NONAME, 'Cloudflare DNS nao respondeu para %s' % host_text)
        results = []
        for ip in addresses:
            try:
                results.extend(self._native_getaddrinfo(ip, port, family, type, proto, flags))
            except Exception:
                pass
        if not results:
            raise socket.gaierror(socket.EAI_NONAME, 'Cloudflare DNS nao retornou endereco utilizavel para %s' % host_text)
        return results

    @contextmanager
    def scoped(self):
        with self._patch_lock:
            if self._patch_depth == 0:
                self._scope_native_getaddrinfo = socket.getaddrinfo
                socket.getaddrinfo = self._patched_getaddrinfo
            self._patch_depth += 1
            self._scope_state.depth = getattr(self._scope_state, 'depth', 0) + 1
        try:
            yield
        finally:
            with self._patch_lock:
                self._scope_state.depth -= 1
                self._patch_depth -= 1
                if self._patch_depth <= 0:
                    self._patch_depth = 0
                    if socket.getaddrinfo == self._patched_getaddrinfo:
                        socket.getaddrinfo = self._scope_native_getaddrinfo

    def mark_active(self):
        if self._logged_active:
            return
        self._logged_active = True
        _dns_log('Cloudflare interno estrito habilitado (sem DNS padrao da rede).')


_cloudflare_dns = CloudflareDNSResolver()


def install_cloudflare_dns():
    _cloudflare_dns.mark_active()
    return True


def _open_native(request, timeout=None):
    if timeout is None:
        return _native_urlopen(request)
    return _native_urlopen(request, timeout=timeout)


def _is_dns_resolution_error(exc):
    reason = getattr(exc, 'reason', None)
    if isinstance(exc, socket.gaierror) or isinstance(reason, socket.gaierror):
        return True
    text = str(exc or '').lower()
    return ('cloudflare dns nao respondeu' in text or
            'name or service not known' in text or
            'nodename nor servname' in text or
            'getaddrinfo failed' in text)


def cloudflare_urlopen(request, timeout=None, allow_native_fallback=False):
    """Abre URL com Cloudflare DNS; fallback nativo e opt-in e por conexao.

    O fallback existe apenas para a infraestrutura nova descoberta pela API/W7.
    Ele não muda configuração do Windows/Android/Kodi e nunca é usado após uma
    resposta HTTP: só entra quando a resolução DNS Cloudflare falha.
    """
    install_cloudflare_dns()
    try:
        with _cloudflare_dns.scoped():
            return _open_native(request, timeout=timeout)
    except Exception as exc:
        if not allow_native_fallback or not _is_dns_resolution_error(exc):
            raise
        try:
            target = request.full_url
        except Exception:
            target = str(request or '')
        host = (urlparse(target).hostname or '?')
        _dns_log('Cloudflare sem A para %s; fallback DNS nativo restrito a esta URL da fonte.' % host, warning=True)
        return _open_native(request, timeout=timeout)


def _is_ts(data):
    if not data:
        return False
    limit = min(188, len(data))
    for offset in range(limit):
        if data[offset] != 0x47:
            continue
        if offset + 188 < len(data) and data[offset + 188] == 0x47:
            return True
    return False


def _sniff_mime(remote_url, content_type, first):
    path = urlparse(remote_url).path.lower()
    ct = (content_type or '').split(';', 1)[0].strip().lower()
    # O novo backend usa file.txt como manifesto. A assinatura HLS do corpo
    # prevalece sobre extensão/MIME para refreshes posteriores do live.
    # Isso não transforma XML/HTML/JSON: exige #EXTM3U no início útil.
    sample = (first or b'')[:128].lstrip()
    if '.m3u8' in path or 'mpegurl' in ct or sample.startswith(b'#EXTM3U'):
        return PLAYLIST_MIME
    if _is_ts(first):
        return 'video/mp2t'
    if len(first) >= 8 and (first[4:8] == b'ftyp' or b'moof' in first[:64]):
        return 'video/mp4'
    if path.endswith('.css'):
        return 'application/octet-stream'
    return ct or 'application/octet-stream'


def _detected_media_route(data, content_type=''):
    if _is_ts(data):
        return ('ts', 'video/mp2t')
    if len(data) >= 8 and (data[4:8] == b'ftyp' or b'moof' in data[:96] or b'styp' in data[:32]):
        return ('m4s', 'video/mp4')
    if data[:3] == b'ID3' or (len(data) >= 2 and data[0] == 0xFF and (data[1] & 0xF0) == 0xF0):
        return ('aac', 'audio/aac')
    return None


def _forced_mime_matches(data, mime):
    if mime == 'video/mp2t':
        return _is_ts(data)
    if mime == 'video/mp4':
        return len(data) >= 8 and (data[4:8] == b'ftyp' or b'moof' in data[:96] or b'styp' in data[:32])
    if mime == 'audio/aac':
        return data[:3] == b'ID3' or (len(data) >= 2 and data[0] == 0xFF and (data[1] & 0xF0) == 0xF0)
    return False


def _extension(remote_url):
    path = urlparse(remote_url).path.lower()
    tail = path.rsplit('/', 1)[-1]
    if '.' not in tail:
        return ''
    return '.' + tail.rsplit('.', 1)[-1]



def _is_invalid_media(data, mime=''):
    """Bloqueia respostas que claramente não são mídia HLS reproduzível."""
    if not data:
        return True
    # A assinatura do payload prevalece sobre o MIME declarado pelo servidor.
    signatures = (b'\x89PNG\r\n\x1a\n', b'\xff\xd8\xff', b'GIF87a', b'GIF89a')
    if any(data.startswith(sig) for sig in signatures):
        return True
    sample = data[:256].lstrip().lower()
    if sample.startswith((b'<!doctype html', b'<html', b'<?xml', b'{"', b'[{')):
        return True
    if _is_ts(data):
        return False
    if len(data) >= 8 and (data[4:8] == b'ftyp' or b'moof' in data[:96] or b'styp' in data[:32]):
        return False
    if data[:3] == b'ID3' or (len(data) >= 2 and data[0] == 0xFF and (data[1] & 0xF0) == 0xF0):
        return False
    ct = (mime or '').split(';', 1)[0].strip().lower()
    if ct.startswith('video/') or ct.startswith('audio/'):
        return False
    return ct.startswith('image/') or ct.startswith('text/html')


def _is_local_disconnect(exc):
    if isinstance(exc, (BrokenPipeError, ConnectionResetError, ConnectionAbortedError)):
        return True
    code = getattr(exc, 'winerror', None)
    if code in (10053, 10054):
        return True
    eno = getattr(exc, 'errno', None)
    return eno in (32, 54, 104)

def _playlist_uri_kind(tag_line):
    upper = (tag_line or '').lstrip().upper()
    if upper.startswith('#EXT-X-KEY:') or upper.startswith('#EXT-X-SESSION-KEY:'):
        return 'key'
    if upper.startswith('#EXT-X-MAP:'):
        return 'media'
    if (upper.startswith('#EXT-X-MEDIA:') or
            upper.startswith('#EXT-X-I-FRAME-STREAM-INF:') or
            upper.startswith('#EXT-X-RENDITION-REPORT:')):
        return 'playlist'
    if upper.startswith('#EXT-X-CONTENT-STEERING:'):
        return 'data'
    return 'auto'


def rewrite_playlist(text, playlist_url, localize):
    out = []
    next_bare_kind = 'media'
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            out.append(raw_line)
            continue
        if line.startswith('#'):
            resource_kind = _playlist_uri_kind(line)
            if line.upper().startswith('#EXT-X-STREAM-INF:'):
                next_bare_kind = 'playlist'
            def repl(match):
                target = urljoin(playlist_url, match.group(2))
                return 'URI=%s%s%s' % (match.group(1), localize(target, resource_kind), match.group(3))
            out.append(URI_ATTR_RE.sub(repl, raw_line))
        else:
            out.append(localize(urljoin(playlist_url, line), next_bare_kind))
            next_bare_kind = 'media'
    return '\n'.join(out) + '\n'


class HlsProxy(object):
    def __init__(self, root_url, root_headers=None, nested_headers=None, log=None, seed_playlist=None, mask_png_ts_segments=False, format_recovery=False, segment_recovery=True):
        self.root_url = root_url
        self.root_headers = dict(root_headers or {})
        self.nested_headers = dict(nested_headers or self.root_headers)
        self.log = log or (lambda msg: None)
        self.server = None
        self.thread = None
        self.port = None
        self.seed_playlist = bytes(seed_playlist) if seed_playlist else None
        self.seed_lock = threading.Lock()
        # Globo RJ usa MPEG-TS camuflado com extensão/MIME image/png.
        # O FFmpeg HLS escolhe o demuxer pela URI antes de ler os bytes; por
        # isso a URL real .png não pode aparecer nem no path nem no query
        # entregue ao player. O mapa abaixo fica somente dentro desta sessão.
        self.mask_png_ts_segments = bool(mask_png_ts_segments)
        # Nos demais canais a correção de formato é passiva na primeira tentativa.
        # Ela só é ligada pelo player após uma falha de startup e somente quando
        # a playlist expôs extensões suspeitas (.png/.woff/etc.).
        self.format_recovery = bool(format_recovery)
        self.segment_recovery = bool(segment_recovery)
        self.route_lock = threading.Lock()
        self.route_by_token = {}
        self.format_cache = {}
        self.format_suspects = set()
        self.started_at = None
        self.stats_lock = threading.Lock()
        self.playlist_count = 0
        self.segment_count = 0
        self.bytes_out = 0
        self.error_count = 0
        self.segment_retry_count = 0
        self.segment_failure_count = 0
        self.format_recovery_count = 0

    def _register_route(self, remote_url, suffix, forced_mime, resource_kind='media'):
        resource_kind = str(resource_kind or 'media').strip().lower()
        token = hashlib.sha256((resource_kind + '\0' + remote_url).encode('utf-8')).hexdigest()[:32]
        with self.route_lock:
            self.route_by_token[token] = (remote_url, forced_mime, resource_kind)
        return 'http://127.0.0.1:%d/segment/%s.%s' % (self.port, token, suffix)

    def _mark_suspect(self, remote_url):
        # O manifest raiz pode terminar em .txt apos redirect; isso por si so
        # nao e sinal de segmento camuflado. Observamos apenas URIs internas.
        if remote_url == self.root_url:
            return False
        ext = _extension(remote_url)
        if ext in FORMAT_SUSPECT_EXTENSIONS:
            with self.route_lock:
                self.format_suspects.add((urlparse(remote_url).netloc.lower(), ext))
            return True
        return False

    def has_format_suspects(self):
        with self.route_lock:
            return bool(self.format_suspects)

    def _detect_recovery_format(self, remote_url):
        ext = _extension(remote_url)
        key = (urlparse(remote_url).netloc.lower(), ext)
        with self.route_lock:
            cached = self.format_cache.get(key)
        if cached:
            return cached
        headers = self._headers_for(remote_url)
        if not any(str(k).lower() == 'range' for k in headers):
            headers['Range'] = 'bytes=0-%d' % (FORMAT_PROBE_BYTES - 1)
        try:
            request = Request(remote_url, headers=headers, method='GET')
            with cloudflare_urlopen(request, timeout=FORMAT_PROBE_TIMEOUT, allow_native_fallback=True) as response:
                sample = response.read(FORMAT_PROBE_BYTES)
                ctype = response.headers.get('Content-Type', '') if getattr(response, 'headers', None) else ''
                detected = _detected_media_route(sample, ctype)
                if detected:
                    with self.route_lock:
                        self.format_cache[key] = detected
                    with self.stats_lock:
                        self.format_recovery_count += 1
                    self.log('recuperacao formato detectou host=%s ext=%s como=%s' % (
                        urlparse(remote_url).netloc, ext or '?', detected[1]))
                    return detected
        except Exception as exc:
            self.log('recuperacao formato probe falhou host=%s ext=%s tipo=%s' % (
                urlparse(remote_url).netloc, ext or '?', exc.__class__.__name__))
        return None

    def _local_url(self, remote_url, resource_kind='auto'):
        resource_kind = str(resource_kind or 'auto').strip().lower()
        if resource_kind not in ('auto', 'playlist', 'media', 'key', 'data'):
            resource_kind = 'auto'
        path = urlparse(remote_url).path.lower()
        # Chaves e metadados HLS são recursos binários/dados; nunca devem
        # entrar na recuperação de formato ou no mascaramento de segmentos.
        if resource_kind not in ('key', 'data'):
            suspect = self._mark_suspect(remote_url)
            if self.mask_png_ts_segments and path.endswith('.png'):
                # Globo RJ: comportamento já validado em Kodi real na 0.0.13.
                return self._register_route(remote_url, 'ts', 'video/mp2t', resource_kind='media')
            if self.format_recovery and suspect:
                detected = self._detect_recovery_format(remote_url)
                if detected:
                    suffix, forced_mime = detected
                    return self._register_route(remote_url, suffix, forced_mime, resource_kind='media')
        return 'http://127.0.0.1:%d/fetch?u=%s&rk=%s' % (
            self.port, quote(remote_url, safe=''), quote(resource_kind, safe=''))

    def _remote_from_request(self, request_path):
        parsed_local = urlparse(request_path)
        local_path = parsed_local.path or ''
        if local_path.startswith('/segment/'):
            filename = local_path.rsplit('/', 1)[-1]
            token = filename.split('.', 1)[0]
            with self.route_lock:
                route = self.route_by_token.get(token)
            if route:
                return route[0], route[1], route[2] if len(route) > 2 else 'media'
            return None, None, 'auto'
        query = parse_qs(parsed_local.query)
        encoded = (query.get('u') or [''])[0]
        resource_kind = str((query.get('rk') or ['auto'])[0] or 'auto').strip().lower()
        if resource_kind not in ('auto', 'playlist', 'media', 'key', 'data'):
            resource_kind = 'auto'
        return encoded, None, resource_kind

    def url(self, remote_url):
        return self._local_url(remote_url, 'auto')

    def _headers_for(self, remote):
        # O primeiro manifest respeita o contrato proprio da origem escolhida.
        # Tudo que for descoberto dentro dele usa os headers de recursos HLS.
        return dict(self.root_headers if remote == self.root_url else self.nested_headers)


    def _take_seed_playlist(self, remote):
        if remote != self.root_url:
            return None
        with self.seed_lock:
            data = self.seed_playlist
            self.seed_playlist = None
            return data

    def _stat(self, kind=None, bytes_out=0, error=False):
        with self.stats_lock:
            if kind == 'playlist':
                self.playlist_count += 1
            elif kind == 'segment':
                self.segment_count += 1
            self.bytes_out += int(bytes_out or 0)
            if error:
                self.error_count += 1

    def start(self):
        parent = self
        self.started_at = time.time()

        class Handler(BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'

            def log_message(self, fmt, *args):
                return

            def _send_error(self, code, message):
                body = (message or 'proxy error').encode('utf-8', 'replace')
                self.send_response(code)
                self.send_header('Content-Type', 'text/plain; charset=utf-8')
                self.send_header('Content-Length', str(len(body)))
                self.send_header('Connection', 'close')
                self.end_headers()
                if self.command != 'HEAD':
                    try:
                        self.wfile.write(body)
                    except Exception:
                        pass

            def do_HEAD(self):
                self._handle(fetch_body=False)

            def do_GET(self):
                self._handle(fetch_body=True)

            def _handle(self, fetch_body=True):
                response = None
                headers_sent = False
                try:
                    remote, forced_mime, resource_kind = parent._remote_from_request(self.path)
                    parsed = urlparse(remote or '')
                    if parsed.scheme not in ('http', 'https'):
                        return self._send_error(400, 'invalid url')

                    seed = parent._take_seed_playlist(remote) if fetch_body else None
                    if seed is not None:
                        text = seed.decode('utf-8', 'ignore')
                        if '#EXTM3U' not in text:
                            parent._stat(error=True)
                            return self._send_error(502, 'invalid seeded HLS')
                        rewritten = rewrite_playlist(text, remote, parent._local_url).encode('utf-8')
                        self.send_response(200)
                        self.send_header('Content-Type', PLAYLIST_MIME)
                        self.send_header('Content-Length', str(len(rewritten)))
                        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
                        self.send_header('Connection', 'close')
                        self.end_headers()
                        headers_sent = True
                        self.wfile.write(rewritten)
                        parent._stat('playlist', len(rewritten))
                        parent.log('playlist inicial reutilizada bytes=%d' % len(rewritten))
                        return

                    headers = parent._headers_for(remote)
                    for name in ('Range', 'If-Range', 'If-None-Match', 'If-Modified-Since'):
                        value = self.headers.get(name)
                        if value:
                            headers[name] = value
                    remote_path = urlparse(remote).path.lower()
                    is_key_resource = resource_kind == 'key'
                    is_data_resource = resource_kind == 'data'
                    is_playlist_resource = resource_kind == 'playlist'
                    is_media_resource = resource_kind == 'media'
                    likely_segment = (not is_key_resource and not is_data_resource and
                                      (bool(forced_mime) or is_media_resource or
                                       (resource_kind == 'auto' and remote != parent.root_url and
                                        not remote_path.endswith('.m3u8'))))
                    max_attempts = SEGMENT_ATTEMPTS if (parent.segment_recovery and likely_segment) else UPSTREAM_ATTEMPTS
                    response = None
                    last_exc = None
                    for attempt in range(1, max_attempts + 1):
                        request = Request(remote, headers=headers, method='GET' if fetch_body else 'HEAD')
                        try:
                            response = cloudflare_urlopen(request, timeout=12, allow_native_fallback=True)
                            last_exc = None
                            break
                        except HTTPError as exc:
                            code = getattr(exc, 'code', 0) or 0
                            if likely_segment and parent.segment_recovery and code in SEGMENT_RETRY_HTTP and attempt < max_attempts:
                                with parent.stats_lock:
                                    parent.segment_retry_count += 1
                                parent.log('segmento retry status=%s tentativa=%d/%d host=%s' % (
                                    code, attempt, max_attempts, parsed.netloc))
                                try:
                                    exc.close()
                                except Exception:
                                    pass
                                time.sleep(SEGMENT_BACKOFF * attempt)
                                continue
                            response = exc
                            last_exc = None
                            break
                        except Exception as exc:
                            last_exc = exc
                            if attempt < max_attempts:
                                if likely_segment and parent.segment_recovery:
                                    with parent.stats_lock:
                                        parent.segment_retry_count += 1
                                    parent.log('segmento retry erro=%s tentativa=%d/%d host=%s' % (
                                        exc.__class__.__name__, attempt, max_attempts, parsed.netloc))
                                time.sleep(SEGMENT_BACKOFF * attempt if likely_segment else UPSTREAM_BACKOFF)
                    if response is None:
                        if likely_segment:
                            with parent.stats_lock:
                                parent.segment_failure_count += 1
                            parent.log('segmento falhou apos tentativas host=%s; proxy permanece ativo para proximos segmentos' % parsed.netloc)
                        raise last_exc or IOError('upstream unavailable')

                    status = getattr(response, 'status', None) or getattr(response, 'code', 200)
                    final_url = getattr(response, 'url', remote) or remote
                    ctype = response.headers.get('Content-Type', '') if getattr(response, 'headers', None) else ''
                    is_playlist = (not is_key_resource and not is_data_resource and
                                   (is_playlist_resource or
                                    (resource_kind == 'auto' and
                                     ('.m3u8' in urlparse(final_url).path.lower() or
                                      'mpegurl' in ctype.lower()))))

                    if status >= 400:
                        parent._stat(error=True)
                        if likely_segment:
                            with parent.stats_lock:
                                parent.segment_failure_count += 1
                            parent.log('segmento indisponivel status=%s host=%s; mantendo proxy para a sequencia HLS' % (
                                status, parsed.netloc))
                        else:
                            parent.log('upstream status=%s host=%s final_host=%s' % (
                                status, parsed.netloc, urlparse(final_url).netloc))
                        return self._send_error(status, 'upstream http error')

                    first = response.read(4096) if fetch_body else b''
                    is_playlist = is_playlist or (
                        not is_key_resource and not is_data_resource and
                        first.lstrip().startswith(b'#EXTM3U'))
                    if is_playlist and fetch_body:
                        data = first + response.read(PLAYLIST_MAX_BYTES + 1 - len(first))
                        if len(data) > PLAYLIST_MAX_BYTES:
                            return self._send_error(502, 'upstream playlist exceeds limit')
                        text = data.decode('utf-8', 'ignore')
                        if '#EXTM3U' not in text:
                            parent.log('playlist invalida status=%s host=%s' % (status, urlparse(final_url).netloc))
                            return self._send_error(502, 'upstream did not return HLS')
                        rewritten = rewrite_playlist(text, final_url, parent._local_url).encode('utf-8')
                        self.send_response(status)
                        self.send_header('Content-Type', PLAYLIST_MIME)
                        self.send_header('Content-Length', str(len(rewritten)))
                        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
                        self.send_header('Connection', 'close')
                        self.end_headers()
                        headers_sent = True
                        self.wfile.write(rewritten)
                        parent._stat('playlist', len(rewritten))
                        parent.log('playlist host=%s bytes=%d' % (urlparse(final_url).netloc, len(rewritten)))
                        return

                    mime = _sniff_mime(final_url, ctype, first)
                    if is_key_resource and ('mpegurl' in (mime or '').lower() or 'mpegurl' in ctype.lower()):
                        mime = 'application/octet-stream'
                    elif is_data_resource and 'mpegurl' in (mime or '').lower():
                        mime = 'application/octet-stream'
                    if forced_mime and fetch_body and _forced_mime_matches(first, forced_mime):
                        mime = forced_mime
                    if fetch_body and not (is_key_resource or is_data_resource) and _is_invalid_media(first, mime):
                        parent._stat(error=True)
                        parent.log('midia invalida bloqueada host=%s mime=%s assinatura=%s' % (
                            urlparse(final_url).netloc, mime, first[:12].hex()))
                        return self._send_error(502, 'invalid upstream media')
                    self.send_response(status)
                    self.send_header('Content-Type', mime)
                    for name in ('Content-Length', 'Content-Range', 'Accept-Ranges', 'ETag', 'Last-Modified'):
                        value = response.headers.get(name) if getattr(response, 'headers', None) else None
                        if value:
                            self.send_header(name, value)
                    self.send_header('Connection', 'close')
                    self.end_headers()
                    headers_sent = True
                    sent = 0
                    if fetch_body:
                        try:
                            if first:
                                self.wfile.write(first)
                                sent += len(first)
                            while True:
                                chunk = response.read(128 * 1024)
                                if not chunk:
                                    break
                                self.wfile.write(chunk)
                                sent += len(chunk)
                        except Exception as exc:
                            if _is_local_disconnect(exc):
                                parent.log('cliente local encerrou leitura; sem erro de origem')
                                return
                            if likely_segment:
                                with parent.stats_lock:
                                    parent.segment_failure_count += 1
                                parent.log('segmento interrompido bytes=%d erro=%s; proxy segue ativo para proximos segmentos' % (
                                    sent, exc.__class__.__name__))
                                return
                            raise
                    if fetch_body:
                        with parent.stats_lock:
                            first_segment = parent.segment_count == 0
                        parent._stat('segment', sent)
                        if first_segment:
                            parent.log('primeiro segmento host=%s mime=%s status=%s bytes=%d' % (
                                urlparse(final_url).netloc, mime, status, sent))
                except Exception as exc:
                    if _is_local_disconnect(exc):
                        parent.log('cliente local encerrou leitura; sem erro de origem')
                        return
                    parent._stat(error=True)
                    parent.log('erro proxy=%s' % exc)
                    try:
                        if not headers_sent:
                            self._send_error(502, 'proxy failure')
                        else:
                            self.close_connection = True
                    except Exception:
                        pass

                finally:
                    if response is not None:
                        try:
                            response.close()
                        except Exception:
                            pass

        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.server.daemon_threads = True
        self.port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, name='OnePlayHlsProxy')
        self.thread.daemon = True
        self.thread.start()
        self.log('proxy local dinamico iniciado host=127.0.0.1 porta=%d' % self.port)
        return self

    def stop(self):
        server = self.server
        self.server = None
        if server is not None:
            try:
                server.shutdown()
            except Exception:
                pass
            try:
                server.server_close()
            except Exception:
                pass
        with self.route_lock:
            self.route_by_token.clear()
            self.format_cache.clear()
        elapsed = max(0.0, time.time() - self.started_at) if self.started_at else 0.0
        with self.stats_lock:
            playlists = self.playlist_count
            segments = self.segment_count
            bytes_out = self.bytes_out
            errors = self.error_count
            seg_retries = self.segment_retry_count
            seg_failures = self.segment_failure_count
            fmt_recoveries = self.format_recovery_count
        self.log('proxy encerrado playlists=%d segmentos=%d bytes=%d erros=%d seg_retries=%d seg_falhas=%d fmt_recovery=%d duracao=%.1fs' % (
            playlists, segments, bytes_out, errors, seg_retries, seg_failures, fmt_recoveries, elapsed))
