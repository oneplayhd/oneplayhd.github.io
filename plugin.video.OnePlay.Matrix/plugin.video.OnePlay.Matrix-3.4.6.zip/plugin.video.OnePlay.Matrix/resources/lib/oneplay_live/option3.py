# -*- coding: utf-8 -*-
"""Catálogo e contrato isolados da Opção 3 do OnePlay Live.

Somente a página pública do catálogo é fixa. Categorias, paginação, canais,
domínios anunciados e páginas de reprodução são descobertos no HTML publicado
em cada acesso. Tokens, páginas ``/__play``, players intermediários, manifests
e CDNs nunca são persistidos nem codificados no add-on.
"""
from __future__ import unicode_literals

import hashlib
import html
from html.parser import HTMLParser
import json
import os
import re
import time
from urllib.parse import parse_qs, urlencode, urljoin, urlparse
from urllib.request import Request

import xbmc
import xbmcaddon
import xbmcvfs

from .option1 import epg_id_for
from .proxy import cloudflare_urlopen
from .source_contract import (
    BROWSER_UA, is_safe_public_url, media_headers, page_headers,
)
from .storage import write_json_atomic


ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CATALOG_URL = 'https://www.reidosembeds.online/'
MAX_HTML_BYTES = 1024 * 1024
MAX_CACHE_BYTES = 1024 * 1024
CACHE_TTL = 5 * 60
MAX_PAGE = 100
_MEMO = {}

# Estado mínimo de saúde dos domínios da Opção 3. Não guarda token, iframe,
# CDN nem URL final de mídia. O principal continua sendo definido pelo aviso
# público; last-known-good só acelera novas aberturas enquanto o principal
# acabou de falhar e é reavaliado periodicamente.
DOMAIN_STATE_FILE = os.path.join(PROFILE, 'oneplay_live_option3_domain_state.json')
DOMAIN_STATE_MAX_BYTES = 32 * 1024
DOMAIN_STATE_MAX_AGE = 24 * 60 * 60
PRIMARY_RETRY_AFTER = 5 * 60
LAST_GOOD_TTL = 10 * 60


def _log(message, warning=False):
    xbmc.log('[ONEPLAY LIVE] OPCAO3 %s' % message,
             xbmc.LOGWARNING if warning else xbmc.LOGINFO)


def _clean_text(value, limit=160):
    value = html.unescape(str(value or ''))
    value = re.sub(r'<[^>]+>', ' ', value)
    value = ' '.join(value.split()).strip()
    return value[:limit]


def _safe_page(value):
    try:
        return max(1, min(MAX_PAGE, int(value or 1)))
    except Exception:
        return 1


def _genre_key(value):
    value = str(value or '').strip().lower()
    if value in ('', '__all__'):
        return '__all__'
    return value if re.fullmatch(r'[a-z0-9_-]{1,80}', value) else '__all__'


def _pretty_genre(slug):
    special = {
        '24-horas': '24 Horas',
        'a-fazenda': 'A Fazenda',
        'canais-abertos': 'Canais Abertos',
        'miamitv': 'Miami TV',
        'realitys': 'Reality shows',
    }
    return special.get(slug, ' '.join(part.capitalize() for part in slug.replace('_', '-').split('-')))


class _CatalogHTMLParser(HTMLParser):
    """Extrai apenas estruturas editoriais; nunca executa JavaScript remoto."""

    def __init__(self, base_url):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.base_url = base_url
        self.cards = []
        self.categories = []
        self.max_page = 1
        self._card = None
        self._capture = ''
        self._capture_parts = []
        self._category = None
        self._category_parts = []

    @staticmethod
    def _attrs(attrs):
        return {str(key or '').lower(): str(value or '') for key, value in attrs}

    def handle_starttag(self, tag, attrs):
        tag = str(tag or '').lower()
        attrs = self._attrs(attrs)

        if tag == 'article' and 'data-channel-card' in attrs:
            self._card = {'href': '', 'name': '', 'image': '', 'category_text': ''}

        if self._card is not None:
            if tag == 'a' and not self._card['href']:
                href = urljoin(self.base_url, attrs.get('href', '').strip())
                if is_safe_public_url(href):
                    self._card['href'] = href
            elif tag == 'img' and not self._card['image']:
                image = urljoin(self.base_url, attrs.get('src', '').strip())
                if is_safe_public_url(image):
                    self._card['image'] = image
                if not self._card['name']:
                    self._card['name'] = _clean_text(attrs.get('alt', ''))
            elif tag == 'h4':
                self._capture = 'name'
                self._capture_parts = []
            elif tag == 'p' and not self._card['category_text']:
                self._capture = 'category_text'
                self._capture_parts = []

        if tag == 'a':
            href = urljoin(self.base_url, attrs.get('href', '').strip())
            try:
                query = parse_qs(urlparse(href).query)
            except Exception:
                query = {}
            genre = str((query.get('genre') or [''])[0] or '').strip().lower()
            if attrs.get('data-async-nav') == '1' and re.fullmatch(r'[a-z0-9_-]{1,80}', genre):
                self._category = {'slug': genre, 'label': ''}
                self._category_parts = []
            page_values = query.get('page') or []
            if page_values:
                try:
                    self.max_page = max(self.max_page, min(MAX_PAGE, int(page_values[0])))
                except Exception:
                    pass

    def handle_data(self, data):
        if self._capture:
            self._capture_parts.append(str(data or ''))
        if self._category is not None:
            self._category_parts.append(str(data or ''))

    def handle_endtag(self, tag):
        tag = str(tag or '').lower()
        if self._capture and tag in ('h4', 'p'):
            value = _clean_text(' '.join(self._capture_parts), 240)
            if self._card is not None and value:
                self._card[self._capture] = value
            self._capture = ''
            self._capture_parts = []

        if tag == 'a' and self._category is not None:
            label = _clean_text(' '.join(self._category_parts), 80)
            self._category['label'] = label or _pretty_genre(self._category['slug'])
            if not any(row.get('slug') == self._category['slug'] for row in self.categories):
                self.categories.append(self._category)
            self._category = None
            self._category_parts = []

        if tag == 'article' and self._card is not None:
            self.cards.append(self._card)
            self._card = None
            self._capture = ''
            self._capture_parts = []


def _published_domains(text):
    """Lê o aviso público e preserva sua prioridade editorial.

    O contrato original usa ``data-copy-text`` + classes de cor. O site já
    mudou markup em outras partes, portanto mantemos esse parser como fonte
    primária e acrescentamos uma leitura limitada ao próprio bloco de aviso.
    Nenhum domínio é empacotado no add-on: somente origens HTTPS publicadas
    pela página atual podem entrar no contrato.
    """
    rows = []
    seen = set()

    def add_origin(value, status='unknown'):
        value = html.unescape(str(value or '')).strip()
        try:
            parsed = urlparse(value)
            if (parsed.scheme or '').lower() != 'https':
                return
            if parsed.path not in ('', '/') or parsed.query or parsed.fragment:
                return
            host = (parsed.hostname or '').lower()
        except Exception:
            return
        if not host or host in seen or not is_safe_public_url(value):
            return
        if status == 'red':
            return
        origin = 'https://%s' % host
        rows.append({'origin': origin, 'status': status})
        seen.add(host)

    body = text or ''
    pattern = re.compile(r'data-copy-text\s*=\s*(["\'])(https://[^"\']+)\1', re.I)
    for match in pattern.finditer(body):
        context = body[max(0, match.start() - 1200):match.start()]
        states = {
            'green': max(context.rfind('bg-emerald-500'), context.rfind('bg-green-500')),
            'yellow': max(context.rfind('bg-yellow-400'), context.rfind('bg-amber-400')),
            'red': context.rfind('bg-red-500'),
        }
        state = max(states, key=states.get)
        if states[state] < 0:
            state = 'unknown'
        add_origin(match.group(2), state)

    # Fallback estrutural: somente dentro da vizinhança textual do aviso de
    # domínios. Isso acompanha mudanças de classes/atributos sem varrer anúncios
    # da página inteira. URLs com caminho/query não são aceitas como origem.
    notice_re = re.compile(
        r'(?:aviso\s+de\s+dom[ií]nio|novo\s+dom[ií]nio\s+dispon[ií]vel|'
        r'use\s+preferencialmente)', re.I)
    root_url_re = re.compile(r'https://[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?/?', re.I)
    for notice in notice_re.finditer(body):
        start = max(0, notice.start() - 1500)
        end = min(len(body), notice.start() + 14000)
        block = body[start:end]
        for match in root_url_re.finditer(block):
            local = block[max(0, match.start() - 450):match.start()]
            markers = {
                'green': max(local.rfind('emerald'), local.rfind('green'), local.rfind('verde')),
                'yellow': max(local.rfind('yellow'), local.rfind('amber'), local.rfind('amarelo')),
                'red': max(local.rfind('red'), local.rfind('vermelho'), local.rfind('bloquead')),
            }
            state = max(markers, key=markers.get)
            if markers[state] < 0:
                state = 'unknown'
            add_origin(match.group(0), state)

    priority = {'green': 0, 'yellow': 1, 'unknown': 2}
    rows.sort(key=lambda row: priority.get(row.get('status'), 3))
    return rows[:12]


def _domain_status(value):
    value = str(value or '').strip().lower()
    return value if value in ('green', 'yellow', 'unknown') else 'unknown'


def _sanitize_domain_rows(rows):
    out = []
    seen = set()
    for raw in rows if isinstance(rows, list) else []:
        origin = str((raw or {}).get('origin') or '').strip().rstrip('/')
        if not is_safe_public_url(origin):
            continue
        try:
            parsed = urlparse(origin)
            if (parsed.scheme or '').lower() != 'https':
                continue
            if parsed.path not in ('', '/') or parsed.query or parsed.fragment:
                continue
            host = (parsed.hostname or '').lower()
        except Exception:
            continue
        if not host or host in seen:
            continue
        out.append({'origin': 'https://%s' % host, 'status': _domain_status((raw or {}).get('status'))})
        seen.add(host)
    priority = {'green': 0, 'yellow': 1, 'unknown': 2}
    out.sort(key=lambda row: priority.get(row.get('status'), 3))
    return out[:12]


def _principal_origin(rows):
    rows = _sanitize_domain_rows(rows)
    for row in rows:
        if row.get('status') == 'green':
            return row.get('origin') or ''
    return (rows[0].get('origin') or '') if rows else ''


def _domain_set_signature(rows):
    rows = _sanitize_domain_rows(rows)
    material = '\n'.join('%s|%s' % (row.get('status'), row.get('origin')) for row in rows)
    return hashlib.sha256(material.encode('utf-8')).hexdigest()[:20] if material else ''


def _read_domain_state():
    try:
        with open(DOMAIN_STATE_FILE, 'rb') as handle:
            raw = handle.read(DOMAIN_STATE_MAX_BYTES + 1)
        if len(raw) > DOMAIN_STATE_MAX_BYTES:
            return {}
        payload = json.loads(raw.decode('utf-8'))
        entries = payload.get('entries') if isinstance(payload, dict) else None
        if not isinstance(entries, dict):
            return {}
        now = time.time()
        clean = {}
        for key, row in entries.items():
            if not re.fullmatch(r'[a-f0-9]{20}', str(key or '')) or not isinstance(row, dict):
                continue
            try:
                updated = float(row.get('updated_at') or 0)
            except Exception:
                updated = 0
            if not updated or now - updated > DOMAIN_STATE_MAX_AGE:
                continue
            principal = str(row.get('principal_origin') or '').rstrip('/')
            last_good = str(row.get('last_good_origin') or '').rstrip('/')
            if principal and not is_safe_public_url(principal):
                principal = ''
            if last_good and not is_safe_public_url(last_good):
                last_good = ''
            clean[key] = {
                'principal_origin': principal,
                'principal_failed_at': float(row.get('principal_failed_at') or 0),
                'last_good_origin': last_good,
                'last_good_at': float(row.get('last_good_at') or 0),
                'updated_at': updated,
            }
        return clean
    except Exception:
        return {}


def _write_domain_state(entries):
    try:
        xbmcvfs.mkdirs(PROFILE)
        payload = {'version': 1, 'entries': entries, 'updated_at': int(time.time())}
        write_json_atomic(DOMAIN_STATE_FILE, payload, DOMAIN_STATE_MAX_BYTES)
    except Exception as exc:
        _log('estado de domínio não pôde ser atualizado: %s' % exc, True)


def _playback_domain_rows(channel):
    # O aviso da raiz é a fonte de verdade global. Se já estiver em cache/memo,
    # usar seus domínios permite que páginas/canais antigos acompanhem uma troca
    # editorial sem alterar o addon nem regravar o catálogo do canal.
    rows = []
    try:
        root = _payload('__all__', 1, False)
        rows = _sanitize_domain_rows((root or {}).get('domains') or [])
    except Exception:
        rows = []
    if rows:
        return rows
    rows = _sanitize_domain_rows(channel.get('_option3_domain_rows') or [])
    if rows:
        return rows
    return _sanitize_domain_rows([
        {'origin': origin, 'status': 'unknown'}
        for origin in (channel.get('_option3_domains') or [])
    ])


def record_domain_result(source, success):
    """Registra somente saúde do domínio oficial usado no probe.

    Falha do principal abre uma janela curta em que o last-known-good pode ser
    tentado antes para reduzir latência. Após PRIMARY_RETRY_AFTER o principal
    volta automaticamente ao topo, mesmo que o fallback continue saudável.
    """
    if not isinstance(source, dict):
        return
    signature = str(source.get('option3_domain_set') or '')
    origin = str(source.get('option3_domain_origin') or '').rstrip('/')
    principal = str(source.get('option3_official_principal') or '').rstrip('/')
    if not re.fullmatch(r'[a-f0-9]{20}', signature) or not origin or not principal:
        return
    if not is_safe_public_url(origin) or not is_safe_public_url(principal):
        return
    entries = _read_domain_state()
    now = time.time()
    row = dict(entries.get(signature) or {})
    previous_failure = float(row.get('principal_failed_at') or 0)
    previous_good = str(row.get('last_good_origin') or '')
    row['principal_origin'] = principal
    row['updated_at'] = now
    if success:
        row['last_good_origin'] = origin
        row['last_good_at'] = now
        if origin == principal:
            row['principal_failed_at'] = 0
            if previous_failure:
                _log('domínio principal recuperado host=%s' % (urlparse(principal).hostname or principal))
        elif origin != previous_good:
            _log('fallback saudável registrado host=%s principal=%s' % (
                urlparse(origin).hostname or origin, urlparse(principal).hostname or principal))
    elif origin == principal:
        row['principal_failed_at'] = now
        if not previous_failure or now - previous_failure > 30:
            _log('domínio principal falhou; habilitando fallback temporário host=%s' % (
                urlparse(principal).hostname or principal), True)
    entries[signature] = row
    _write_domain_state(entries)


def _card_categories(value):
    parts = re.split(r'\s*(?:[•|·]|\s+-\s+)\s*', _clean_text(value, 240))
    out = []
    for part in parts:
        part = _clean_text(part, 80)
        if part and part not in out:
            out.append(part)
    return out[:8]


_TIME_LABEL_RE = re.compile(r'^(?:[01]?\d|2[0-3]):[0-5]\d$')


def _safe_timestamp(value):
    try:
        ts = float(value)
    except Exception:
        return None
    # Limites amplos, mas impedem lixo/overflow vindo do HTML remoto.
    if ts < 946684800 or ts > 4102444800:
        return None
    return ts


def _clean_time_label(value):
    value = _clean_text(value, 16)
    return value if _TIME_LABEL_RE.fullmatch(value) else ''


def _clean_native_epg(value):
    """Valida o EPG publicado pelo próprio card, sem converter fuso horário.

    Os rótulos HH:MM são editoriais e permanecem exatamente como o site os
    publicou. Os timestamps servem apenas para validar a janela do programa
    atual; não são usados para reconstruir os horários visíveis.
    """
    if not isinstance(value, dict):
        return None
    current = value.get('current')
    if not isinstance(current, dict):
        return None
    title = _clean_text(current.get('title'), 320)
    start_label = _clean_time_label(current.get('start_label'))
    end_label = _clean_time_label(current.get('end_label'))
    start_ts = _safe_timestamp(current.get('start_ts'))
    end_ts = _safe_timestamp(current.get('end_ts'))
    if not title or not start_label or start_ts is None or end_ts is None or end_ts <= start_ts:
        return None
    # Um programa de TV não deve manter um card atual por mais de um dia.
    if end_ts - start_ts > 24 * 60 * 60:
        return None
    upcoming = []
    for raw in value.get('upcoming') or []:
        if not isinstance(raw, dict):
            continue
        up_title = _clean_text(raw.get('title'), 320)
        up_label = _clean_time_label(raw.get('start_label'))
        if not up_title or not up_label:
            continue
        upcoming.append({'title': up_title, 'start_label': up_label})
        if len(upcoming) >= 6:
            break
    if not end_label and upcoming:
        end_label = upcoming[0]['start_label']
    return {
        'current': {
            'title': title,
            'start_label': start_label,
            'end_label': end_label,
            'start_ts': start_ts,
            'end_ts': end_ts,
        },
        'upcoming': upcoming,
    }


def _extract_native_epg(text, base_url):
    """Extrai o guia que o próprio catálogo publica dentro de cada card.

    O contrato comprovado contém programa atual, ``data-start-ts``/
    ``data-end-ts`` e próximos horários. Não consulta endpoint inventado,
    não executa JavaScript e não faz casamento fuzzy entre canais.
    """
    out = {}
    article_re = re.compile(
        r'<article\b(?=[^>]*\bdata-channel-card\b)[^>]*>(.*?)</article>',
        re.I | re.S,
    )
    href_re = re.compile(r'<a\b[^>]*\bhref\s*=\s*(["\'])(.*?)\1', re.I | re.S)
    strong_re = re.compile(r'<strong\b[^>]*>(.*?)</strong>', re.I | re.S)
    title_re = re.compile(
        r'<span\b[^>]*\bclass\s*=\s*(["\'])[^"\']*\btruncate\b[^"\']*\1[^>]*>'
        r'(.*?)</span>',
        re.I | re.S,
    )
    progress_re = re.compile(r'<[^>]*\bdata-guide-progress\b[^>]*>', re.I | re.S)
    start_re = re.compile(r'\bdata-start-ts\s*=\s*(["\'])(\d{9,12})\1', re.I)
    end_re = re.compile(r'\bdata-end-ts\s*=\s*(["\'])(\d{9,12})\1', re.I)

    for match in article_re.finditer(text or ''):
        article = match.group(1)
        href_match = href_re.search(article)
        if not href_match:
            continue
        href = urljoin(base_url, html.unescape(href_match.group(2)).strip())
        if not is_safe_public_url(href):
            continue
        try:
            parts = [part for part in (urlparse(href).path or '').split('/') if part]
            slug = parts[-1].lower() if len(parts) == 1 else ''
        except Exception:
            slug = ''
        if not slug or not re.fullmatch(r'[a-z0-9_-]{1,96}', slug):
            continue

        times = [_clean_time_label(_clean_text(value, 16))
                 for value in strong_re.findall(article)]
        titles = [_clean_text(value[1], 320) for value in title_re.findall(article)]
        rows = [(when, title) for when, title in zip(times, titles) if when and title]
        progress_match = progress_re.search(article)
        if not rows or not progress_match:
            continue
        progress_tag = progress_match.group(0)
        start_match = start_re.search(progress_tag)
        end_match = end_re.search(progress_tag)
        if not start_match or not end_match:
            continue
        start_ts = _safe_timestamp(start_match.group(2))
        end_ts = _safe_timestamp(end_match.group(2))
        if start_ts is None or end_ts is None or end_ts <= start_ts:
            continue

        upcoming = [
            {'title': title, 'start_label': when}
            for when, title in rows[1:7]
        ]
        payload = _clean_native_epg({
            'current': {
                'title': rows[0][1],
                'start_label': rows[0][0],
                'end_label': upcoming[0]['start_label'] if upcoming else '',
                'start_ts': start_ts,
                'end_ts': end_ts,
            },
            'upcoming': upcoming,
        })
        if payload is not None:
            out[slug] = payload
    return out


def native_epg_info(channel, now_ts=None, upcoming_count=4):
    """Converte o guia nativo da Opção 3 para o contrato usado pela UI.

    A fonte primária é sempre o próprio card do site. Se o card não publicar
    programação, ou se a janela do programa atual já tiver expirado, ``has_epg``
    fica falso e a camada integrada recorre ao EPG homologado existente.
    """
    data = _clean_native_epg((channel or {}).get('_option3_epg'))
    empty = {
        'plot': 'Programação não disponível no EPG.',
        'current_title': '', 'next_title': '', 'upcoming_titles': [],
        'next_change_ts': None, 'has_epg': False, 'source': 'option3-site',
    }
    if data is None:
        return empty
    now = float(time.time() if now_ts is None else now_ts)
    current = data['current']
    # O timestamp valida somente se o card ainda representa o "AGORA".
    # Fora da janela conhecida, não promovemos próximos programas por cálculo
    # local: uma nova leitura/fallback é mais segura que inventar fuso/horário.
    if not (current['start_ts'] <= now < current['end_ts']):
        return empty

    try:
        count = max(1, min(6, int(upcoming_count)))
    except Exception:
        count = 4
    upcoming = (data.get('upcoming') or [])[:count]

    period = current.get('start_label') or ''
    end_label = current.get('end_label') or ''
    if period and end_label:
        period += '–' + end_label
    lines = [('AGORA • %s' % period) if period else 'AGORA', current['title']]
    if upcoming:
        lines.extend(['', 'PRÓXIMOS'])
        for event in upcoming:
            when = event.get('start_label') or ''
            lines.append(('%s • %s' % (when, event['title'])) if when else event['title'])

    return {
        'plot': '\n'.join(lines),
        'current_title': current.get('title', ''),
        'next_title': upcoming[0].get('title', '') if upcoming else '',
        'upcoming_titles': [event.get('title', '') for event in upcoming],
        'next_change_ts': current.get('end_ts'),
        'has_epg': True,
        'source': 'option3-site',
    }

def _normalize_cards(cards, domains, genre, page, native_epg=None):
    domain_rows = _sanitize_domain_rows(domains)
    allowed_hosts = set()
    ordered_origins = []
    for row in domain_rows:
        origin = str((row or {}).get('origin') or '').strip()
        try:
            host = (urlparse(origin).hostname or '').lower()
        except Exception:
            host = ''
        if host:
            allowed_hosts.add(host)
            if origin not in ordered_origins:
                ordered_origins.append(origin)
    principal_origin = _principal_origin(domain_rows)

    out = []
    seen = set()
    route_label = _pretty_genre(genre) if genre != '__all__' else ''
    for raw in cards if isinstance(cards, list) else []:
        if not isinstance(raw, dict):
            continue
        href = str(raw.get('href') or '').strip()
        try:
            parsed = urlparse(href)
            host = (parsed.hostname or '').lower()
            path_parts = [part for part in (parsed.path or '').split('/') if part]
            slug = path_parts[-1].lower() if len(path_parts) == 1 else ''
        except Exception:
            continue
        if (not is_safe_public_url(href) or not slug or
                not re.fullmatch(r'[a-z0-9_-]{1,96}', slug)):
            continue
        if allowed_hosts and host not in allowed_hosts:
            continue
        if slug in seen:
            continue
        name = _clean_text(raw.get('name') or slug, 160)
        if not name:
            continue
        categories = _card_categories(raw.get('category_text'))
        if genre == 'adulto':
            categories = ['Adulto']
        elif route_label and route_label not in categories:
            categories.insert(0, route_label)
        if not categories:
            categories = ['Outros']
        image = str(raw.get('image') or '').strip()
        if image and not is_safe_public_url(image):
            image = ''
        contract_values = [href] + ordered_origins
        signature = hashlib.sha256('\n'.join(contract_values).encode('utf-8')).hexdigest()[:24]
        native_guide = _clean_native_epg((native_epg or {}).get(slug))
        row = {
            'id': slug,
            'epg_id': epg_id_for(slug),
            'name': name,
            'categories': categories,
            'category': categories[0],
            'description': '',
            'image': image,
            'preview': '',
            'api_url': href,
            'source_page': href,
            'stream_url': '',
            'headers': {},
            '_oneplay_source': 'option3',
            '_option3_domains': list(ordered_origins),
            '_option3_domain_rows': [dict(item) for item in domain_rows],
            '_option3_principal_origin': principal_origin,
            '_option3_genre': genre,
            '_option3_page': page,
            '_contract_signature': signature,
        }
        if native_guide is not None:
            row['_option3_epg'] = native_guide
        out.append(row)
        seen.add(slug)
    if len(out) > 80:
        raise ValueError('quantidade de canais da página fora do esperado: %d' % len(out))
    return out


def _parse_page(text, request_url, genre='__all__', page=1, fallback_meta=None):
    if not isinstance(text, str) or not text:
        raise ValueError('HTML vazio')
    parser = _CatalogHTMLParser(request_url)
    parser.feed(text)
    fallback_meta = fallback_meta if isinstance(fallback_meta, dict) else {}
    domains = _published_domains(text) or list(fallback_meta.get('domains') or [])
    if not domains:
        raise ValueError('aviso de domínios ativos ausente')
    native_epg = _extract_native_epg(text, request_url)
    channels = _normalize_cards(parser.cards, domains, genre, page, native_epg)
    if not channels:
        raise ValueError('nenhum canal válido na página')
    total_match = re.search(r'([0-9]{1,5})\s+canais\s+dispon[ií]veis', text, re.I)
    total = int(total_match.group(1)) if total_match else 0
    categories = parser.categories or list(fallback_meta.get('categories') or [])
    if not categories:
        raise ValueError('categorias dinâmicas ausentes')
    return {
        'channels': channels,
        'categories': categories[:80],
        'domains': domains,
        'genre': genre,
        'page': page,
        'max_page': max(page, parser.max_page),
        'total': total,
        'fetched_at': int(time.time()),
    }


def _page_url(genre='__all__', page=1):
    query = {}
    if genre and genre != '__all__':
        query['genre'] = genre
    if page > 1:
        query['page'] = str(page)
    return CATALOG_URL + (('?' + urlencode(query)) if query else '')


def _cache_file(genre, page):
    key = ('%s|%d' % (genre, page)).encode('utf-8')
    suffix = hashlib.sha256(key).hexdigest()[:20]
    return os.path.join(PROFILE, 'oneplay_live_option3_%s.json' % suffix)


def _valid_payload(payload, genre, page):
    if not isinstance(payload, dict):
        return None
    if _genre_key(payload.get('genre')) != genre or _safe_page(payload.get('page')) != page:
        return None
    channels = payload.get('channels')
    categories = payload.get('categories')
    domains = payload.get('domains')
    if not isinstance(channels, list) or not channels or len(channels) > 80:
        return None
    if not isinstance(categories, list) or not categories or len(categories) > 80:
        return None
    if not isinstance(domains, list) or not domains or len(domains) > 12:
        return None
    clean_domain_rows = _sanitize_domain_rows(domains)
    if len(clean_domain_rows) != len(domains):
        return None
    clean_origins = [row.get('origin') for row in clean_domain_rows]
    principal_origin = _principal_origin(clean_domain_rows)
    allowed = set((urlparse(origin).hostname or '').lower() for origin in clean_origins)
    checked = []
    for channel in channels:
        if not isinstance(channel, dict):
            return None
        cid = str(channel.get('id') or '').strip().lower()
        href = str(channel.get('api_url') or '').strip()
        if not re.fullmatch(r'[a-z0-9_-]{1,96}', cid) or not is_safe_public_url(href):
            return None
        if (urlparse(href).hostname or '').lower() not in allowed:
            return None
        clean_channel = dict(channel)
        clean_channel['_option3_domains'] = list(clean_origins)
        clean_channel['_option3_domain_rows'] = [dict(item) for item in clean_domain_rows]
        clean_channel['_option3_principal_origin'] = principal_origin
        native_guide = _clean_native_epg(clean_channel.get('_option3_epg'))
        if native_guide is not None:
            clean_channel['_option3_epg'] = native_guide
        else:
            clean_channel.pop('_option3_epg', None)
        checked.append(clean_channel)
    copy = dict(payload)
    copy['channels'] = checked
    copy['domains'] = [dict(item) for item in clean_domain_rows]
    copy['max_page'] = max(page, min(MAX_PAGE, int(payload.get('max_page') or page)))
    return copy


def _read_cache(genre, page, fresh_only=False):
    path = _cache_file(genre, page)
    try:
        if fresh_only and time.time() - os.path.getmtime(path) > CACHE_TTL:
            return None
        with open(path, 'rb') as handle:
            raw = handle.read(MAX_CACHE_BYTES + 1)
        if len(raw) > MAX_CACHE_BYTES:
            return None
        return _valid_payload(json.loads(raw.decode('utf-8')), genre, page)
    except Exception:
        return None


def _write_cache(genre, page, payload):
    try:
        xbmcvfs.mkdirs(PROFILE)
        write_json_atomic(_cache_file(genre, page), payload, MAX_CACHE_BYTES)
    except Exception as exc:
        _log('cache não pôde ser atualizado: %s' % exc, True)


def _fetch_page(genre='__all__', page=1, force_root_meta=False):
    genre = _genre_key(genre)
    page = _safe_page(page)
    url = _page_url(genre, page)
    headers = page_headers(page_url=url, parent_url=CATALOG_URL)
    headers['User-Agent'] = BROWSER_UA
    headers['Referer'] = CATALOG_URL
    if genre != '__all__' or page > 1:
        headers['X-Requested-With'] = 'XMLHttpRequest'
        headers['Sec-Fetch-Dest'] = 'empty'
        headers['Sec-Fetch-Mode'] = 'cors'
        headers['Sec-Fetch-Site'] = 'same-origin'
    else:
        headers['Sec-Fetch-Dest'] = 'document'
        headers['Sec-Fetch-Site'] = 'none'
    fallback_meta = None
    if genre != '__all__' or page > 1:
        # O HTML AJAX omite o modal de domínios. Ele é sempre herdado da raiz
        # pública atual, nunca de uma lista fixa empacotada.
        if force_root_meta:
            fallback_meta = _fetch_page('__all__', 1, False)
            _write_cache('__all__', 1, fallback_meta)
            _MEMO[('__all__', 1)] = {
                'payload': fallback_meta,
                'deadline': time.monotonic() + CACHE_TTL,
            }
        else:
            fallback_meta = _payload('__all__', 1, False)
    request = Request(url, headers=headers, method='GET')
    with cloudflare_urlopen(request, timeout=10, allow_native_fallback=True) as response:
        raw = response.read(MAX_HTML_BYTES + 1)
    if len(raw) > MAX_HTML_BYTES:
        raise ValueError('HTML excedeu limite')
    return _parse_page(raw.decode('utf-8', 'ignore'), url, genre, page, fallback_meta)


def _payload(genre='__all__', page=1, force=False):
    genre = _genre_key(genre)
    page = _safe_page(page)
    key = (genre, page)
    now = time.monotonic()
    memo = _MEMO.get(key)
    if not force and memo and now < memo.get('deadline', 0):
        return memo.get('payload')
    if not force:
        fresh = _read_cache(genre, page, True)
        if fresh is not None:
            _MEMO[key] = {'payload': fresh, 'deadline': now + CACHE_TTL}
            return fresh
    try:
        live = _fetch_page(genre, page)
        _write_cache(genre, page, live)
        _MEMO[key] = {'payload': live, 'deadline': now + CACHE_TTL}
        domain_hosts = []
        for _row in live.get('domains') or []:
            try:
                _host = (urlparse(str((_row or {}).get('origin') or '')).hostname or '').lower()
            except Exception:
                _host = ''
            if _host and _host not in domain_hosts:
                domain_hosts.append(_host)
        principal = _principal_origin(live.get('domains') or [])
        _log('catálogo atualizado genero=%s pagina=%d canais=%d dominios=%d principal=%s ativos=%s' % (
            genre, page, len(live.get('channels') or []), len(live.get('domains') or []),
            (urlparse(principal).hostname or '-') if principal else '-',
            ','.join(domain_hosts) or '-'))
        return live
    except Exception as exc:
        _log('catálogo online indisponível genero=%s pagina=%d: %s' % (
            genre, page, exc), True)
    stale = _read_cache(genre, page, False)
    if stale is not None:
        _MEMO[key] = {'payload': stale, 'deadline': now + 60}
        _log('usando cache anterior genero=%s pagina=%d canais=%d' % (
            genre, page, len(stale.get('channels') or [])), True)
        return stale
    empty = {'channels': [], 'categories': [], 'domains': [], 'genre': genre,
             'page': page, 'max_page': page, 'total': 0, 'fetched_at': 0}
    _MEMO[key] = {'payload': empty, 'deadline': now + 20}
    return empty


def sources_for(channel):
    """Principal editorial dinâmico + fallback lazy + last-known-good curto.

    O site define a preferência; o addon nunca codifica nome de domínio. O
    principal oficial é tentado primeiro. Se ele acabou de falhar e um fallback
    já provou HLS real, esse last-known-good pode liderar por alguns minutos;
    após PRIMARY_RETRY_AFTER o principal volta automaticamente ao topo para
    comprovar recuperação. Fallbacks só são lidos se a fonte anterior falhar.
    """
    if not isinstance(channel, dict):
        return []
    published = str(channel.get('api_url') or channel.get('source_page') or '').strip()
    if not is_safe_public_url(published):
        return []
    parsed = urlparse(published)
    path = parsed.path or '/'
    query = ('?' + parsed.query) if parsed.query else ''

    rows = _playback_domain_rows(channel)
    principal = _principal_origin(rows)
    signature = _domain_set_signature(rows)
    origins = [row.get('origin') for row in rows if row.get('origin')]

    entries = _read_domain_state() if signature else {}
    state = entries.get(signature) or {}
    now = time.time()
    last_good = str(state.get('last_good_origin') or '').rstrip('/')
    try:
        last_good_at = float(state.get('last_good_at') or 0)
        principal_failed_at = float(state.get('principal_failed_at') or 0)
    except Exception:
        last_good_at = 0
        principal_failed_at = 0

    # Em estado normal, o verde/oficial sempre lidera. Só usamos last-good
    # antes dele quando a falha do principal é recente e o fallback também foi
    # comprovado recentemente. A preferência oficial volta sozinha em 5 min.
    use_last_good_first = bool(
        principal and last_good and last_good != principal and last_good in origins and
        principal_failed_at and (now - principal_failed_at) < PRIMARY_RETRY_AFTER and
        last_good_at and (now - last_good_at) < LAST_GOOD_TTL
    )
    ordered_origins = []
    if use_last_good_first:
        ordered_origins.append(last_good)
    if principal and principal not in ordered_origins:
        ordered_origins.append(principal)
    for origin in origins:
        if origin not in ordered_origins:
            ordered_origins.append(origin)

    # Se o card publicar um host novo antes do aviso global refletir a mudança,
    # ele continua elegível como último fallback editorial, nunca acima do verde.
    try:
        published_origin = '%s://%s' % ((parsed.scheme or 'https').lower(), parsed.netloc)
    except Exception:
        published_origin = ''
    if published_origin and is_safe_public_url(published_origin) and published_origin not in ordered_origins:
        ordered_origins.append(published_origin.rstrip('/'))

    principal_host = (urlparse(principal).hostname or principal) if principal else '-'
    order_hosts = []
    for origin in ordered_origins:
        try:
            order_hosts.append(urlparse(origin).hostname or origin)
        except Exception:
            order_hosts.append(origin)
    mode = 'last-good-temporario' if use_last_good_first else 'principal-oficial'
    _log('ordem playback id=%s modo=%s principal=%s ordem=%s' % (
        channel.get('id'), mode, principal_host, ','.join(order_hosts) or '-'))

    out = []
    fallback_no = 0
    for index, origin in enumerate(ordered_origins[:12], 1):
        target = origin.rstrip('/') + path + query
        if not is_safe_public_url(target):
            continue
        if origin == principal:
            role = 'principal'
        elif use_last_good_first and origin == last_good:
            role = 'last-good'
        else:
            fallback_no += 1
            role = 'fallback-%d' % fallback_no
        nav = page_headers(page_url=target, parent_url=CATALOG_URL)
        nav['Referer'] = CATALOG_URL
        out.append({
            'name': 'opcao3-%s' % role,
            'url': target,
            'playlist_headers': nav,
            'resource_headers': media_headers(page_url=target),
            'allow_html_resolve': True,
            'allow_native_dns_fallback': True,
            'source_kind': 'derived-page',
            'option3_domain_role': role,
            'option3_domain_origin': origin,
            'option3_official_principal': principal,
            'option3_domain_set': signature,
            # /canal -> /__play/canal -> player rotativo -> HLS publicado.
            'max_html_depth': 2,
            # O player final publicado pela cadeia /canal -> /__play pode
            # levar ~11 s para concluir o documento mesmo quando está saudável.
            'html_probe_timeout': 16,
            'progressive_html_read': True,
            'allow_partial_html_on_timeout': True,
            'preserve_navigation_referer': True,
            # V3D: adapta o bootstrap HTTP assinado publicado pelo próprio
            # player. Só GETs declarativos e scripts first-party são sondados;
            # nenhum token é fabricado/persistido e JavaScript remoto não é
            # executado.
            'enable_signed_bootstrap': True,
            'bootstrap_max_requests': 4,
            # Consenso existe apenas neste clique/recovery e nunca persiste
            # token/CDN/manifesto; o estado persistente acima guarda só saúde
            # do domínio raiz oficial.
            'dynamic_failure_consensus': 2,
        })
    return out


class Catalog(object):
    def __init__(self, genre='__all__', page=1):
        self.genre = _genre_key(genre)
        self.page = _safe_page(page)
        self._data = _payload(self.genre, self.page, False) or {}

    def channels(self):
        return list(self._data.get('channels') or [])

    def categories(self):
        return [dict(row) for row in self._data.get('categories') or [] if isinstance(row, dict)]

    def category_description(self, category):
        return 'Acessar os canais disponíveis.'

    def max_page(self):
        return max(self.page, _safe_page(self._data.get('max_page') or self.page))

    def has_next(self):
        return self.page < self.max_page()

    def get(self, channel_id):
        wanted = str(channel_id or '').strip().lower()
        for channel in self.channels():
            if str(channel.get('id') or '').strip().lower() == wanted:
                return channel
        return None

    def refresh_get(self, channel_id):
        key = (self.genre, self.page)
        try:
            live = _fetch_page(self.genre, self.page, True)
            _write_cache(self.genre, self.page, live)
            _MEMO[key] = {'payload': live, 'deadline': time.monotonic() + CACHE_TTL}
            self._data = live
            wanted = str(channel_id or '').strip().lower()
            for channel in live.get('channels') or []:
                if str(channel.get('id') or '').strip().lower() == wanted:
                    return channel
        except Exception as exc:
            _log('refresh live falhou id=%s: %s' % (channel_id, exc), True)
        return None
