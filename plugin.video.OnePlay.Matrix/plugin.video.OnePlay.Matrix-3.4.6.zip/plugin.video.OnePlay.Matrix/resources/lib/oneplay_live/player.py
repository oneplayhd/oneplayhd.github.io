# -*- coding: utf-8 -*-
from urllib.error import HTTPError
from urllib.parse import unquote, urljoin, urlparse
from urllib.request import Request
import re
import html
import os
import json
import threading
import ipaddress
import socket
import time
import uuid
import xbmcvfs
import xbmc
import xbmcaddon
import xbmcgui
from .catalog import Catalog
from .artwork import artwork_for
from .presentation import public_text as _public_text
from .proxy import HlsProxy, cloudflare_urlopen
from .source_contract import api_source, media_headers, page_headers, is_safe_public_url

ALLOWED_SCHEMES = {'http', 'https'}
PROBE_TIMEOUT = 8
MEDIA_PROBE_TIMEOUT = 7
MAX_MANIFEST_BYTES = 256 * 1024
MEDIA_PROBE_BYTES = 4096
MAX_PLAYLIST_DEPTH = 3
STARTUP_TIMEOUT = 20
PLAYBACK_POLL = 0.25
END_GRACE = 1.5
# Android pode retirar isPlaying() antes de entregar onPlayBackStopped ao Python.
# Esta janela adicional evita classificar um STOP real como live_lost.
LIVE_LOST_CONFIRM_GRACE = 2.0
LIVE_RECOVERY_MAX = 2
LIVE_RECOVERY_BACKOFF = (2.0, 4.0)
# Se uma reprodução recuperada permanecer saudável por esta janela, a queda
# seguinte é tratada como um novo incidente e o orçamento 1/2 -> 2/2 é rearmado.
# Evita esgotar para sempre uma sessão longa sem transformar falhas rápidas em loop.
LIVE_RECOVERY_REARM_STABLE = 180.0
URI_ATTR_RE = re.compile(r'URI=("|\')([^"\']+)(\1)')


def _log(message, level=xbmc.LOGINFO):
    xbmc.log('[ONEPLAY LIVE] %s' % message, level)


def _prepare_dialog_state():
    try:
        import builtins
        state=getattr(builtins,'_oneplay_live_early_wait',None)
        if isinstance(state,tuple):
            return state
        if state is not None:
            return (state,0.0)
    except Exception:
        pass
    return (None,0.0)


def _startup_lock_state():
    try:
        import builtins
        state=getattr(builtins,'_oneplay_live_startup_lock',None)
        if isinstance(state,tuple) and len(state)>=2:
            return state[0],state[1]
    except Exception:
        pass
    return None,None


def _play_session_register(channel_id):
    """Registra a invocação manual mais recente do OnePlay Live.

    O arquivo é compartilhado entre invocadores Python do Kodi. Assim, uma
    nova seleção de canal invalida recuperações antigas que ainda estejam em
    backoff/refresh/resolução, sem interferir em STOP ou startup normal.
    """
    try:
        profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        if profile and not os.path.isdir(profile):
            try:
                os.makedirs(profile, exist_ok=True)
            except Exception:
                pass
        path = os.path.join(profile, 'oneplay_live_session.json')
        _lock_path, startup_token = _startup_lock_state()
        token = str(startup_token or uuid.uuid4().hex)
        payload = {
            'token': token,
            'channel_id': str(channel_id or ''),
            'created': time.time(),
        }
        tmp = path + '.tmp-' + token[:12]
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(payload, fh, ensure_ascii=False, separators=(',', ':'))
        os.replace(tmp, path)
        _log('sessao ativa registrada id=%s token=%s' % (channel_id, token[:8]), xbmc.LOGDEBUG)
        return (path, token, str(channel_id or ''))
    except Exception as exc:
        _log('registro de sessao ativa indisponivel: %s' % exc, xbmc.LOGWARNING)
        return None


def _play_session_is_current(session_state):
    if not session_state:
        return True
    try:
        path, token = session_state[0], session_state[1]
        if not path or not os.path.exists(path):
            return False
        with open(path, 'r', encoding='utf-8') as fh:
            current = json.load(fh)
        return str(current.get('token') or '') == str(token)
    except Exception:
        # Falha transitória de leitura não deve derrubar uma sessão válida.
        return True


def _play_session_cancelled(session_state, channel_id, stage=''):
    if _play_session_is_current(session_state):
        return False
    _log('sessao substituida por nova selecao id=%s etapa=%s; recovery antigo cancelado' % (
        channel_id, stage or 'verificacao'), xbmc.LOGWARNING)
    return True


def _play_session_clear(session_state):
    if not session_state:
        return
    try:
        path, token = session_state[0], session_state[1]
        if not path or not os.path.exists(path):
            return
        current = {}
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                current = json.load(fh)
        except Exception:
            current = {}
        if str(current.get('token') or '') == str(token):
            os.remove(path)
            _log('sessao ativa liberada token=%s' % str(token)[:8], xbmc.LOGDEBUG)
    except Exception as exc:
        _log('falha ao liberar sessao ativa: %s' % exc, xbmc.LOGDEBUG)


def _startup_lock_update_name(channel_name):
    path,token=_startup_lock_state()
    if not path or not token:
        return
    try:
        current={}
        if os.path.exists(path):
            with open(path,'r',encoding='utf-8') as fh:
                current=json.load(fh)
        if str(current.get('token') or '') != str(token):
            return
        current['name']=_public_text(channel_name or current.get('name') or current.get('channel_id') or 'Canal') or 'Canal'
        current['updated']=time.time()
        tmp=path+'.tmp-'+str(token)[:12]
        with open(tmp,'w',encoding='utf-8') as fh:
            json.dump(current,fh,ensure_ascii=False,separators=(',',':'))
        os.replace(tmp,path)
    except Exception as exc:
        try: _log('lock startup não pôde atualizar nome: %s' % exc, xbmc.LOGDEBUG)
        except Exception: pass


def _startup_lock_release(reason=''):
    path,token=_startup_lock_state()
    if not path or not token:
        return
    removed=False
    try:
        current={}
        if os.path.exists(path):
            try:
                with open(path,'r',encoding='utf-8') as fh:
                    current=json.load(fh)
            except Exception:
                current={}
            if str(current.get('token') or '') == str(token):
                try:
                    os.remove(path); removed=True
                except FileNotFoundError:
                    removed=True
        else:
            removed=True
    except Exception as exc:
        try: _log('lock startup falha ao liberar: %s' % exc, xbmc.LOGWARNING)
        except Exception: pass
    try:
        import builtins
        state=getattr(builtins,'_oneplay_live_startup_lock',None)
        if isinstance(state,tuple) and len(state)>=2 and str(state[1])==str(token):
            delattr(builtins,'_oneplay_live_startup_lock')
    except Exception:
        pass
    if removed:
        try: _log('lock startup liberado motivo=%s' % (reason or 'concluido'), xbmc.LOGDEBUG)
        except Exception: pass


def _prepare_dialog_update(channel_name='', ready=False):
    dlg,_started=_prepare_dialog_state()
    if dlg is None:
        return
    name=_public_text(channel_name)
    if not name:
        return
    message=('Transmissão pronta: %s' if ready else 'Preparando transmissão: %s') % name
    try:
        dlg.update(0,'AGUARDE...',message)
        _log('AGUARDE atualizado: %s' % message, xbmc.LOGDEBUG)
    except Exception:
        pass


def _prepare_dialog_close(reason=''):
    dlg,_started=_prepare_dialog_state()
    if dlg is not None:
        try:
            dlg.close()
        except Exception:
            pass
    try:
        import builtins
        if hasattr(builtins,'_oneplay_live_early_wait'):
            delattr(builtins,'_oneplay_live_early_wait')
    except Exception:
        pass
    _startup_lock_release(reason)
    try:
        _log('AGUARDE encerrado motivo=%s' % (reason or 'concluido'), xbmc.LOGDEBUG)
    except Exception:
        pass


def _clean_headers(headers):
    if not isinstance(headers, dict):
        return {}
    return {str(k): str(v) for k, v in headers.items() if k and v is not None}


def _candidate_sources(ch):
    """Raiz de playback isolada por catálogo, sem misturar provedores."""
    if str(ch.get('_oneplay_source') or '') == 'option1':
        try:
            from .option1 import source_for
            source = source_for(ch)
            return [source] if source else []
        except Exception as exc:
            _log('OPCAO1 contrato inválido id=%s tipo=%s msg=%s' % (
                ch.get('id'), exc.__class__.__name__, exc), xbmc.LOGWARNING)
            return []
    if str(ch.get('_oneplay_source') or '') == 'option3':
        try:
            from .option3 import sources_for
            return list(sources_for(ch) or [])
        except Exception as exc:
            _log('OPCAO3 contrato inválido id=%s tipo=%s msg=%s' % (
                ch.get('id'), exc.__class__.__name__, exc), xbmc.LOGWARNING)
            return []
    if str(ch.get('_oneplay_source') or '') == 'option4':
        try:
            from .option4 import source_for
            source = source_for(ch)
            return [source] if source else []
        except Exception as exc:
            _log('OPCAO4 contrato inválido id=%s tipo=%s msg=%s' % (
                ch.get('id'), exc.__class__.__name__, exc), xbmc.LOGWARNING)
            return []
    # Opção 2: contrato homologado anterior, inalterado.
    api=api_source(ch.get('api_url'), ch.get('headers') or {})
    return [api] if api else []

def _is_ts(data):
    if not data:
        return False
    limit = min(188, len(data))
    for offset in range(limit):
        if data[offset] != 0x47:
            continue
        if offset + 188 < len(data) and data[offset + 188] == 0x47:
            return True
    return False


def _is_media_bytes(data, content_type=''):
    if not data:
        return False
    ct = (content_type or '').split(';', 1)[0].strip().lower()
    # Assinatura real prevalece sobre Content-Type: alguns upstreams respondem
    # com MIME de vídeo mesmo quando entregam placeholder PNG/JPEG/GIF.
    image_signatures = (b'\x89PNG\r\n\x1a\n', b'\xff\xd8\xff', b'GIF87a', b'GIF89a')
    # Rejeita imagem tanto no inicio quanto encapsulada nos primeiros bytes.
    # Alguns falsos HLS usam segmento .ts/MIME video mas carregam PNG como
    # stream elementar; o log real da 0.0.10 mostrou exatamente esse caso.
    if any(data.startswith(sig) or sig in data[:MEDIA_PROBE_BYTES] for sig in image_signatures):
        return False
    sample = data[:256].lstrip().lower()
    if sample.startswith((b'<!doctype html', b'<html', b'<?xml', b'{"', b'[{')):
        return False
    if _is_ts(data):
        return True
    if len(data) >= 8 and (data[4:8] == b'ftyp' or b'moof' in data[:96] or b'styp' in data[:32]):
        return True
    if data[:3] == b'ID3':
        return True
    if len(data) >= 2 and data[0] == 0xFF and (data[1] & 0xF0) == 0xF0:
        return True
    if ct.startswith('image/') or ct in ('video/png',):
        return False
    if ct.startswith('video/') or ct.startswith('audio/'):
        return True
    return False


def _first_uri(text):
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        return line
    return ''


def _fetch_probe(url, headers, limit, timeout, allow_native_dns_fallback=True):
    request_headers = dict(headers or {})
    if limit and not any(str(k).lower() == 'range' for k in request_headers):
        request_headers['Range'] = 'bytes=0-%d' % (limit - 1)
    request = Request(url, headers=request_headers, method='GET')
    response = cloudflare_urlopen(request, timeout=timeout, allow_native_fallback=allow_native_dns_fallback)
    data = response.read(limit + 1 if limit else -1)
    return response, data


def _validate_hls_media(playlist_url, text, resource_headers, depth=0):
    """Valida a primeira mídia e identifica live sem iniciar o player."""
    if depth >= MAX_PLAYLIST_DEPTH:
        return False, None
    target = _first_uri(text)
    if not target:
        return False, None
    target_url = urljoin(playlist_url, target)
    try:
        response, data = _fetch_probe(target_url, resource_headers, MEDIA_PROBE_BYTES, MEDIA_PROBE_TIMEOUT, allow_native_dns_fallback=True)
        final_url = getattr(response, 'url', target_url) or target_url
        ctype = response.headers.get('Content-Type', '') if getattr(response, 'headers', None) else ''
        sample = data[:MEDIA_PROBE_BYTES]
        sample_text = sample.decode('utf-8', 'ignore')
        if '#EXTM3U' in sample_text:
            nested_live = '#EXT-X-ENDLIST' not in sample_text
            ok, leaf_live = _validate_hls_media(final_url, sample_text, resource_headers, depth + 1)
            if ok:
                return True, bool(nested_live if leaf_live is None else leaf_live)
            return False, None
        ok = _is_media_bytes(sample, ctype)
        if not ok:
            sig = sample[:12].hex()
            _log('preflight rejeitou mídia host=%s tipo=%s assinatura=%s' % (
                urlparse(final_url).netloc, (ctype or '?').split(';', 1)[0], sig), xbmc.LOGWARNING)
            return False, None
        return True, None
    except HTTPError as exc:
        _log('preflight HTTP status=%s host=%s' % (
            getattr(exc, 'code', '?'), urlparse(target_url).netloc), xbmc.LOGWARNING)
        return False, None
    except Exception as exc:
        _log('preflight erro host=%s tipo=%s msg=%s' % (
            urlparse(target_url).netloc, exc.__class__.__name__, exc), xbmc.LOGWARNING)
        return False, None


def _decode_ascii_js_escapes(value):
    """Decodifica apenas escapes ASCII usados para esconder URLs em JS/JSON."""
    def repl_u(match):
        try:
            code = int(match.group(1), 16)
            return chr(code) if 0x20 <= code <= 0x7e else match.group(0)
        except Exception:
            return match.group(0)

    def repl_x(match):
        try:
            code = int(match.group(1), 16)
            return chr(code) if 0x20 <= code <= 0x7e else match.group(0)
        except Exception:
            return match.group(0)

    value = re.sub(r'\\u([0-9a-fA-F]{4})', repl_u, value or '')
    value = re.sub(r'\\x([0-9a-fA-F]{2})', repl_x, value)
    return value


def _normalized_html(text):
    if not text:
        return ''
    cleaned = html.unescape(text)
    cleaned = (cleaned.replace('\\/', '/')
                       .replace('\\u002F', '/').replace('\\u002f', '/')
                       .replace('\\u003A', ':').replace('\\u003a', ':')
                       .replace('\\x2F', '/').replace('\\x2f', '/')
                       .replace('\\x3A', ':').replace('\\x3a', ':'))
    return _decode_ascii_js_escapes(cleaned)



def _deobfuscate_rotating_string_tables(text):
    '''Expande tabelas de strings no padrão ``_0x`` sem executar JavaScript.

    Suporta somente o contrato observado no player: um array literal de
    strings, um decoder por índice com deslocamento constante e aliases diretos
    do decoder. A rotação é escolhida por coerência lexical do próprio código;
    nenhum IIFE, ``eval`` ou função remota é executado.
    '''
    if not text or len(text) > MAX_MANIFEST_BYTES:
        return []

    string_re = re.compile(r'''(["'])(?:\\.|(?!\1).)*\1''', re.S)
    array_re = re.compile(
        r'\bvar\s+([A-Za-z_$][\w$]*)\s*=\s*\[((?:.|\n){32,65536}?)\]\s*;',
        re.S)
    decoder_re = re.compile(
        r'\b([A-Za-z_$][\w$]*)\s*=\s*function\s*\(\s*([A-Za-z_$][\w$]*)[^)]*\)\s*\{\s*'
        r'\2\s*=\s*\2\s*-\s*(0x[0-9a-fA-F]+|\d+)', re.S)

    arrays = []
    for am in array_re.finditer(text):
        body = am.group(2)
        values = []
        for sm in string_re.finditer(body):
            raw = sm.group(0)[1:-1]
            raw = (_decode_ascii_js_escapes(raw)
                   .replace('\\\\/', '/')
                   .replace('\\\\"', '"')
                   .replace("\\\\'", "'")
                   .replace('\\\\\\\\', '\\\\'))
            values.append(html.unescape(raw))
        if 8 <= len(values) <= 256:
            arrays.append(values)
        if len(arrays) >= 6:
            break
    if not arrays:
        return []

    common = set(('body addEventListener removeEventListener function object domain data '
                  'parentNode init click removeChild toString type referrer onerror '
                  'toLowerCase onclick setAttribute indexOf href onload namedItem '
                  'location div createElement plugins hasAttribute appendChild open '
                  '_blank innerHeight innerWidth sandbox src source stream hls manifest '
                  'playlist token loadSource setSource setSrc setUrl playStream').split())
    media_markers = ('__index', '.m3u8', '#extm3u', 'loadsource', 'manifest',
                     'playlist', 'hls', 'token=', '/live/', '/stream')
    results = []

    for dm in decoder_re.finditer(text):
        decoder = dm.group(1)
        try:
            offset = int(dm.group(3), 0)
        except Exception:
            continue
        names = {decoder}
        alias_re = re.compile(r'\b(?:var|let|const)\s+([A-Za-z_$][\w$]*)\s*=\s*' +
                              re.escape(decoder) + r'\s*[;,]')
        for alias in alias_re.finditer(text):
            names.add(alias.group(1))
        call_re = re.compile(
            r'\b(?:' + '|'.join(re.escape(x) for x in sorted(names, key=len, reverse=True)) +
            r')\s*\(\s*(0x[0-9a-fA-F]+|\d+)(?:\s*,[^)]*)?\)')
        calls = []
        for cm in call_re.finditer(text):
            try:
                calls.append(int(cm.group(1), 0))
            except Exception:
                pass
            if len(calls) >= 512:
                break
        if len(calls) < 4:
            continue

        best = None
        second_score = -1
        for values in arrays:
            positions = [idx - offset for idx in calls]
            if min(positions) < 0 or max(positions) >= len(values):
                continue
            for rotation in range(len(values)):
                rotated = values[rotation:] + values[:rotation]
                score = 0
                media_hits = 0
                for pos in positions:
                    value = rotated[pos]
                    low = value.lower()
                    if value in common:
                        score += 4
                    elif re.match(r'^[A-Za-z_$][\w$]{1,31}$', value or ''):
                        score += 1
                    if low.startswith(('http://', 'https://')):
                        score += 1
                    if any(media_marker in low for media_marker in media_markers):
                        score += 6
                        media_hits += 1
                candidate = (score, media_hits, values, rotation)
                if best is None or (score, media_hits) > (best[0], best[1]):
                    if best is not None:
                        second_score = max(second_score, best[0])
                    best = candidate
                else:
                    second_score = max(second_score, score)
        if best is None or best[0] < 18 or (best[0] - second_score) < 4:
            continue
        _score, media_hits, values, rotation = best
        rotated = values[rotation:] + values[:rotation]

        def repl_call(match):
            try:
                pos = int(match.group(1), 0) - offset
                if pos < 0 or pos >= len(rotated):
                    return match.group(0)
                return json.dumps(rotated[pos], ensure_ascii=False)
            except Exception:
                return match.group(0)

        decoded = call_re.sub(repl_call, text)
        if decoded != text:
            results.append((decoded, media_hits, rotation, len(values)))
        if len(results) >= 3:
            break

    return results


def _candidate_text_views(text):
    """Cria visões estáticas do HTML para descobrir URLs sem executar JS.

    O player da Opção 3 passou a publicar HLS em ``__index.txt?token=...`` e
    pode serializar a URL com percent-encoding, escapes JS, concatenação de
    literais ou base64. Cada URL encontrada ainda precisa passar por GET real,
    assinatura #EXTM3U e preflight do primeiro segmento; portanto decodificar
    representações textuais não reduz a validação de mídia.
    """
    base = _normalized_html(text)
    views = []
    seen = set()

    def add(value):
        value = str(value or '')
        if not value or value in seen:
            return
        seen.add(value)
        views.append(value)

    add(base)
    for decoded_view, media_hits, rotation, table_size in _deobfuscate_rotating_string_tables(base):
        add(decoded_view)
        _log('resolver JS tabela estatica decodificada rotacao=%d itens=%d midia=%d' % (
            rotation, table_size, media_hits), xbmc.LOGDEBUG)
    current = base
    for _ in range(2):
        try:
            decoded = unquote(current)
        except Exception:
            decoded = current
        decoded = _decode_ascii_js_escapes(decoded)
        if decoded == current:
            break
        add(decoded)
        current = decoded

    # Junta somente sequências de literais JS. Expressões com variáveis não
    # são avaliadas e continuam fora do contrato.
    concat_re = re.compile(
        r'(?:(?:["\'][^"\']{1,2048}["\'])\s*\+\s*)+(?:["\'][^"\']{1,2048}["\'])')
    for _concat_no, match in enumerate(concat_re.finditer(base), 1):
        if _concat_no > 24:
            break
        parts = re.findall(r'["\']([^"\']*)["\']', match.group(0))
        joined = ''.join(parts)
        if ('http' in joined.lower() or '__index' in joined.lower() or
                '.m3u' in joined.lower()):
            add(_decode_ascii_js_escapes(unquote(joined)))

    # Alguns players escondem a configuração em uma string base64/base64url.
    # Só incorporamos decodificações que claramente contêm pista de manifesto.
    import base64
    for _b64_no, match in enumerate(re.finditer(r'["\']([A-Za-z0-9_+/=-]{32,4096})["\']', base), 1):
        if _b64_no > 24:
            break
        token = match.group(1)
        try:
            padded = token + ('=' * ((4 - len(token) % 4) % 4))
            raw = base64.urlsafe_b64decode(padded.encode('ascii'))
            decoded = raw.decode('utf-8', 'ignore')
        except Exception:
            continue
        low = decoded.lower()
        if ('http://' in low or 'https://' in low or '__index.txt' in low or
                '.m3u8' in low or '#extm3u' in low):
            add(_decode_ascii_js_escapes(unquote(decoded)))

    # Reconstrói SOMENTE expressões JavaScript estáticas de string. O player
    # atual pode dividir a URL assinada em variáveis (base + caminho + token),
    # algo que a concatenação literal acima não cobre. Não executamos JS:
    # aceitamos apenas literais, identificadores já resolvidos, operador +,
    # decodeURI/decodeURIComponent e atob sobre valores estáticos.
    def _split_static_plus(expr):
        parts = []
        buf = []
        quote = None
        escape = False
        depth = 0
        for ch in expr:
            if quote:
                buf.append(ch)
                if escape:
                    escape = False
                elif ch == '\\':
                    escape = True
                elif ch == quote:
                    quote = None
                continue
            if ch in ('\"', "'", '`'):
                quote = ch
                buf.append(ch)
                continue
            if ch == '(':
                depth += 1
                buf.append(ch)
                continue
            if ch == ')':
                depth = max(0, depth - 1)
                buf.append(ch)
                continue
            if ch == '+' and depth == 0:
                parts.append(''.join(buf).strip())
                buf = []
                continue
            buf.append(ch)
        parts.append(''.join(buf).strip())
        return parts

    def _static_unquote(expr):
        expr = expr.strip()
        if len(expr) < 2 or expr[0] not in ('\"', "'", '`') or expr[-1] != expr[0]:
            return None
        body = expr[1:-1]
        if expr[0] == '`' and '${' in body:
            # Template literal é aceito apenas quando cada ${...} é um
            # identificador estático já resolvido. Nenhuma expressão/função
            # JavaScript é executada.
            def repl_static(match):
                name = match.group(1)
                value = static_env.get(name)
                if value is None:
                    raise ValueError('template-dinamico')
                return value
            try:
                body = re.sub(r'\$\{([A-Za-z_$][\w$]*)\}', repl_static, body)
            except Exception:
                return None
            if '${' in body:
                return None
        body = _decode_ascii_js_escapes(body).replace('\\/', '/')
        return html.unescape(body)

    import base64
    static_env = {}

    def _eval_static(expr, depth=0):
        if depth > 8:
            return None
        expr = (expr or '').strip()
        if not expr or len(expr) > 8192:
            return None
        while len(expr) >= 2 and expr[0] == '(' and expr[-1] == ')':
            expr = expr[1:-1].strip()
        literal = _static_unquote(expr)
        if literal is not None:
            return literal
        if re.match(r'^[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)?$', expr):
            return static_env.get(expr)

        call = re.match(r'^(decodeURIComponent|decodeURI|unescape|atob)\s*\((.*)\)$', expr, re.I | re.S)
        if call:
            inner = _eval_static(call.group(2), depth + 1)
            if inner is None:
                return None
            try:
                fn = call.group(1).lower()
                if fn in ('decodeuricomponent', 'decodeuri', 'unescape'):
                    return unquote(inner)
                padded = inner + ('=' * ((4 - len(inner) % 4) % 4))
                return base64.b64decode(padded.encode('ascii'), altchars=b'-_').decode('utf-8', 'ignore')
            except Exception:
                return None

        parts = _split_static_plus(expr)
        if len(parts) > 1:
            values = []
            for part in parts:
                value = _eval_static(part, depth + 1)
                if value is None:
                    return None
                values.append(value)
            return ''.join(values)
        return None

    # Primeiro coleta atribuições curtas. Iterações posteriores resolvem
    # dependências entre variáveis sem permitir chamadas arbitrárias.
    assignments = []
    assign_re = re.compile(
        r'\b(?:var|let|const)\s+([A-Za-z_$][\w$]*)\s*=\s*([^;\n]{1,8192})[;\n]',
        re.I)
    for no, match in enumerate(assign_re.finditer(base), 1):
        if no > 160:
            break
        assignments.append((match.group(1), match.group(2)))

    # Propriedades literais de objetos estáticos: const cfg={base:'...', token:'...'}
    # viram aliases cfg.base/cfg.token somente quando o valor é uma string literal.
    object_re = re.compile(
        r'\b(?:var|let|const)\s+([A-Za-z_$][\w$]*)\s*=\s*\{([^{}]{1,16384})\}\s*[;\n]',
        re.I | re.S)
    for ono, om in enumerate(object_re.finditer(base), 1):
        if ono > 40:
            break
        obj = om.group(1)
        body = om.group(2)
        for pm in re.finditer(r'([A-Za-z_$][\w$]*)\s*:\s*(["\'][^"\']{0,8192}["\'])', body):
            assignments.append((obj + '.' + pm.group(1), pm.group(2)))

    # Atribuições posteriores (hlsUrl = base + path + token) também são
    # resolvidas, ainda sob o mesmo subconjunto puramente estático.
    later_re = re.compile(
        r'(?<![\w.$])([A-Za-z_$][\w$]*)\s*=\s*([^=;\n][^;\n]{0,8191})[;\n]',
        re.I)
    for lno, lm in enumerate(later_re.finditer(base), 1):
        if lno > 120:
            break
        pair = (lm.group(1), lm.group(2))
        if pair not in assignments:
            assignments.append(pair)

    for _ in range(10):
        changed = False
        for name, expr in assignments:
            if name in static_env:
                continue
            value = _eval_static(expr)
            if value is None or len(value) > 16384:
                continue
            static_env[name] = value
            changed = True
        if not changed:
            break

    for value in static_env.values():
        low = value.lower()
        if ('http://' in low or 'https://' in low or '__index.txt' in low or
                '.m3u8' in low or '#extm3u' in low or 'token=' in low or
                (value.startswith('/') and any(marker in low for marker in (
                    '/api', 'token', 'stream', 'source', 'manifest', 'playlist',
                    'player', '__play', 'bootstrap', 'config', 'hls')))):
            add(_decode_ascii_js_escapes(unquote(value)))

    # O handoff atual pode montar a URL assinada diretamente no argumento de
    # hls.loadSource(base + path + token), sem antes atribuí-la a uma variável.
    # Avaliamos apenas o mesmo subconjunto estático acima; nenhuma função JS é
    # executada. Isso cobre também wrappers equivalentes já observados em
    # players HLS.
    call_expr_re = re.compile(
        r'\b(?:loadSource|startPlayer|setSource|setSrc|setUrl|loadStream|playStream)'
        r'\s*\(\s*([^;\n]{1,8192}?)\s*\)', re.I | re.S)
    for cno, cm in enumerate(call_expr_re.finditer(base), 1):
        if cno > 48:
            break
        expr = cm.group(1).strip()
        # Evita engolir argumentos adicionais complexos; o contrato suportado
        # é de uma URL de string estática como primeiro argumento.
        if ',' in expr and not expr.startswith(('\"', "'", '`')):
            expr = expr.split(',', 1)[0].strip()
        value = _eval_static(expr)
        if value is None or len(value) > 16384:
            continue
        low = value.lower()
        if ('http://' in low or 'https://' in low or '__index.txt' in low or
                '.m3u8' in low or 'token=' in low):
            add(_decode_ascii_js_escapes(unquote(value)))

    # Fallback estrutural: em alguns builds, prefixo e token são variáveis
    # distintas mas a atribuição final é ofuscada além do subconjunto acima.
    # Unimos apenas um prefixo HTTP terminando em token= a um token assinado
    # que já esteja literalmente presente no documento. O resultado ainda
    # precisa passar pelo GET real + #EXTM3U + preflight do primeiro segmento.
    prefixes = []
    tokens = []
    for view in list(views):
        for m in re.finditer(r'https?://[^\s\"\'<>]{1,2048}(?:__index\.txt|[^/\s\"\'<>]+\.txt)\?token=', view, re.I):
            prefixes.append(m.group(0))
        for m in re.finditer(r'eyJ[A-Za-z0-9_-]{20,4096}\.[A-Za-z0-9_-]{20,512}', view):
            tokens.append(m.group(0))
    for prefix in prefixes[:8]:
        for token in tokens[:8]:
            add(prefix + token)

    # Limita expansão de memória em páginas hostis; o documento original já é
    # limitado por MAX_MANIFEST_BYTES.
    return views[:20]


_NON_HLS_EXTENSIONS = (
    '.mp4', '.m4v', '.webm', '.mp3', '.aac', '.jpg', '.jpeg', '.png', '.gif',
    '.webp', '.svg', '.ico', '.css', '.js', '.xml', '.woff', '.woff2', '.ttf',
    '.otf', '.json', '.html', '.htm', '.php',
)


def _normalize_candidate_url(base_url, value):
    target = html.unescape(str(value or '').strip()).replace('\\/', '/')
    if not target:
        return ''
    # Uma URL HTTP nunca pode conter espaço ou caractere de controle literal.
    # O player remoto usa várias propriedades JavaScript (``url: '/+ i ...'``)
    # que parecem fortes semanticamente, mas são apenas trechos de código.
    # Rejeitar isso antes do urlopen elimina probes impossíveis sem reduzir o
    # contrato dinâmico: URLs reais com espaço chegam percent-encoded.
    if re.search(r'[\x00-\x20\x7f]', target):
        return ''
    if target.startswith('//'):
        target = 'https:' + target
    else:
        target = urljoin(base_url, target)
    target = target.rstrip(');,]')
    if re.search(r'[\x00-\x20\x7f]', target):
        return ''
    try:
        parsed = urlparse(target)
    except Exception:
        return ''
    if (parsed.scheme or '').lower() not in ALLOWED_SCHEMES or not parsed.hostname:
        return ''
    host = (parsed.hostname or '').lower()
    # Nunca permita que HTML remoto transforme o Kodi em cliente de endereços
    # locais. Nomes públicos continuam livres para rotação de CDN.
    if host == 'localhost' or host.endswith('.local'):
        return ''
    try:
        if not ipaddress.ip_address(host).is_global:
            return ''
    except ValueError:
        pass
    return target


def _candidate_is_plausible(target, strong=False):
    try:
        parsed = urlparse(target)
    except Exception:
        return False
    host = (parsed.hostname or '').lower()
    path = (parsed.path or '').lower()
    if any(path.endswith(ext) for ext in _NON_HLS_EXTENSIONS):
        return False
    # Evita um prefixo incompleto ``__index.txt?token=`` virar probe antes de
    # a expressão estática montar o token assinado real.
    if path.endswith('/__index.txt') and re.search(r'(?:^|&)token=(?:&|$)', parsed.query or '', re.I):
        return False
    # Contratos conhecidos: HLS convencional e manifests textuais disfarçados.
    if path.endswith(('.m3u8', '.m3u', '.txt')):
        return True
    if 'm3u8' in (parsed.query or '').lower():
        return True
    # Uma URL explicitamente atribuída a source/src/stream pode mudar de
    # extensão ou ficar extensionless. Ela ainda será aceita somente depois de
    # o probe confirmar #EXTM3U e validar a primeira mídia.
    if strong:
        return True
    # URLs genéricas sem pista forte precisam ao menos parecer um caminho de
    # manifesto. O domínio continua totalmente dinâmico e a aceitação final
    # depende do probe real (#EXTM3U + primeira mídia válida).
    return any(token in path for token in ('/manifest', '/playlist', '/live/', '/hls/'))


def _extract_inline_hls_candidates(base_url, text):
    """Descobre manifestos publicados pela página sem executar JavaScript.

    A URL final continua 100% dinâmica. O caso ``__index.txt?token=...`` é
    priorizado por ter sido comprovado no HAR atual, mas nenhuma origem/CDN,
    token ou caminho de canal é codificado no add-on.
    """
    ranked = []
    order = 0

    def add(value, rank, strong=False):
        nonlocal order
        target = _normalize_candidate_url(base_url, value)
        if not target or not _candidate_is_plausible(target, strong=strong):
            return
        ranked.append((rank, order, target))
        order += 1

    for cleaned in _candidate_text_views(text):
        variable_re = re.compile(
            r'\b(?:var|let|const)\s+(?:src|source|file|stream|streamurl|stream_url|playlist|playlisturl|playlist_url|hls|hlsurl|hls_url|manifest|manifesturl|manifest_url|playback|playbackurl|playback_url)\s*=\s*(["\'])([^"\']+)\1',
            re.I)
        for m in variable_re.finditer(cleaned):
            add(m.group(2), 0, strong=True)

        property_re = re.compile(
            r'\b(?:source|src|file|stream|streamurl|stream_url|playlist|playlisturl|playlist_url|hls|hlsurl|hls_url|manifest|manifesturl|manifest_url|playback|playbackurl|playback_url)\s*:\s*(["\'])([^"\']+)\1',
            re.I)
        for m in property_re.finditer(cleaned):
            add(m.group(2), 1, strong=True)

        # ``url`` genérico é comum em publicidade/pop/sandbox e foi a origem
        # dos falsos candidatos 404 observados na V3D. Só entra como candidato
        # fraco; portanto o próprio caminho precisa parecer manifesto/HLS.
        generic_url_re = re.compile(
            r'\b(?:var|let|const)\s+url\s*=\s*(["\'])([^"\']+)\1|'
            r'\burl\s*:\s*(["\'])([^"\']+)\3', re.I)
        for m in generic_url_re.finditer(cleaned):
            add(m.group(2) or m.group(4), 7, strong=False)

        tag_re = re.compile(
            r'<(?:source|video)[^>]+(?:src|data-src)\s*=\s*(["\'])([^"\']+)\1',
            re.I)
        for m in tag_re.finditer(cleaned):
            add(m.group(2), 1, strong=True)

        call_re = re.compile(
            r'\b(?:startPlayer|loadSource|setSource|setSrc|setUrl|loadStream|playStream)\s*\(\s*(["\'])([^"\']+)\1',
            re.I)
        for m in call_re.finditer(cleaned):
            add(m.group(2), 2, strong=True)

        for m in re.finditer(r'https?://[^\s"\'<>]+', cleaned, re.I):
            target = m.group(0)
            try:
                parsed = urlparse(target)
                path = (parsed.path or '').lower()
                query = (parsed.query or '').lower()
            except Exception:
                continue
            if path.endswith('/__index.txt') and 'token=' in query:
                rank = -2
            elif path.endswith('.txt') and 'token=' in query:
                rank = -1
            elif path.endswith('.txt'):
                rank = 3
            elif path.endswith(('.m3u8', '.m3u')):
                rank = 4
            elif any(token in path for token in ('/manifest', '/playlist', '/live/', '/hls/')):
                rank = 5
            else:
                continue
            add(target, rank, strong=False)

        for m in re.finditer(r'(?<!:)//[^\s"\'<>]+', cleaned, re.I):
            add('https:' + m.group(0), 8, strong=False)
        for m in re.finditer(r'(["\'])(/[^"\']+)(\1)', cleaned, re.I):
            add(m.group(2), 9, strong=False)

    unique = []
    seen = set()
    for rank, idx, target in sorted(ranked, key=lambda x: (x[0], x[1])):
        if target in seen:
            continue
        seen.add(target)
        unique.append(target)
        if len(unique) >= 16:
            break
    return unique


def _extract_player_sources(base_url, text):
    """Extrai ``sources`` do player sem executar JavaScript.

    O contrato observado na Opção 3 publica um array JSON literal em
    ``var/let/const sources = [...]``. Cada item pode trazer ``src`` pronto ou
    um ``ref`` same-origin efêmero que deve ser consumido por POST para obter
    ``src``. O parser é propositalmente estreito: não avalia expressões, não
    executa JS e nunca aceita ``ref`` cross-origin.
    """
    cleaned=_normalized_html(text)
    if not cleaned or len(cleaned)>MAX_MANIFEST_BYTES:
        return []

    def _balanced_array(start):
        depth=0; quote=''; escaped=False
        limit=min(len(cleaned), start + 192*1024)
        for pos in range(start, limit):
            ch=cleaned[pos]
            if quote:
                if escaped:
                    escaped=False
                elif ch=='\\':
                    escaped=True
                elif ch==quote:
                    quote=''
                continue
            if ch in ('"', "'"):
                quote=ch; continue
            if ch=='[':
                depth+=1
            elif ch==']':
                depth-=1
                if depth==0:
                    return cleaned[start:pos+1]
        return ''

    blocks=[]
    assign_re=re.compile(
        r'(?<![\w$])(?:var|let|const)\s+sources\s*=\s*\[', re.I)
    for m in assign_re.finditer(cleaned):
        start=cleaned.find('[',m.start(),m.end()+1)
        if start>=0:
            block=_balanced_array(start)
            if block:
                blocks.append(block)
        if len(blocks)>=4:
            break

    rows=[]; seen=set()

    def _safe_same_origin_ref(value):
        raw=html.unescape(str(value or '').strip()).replace('\\/','/')
        if not raw:
            return ''
        target=urljoin(base_url,raw)
        if not is_safe_public_url(target):
            return ''
        try:
            bp=urlparse(base_url); tp=urlparse(target)
            if (bp.scheme,bp.netloc)!=(tp.scheme,tp.netloc):
                return ''
            if not (tp.path or '').startswith('/'):
                return ''
        except Exception:
            return ''
        return target

    def _safe_media(value):
        raw=html.unescape(str(value or '').strip()).replace('\\/','/')
        if not raw:
            return ''
        target=urljoin(base_url,raw)
        return target if is_safe_public_url(target) else ''

    def _add(obj):
        if not isinstance(obj,dict):
            return
        src=_safe_media(obj.get('src'))
        ref=_safe_same_origin_ref(obj.get('ref'))
        fallback=_safe_media(obj.get('mpegtsFallbackSrc'))
        if not src and not ref and not fallback:
            return
        key=(src,ref,fallback)
        if key in seen:
            return
        seen.add(key)
        rows.append({
            'src':src,
            'ref':ref,
            'mpegtsFallbackSrc':fallback,
            'type':str(obj.get('type') or '')[:96],
            'label':str(obj.get('label') or '')[:160],
        })

    for block in blocks:
        try:
            payload=json.loads(block)
        except Exception:
            payload=None
        if isinstance(payload,list):
            for obj in payload[:8]:
                _add(obj)
        if len(rows)>=8:
            break

    # Fallback estático para pequenas variações de serialização (aspas simples
    # ou propriedades em ordem diferente). Só lê strings literais dentro do
    # próprio bloco ``sources``; expressões continuam rejeitadas.
    if not rows:
        prop_re=re.compile(
            r'([A-Za-z_$][\w$]*)\s*:\s*(["\'])(.*?)\2', re.S)
        for block in blocks:
            for om in re.finditer(r'\{([^{}]{1,32768})\}',block,re.S):
                obj={}
                for pm in prop_re.finditer(om.group(1)):
                    raw=_decode_ascii_js_escapes(pm.group(3)).replace('\\/','/')
                    obj[pm.group(1)]=raw
                _add(obj)
                if len(rows)>=8:
                    break
            if len(rows)>=8:
                break
    return rows


def _probe_player_source_refs(source, base_url, text, resolve_depth=0, visited=None):
    """Resolve o bootstrap first-party ``source.ref -> POST -> JSON.src``.

    O endpoint ``ref`` é capability efêmera e potencialmente one-shot. Ele é
    marcado como visitado *antes* do POST e nunca é repetido na mesma resolução.
    A resposta pode anunciar ``application/octet-stream`` embora o corpo seja
    JSON; a validação é feita pelo conteúdo e, em seguida, pelo preflight HLS.
    """
    if not source.get('enable_signed_bootstrap'):
        return None
    visited=visited if isinstance(visited,set) else set(visited or ())
    rows=_extract_player_sources(base_url,text)
    if not rows:
        return None
    _log('resolver source-ref host=%s fontes=%d' % (
        urlparse(base_url).netloc,len(rows)),xbmc.LOGDEBUG)

    for idx,row in enumerate(rows[:4],1):
        src=row.get('src') or ''
        ref=row.get('ref') or ''
        fallback=row.get('mpegtsFallbackSrc') or ''

        # Alguns players podem publicar src diretamente. Continua sujeito ao
        # mesmo GET real + #EXTM3U + primeiro segmento válido.
        if src:
            nested=dict(source)
            nested['name']=str(source.get('name') or 'embedtv')+'-source-src-%d'%idx
            nested['url']=src
            nested['allow_html_resolve']=False
            nested['allow_native_dns_fallback']=True
            h=media_headers(source.get('resource_headers') or {},page_url=base_url)
            nested['playlist_headers']=dict(h); nested['resource_headers']=dict(h)
            selected=_probe_hls(nested,resolve_depth=resolve_depth,visited=visited)
            if selected:
                return selected

        if not ref or ref in visited:
            continue
        # Capability one-shot: nunca refaz o mesmo POST neste clique/recovery.
        visited.add(ref)
        headers=media_headers(source.get('resource_headers') or {},page_url=base_url)
        headers['Accept']='application/json'
        headers['Cache-Control']='no-cache'
        headers['Pragma']='no-cache'
        headers['Sec-Fetch-Site']='same-origin'
        headers['Sec-Fetch-Dest']='empty'
        headers['Sec-Fetch-Mode']='cors'
        headers.pop('Range',None)
        req=Request(ref,data=b'',headers=_clean_headers(headers),method='POST')
        try:
            with cloudflare_urlopen(req,timeout=6,allow_native_fallback=True) as response:
                raw=response.read(64*1024+1)
                if len(raw)>64*1024:
                    _log('source-ref resposta excedeu limite host=%s' % urlparse(ref).netloc,xbmc.LOGWARNING)
                    continue
                status=getattr(response,'status',200)
                # Não confiar no MIME: o player real responde octet-stream.
                payload=raw.decode('utf-8','ignore').lstrip('\ufeff').strip()
                try:
                    data=json.loads(payload)
                except Exception:
                    data=None
                if not isinstance(data,dict):
                    _log('source-ref POST %d/%d status=%s host=%s json=nao' % (
                        idx,len(rows),status,urlparse(ref).netloc),xbmc.LOGDEBUG)
                    continue
                final_src=str(data.get('src') or '').strip()
                final_fallback=str(data.get('mpegtsFallbackSrc') or fallback or '').strip()
                if final_src:
                    final_src=urljoin(base_url,html.unescape(final_src).replace('\\/','/'))
                if final_fallback:
                    final_fallback=urljoin(base_url,html.unescape(final_fallback).replace('\\/','/'))
                if not is_safe_public_url(final_src):
                    _log('source-ref POST %d/%d status=%s host=%s src=inválido' % (
                        idx,len(rows),status,urlparse(ref).netloc),xbmc.LOGWARNING)
                    continue
                _log('source-ref POST %d/%d status=%s host=%s src_host=%s fallback=%s' % (
                    idx,len(rows),status,urlparse(ref).netloc,urlparse(final_src).netloc,
                    'sim' if is_safe_public_url(final_fallback) else 'nao'),xbmc.LOGDEBUG)
                nested=dict(source)
                nested['name']=str(source.get('name') or 'embedtv')+'-source-ref-%d'%idx
                nested['url']=final_src
                nested['allow_html_resolve']=False
                nested['allow_native_dns_fallback']=True
                h=media_headers(source.get('resource_headers') or {},page_url=base_url)
                nested['playlist_headers']=dict(h); nested['resource_headers']=dict(h)
                if is_safe_public_url(final_fallback):
                    nested['mpegts_fallback_url']=final_fallback
                selected=_probe_hls(nested,resolve_depth=resolve_depth,visited=visited)
                if selected:
                    return selected
        except HTTPError as exc:
            _log('source-ref POST rejeitado status=%s host=%s' % (
                getattr(exc,'code','?'),urlparse(ref).netloc),xbmc.LOGDEBUG)
        except Exception as exc:
            _log('source-ref POST falhou host=%s tipo=%s' % (
                urlparse(ref).netloc,exc.__class__.__name__),xbmc.LOGDEBUG)
    return None


def _extract_inline_hls(base_url, text):
    # Compatibilidade com testes/chamadores anteriores: devolve o melhor.
    items=_extract_inline_hls_candidates(base_url,text)
    return items[0] if items else ''


def _extract_nested_pages(base_url, text):
    """Descobre páginas/iframes públicos publicados pela cadeia confiável.

    Além do iframe HTML tradicional, a Opção 3 atual publica um bootstrap
    assinado ``/__play/<slug>?pt=...&pc=...&ib=...``. Esse caminho é extraído
    literalmente do documento/JS recebido; os parâmetros nunca são criados,
    persistidos ou reaproveitados pelo add-on.
    """
    cleaned=_normalized_html(text)
    out=[]; seen=set()

    def add(value, signed=False):
        value=html.unescape(str(value or '').strip()).replace('\\/','/')
        if not value:
            return
        target=urljoin(base_url,value)
        if target in seen or not is_safe_public_url(target) or target==base_url:
            return
        try:
            parsed=urlparse(target)
            base=urlparse(base_url)
        except Exception:
            return
        # O bootstrap /__play é confiável apenas quando permanece no mesmo
        # origin da página raiz que o publicou. Iframes normais continuam
        # livres para apontar ao player público rotativo.
        if signed and ((parsed.scheme, parsed.netloc)!=(base.scheme, base.netloc) or
                       not (parsed.path or '').startswith('/__play/')):
            return
        seen.add(target); out.append(target)

    for m in re.finditer(r'<iframe[^>]+src\s*=\s*(["\'])([^"\']+)(\1)', cleaned, re.I):
        add(m.group(2), signed=False)
        if len(out)>=6: return out

    # Captura /__play também quando o site o publica em JavaScript/atributo
    # antes de materializar o iframe no DOM. A query assinada é preservada
    # byte a byte após normalização HTML.
    for view in _candidate_text_views(text):
        for m in re.finditer(
                r'(?:(?:https?:)?//[^\s"\'<>]+)?/__play/[a-z0-9_-]{1,128}'
                r'\?[^\s"\'<>]{8,8192}', view, re.I):
            add(m.group(0), signed=True)
            if len(out)>=6: return out
        for m in re.finditer(r'(["\'])(/__play/[a-z0-9_-]{1,128}\?[^"\']{8,8192})\1', view, re.I):
            add(m.group(2), signed=True)
            if len(out)>=6: return out
    return out


def _sanitize_log_url(url):
    """URL segura para log: host/path + nomes dos parâmetros, sem valores."""
    try:
        parsed=urlparse(str(url or ''))
        names=[]
        for piece in (parsed.query or '').split('&'):
            name=(piece.split('=',1)[0] or '').strip()
            if name and name not in names:
                names.append(name[:32])
        suffix=('?'+','.join(names)) if names else ''
        return '%s%s' % ((parsed.path or '/'), suffix)
    except Exception:
        return '/'


def _extract_bootstrap_endpoints(base_url, text):
    """Extrai somente GETs declarativos de bootstrap sem executar JS.

    O objetivo é alcançar respostas JSON/texto que o player usa para obter a
    capability URL assinada. Endpoints são aceitos quando aparecem em fetch,
    axios.get ou XMLHttpRequest.open('GET', ...), ou quando uma string estática
    claramente descreve bootstrap/manifest/source. Nenhum POST é reproduzido.
    """
    ranked=[]; seen=set()

    def add(raw, rank=5, explicit=False):
        target=_normalize_candidate_url(base_url, raw)
        if not target or target in seen or target==base_url:
            return
        try:
            p=urlparse(target); b=urlparse(base_url)
            path=(p.path or '').lower(); query=(p.query or '').lower()
        except Exception:
            return
        if any(path.endswith(ext) for ext in ('.css','.png','.jpg','.jpeg','.gif','.svg','.ico','.woff','.woff2','.ttf','.otf','.mp4','.webm')):
            return
        low=path+'?'+query
        strong=any(k in low for k in ('__play','token','manifest','playlist','stream','source','bootstrap','config','hls','player','/api/','/api?'))
        same_origin=(p.scheme,p.netloc)==(b.scheme,b.netloc)
        if not explicit and not strong:
            return
        if not same_origin and not strong:
            return
        seen.add(target); ranked.append((rank, target))

    for view in _candidate_text_views(text):
        for m in re.finditer(r'\bfetch\s*\(\s*(["\'])([^"\']+)\1', view, re.I):
            add(m.group(2),0,True)
        for m in re.finditer(r'\b(?:axios\.get|\$\.get|jQuery\.get)\s*\(\s*(["\'])([^"\']+)\1', view, re.I):
            add(m.group(2),1,True)
        for m in re.finditer(r'\.open\s*\(\s*(["\'])GET\1\s*,\s*(["\'])([^"\']+)\2', view, re.I):
            add(m.group(3),1,True)
        # Visões estáticas isoladas produzidas pelo avaliador da V3C/V3D.
        stripped=str(view or '').strip()
        if (stripped.startswith(('http://','https://','/')) and len(stripped)<8192):
            add(stripped,3,False)

    return [target for _rank,target in sorted(ranked,key=lambda row: row[0])[:6]]


def _extract_bootstrap_scripts(base_url, text):
    """Scripts first-party curtos que podem conter o bootstrap do player."""
    cleaned=_normalized_html(text)
    out=[]; seen=set()
    try:
        base_host=(urlparse(base_url).hostname or '').lower()
    except Exception:
        base_host=''
    for m in re.finditer(r'<script[^>]+src\s*=\s*(["\'])([^"\']+)\1', cleaned, re.I):
        target=_normalize_candidate_url(base_url,m.group(2))
        if not target or target in seen:
            continue
        try:
            p=urlparse(target); host=(p.hostname or '').lower(); path=(p.path or '').lower()
        except Exception:
            continue
        # Não baixa bibliotecas/adtech de terceiros. O bootstrap funcional deve
        # estar inline ou em script first-party publicado pelo próprio player.
        if host!=base_host or not path.endswith(('.js','.mjs')):
            continue
        if any(x in path for x in ('hls.min.js','hls.js','jquery','bootstrap.min','ads','ima')):
            continue
        seen.add(target); out.append(target)
        if len(out)>=3:
            break
    return out


def _dynamic_probe_state(source):
    state = source.get('_dynamic_probe_state') if isinstance(source, dict) else None
    return state if isinstance(state, dict) else None


def _dynamic_root_id(source):
    return str((source or {}).get('_dynamic_root_id') or (source or {}).get('name') or '')


def _dynamic_endpoint_key(url):
    """Identidade estável só para consenso da tentativa atual.

    Query/token não participa da chave: antes de encurtar o contrato exigimos
    duas leituras independentes, permitindo que um token fresco se recupere.
    Nada desta informação é persistido entre canais/sessões.
    """
    try:
        parsed = urlparse(str(url or ''))
        scheme = (parsed.scheme or '').lower()
        host = (parsed.hostname or '').lower()
        if scheme not in ALLOWED_SCHEMES or not host:
            return ''
        port = parsed.port
        authority = host if port is None else '%s:%d' % (host, port)
        path = parsed.path or '/'
        return '%s://%s%s' % (scheme, authority, path)
    except Exception:
        return ''


def _dynamic_record_media_outcome(source, url, outcome):
    state = _dynamic_probe_state(source)
    if state is None:
        return
    root = _dynamic_root_id(source)
    key = _dynamic_endpoint_key(url)
    if not root or not key:
        return
    outcomes = state.setdefault('media_outcomes', {})
    outcomes[(root, key)] = str(outcome or '')


def _dynamic_page_short_circuit(source, page_url):
    state = _dynamic_probe_state(source)
    if state is None:
        return False
    key = _dynamic_endpoint_key(page_url)
    row = (state.get('terminal_pages') or {}).get(key)
    if not row:
        return False
    _log('resolver consenso dinâmico host=%s confirmacoes=%s motivo=%s; evitando leitura repetida' % (
        urlparse(page_url).netloc, row.get('confirmations', '?'), row.get('reason', 'indisponivel')),
        xbmc.LOGWARNING)
    return True


def _dynamic_update_page_consensus(source, page_url, targets):
    """Encurta apenas repetição comprovada dentro do MESMO clique/recovery.

    O primeiro espelho sempre é testado por completo. O segundo também, mesmo
    que publique o mesmo host/caminho com token novo. Só após duas origens
    independentes produzirem a mesma assinatura de endpoints e apenas 404 ou
    timeout (com pelo menos um 404) a página intermediária passa a ser tratada
    como repetição sem diversidade. 403/5xx/preflight/outros nunca ativam o
    atalho, porque podem depender de referer, token ou instabilidade transitória.
    """
    state = _dynamic_probe_state(source)
    if state is None:
        return
    try:
        threshold = max(2, min(4, int(source.get('dynamic_failure_consensus') or 2)))
    except Exception:
        threshold = 2
    root = _dynamic_root_id(source)
    page_key = _dynamic_endpoint_key(page_url)
    if not root or not page_key:
        return
    outcomes = state.get('media_outcomes') or {}
    signature = []
    for target in targets or []:
        media_key = _dynamic_endpoint_key(target)
        if not media_key:
            continue
        outcome = outcomes.get((root, media_key))
        if outcome:
            signature.append((media_key, outcome))
    if not signature:
        return
    signature = tuple(sorted(signature))
    statuses = [row[1] for row in signature]
    # Só o perfil observado nos logs de origem realmente offline: endpoint(s)
    # de mídia em 404 e, opcionalmente, um endpoint lento em timeout.
    if not all(status in ('http404', 'timeout') for status in statuses):
        return
    if 'http404' not in statuses:
        return
    observations = state.setdefault('page_observations', {}).setdefault(page_key, {})
    observations[root] = signature
    equivalent = [rid for rid, sig in observations.items() if sig == signature]
    if len(equivalent) < threshold:
        return
    reason = '404-confirmado' if all(status == 'http404' for status in statuses) else 'indisponibilidade-repetida'
    state.setdefault('terminal_pages', {})[page_key] = {
        'confirmations': len(equivalent),
        'reason': reason,
    }
    _log('resolver consenso dinâmico confirmado host=%s origens=%d motivo=%s' % (
        urlparse(page_url).netloc, len(equivalent), reason), xbmc.LOGWARNING)


def _probe_bootstrap_payload(source, base_url, payload_text, resolve_depth=0, visited=None, label='bootstrap'):
    """Resolve HLS/páginas a partir de resposta declarativa de bootstrap."""
    # Primeiro URLs HLS publicadas diretamente na resposta JSON/texto.
    targets=_extract_inline_hls_candidates(base_url,payload_text)
    for idx,target in enumerate(targets[:8],1):
        nested=dict(source)
        nested['name']=str(source.get('name') or 'embedtv')+'-%s-media-%d'%(label,idx)
        nested['url']=target
        nested['allow_html_resolve']=False
        nested['allow_native_dns_fallback']=True
        h=media_headers(source.get('resource_headers') or {},page_url=base_url)
        nested['playlist_headers']=dict(h); nested['resource_headers']=dict(h)
        _log('bootstrap mídia candidata host=%s -> %s' % (urlparse(base_url).netloc,urlparse(target).netloc),xbmc.LOGDEBUG)
        selected=_probe_hls(nested,resolve_depth=resolve_depth,visited=visited)
        if selected:
            return selected

    # Respostas de bootstrap também podem publicar novo iframe/player. Limitado
    # à profundidade normal da Opção 3 e sempre por URL pública explícita.
    try:
        max_depth=max(0,min(2,int(source.get('max_html_depth',1))))
    except Exception:
        max_depth=1
    if resolve_depth < max_depth:
        for page in _extract_nested_pages(base_url,payload_text)[:4]:
            shared_visited = visited if isinstance(visited, set) else set(visited or ())
            if page in shared_visited:
                continue
            shared_visited.add(page)
            nested=dict(source)
            nested['name']=str(source.get('name') or 'embedtv')+'-%s-page'%label
            nested['url']=page
            nested['allow_html_resolve']=True
            nested['allow_native_dns_fallback']=True
            nested['source_kind']='derived-page'
            nested['playlist_headers']=page_headers(source.get('playlist_headers') or {},page_url=page,parent_url=base_url)
            if source.get('preserve_navigation_referer'):
                nested['playlist_headers']['Referer']=base_url
            nested['resource_headers']=media_headers(source.get('resource_headers') or {},page_url=page)
            selected=_probe_hls(nested,resolve_depth=resolve_depth+1,visited=shared_visited)
            if selected:
                return selected
    return None


def _probe_bootstrap_endpoints(source, base_url, text, resolve_depth=0, visited=None):
    if not source.get('enable_signed_bootstrap'):
        return None
    visited = visited if isinstance(visited, set) else set(visited or ())
    budget=max(1,min(6,int(source.get('bootstrap_max_requests') or 4)))
    endpoints=_extract_bootstrap_endpoints(base_url,text)[:budget]
    if endpoints:
        _log('bootstrap HTTP host=%s endpoints=%d' % (urlparse(base_url).netloc,len(endpoints)),xbmc.LOGDEBUG)
    for idx,target in enumerate(endpoints,1):
        if target in visited:
            continue
        visited.add(target)
        headers=media_headers(source.get('resource_headers') or {},page_url=base_url)
        try:
            bp=urlparse(base_url); tp=urlparse(target)
            if (bp.scheme,bp.netloc)==(tp.scheme,tp.netloc):
                headers['Sec-Fetch-Site']='same-origin'
                headers['Referer']=base_url
        except Exception:
            pass
        req=Request(target,headers=_clean_headers(headers),method='GET')
        try:
            with cloudflare_urlopen(req,timeout=6,allow_native_fallback=True) as response:
                data=response.read(256*1024+1)
                if len(data)>256*1024:
                    _log('bootstrap resposta excedeu limite host=%s path=%s' % (urlparse(target).netloc,_sanitize_log_url(target)),xbmc.LOGWARNING)
                    continue
                final_url=getattr(response,'url',target) or target
                payload=data.decode('utf-8','ignore')
                _log('bootstrap GET %d/%d status=%s host=%s path=%s bytes=%d' % (
                    idx,len(endpoints),getattr(response,'status',200),urlparse(final_url).netloc,
                    _sanitize_log_url(final_url),len(data)),xbmc.LOGDEBUG)
                if '#EXTM3U' in payload:
                    nested=dict(source)
                    nested['name']=str(source.get('name') or 'embedtv')+'-bootstrap-hls'
                    nested['url']=final_url
                    nested['allow_html_resolve']=False
                    nested['playlist_headers']=dict(headers); nested['resource_headers']=dict(headers)
                    selected=_probe_hls(nested,resolve_depth=resolve_depth,visited=visited)
                    if selected:
                        return selected
                selected=_probe_bootstrap_payload(source,final_url,payload,resolve_depth,visited,label='bootstrap')
                if selected:
                    return selected
        except HTTPError as exc:
            _log('bootstrap GET rejeitado status=%s host=%s path=%s' % (getattr(exc,'code','?'),urlparse(target).netloc,_sanitize_log_url(target)),xbmc.LOGDEBUG)
        except Exception as exc:
            _log('bootstrap GET falhou host=%s path=%s tipo=%s' % (urlparse(target).netloc,_sanitize_log_url(target),exc.__class__.__name__),xbmc.LOGDEBUG)
    return None


def _probe_bootstrap_scripts(source, base_url, text, resolve_depth=0, visited=None):
    if not source.get('enable_signed_bootstrap'):
        return None
    scripts=_extract_bootstrap_scripts(base_url,text)
    for idx,target in enumerate(scripts,1):
        headers=media_headers(source.get('resource_headers') or {},page_url=base_url)
        headers['Sec-Fetch-Dest']='script'; headers['Sec-Fetch-Mode']='no-cors'; headers['Sec-Fetch-Site']='same-origin'
        headers['Referer']=base_url
        headers.pop('Origin',None)
        req=Request(target,headers=_clean_headers(headers),method='GET')
        try:
            with cloudflare_urlopen(req,timeout=6,allow_native_fallback=True) as response:
                data=response.read(384*1024+1)
                if len(data)>384*1024:
                    continue
                script=data.decode('utf-8','ignore')
                _log('bootstrap script %d/%d host=%s path=%s bytes=%d' % (idx,len(scripts),urlparse(target).netloc,_sanitize_log_url(target),len(data)),xbmc.LOGDEBUG)
                selected=_probe_bootstrap_payload(source,base_url,script,resolve_depth,visited,label='script')
                if selected:
                    return selected
                selected=_probe_bootstrap_endpoints(source,base_url,script,resolve_depth,visited)
                if selected:
                    return selected
        except Exception as exc:
            _log('bootstrap script falhou host=%s tipo=%s' % (urlparse(target).netloc,exc.__class__.__name__),xbmc.LOGDEBUG)
    return None


def _probe_inline_hls(source, base_url, text, resolve_depth=0, visited=None):
    if not source.get('allow_html_resolve'):
        return None
    visited = visited if isinstance(visited, set) else set(visited or ())
    visited.add(base_url)

    # V3F: o player atual publica ``sources[].ref`` e consome esse capability
    # por POST first-party para receber JSON com ``src`` HLS. Este é o caminho
    # principal porque foi comprovado em capturas independentes e permanece
    # totalmente dinâmico; nenhum endpoint, CDN ou token é codificado.
    selected=_probe_player_source_refs(source,base_url,text,resolve_depth,visited)
    if selected:
        return selected

    # Caminhos declarativos antigos permanecem como fallback compatível.
    selected=_probe_bootstrap_endpoints(source,base_url,text,resolve_depth,visited)
    if selected:
        return selected
    selected=_probe_bootstrap_scripts(source,base_url,text,resolve_depth,visited)
    if selected:
        return selected

    targets=_extract_inline_hls_candidates(base_url,text)
    if targets:
        _log('resolver HTML host=%s candidatos_midia=%d' % (urlparse(base_url).netloc,len(targets)))
    for idx,target in enumerate(targets,1):
        nested=dict(source)
        nested['name']=str(source.get('name') or 'embedtv')+'-resolved-%d'%idx
        nested['url']=target
        nested['allow_html_resolve']=False
        nested['allow_native_dns_fallback']=True
        # Playlist e segmentos herdam dinamicamente o contexto exato da
        # página que publicou a mídia, independentemente do domínio/CDN.
        h=media_headers(source.get('resource_headers') or {}, page_url=base_url)
        nested['playlist_headers']=dict(h)
        nested['resource_headers']=dict(h)
        _log('resolver tentando mídia %d/%d host=%s' % (idx,len(targets),urlparse(target).netloc))
        selected=_probe_hls(nested,resolve_depth=resolve_depth,visited=visited)
        if selected:
            _log('resolver mídia válida host=%s -> %s' % (urlparse(base_url).netloc,urlparse(target).netloc))
            return selected
        _log('resolver descartou candidato host=%s' % urlparse(target).netloc,xbmc.LOGWARNING)

    _dynamic_update_page_consensus(source, base_url, targets)

    # A página de entrada pode publicar outro iframe. O padrão homologado
    # continua em um nível; adaptadores isolados podem pedir no máximo dois,
    # sempre por URL pública explícita e com validação HLS antes de reproduzir.
    try:
        max_depth = max(0, min(2, int(source.get('max_html_depth', 1))))
    except Exception:
        max_depth = 1
    if resolve_depth < max_depth:
        pages=_extract_nested_pages(base_url,text)
        for page in pages:
            if page in visited: continue
            if _dynamic_page_short_circuit(source, page):
                continue
            visited.add(page)
            nested=dict(source)
            nested['name']=str(source.get('name') or 'embedtv')+'-iframe'
            nested['url']=page
            nested['allow_html_resolve']=True
            nested['allow_native_dns_fallback']=True
            nested['source_kind']='derived-page'
            nested['playlist_headers']=page_headers(source.get('playlist_headers') or {}, page_url=page, parent_url=base_url)
            # Alguns contratos publicam /canal -> /__play -> player. O
            # Referer de cada navegação é necessário, mas só é ativado quando
            # o adaptador da fonte o declara; Opções 1 e 2 ficam inalteradas.
            if source.get('preserve_navigation_referer'):
                nested['playlist_headers']['Referer'] = base_url
            nested['resource_headers']=media_headers(source.get('resource_headers') or {}, page_url=page)
            if (urlparse(page).path or '').startswith('/__play/'):
                _log('resolver bootstrap assinado host=%s path=%s parametros=%s' % (
                    urlparse(base_url).netloc,urlparse(page).path,
                    ','.join(sorted(set((piece.split('=',1)[0] or '') for piece in (urlparse(page).query or '').split('&') if piece))) or '-'),
                    xbmc.LOGDEBUG)
            else:
                _log('resolver seguindo iframe publicado host=%s -> %s' % (urlparse(base_url).netloc,urlparse(page).netloc))
            selected=_probe_hls(nested,resolve_depth=resolve_depth+1,visited=visited)
            if selected: return selected

    _log('resolver sem HLS válido host=%s' % urlparse(base_url).netloc,xbmc.LOGWARNING)
    return None


def _read_probe_payload(response, source):
    """Leitura limitada; HTML opcionalmente acompanha streaming progressivo.

    Alguns players publicam o manifesto em script inline, mas demoram para
    encerrar o documento. Para a Opção 3 guardamos chunks já recebidos e,
    somente em timeout de leitura, aceitamos HTML parcial. Isso não aprova
    mídia por si só: qualquer URL extraída ainda passa pelo preflight HLS e
    pelo primeiro segmento antes de chegar ao player.
    """
    progressive = bool(source.get('allow_html_resolve') and
                       source.get('progressive_html_read'))
    if not progressive:
        return response.read(MAX_MANIFEST_BYTES + 1), False

    chunks = []
    total = 0
    timed_out = False
    chunk_size = 32 * 1024
    try:
        while total <= MAX_MANIFEST_BYTES:
            remaining = (MAX_MANIFEST_BYTES + 1) - total
            if remaining <= 0:
                break
            block = response.read(min(chunk_size, remaining))
            if not block:
                break
            chunks.append(block)
            total += len(block)
    except (TimeoutError, socket.timeout):
        if not chunks or not source.get('allow_partial_html_on_timeout'):
            raise
        timed_out = True
    return b''.join(chunks), timed_out


def _probe_hls(source, resolve_depth=0, visited=None):
    url=source['url']
    headers=_clean_headers(source.get('playlist_headers') or {})
    if source.get('source_kind') in ('api-url', 'derived-page'):
        _log('probe página fonte=%s modo=%s/%s host=%s' % (
            source.get('name'), headers.get('Sec-Fetch-Dest', '?'),
            headers.get('Sec-Fetch-Mode', '?'), urlparse(url).netloc), xbmc.LOGDEBUG)
    request=Request(url,headers=headers,method='GET')
    # O timeout padrão homologado continua intacto. Adaptadores isolados podem
    # ampliar somente a leitura de DOCUMENTOS HTML que sabidamente concluem
    # mais devagar; mídia já resolvida nunca herda essa ampliação.
    probe_timeout = PROBE_TIMEOUT
    if source.get('allow_html_resolve'):
        try:
            probe_timeout = max(
                PROBE_TIMEOUT,
                min(18, float(source.get('html_probe_timeout') or PROBE_TIMEOUT))
            )
        except Exception:
            probe_timeout = PROBE_TIMEOUT
    try:
        with cloudflare_urlopen(request,timeout=probe_timeout,
                allow_native_fallback=bool(source.get('allow_native_dns_fallback'))) as response:
            data, partial_timeout = _read_probe_payload(response, source)
            if partial_timeout:
                _log('probe HTML parcial após timeout fonte=%s host=%s bytes=%d; validando conteúdo recebido' % (
                    source.get('name'), urlparse(url).netloc, len(data)), xbmc.LOGDEBUG)
            if len(data)>MAX_MANIFEST_BYTES:
                _log('probe manifest excedeu limite fonte=%s host=%s' % (
                    source.get('name'),urlparse(url).netloc),xbmc.LOGWARNING)
                return None
            text=data.decode('utf-8','ignore')
            final_url=getattr(response,'url',url) or url
            ok='#EXTM3U' in text
            _log('probe fonte=%s status=%s host=%s final_host=%s hls=%s' % (
                source.get('name'),getattr(response,'status',200),
                urlparse(url).netloc,urlparse(final_url).netloc,ok))
            if not ok:
                selected = _probe_inline_hls(source,final_url,text,resolve_depth=resolve_depth,visited=visited)
                if selected:
                    return selected
                if not source.get('allow_html_resolve'):
                    _dynamic_record_media_outcome(source, final_url, 'not_hls')
                return None

            media_ok,nested_live=_validate_hls_media(
                final_url,text,_clean_headers(source.get('resource_headers') or {}),0)
            if not media_ok:
                _dynamic_record_media_outcome(source, final_url, 'preflight')
                _log('fonte rejeitada no preflight fonte=%s host=%s' % (
                    source.get('name'),urlparse(final_url).netloc),xbmc.LOGWARNING)
                return None
            selected=dict(source)
            selected['resolved_url']=final_url
            selected['seed_playlist']=data
            root_live='#EXT-X-ENDLIST' not in text
            selected['is_live']=root_live if nested_live is None else bool(nested_live)
            _dynamic_record_media_outcome(source, final_url, 'valid')
            _log('preflight mídia válida fonte=%s live=%s' % (
                source.get('name'),'sim' if selected['is_live'] else 'nao'))
            return selected
    except HTTPError as exc:
        final_url=getattr(exc,'url',url) or url
        code=getattr(exc,'code','?')
        _dynamic_record_media_outcome(source, final_url, 'http%s' % code)
        _log('probe HTTP fonte=%s status=%s host=%s final_host=%s' % (
            source.get('name'),code,urlparse(url).netloc,
            urlparse(final_url).netloc),xbmc.LOGWARNING)
        return None
    except Exception as exc:
        outcome = 'timeout' if isinstance(exc, (TimeoutError, socket.timeout)) or exc.__class__.__name__.lower() == 'timeout' else 'error'
        _dynamic_record_media_outcome(source, url, outcome)
        _log('probe erro fonte=%s host=%s tipo=%s msg=%s' % (
            source.get('name'),urlparse(url).netloc,exc.__class__.__name__,exc),xbmc.LOGWARNING)
        return None

def _validated_sources(ch):
    """Gera fontes aprovadas no probe, uma por vez, preservando a ordem.

    A validação é lazy de propósito: se a primeira fonte inicia A/V, a segunda
    nem é consultada. Se a primeira morrer antes de OnAVStarted, o chamador pode
    avançar para a próxima sem confundir isso com reconnect após Stop.
    """
    candidates = _candidate_sources(ch)
    _log('contrato id=%s candidatos=%d' % (ch.get('id'), len(candidates)))
    dynamic_state = {} if any(source.get('dynamic_failure_consensus') for source in candidates if isinstance(source, dict)) else None
    for index, source in enumerate(candidates, 1):
        if dynamic_state is not None and source.get('dynamic_failure_consensus'):
            source = dict(source)
            source['_dynamic_probe_state'] = dynamic_state
            source['_dynamic_root_id'] = str(source.get('name') or 'fonte-%d' % index)
        url = source.get('url') or ''
        parsed = urlparse(url)
        if parsed.scheme.lower() not in ALLOWED_SCHEMES:
            _log('fonte ignorada esquema invalido id=%s fonte=%s' % (
                ch.get('id'), source.get('name')), xbmc.LOGWARNING)
            continue
        _log('testando id=%s fonte=%d/%d nome=%s host=%s referer=%s' % (
            ch.get('id'), index, len(candidates), source.get('name'), parsed.netloc,
            'sim' if any(k.lower() == 'referer' for k in (source.get('playlist_headers') or {})) else 'nao'))
        selected = _probe_hls(source)
        if source.get('option3_domain_set'):
            try:
                from .option3 import record_domain_result
                record_domain_result(source, bool(selected))
            except Exception as exc:
                _log('OPCAO3 estado de domínio não atualizado tipo=%s msg=%s' % (
                    exc.__class__.__name__, exc), xbmc.LOGWARNING)
        if selected:
            selected['_candidate_index'] = index
            selected['_candidate_total'] = len(candidates)
            yield selected


def _notify_source_unavailable(channel_name=None):
    msg = 'Fonte indisponível no momento. Tente novamente mais tarde.'
    display_name=_public_text(channel_name)
    if display_name:
        msg = '%s: fonte indisponível no momento.' % display_name
    try:
        xbmcgui.Dialog().notification('OnePlay Live', msg, xbmcgui.NOTIFICATION_ERROR, 5000)
    except Exception:
        pass


class _PlaybackSession(xbmc.Player):
    """Vigia uma sessão; live não pausa e STOP do usuário nunca reconecta."""
    def __init__(self, live=False):
        xbmc.Player.__init__(self)
        self.live = bool(live)
        self.started = threading.Event()
        self.stopped = threading.Event()
        self.ended = threading.Event()
        self.failed = threading.Event()
        self.paused = threading.Event()
        self._resume_guard = threading.Lock()

    def onAVStarted(self):
        self.started.set()
        _prepare_dialog_close('av_started')
        _log('OnAVStarted')

    def onPlayBackStarted(self):
        _log('OnPlayBackStarted')

    def onPlayBackPaused(self):
        if self.live:
            _log('OnPlayBackPaused em live; retomada imediata sem timeshift', xbmc.LOGWARNING)
            if self._resume_guard.acquire(False):
                try:
                    # pause() é toggle no xbmc.Player; aqui desfaz imediatamente
                    # uma pausa aplicada ao live, sem criar buffer/timeshift.
                    self.pause()
                except Exception as exc:
                    _log('falha ao retomar live apos pause: %s' % exc, xbmc.LOGWARNING)
                finally:
                    self._resume_guard.release()
            return
        self.paused.set()
        _log('OnPlayBackPaused; proxy preservado')

    def onPlayBackResumed(self):
        self.paused.clear()
        _log('OnPlayBackResumed')

    def onPlayBackStopped(self):
        self.stopped.set()
        _log('OnPlayBackStopped; sem reconnect')

    def onPlayBackEnded(self):
        self.ended.set()
        _log('OnPlayBackEnded; fim involuntario elegivel a recuperacao se live')

    def onPlayBackError(self):
        self.failed.set()
        _log('OnPlayBackError; elegivel a recuperacao se live', xbmc.LOGWARNING)


def _enable_ffmpegdirect(li, is_live=False):
    try:
        xbmcaddon.Addon('inputstream.ffmpegdirect')
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        if is_live:
            li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            # Não definir stream_mode=timeshift: live permanece linear, sem
            # buffer local de rewind/pause e sem consumo extra de armazenamento.
        _log('inputstream.ffmpegdirect HLS live=%s timeshift=nao' % ('sim' if is_live else 'nao'))
    except Exception:
        _log('inputstream.ffmpegdirect indisponivel; usando player nativo', xbmc.LOGWARNING)


def _confirm_live_loss(player, monitor):
    """Confirma perda real do live antes de habilitar recovery.

    Em Android/Kodi o estado isPlaying() pode cair antes de o callback
    onPlayBackStopped() chegar ao objeto Python. Durante esta janela STOP
    tem prioridade absoluta; Ended/Error continuam recuperáveis.
    """
    deadline = time.time() + LIVE_LOST_CONFIRM_GRACE
    _log('live deixou de tocar sem callback; aguardando confirmacao por %.1fs' %
         LIVE_LOST_CONFIRM_GRACE, xbmc.LOGDEBUG)
    while time.time() < deadline and not monitor.abortRequested():
        if player.stopped.is_set():
            _log('STOP confirmado durante janela de live_lost; recovery cancelado')
            return 'stopped'
        if player.failed.is_set():
            return 'live_error'
        if player.ended.is_set():
            return 'live_ended'
        try:
            if player.isPlaying():
                _log('live voltou a tocar durante janela de confirmacao; mantendo sessao', xbmc.LOGDEBUG)
                return 'resumed'
        except Exception:
            pass
        remaining = max(0.0, deadline - time.time())
        monitor.waitForAbort(min(PLAYBACK_POLL, remaining))
    if monitor.abortRequested():
        return 'abort'
    if player.stopped.is_set():
        return 'stopped'
    if player.failed.is_set():
        return 'live_error'
    if player.ended.is_set():
        return 'live_ended'
    return 'live_lost'


def _observer_stopped(player):
    try:
        return bool(player is not None and player.stopped.is_set())
    except Exception:
        return False


def _wait_recovery_backoff(monitor, delay, stop_observer=None):
    """Espera o backoff, mas um STOP tardio cancela recovery imediatamente."""
    deadline = time.time() + max(0.0, float(delay or 0.0))
    while time.time() < deadline:
        if _observer_stopped(stop_observer):
            _log('STOP tardio confirmado durante backoff; recovery cancelado')
            return 'stopped'
        remaining = max(0.0, deadline - time.time())
        if monitor.waitForAbort(min(0.10, remaining)):
            return 'abort'
    if _observer_stopped(stop_observer):
        _log('STOP tardio confirmado ao fim do backoff; recovery cancelado')
        return 'stopped'
    return 'continue'


def _play_direct(local_url, li, channel_name, is_live=False):
    """Executa uma tentativa e preserva a causa real do encerramento.

    completed: reprodução não-live terminou normalmente.
    live_ended: live entrou em A/V e Kodi encerrou por EOF/fim da mídia.
    live_error: live entrou em A/V e Kodi reportou erro de playback.
    live_lost: live entrou em A/V, deixou de tocar sem callback terminal.
    startup_failed: terminou/errou/timeout antes de A/V; pode testar backup.
    stopped: usuário emitiu Stop; é sempre terminal e nunca reconecta.
    abort: Kodi está encerrando.
    """
    monitor = xbmc.Monitor()
    player = _PlaybackSession(live=is_live)
    _log('iniciando xbmc.Player.play direto; rota nao usa setResolvedUrl')
    player.play(item=local_url, listitem=li)

    deadline = time.time() + STARTUP_TIMEOUT
    while time.time() < deadline and not monitor.abortRequested():
        if player.started.is_set():
            break
        try:
            if player.isPlayingVideo():
                player.started.set()
                break
        except Exception:
            pass
        if player.stopped.is_set():
            _prepare_dialog_close('stop_pre_av')
            _log('Stop recebido antes de A/V; sem fallback/reconnect')
            return 'stopped', player
        if player.failed.is_set() or player.ended.is_set():
            break
        monitor.waitForAbort(PLAYBACK_POLL)

    if monitor.abortRequested():
        _prepare_dialog_close('abort')
        return 'abort', player

    if player.started.is_set():
        _prepare_dialog_close('av_started_checkpoint')
        av_started_at = time.monotonic()
    else:
        av_started_at = None

    if not player.started.is_set():
        reason = 'ended' if player.ended.is_set() else ('error' if player.failed.is_set() else 'timeout')
        _log('player nao entrou em A/V motivo=%s; fonte elegivel a fallback de startup' % reason, xbmc.LOGWARNING)
        try:
            if player.isPlaying():
                player.stop()
        except Exception:
            pass
        return 'startup_failed', player

    _log('reproducao iniciada; live=%s proxy mantido' % ('sim' if is_live else 'nao'))
    not_playing_since = 0.0
    terminal = 'completed'
    while not monitor.abortRequested():
        if player.stopped.is_set():
            terminal = 'stopped'
            break
        if player.failed.is_set():
            terminal = 'live_error' if is_live else 'completed'
            break
        if player.ended.is_set():
            terminal = 'live_ended' if is_live else 'completed'
            break
        try:
            active = bool(player.isPlaying())
        except Exception:
            active = False
        if (not is_live) and player.paused.is_set():
            not_playing_since = 0.0
        elif active:
            not_playing_since = 0.0
        else:
            if not not_playing_since:
                not_playing_since = time.time()
            elif time.time() - not_playing_since >= END_GRACE:
                if is_live:
                    confirmed = _confirm_live_loss(player, monitor)
                    if confirmed == 'resumed':
                        not_playing_since = 0.0
                        continue
                    terminal = confirmed
                else:
                    terminal = 'completed'
                break
        monitor.waitForAbort(PLAYBACK_POLL)

    if av_started_at is not None:
        try:
            player._oneplay_live_stable_seconds = max(0.0, time.monotonic() - av_started_at)
        except Exception:
            player._oneplay_live_stable_seconds = 0.0

    if monitor.abortRequested():
        _log('sessao encerrada por abort; liberando proxy da tentativa')
        return 'abort', player
    if terminal == 'stopped':
        _log('sessao encerrada por Stop do usuario; liberando proxy sem reconnect')
        return terminal, player
    if terminal in ('live_ended', 'live_error', 'live_lost'):
        _log('sessao live encerrou involuntariamente motivo=%s; liberando proxy para recuperacao controlada' % terminal, xbmc.LOGWARNING)
        return terminal, player
    _log('sessao encerrada; liberando proxy sem reconnect')
    return terminal, player


def _apply_channel_art(li, ch):
    try:
        artinfo=artwork_for(ch)
        remote=artinfo.get('remote',''); preview=artinfo.get('preview',''); fallback=artinfo.get('fallback','')
        addon=xbmcaddon.Addon(); addon_icon=addon.getAddonInfo('icon'); addon_fanart=addon.getAddonInfo('fanart')
        primary=remote or fallback or addon_icon
        fanart=preview or remote or addon_fanart
        art={}
        if primary:
            art.update({'icon':primary,'thumb':primary,'poster':primary,'clearlogo':primary})
        if fanart:
            art.update({'fanart':fanart,'landscape':fanart})
        if art: li.setArt(art)
        if fanart: li.setProperty('fanart_image',fanart)
    except Exception as exc:
        _log('artwork do player indisponível: %s'%exc, xbmc.LOGDEBUG)


def _run_source_attempt(ch, selected, channel_id, attempted, format_recovery=False, live_recovery=False):
    upstream = selected.get('resolved_url') or selected['url']
    display_name=_public_text(ch.get('name')) or str(channel_id)
    display_category=_public_text(ch.get('category'))
    display_plot=_public_text(ch.get('_epg_plot'),multiline=True)
    is_live = bool(selected.get('is_live'))
    is_globorj = str(ch.get('id') or '').lower() == 'globorj'
    proxy = HlsProxy(
        root_url=upstream,
        root_headers=selected.get('playlist_headers') or {},
        nested_headers=selected.get('resource_headers') or {},
        log=lambda msg: _log('PROXY %s' % msg),
        # Na recuperação pedimos playlist fresca para evitar reutilizar
        # segmentos que podem ter expirado durante a primeira tentativa.
        seed_playlist=None if (format_recovery or live_recovery) else selected.get('seed_playlist'),
        mask_png_ts_segments=is_globorj,
        format_recovery=bool(format_recovery and not is_globorj),
        segment_recovery=True,
    ).start()
    result = 'startup_failed'
    stop_observer = None
    had_format_suspect = False
    try:
        local_url = proxy.url(upstream)
        li = xbmcgui.ListItem(label=display_name, path=local_url)
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)
        _apply_channel_art(li,ch)
        _enable_ffmpegdirect(li, is_live=is_live)
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(display_name)
            try: tag.setMediaType('video')
            except Exception: pass
            tag.setPlot(display_plot)
            if display_category:
                tag.setGenres([display_category])
        except Exception:
            pass

        _log('play id=%s fonte=%s upstream=%s proxy_port=%d live=%s tentativa=%d/%d recuperacao_formato=%s' % (
            channel_id, selected.get('name'), urlparse(upstream).netloc, proxy.port,
            'sim' if is_live else 'nao', selected.get('_candidate_index', attempted),
            selected.get('_candidate_total', attempted), 'sim' if format_recovery else 'nao'))
        if live_recovery:
            _log('tentativa de recuperacao live usando playlist fresca id=%s fonte=%s' % (
                channel_id, selected.get('name')), xbmc.LOGWARNING)
        _prepare_dialog_update(display_name, ready=True)
        result, stop_observer = _play_direct(local_url, li, display_name, is_live=is_live)
        had_format_suspect = proxy.has_format_suspects()
    finally:
        # Captura antes do stop para decidir se uma segunda tentativa do MESMO
        # source deve esconder extensão enganosa. Nunca é usado após A/V.
        try:
            had_format_suspect = had_format_suspect or proxy.has_format_suspects()
        except Exception:
            pass
        proxy.stop()
    return result, had_format_suspect, stop_observer


def _try_channel_contract(ch, channel_id, attempted_start=0, live_recovery=False, cancel_observer=None, session_state=None):
    attempted=attempted_start
    is_globorj=str(ch.get('id') or '').lower()=='globorj'
    any_selected=False
    if _play_session_cancelled(session_state, channel_id, 'antes_contrato'):
        return 'terminal',attempted,'superseded',cancel_observer
    for selected in _validated_sources(ch):
        # _validated_sources pode gastar alguns segundos em rede. Revalida o
        # dono da sessão depois de cada candidato para não iniciar playback de
        # uma recuperação antiga caso o usuário já tenha escolhido outro canal.
        if _play_session_cancelled(session_state, channel_id, 'apos_validacao_fonte'):
            return 'terminal',attempted,'superseded',cancel_observer
        if _observer_stopped(cancel_observer):
            _log('STOP tardio confirmado durante resolucao do recovery; nova reproducao cancelada')
            return 'terminal',attempted,'stopped',cancel_observer
        any_selected=True
        if live_recovery and not bool(selected.get('is_live')):
            _log('recuperacao live rejeitou manifesto encerrado/nao-live id=%s fonte=%s' % (
                channel_id,selected.get('name')),xbmc.LOGWARNING)
            continue
        attempted+=1
        result,had_format_suspect,stop_observer=_run_source_attempt(
            ch,selected,channel_id,attempted,format_recovery=False,live_recovery=live_recovery)
        if result in ('live_ended','live_error','live_lost'):
            return 'recoverable',attempted,result,stop_observer
        if result=='startup_failed' and had_format_suspect and not is_globorj:
            _log('startup falhou id=%s fonte=%s com extensao suspeita; tentando recuperacao de formato na mesma origem' % (
                channel_id,selected.get('name')),xbmc.LOGWARNING)
            result,_,stop_observer=_run_source_attempt(
                ch,selected,channel_id,attempted,format_recovery=True,live_recovery=live_recovery)
            if result in ('live_ended','live_error','live_lost'):
                return 'recoverable',attempted,result,stop_observer
            if result=='startup_failed':
                _log('recuperacao de formato nao iniciou A/V id=%s fonte=%s; avancando no contrato' % (
                    channel_id,selected.get('name')),xbmc.LOGWARNING)
                continue
            return 'terminal',attempted,result,stop_observer
        if result=='startup_failed':
            _log('startup falhou id=%s fonte=%s; tentando proxima origem NOVA do contrato' % (
                channel_id,selected.get('name')),xbmc.LOGWARNING)
            continue
        return 'terminal',attempted,result,stop_observer
    if _play_session_cancelled(session_state, channel_id, 'fim_contrato'):
        return 'terminal',attempted,'superseded',cancel_observer
    if _observer_stopped(cancel_observer):
        _log('STOP tardio confirmado ao fim da resolucao do recovery; recovery encerrado')
        return 'terminal',attempted,'stopped',cancel_observer
    return ('failed' if any_selected else 'unvalidated'),attempted,None,None


def _recover_live_channel(catalog, ch, channel_id, attempted, reason, stop_observer=None, session_state=None):
    """Recupera somente término involuntário de live já iniciado.

    Nunca é chamado para OnPlayBackStopped. Cada rodada relê o catálogo da
    opção ativa, reexecuta o contrato dinâmico e obriga playlist fresca no
    proxy. Há no máximo duas recuperações consecutivas para uma origem
    instável. Se uma reprodução recuperada permanecer saudável por
    LIVE_RECOVERY_REARM_STABLE, a queda seguinte é um novo incidente e o
    orçamento 1/2 -> 2/2 é rearmado.
    """
    monitor=xbmc.Monitor()
    current=ch
    recovery_no=0
    while True:
        if _play_session_cancelled(session_state, channel_id, 'inicio_recovery'):
            return 'terminal',attempted

        if recovery_no >= LIVE_RECOVERY_MAX:
            _log('recuperacao live esgotada id=%s tentativas=%d; encerrando sem loop' % (
                channel_id,LIVE_RECOVERY_MAX),xbmc.LOGWARNING)
            _notify_source_unavailable((current or ch or {}).get('name','Canal'))
            return 'failed',attempted

        recovery_no += 1
        delay=LIVE_RECOVERY_BACKOFF[min(recovery_no-1,len(LIVE_RECOVERY_BACKOFF)-1)]
        _log('queda involuntaria live id=%s motivo=%s; recuperacao=%d/%d em %.1fs' % (
            channel_id,reason,recovery_no,LIVE_RECOVERY_MAX,delay),xbmc.LOGWARNING)
        wait_state=_wait_recovery_backoff(monitor,delay,stop_observer)
        if wait_state=='abort':
            return 'abort',attempted
        if wait_state=='stopped':
            return 'terminal',attempted
        if _play_session_cancelled(session_state, channel_id, 'apos_backoff'):
            return 'terminal',attempted

        fresh=catalog.refresh_get(channel_id)
        if _play_session_cancelled(session_state, channel_id, 'apos_refresh'):
            return 'terminal',attempted
        if _observer_stopped(stop_observer):
            _log('STOP tardio confirmado apos refresh do catalogo; recovery cancelado')
            return 'terminal',attempted
        if not fresh:
            _log('recuperacao live id=%s tentativa=%d/%d sem catalogo fresco' % (
                channel_id,recovery_no,LIVE_RECOVERY_MAX),xbmc.LOGWARNING)
            continue
        fresh=dict(fresh)
        # O refresh do catálogo renova o contrato de rede; metadados já obtidos
        # localmente (EPG) continuam válidos para o ListItem recuperado.
        if (current or {}).get('_epg_plot'):
            fresh['_epg_plot']=(current or {}).get('_epg_plot')

        old_host=urlparse(str((current or {}).get('api_url') or '')).netloc
        new_host=urlparse(str(fresh.get('api_url') or '')).netloc
        _log('recuperacao live id=%s tentativa=%d/%d contrato_fresco host_antigo=%s host_novo=%s' % (
            channel_id,recovery_no,LIVE_RECOVERY_MAX,old_host or '-',new_host or '-'),xbmc.LOGWARNING)
        current=fresh

        state,attempted,new_reason,new_observer=_try_channel_contract(
            fresh,channel_id,attempted,live_recovery=True,cancel_observer=stop_observer,
            session_state=session_state)
        if state=='terminal':
            # Stop do usuário ou nova sessão que permaneceu até término terminal.
            return 'terminal',attempted
        if state=='recoverable':
            reason=new_reason or reason
            stop_observer=new_observer
            try:
                stable_seconds=float(getattr(new_observer,'_oneplay_live_stable_seconds',0.0) or 0.0)
            except Exception:
                stable_seconds=0.0
            if stable_seconds >= LIVE_RECOVERY_REARM_STABLE:
                _log('recuperacao live estabilizada id=%s duracao=%.1fs >= %.1fs; contador rearmado 0/%d' % (
                    channel_id,stable_seconds,LIVE_RECOVERY_REARM_STABLE,LIVE_RECOVERY_MAX),xbmc.LOGWARNING)
                recovery_no=0
            else:
                _log('recuperacao live voltou a cair id=%s duracao=%.1fs < %.1fs; mantendo contador=%d/%d' % (
                    channel_id,stable_seconds,LIVE_RECOVERY_REARM_STABLE,recovery_no,LIVE_RECOVERY_MAX),xbmc.LOGWARNING)
            continue
        _log('recuperacao live id=%s tentativa=%d/%d sem fonte HLS valida; aguardando proxima rodada' % (
            channel_id,recovery_no,LIVE_RECOVERY_MAX),xbmc.LOGWARNING)


def _play_channel_impl(handle, channel_id, catalog=None, session_state=None):
    catalog = catalog or Catalog()
    ch=catalog.get(channel_id)
    if ch:
        _prepare_dialog_update(ch.get('name',channel_id), ready=False)
        _startup_lock_update_name(ch.get('name',channel_id))
        epg_id = str(ch.get('epg_id') or '').strip()
        if not epg_id and str(ch.get('_oneplay_source') or '') != 'option1':
            epg_id = str(channel_id or '').strip()
        if epg_id:
            try:
                from .epg import EpgGuide
                # Playback nunca abre uma segunda consulta de rede: apenas
                # reaproveita o cache carregado ao montar a grade.
                epg_info=EpgGuide(allow_network=False).info(epg_id)
                ch=dict(ch)
                ch['_epg_plot']=_public_text(epg_info.get('plot'),multiline=True)
            except Exception:
                pass
    if not ch:
        xbmcgui.Dialog().notification('OnePlay Live','Canal não encontrado.',xbmcgui.NOTIFICATION_ERROR,4000)
        return

    attempted=0
    state,attempted,reason,stop_observer=_try_channel_contract(ch,channel_id,attempted,session_state=session_state)
    if state=='terminal':
        return
    if state=='recoverable':
        _recover_live_channel(catalog,ch,channel_id,attempted,reason,stop_observer,session_state=session_state)
        return

    # Se o catálogo rotacionou URL ou conjunto oficial de domínios enquanto o
    # menu estava em cache, atualiza uma vez e repete somente contrato novo.
    old_url=str(ch.get('api_url') or '')
    old_contract=str(ch.get('_contract_signature') or old_url)
    fresh=catalog.refresh_get(channel_id)
    new_url=str((fresh or {}).get('api_url') or '')
    new_contract=str((fresh or {}).get('_contract_signature') or new_url)
    if fresh and new_url and new_contract!=old_contract:
        _log('contrato rotacionado id=%s host_antigo=%s host_novo=%s; nova tentativa de startup' % (
            channel_id,urlparse(old_url).netloc,urlparse(new_url).netloc),xbmc.LOGWARNING)
        state,attempted,reason,stop_observer=_try_channel_contract(fresh,channel_id,attempted,session_state=session_state)
        if state=='terminal':
            return
        if state=='recoverable':
            _recover_live_channel(catalog,fresh,channel_id,attempted,reason,stop_observer,session_state=session_state)
            return
    elif fresh:
        _log('refresh API manteve mesma URL id=%s; não repetindo fonte idêntica' % channel_id)

    _log('todas as fontes NOVAS falharam id=%s fontes_validadas=%d' % (channel_id,attempted),xbmc.LOGWARNING)
    _notify_source_unavailable(ch.get('name','Canal'))


def play_channel(handle, channel_id, catalog=None):
    session_state = _play_session_register(channel_id)
    try:
        return _play_channel_impl(handle, channel_id, catalog=catalog, session_state=session_state)
    finally:
        _play_session_clear(session_state)
        _prepare_dialog_close('play_channel_exit')
