# -*- coding: utf-8 -*-
import os
import socket
import threading
import sys
import time
from six import PY3
if PY3:
    from urllib.parse import urlparse, parse_qs, quote, unquote, unquote_plus, quote_plus
else:
    from urlparse import urlparse, parse_qs
    from urllib import quote, unquote, unquote_plus, quote_plus
import re
from doh_client import requests
import logging
import base64
import random
import binascii

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Evento para sinalizar parada do servidor
stop_event = threading.Event()

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('10.255.255.255', 1))
        local_ip = s.getsockname()[0]
    except Exception:
        local_ip = '127.0.0.1'
    finally:
        try:
            s.close()
        except:
            pass
    return local_ip

def log(msg):   
    logger.info(msg)    

HOST_NAME = get_local_ip()
PORT_NUMBER = 57340

url_proxy = 'http://'+HOST_NAME+':'+str(PORT_NUMBER)+'/?url='

global MAX_RETRY, URL_BASE, LAST_URL, HEADERS_BASE, STOP_SERVER, CACHE_CHUNKS, CACHE_M3U8
global DELAY_MODE, RESOLUTION, LAST_M3U8, PARAMS, URL_BASE_PARAMS, CHECK_URL_PARAMS
global URL_BASE_STALKER, TOKEN_STALKER, NSPLAYER

MAX_RETRY = 28
DELAY_MODE = True
URL_BASE = ''
URL_BASE_PARAMS = ''
LAST_URL = ''
HEADERS_BASE = {}
STOP_SERVER = False
CACHE_CHUNKS = []
CACHE_M3U8 = ''
RESOLUTION = True
LAST_M3U8 = ''
PARAMS = ''
CHECK_URL_PARAMS = True
URL_BASE_STALKER = ''
TOKEN_STALKER = ''
NSPLAYER = False

def gerar_ip_brasileiro():
    ranges = [
        (167772160, 184549375),   # 10.0.0.0 – 10.255.255.255
        (1879048192, 1884162559), # 112.0.0.0 – 112.63.255.255
        (2896692480, 2896702975), # 172.16.0.0 – 172.31.255.255
        (3232235520, 3232301055)  # 192.168.0.0 – 192.168.255.255
    ]
    faixa = random.choice(ranges)
    ip_numerico = random.randint(faixa[0], faixa[1])
    ip = ".".join([str((ip_numerico >> (i * 8)) & 0xFF) for i in range(4)[::-1]])
    return ip

class XtreamCodes:
    def update_headers(self):
        global HEADERS_BASE, NSPLAYER
        header = HEADERS_BASE
        header.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36',
            'Accept-Encoding': 'gzip, deflate',
            'Accept': '*/*',
            'Connection': 'keep-alive'
        })
        if NSPLAYER:
            header['User-Agent'] = binascii.b2a_hex(os.urandom(20))[:32]
        return header

    def basename(self, p):
        i = p.rfind('/') + 1
        return p[i:]

    def convert_to_m3u8(self, url):
        if '|' in url:
            url = url.split('|')[0]
        elif '%7C' in url:
            url = url.split('%7C')[0]
        if not '.m3u8' in url and not '/hl' in url and int(url.count("/")) > 4 and not '.mp4' in url and not '.avi' in url:
            parsed_url = urlparse(url)
            try:
                host_part1 = '%s://%s' % (parsed_url.scheme, parsed_url.netloc)
                host_part2 = url.split(host_part1)[1]
                url = host_part1 + '/live' + host_part2
                file = self.basename(url)
                if '.ts' in file:
                    file_new = file.replace('.ts', '.m3u8')
                    url = url.replace(file, file_new)
                else:
                    url = url + '.m3u8'
            except:
                pass
        return url

    def set_headers(self, url):
        global URL_BASE, HEADERS_BASE, PARAMS
        headers_default = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive'
        }
        headers = {}
        if 'User-Agent' in url:
            try:
                user_agent = url.split('User-Agent=')[1]
                try:
                    user_agent = user_agent.split('&')[0]
                except:
                    pass
                user_agent = unquote_plus(user_agent) if PY3 else unquote(user_agent)
                if 'Mozilla' in user_agent:
                    headers['User-Agent'] = user_agent
            except:
                pass
        if 'Referer' in url:
            try:
                referer = url.split('Referer=')[1]
                try:
                    referer = referer.split('&')[0]
                except:
                    pass
                referer = unquote_plus(referer) if PY3 else unquote(referer)
                headers['Referer'] = referer
            except:
                pass
        if 'Origin' in url:
            try:
                origin = url.split('Origin=')[1]
                try:
                    origin = origin.split('&')[0]
                except:
                    pass
                origin = unquote_plus(origin) if PY3 else unquote(origin)
                headers['Origin'] = origin
            except:
                pass
        if headers:
            headers.update({'Connection': 'keep-alive'})
            HEADERS_ = headers
        else:
            HEADERS_ = headers_default
        if not HEADERS_BASE:
            HEADERS_BASE = HEADERS_

    def base_url(self, url):
        global HEADERS_BASE
        header_ = self.update_headers()
        try:
            for i in range(7):
                r = requests.get(url, headers=header_, timeout=3, verify=False)
                if r.status_code == 200:
                    url = r.url
                else:
                    break
        except:
            pass
        filename = url.split('/')[-1]
        if not '.m3u8' in filename:
            url = url.split('?')[0]
            filename = url.split('/')[-1]
            url = url.split(filename)[0]
        else:
            url = url.replace(filename, '')
        return url

    def base_url_params(self, url):
        global HEADERS_BASE
        header_ = self.update_headers()
        try:
            for i in range(7):
                r = requests.get(url, headers=header_, timeout=3, verify=False)
                if r.status_code == 200:
                    url = r.url
                    break
        except:
            pass
        filename = url.split('/')[-1]
        if not '.m3u8' in filename:
            url = url.split('?')[0]
            filename = url.split('/')[-1]
            url = url.split(filename)[0]
        else:
            url = url.replace(filename, '')
        return url

    def get_filename_params(self, url):
        if '.m3u8' in url:
            try:
                filename = url.split('.m3u8')[0].split('/')[-1] + '.m3u8'
                url = filename + url.split(filename)[1]
            except:
                pass
        return url

    def check_url_params(self, url):
        global URL_BASE_PARAMS, HEADERS_BASE, CHECK_URL_PARAMS
        baseurl = url
        if URL_BASE_PARAMS:
            url = URL_BASE_PARAMS + self.get_filename_params(url)
            if '.m3u8' in url and CHECK_URL_PARAMS:
                try:
                    r = requests.get(url, headers=HEADERS_BASE, timeout=3, verify=False)
                    if r.status_code == 200:
                        CHECK_URL_PARAMS = False
                        return url
                except:
                    pass
        return baseurl

    def make_m3u8(self, m3u):
        padrao = r'#EXTINF:\d+\.\d+,\n/hl.+?/[^/]+\d+\.ts\?[^#]+'
        padrao2 = r'#EXTINF:\d+\.\d+,\n/hl.+?/[^/]+\d+\.ts'
        resultados = re.findall(padrao, m3u)
        if not resultados:
            resultados = re.findall(padrao2, m3u)
        if resultados:
            base_m3u = m3u.split('#EXTINF')[0]
            duas_ultimas_linhas = resultados[-1:]
            for linha in duas_ultimas_linhas:
                base_m3u += linha
            m3u = base_m3u
        return m3u

    def magical_hls(self, url):
        global DELAY_MODE
        if '/hl' in url and not 'https' in url:
            segment = re.findall('ls/(.*?).ts', url)
            segment2 = re.findall('/(.*?).ts', url)
            if segment and DELAY_MODE:
                try:
                    s = segment[0]
                    file, part = s.split('_')
                    part = int(part) - 1
                    new_s = file + '_' + str(part)
                    url = url.replace(s, new_s)
                except:
                    pass
            elif segment2 and DELAY_MODE:
                try:
                    s = segment2[0]
                    file, part = s.split('_')
                    part = int(part) - 1
                    new_s = file + '_' + str(part)
                    url = url.replace(s, new_s)
                except:
                    pass
        return url

    def get_max_m3u8(self, src):
        global URL_BASE
        try:
            regex1 = r"RESOLUTION=(\d+x\d+).*\n(.+\.m3u8.+)"
            regex2 = r"RESOLUTION=(\d+x\d+).*\n(.+\.m3u8)"
            matches = re.findall(regex1, src)
            if not matches:
                matches = re.findall(regex2, src)
            max_resolution_url = max(matches, key=lambda x: tuple(map(int, x[0].split('x'))))
            url = URL_BASE + max_resolution_url[1]
        except:
            url = ''
        return url

    def send_m3u8(self, client_socket, url):
        global MAX_RETRY, URL_BASE, LAST_URL, HEADERS_BASE, STOP_SERVER, CACHE_CHUNKS, CACHE_M3U8
        global DELAY_MODE, RESOLUTION, LAST_M3U8, PARAMS, URL_BASE_PARAMS, CHECK_URL_PARAMS, NSPLAYER
        try:
            url = url.split('|')[0]
        except:
            pass
        try:
            url = url.split('%7C')[0]
        except:
            pass
        if url:
            # envia cabecalho
            response = b'HTTP/1.1 200 OK\r\nContent-Type: application/x-mpegURL\r\n\r\n'
            client_socket.sendall(response)
        URL_PLAY = url
        if not URL_BASE:
            URL_BASE = self.base_url(url)
            LAST_URL = url
        elif URL_BASE:
            if 'http' in url:
                last_parse = urlparse(LAST_URL)
                last_host = '%s://%s' % (last_parse.scheme, last_parse.netloc)
                url_parse = urlparse(url)
                url_host = '%s://%s' % (url_parse.scheme, url_parse.netloc)
                if last_host != url_host:
                    URL_BASE = self.base_url(url)
        if not 'http' in url:
            if url.startswith('/'):
                url = url[1:]
                #log('URL DO NO HTTP: %s' % url)
        if PARAMS and not '?' in url:
            url = url + PARAMS
            #log('URL DO PARAMS: %s' % url)
        if not URL_BASE_PARAMS and '?' in url:
            URL_BASE_PARAMS = self.base_url_params(url)
        if URL_BASE_PARAMS:
            url = self.check_url_params(url)
            #log('URL DO BASE PARAMS: %s' % url)
        #DNSOverride()
        for i in range(MAX_RETRY):
            count = i + 1
            if STOP_SERVER or stop_event.is_set():
                break
            #log('URL POS PROCESSAMENTO: %s' % url)
            header_ = self.update_headers()
            if RESOLUTION:
                try:
                    r = requests.get(url, headers=header_, allow_redirects=True, timeout=2, verify=False)
                    code = r.status_code
                    log('Status Code: %s' % str(code))
                    if code == 200:
                        src = r.text
                        if '.m3u8' in src and 'RESOLUTION' in src:
                            url = self.get_max_m3u8(src)
                            log('URL DO GET MAX M3U8: %s' % url)
                            LAST_M3U8 = url
                except:
                    pass
                RESOLUTION = False
            if LAST_M3U8:
                url = LAST_M3U8
                #log('URL DO LAST M3U8: %s' % url)
            if PARAMS and not '?' in url:
                url = url + PARAMS
                #log('URL DO PARAMS: %s' % url)
            try:
                #log('URL FINAL DO M3U: %s' % url)
                log('USER-AGENT: {0}'.format(header_.get('User-Agent', '')))
                r = requests.get(url, headers=header_, allow_redirects=True, timeout=4, verify=False)
                code = r.status_code
                #log('HEADERS: %s' % str(header_))
                #log('URL M3U8: %s' % str(url))
                #log('Status Code: %s' % str(code))
                if code == 200:
                    NSPLAYER = False
                    src = r.text
                    if 'http' in src:
                        url_proxy = 'http://%s:%s/?url=http' % (HOST_NAME, PORT_NUMBER)
                        src = src.replace('http', url_proxy)
                    if '/live/' in url and url.count('/') == 6:
                        try:
                            CACHE_M3U8 = self.make_m3u8(src)
                        except:
                            pass
                    src = src.encode('utf-8') if PY3 else src
                    #response = b'HTTP/1.1 200 OK\r\nContent-Type: application/x-mpegURL\r\n\r\n' + src
                    #client_socket.sendall(response)
                    client_socket.sendall(src)
                    return
                else:
                    NSPLAYER = True
                    if '/live/' in url and url.count('/') == 6 and CACHE_M3U8:
                        src = CACHE_M3U8
                        src = src.encode('utf-8') if PY3 else src
                        #response = b'HTTP/1.1 200 OK\r\nContent-Type: application/x-mpegURL\r\n\r\n' + src
                        #client_socket.sendall(response)
                        client_socket.sendall(src)
                        return
            except:
                NSPLAYER = True
        response = b'HTTP/1.1 500 Internal Server Error\r\n\r\n'
        client_socket.sendall(response)

    def send_ts(self, client_socket, url):
        global MAX_RETRY, URL_BASE, LAST_URL, HEADERS_BASE, STOP_SERVER, CACHE_CHUNKS, CACHE_M3U8
        global DELAY_MODE, RESOLUTION, LAST_M3U8, PARAMS, URL_BASE_PARAMS, CHECK_URL_PARAMS
        global NSPLAYER
        if '.ts' in url or '/hl' in url and not '.ts' in url:
            client_socket.sendall(b'HTTP/1.1 200 OK\r\nContent-Type: video/mp2t\r\n\r\n')
            if url.startswith('/') and not '/hl' in url:
                url = url[1:]
                ts = URL_BASE + url
            elif url.startswith('/'):
                url = url[1:]
                if 'https' in URL_BASE:
                    ts = 'https://' + URL_BASE.split('/')[2] + '/' + url
                else:
                    ts = 'http://' + URL_BASE.split('/')[2] + '/' + url
            for i in range(MAX_RETRY):
                count = i + 1
                if STOP_SERVER or stop_event.is_set():
                    break

                try:
                    header_ = self.update_headers()
                    log('USER-AGENT: {0}'.format(header_.get('User-Agent', '')))
                    r = requests.get(ts, headers=header_, allow_redirects=True, stream=True, verify=False)
                    code = r.status_code
                    log('Status Code: %s' % str(code))
                    if code == 200:
                        NSPLAYER = False
                        CACHE_CHUNKS = []
                        for chunk in r.iter_content(50*1024):
                            if stop_event.is_set():
                                break
                            try:
                                client_socket.sendall(chunk)
                                CACHE_CHUNKS.append(chunk)
                            except:
                                pass
                        return
                    else:
                        NSPLAYER = True
                        if i == 0:
                            DELAY_MODE = False
                        if CACHE_CHUNKS:
                            #client_socket.sendall(b'HTTP/1.1 200 OK\r\nContent-Type: video/mp2t\r\n\r\n')
                            client_socket.sendall(CACHE_CHUNKS[-1])
                            return
                except:
                    NSPLAYER = True
        response = b'HTTP/1.1 500 Internal Server Error\r\n\r\n'
        client_socket.sendall(response)

    def parse_url(self, url):
        parsed_url = urlparse(url)
        scheme = parsed_url.scheme
        host = parsed_url.hostname
        port = parsed_url.port
        return scheme, host, port

    def send_m3u8_stalker(self, client_socket, url):
        global URL_BASE_STALKER, TOKEN_STALKER, NSPLAYER
        if 'm3u8' in url:
            if not URL_BASE_STALKER:
                header_ = self.update_headers()
                try:
                    r = requests.get(url, headers=header_, allow_redirects=True, timeout=4, verify=False)
                    url = r.url
                except:
                    pass
                scheme, host, port = self.parse_url(url)
                if port:
                    URL_BASE_STALKER = scheme + '://' + host + ':' + str(port)
                else:
                    URL_BASE_STALKER = scheme + '://' + host
            if not TOKEN_STALKER:
                if '?' in url:
                    try:
                        TOKEN_STALKER = url.split('?')[1]
                    except:
                        pass
            for i in range(MAX_RETRY):
                count = i + 1
                if STOP_SERVER or stop_event.is_set():
                    break
                try:
                    header_ = self.update_headers()
                    log('USER-AGENT: {0}'.format(header_.get('User-Agent', '')))
                    r = requests.get(url, headers=header_, allow_redirects=True, timeout=4, verify=False)
                    code = r.status_code
                    log('Status Code: %s' % str(code))
                    if code == 200:
                        NSPLAYER = False
                        src = r.text
                        try:
                            CACHE_M3U8 = self.make_m3u8(src)
                        except:
                            pass
                        src = src.encode('utf-8') if PY3 else src
                        response = b'HTTP/1.1 200 OK\r\nContent-Type: application/x-mpegURL\r\n\r\n' + src
                        client_socket.sendall(response)
                        return
                    else:
                        NSPLAYER = True
                        if CACHE_M3U8:
                            src = CACHE_M3U8
                            src = src.encode('utf-8') if PY3 else src
                            response = b'HTTP/1.1 200 OK\r\nContent-Type: application/x-mpegURL\r\n\r\n' + src
                            client_socket.sendall(response)
                            return
                except:
                    NSPLAYER = True
        response = b'HTTP/1.1 500 Internal Server Error\r\n\r\n'
        client_socket.sendall(response)

    def send_ts_stalker(self, client_socket, url):
        global MAX_RETRY, URL_BASE, LAST_URL, HEADERS_BASE, STOP_SERVER, CACHE_CHUNKS, CACHE_M3U8
        global DELAY_MODE, RESOLUTION, LAST_M3U8, PARAMS, URL_BASE_PARAMS, CHECK_URL_PARAMS
        global URL_BASE_STALKER, TOKEN_STALKER, NSPLAYER
        if '.ts' in url and URL_BASE_STALKER:
            ts = URL_BASE_STALKER + url
            for i in range(MAX_RETRY):
                count = i + 1
                if STOP_SERVER or stop_event.is_set():
                    break
                try:
                    header_ = self.update_headers()
                    log('USER-AGENT: {0}'.format(header_.get('User-Agent', '')))
                    r = requests.get(ts, headers=header_, allow_redirects=True, stream=True, verify=False)
                    code = r.status_code
                    log('Status Code: %s' % str(code))
                    if code == 200:
                        NSPLAYER = False
                        CACHE_CHUNKS = []
                        client_socket.sendall(b'HTTP/1.1 200 OK\r\nContent-Type: video/mp2t\r\n\r\n')
                        for chunk in r.iter_content(50*1024):
                            if stop_event.is_set():
                                break
                            try:
                                client_socket.sendall(chunk)
                                CACHE_CHUNKS.append(chunk)
                            except:
                                pass
                        return
                    else:
                        NSPLAYER = True
                        if i == 0:
                            DELAY_MODE = False
                        if CACHE_CHUNKS:
                            client_socket.sendall(b'HTTP/1.1 200 OK\r\nContent-Type: video/mp2t\r\n\r\n')
                            client_socket.sendall(CACHE_CHUNKS[-1])
                            return
                except:
                    NSPLAYER = True
        response = b'HTTP/1.1 500 Internal Server Error\r\n\r\n'
        client_socket.sendall(response)

    def stream_video(self, client_socket, url, headers):
        try:
            url = url.split('|')[0]
        except:
            pass
        try:
            url = url.split('%7C')[0]
        except:
            pass
        global HEADERS_BASE
        headers_base = HEADERS_BASE
        try:
            response = requests.head(url, headers=headers_base)
            if response.status_code == 200:
                content_length = int(response.headers.get('Content-Length', 0))
                start, end = self.get_range(headers, content_length)
                headers_base['Range'] = 'bytes=%s-%s' % (str(start), str(end))
                response = requests.get(url, headers=headers_base, stream=True)
                if response.status_code == 206 or response.status_code == 200:
                    self.sendall_partial_response(client_socket, 206, response.headers, content_length, response.iter_content(chunk_size=1024), start, end)
                else:
                    client_socket.sendall(b'HTTP/1.1 404 Not Found\r\n\r\n')
            else:
                client_socket.sendall(b'HTTP/1.1 404 Not Found\r\n\r\n')
        except:
            client_socket.sendall(b'HTTP/1.1 500 Internal Server Error\r\n\r\n')

    def get_range(self, headers, content_length):
        range_header = headers.get('Range') or headers.get('range')
        if range_header:
            parts = range_header.split('-')
            start = int(parts[0].split('=')[-1])
            end = int(parts[1]) if parts[1] else content_length - 1
            return start, end
        return 0, content_length - 1

    def send_partial_response(self, client_socket, status_code, headers, content_length, content_generator, start, end):
        status = '206 Partial Content' if status_code == 206 else '200 OK'
        response = 'HTTP/1.1 %s\r\nAccept-Ranges: bytes\r\nContent-Range: bytes %s-%s/%s\r\n' % (status, start, end, content_length)
        for key, value in headers.items():
            response += '%s: %s\r\n' % (key, value)
        response += '\r\n'
        client_socket.sendall(response.encode('utf-8') if PY3 else response)
        for chunk in content_generator:
            if STOP_SERVER or stop_event.is_set():
                break
            try:
                client_socket.sendall(chunk)
            except:
                pass

class ProxyHandler(XtreamCodes):
    def handle_client(self, client_socket, address):
        global URL_BASE, LAST_URL, HEADERS_BASE, STOP_SERVER, CACHE_CHUNKS, CACHE_M3U8
        global DELAY_MODE, RESOLUTION, LAST_M3U8, PARAMS, URL_BASE_PARAMS, CHECK_URL_PARAMS
        global URL_BASE_STALKER, TOKEN_STALKER
        try:
            # Read HTTP request
            client_socket.settimeout(5)
            data = client_socket.recv(4096)
            if not data:
                return
            request = data.decode('utf-8', errors='ignore')
            # Parse request
            lines = request.split('\r\n')
            if not lines:
                return
            request_line = lines[0].split()
            if len(request_line) < 2:
                return
            method, path = request_line[0], request_line[1]
            # if method != 'GET':
            #     client_socket.sendall(b'HTTP/1.1 405 Method Not Allowed\r\n\r\n')
            #     return
            # Parse headers
            headers = {}
            for line in lines[1:]:
                if ': ' in line:
                    key, value = line.split(': ', 1)
                    headers[key] = value
            path = unquote_plus(path)
            if path == "/stop":
                global STOP_SERVER
                STOP_SERVER = True
                stop_event.set()
                URL_BASE = ''
                LAST_URL = ''
                HEADERS_BASE = {}
                CACHE_CHUNKS = []
                CACHE_M3U8 = ''
                DELAY_MODE = True
                LAST_M3U8 = ''
                RESOLUTION = True
                PARAMS = ''
                CHECK_URL_PARAMS = True
                URL_BASE_STALKER = ''
                TOKEN_STALKER = ''
                response = b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\nServer stopping...'
                client_socket.sendall(response)
                return
            elif path == "/reset":
                URL_BASE = ''
                LAST_URL = ''
                HEADERS_BASE = {}
                CACHE_CHUNKS = []
                CACHE_M3U8 = ''
                DELAY_MODE = True
                RESOLUTION = True
                LAST_M3U8 = ''
                PARAMS = ''
                URL_BASE_PARAMS = ''
                CHECK_URL_PARAMS = True
                URL_BASE_STALKER = ''
                TOKEN_STALKER = ''
                response = b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\nServer reset'
                client_socket.sendall(response)
                return
            elif path == '/check':
                response = b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\nHello, world!'
                client_socket.sendall(response)
                return
            else:
                if method != 'GET':
                    client_socket.sendall(b'HTTP/1.1 405 Method Not Allowed\r\n\r\n')
                    return
                url_parts = urlparse(path)
                query_params = parse_qs(url_parts.query)
                if 'url' in query_params:
                    url = path.split('url=')[1]
                    try:
                        url = url.split('|')[0]
                    except:
                        pass
                    try:
                        url = url.split('%7C')[0]
                    except:
                        pass
                    url = self.convert_to_m3u8(url)
                else:
                    url = path
                self.set_headers(url)
                if '.m3u8' in url and '?' in url and not 'extension' in url:
                    if not PARAMS:
                        try:
                            PARAMS = '?' + url.split('?')[1]
                        except:
                            pass
                # STALKER
                if '/hl' in url and '.ts' in url:
                    self.send_ts(client_socket, url)
                elif '/hl' in url and not '.ts' in url:
                    self.send_ts(client_socket, url)
                elif 'm3u8' in url and not 'extension' in url and '/play/' in url and not '.m3u8' in url:
                    self.send_m3u8_stalker(client_socket, url)
                elif 'm3u8' in url and 'extension' in url:
                    client_socket.sendall(b'HTTP/1.1 200 OK\r\n\r\n')
                elif '.ts' in url and URL_BASE_STALKER or 'hls' in url and URL_BASE_STALKER:
                    self.send_ts_stalker(client_socket, url)
                # XTREAM CODES
                elif '.mp4' in url and not '.m3u8' in url and not '.ts' in url:
                    self.stream_video(client_socket, url, headers)
                elif '.m3u8' in url:
                    self.send_m3u8(client_socket, url)
                elif '.ts' in url:
                    self.send_ts(client_socket, url)
                else:
                    client_socket.sendall(b'HTTP/1.1 404 Not Found\r\n\r\n')
        except Exception as e:
            log('Error handling client: {0}'.format(str(e)))
            client_socket.sendall(b'HTTP/1.1 500 Internal Server Error\r\n\r\n')
        finally:
            try:
                client_socket.close()
            except:
                pass

def monitor():
    try:
        try:
            from kodi_six import xbmc
        except:
            import xbmc
        monitor = xbmc.Monitor()
        while not monitor.waitForAbort(3) and not stop_event.is_set():
            pass
        log('Encerrando proxy server via monitor')
        url = 'http://{0}:{1}/stop'.format(HOST_NAME, PORT_NUMBER)
        try:
            requests.get(url, timeout=4)
        except:
            pass
        log('Proxy encerrado')
    except Exception as e:
        log('Erro no monitor: {0}'.format(str(e)))

class SocketServer:
    def __init__(self):
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((HOST_NAME, PORT_NUMBER))
        self.server_socket.listen(5)
        self.active = True

    def serve_forever(self):
        global STOP_SERVER
        log('Server started on http://{0}:{1}'.format(HOST_NAME, PORT_NUMBER))
        try:
            while not stop_event.is_set():
                self.server_socket.settimeout(1)  # Allow checking for shutdown
                try:
                    client_socket, address = self.server_socket.accept()
                    handler = threading.Thread(target=ProxyHandler().handle_client, args=(client_socket, address))
                    if PY3:
                        handler.daemon = True
                    else:
                        handler.setDaemon(True)
                    handler.start()
                except socket.timeout:
                    continue
                except Exception as e:
                    log('Error accepting connection: {0}'.format(str(e)))
                    if stop_event.is_set():
                        break
        except KeyboardInterrupt:
            pass
        finally:
            self.stop_server()

    def stop_server(self):
        try:
            self.active = False
            self.server_socket.close()
            stop_event.set()
            log('Servidor socket encerrado')
        except Exception as e:
            log('Error closing socket server: {0}'.format(str(e)))

def loop_server():
    server = SocketServer()
    server.serve_forever()

class XtreamProxy:
    def reset(self):
        try:
            url = 'http://{0}:{1}/reset'.format(HOST_NAME, PORT_NUMBER)
            requests.get(url, timeout=3)
            log('Proxy resetado')
        except Exception as e:
            log('Erro ao resetar proxy: {0}'.format(str(e)))

    def check_service(self):
        try:
            url = 'http://{0}:{1}/check'.format(HOST_NAME, PORT_NUMBER)
            r = requests.head(url, timeout=3)
            return r.status_code == 200
        except:
            return False

    def start_(self):
        log('Iniciando Xtream Proxy - HLSRETRY')
        status = self.check_service()
        if not status:
            proxy_service = threading.Thread(target=loop_server)         
            monitor_service = threading.Thread(target=monitor)
            if PY3:
                proxy_service.daemon = True
                monitor_service.daemon = True
            else:
                proxy_service.setDaemon(True)
                monitor_service.daemon = True
            proxy_service.start()               
            monitor_service.start()
            log('Proxy iniciado em: {0}'.format(url_proxy))
            while not stop_event.is_set():
                time.sleep(1)
        else:
            self.reset()
        
    def start(self):
        threading.Thread(target=self.start_).start()

# if __name__ == '__main__':
#     XtreamProxy().start()
#     print('teste')