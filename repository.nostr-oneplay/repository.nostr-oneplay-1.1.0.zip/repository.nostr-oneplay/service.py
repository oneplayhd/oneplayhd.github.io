import os
import sys

import xbmc
import xbmcaddon
import xbmcvfs

HERE = os.path.dirname(os.path.abspath(__file__))
LIB = os.path.join(HERE, "resources", "lib")
for path in (LIB,):
    if path not in sys.path:
        sys.path.insert(0, path)

import bridge
import dns
from ngnostr import normalize_relay_list
from blossom import normalize_blossom_list


def _split(value):
    parts = str(value or "").replace("\n", ",").split(",")
    return [part.strip() for part in parts if part.strip()]


def _int_setting(value, fallback):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return fallback


def _bool_setting(value, fallback):
    if value is None or str(value).strip() == "":
        return fallback
    return str(value).strip().lower() in ("true", "1")


def read_config(addon, log):
    relays = normalize_relay_list(_split(addon.getSetting("relays")))
    blossom_servers = normalize_blossom_list(_split(addon.getSetting("blossom")))
    sources = _split(addon.getSetting("sources"))
    refresh = _int_setting(addon.getSetting("refresh"), 30)
    return {
        "port": _int_setting(addon.getSetting("port"), bridge.SERVER_PORT_FALLBACK),
        "relays": relays,
        "blossom": blossom_servers,
        "sources": sources,
        "discover": _bool_setting(addon.getSetting("discover"), True),
        "prebuild": _bool_setting(addon.getSetting("prebuild"), True),
        "tag": (addon.getSetting("tag") or "").strip(),
        "refreshMinutes": max(1, refresh),
        "timeout": 9.0,
    }


def main():
    addon = xbmcaddon.Addon()
    addon_id = addon.getAddonInfo("id")
    addon_name = addon.getAddonInfo("name")

    def log(message):
        xbmc.log("[%s] %s" % (addon_id, message), level=xbmc.LOGINFO)

    log("service starting (%s)" % addon_name)
    config = read_config(addon, log)
    data_dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    try:
        os.makedirs(data_dir, exist_ok=True)
    except OSError:
        pass
    dns_cache_file = os.path.join(data_dir, "dns_cache.json")
    if dns.apply_configured_override(dns_cache_file):
        log("alternative DNS active (system DNS bypassed)")
    else:
        log("system DNS in use")
    instance = bridge.make_bridge(config, data_dir, log=log)
    monitor = xbmc.Monitor()
    try:
        instance.refresh(force=True)
    except Exception as exc:
        log("initial refresh failed: %s" % exc)
    try:
        instance.start()
    except Exception as exc:
        log("bridge failed to start: %s" % exc)
        return
    try:
        while not monitor.waitForAbort(30):
            try:
                instance.tick()
            except Exception as exc:
                log("tick failed: %s" % exc)
    finally:
        instance.stop()
        dns.disable_customdns()
        log("service stopped")


if __name__ == "__main__":
    main()
