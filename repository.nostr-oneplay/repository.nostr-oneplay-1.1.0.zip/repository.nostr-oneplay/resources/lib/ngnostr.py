import base64
import hashlib
import json
import os
import socket
import ssl
import struct
import threading
import time
from urllib.parse import urlparse

RELAY_TIMEOUT = 9.0
GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

OP_CONT = 0x0
OP_TEXT = 0x1
OP_CLOSE = 0x8
OP_PING = 0x9
OP_PONG = 0xA


class RelayError(Exception):
    pass


class ConnectionClosed(RelayError):
    pass


class ProtocolError(RelayError):
    pass


def normalize_relay_url(value):
    raw = str(value or "").strip()
    if not raw:
        raise ValueError("empty relay url")
    raw = raw.rstrip("/")
    if raw.startswith("wss://") or raw.startswith("ws://"):
        return raw
    if raw.startswith("https://"):
        return "wss://" + raw[len("https://"):]
    if raw.startswith("http://"):
        return "ws://" + raw[len("http://"):]
    return "wss://" + raw


def normalize_relay_list(values):
    result = []
    for value in values or []:
        try:
            url = normalize_relay_url(value)
        except ValueError:
            continue
        if url not in result:
            result.append(url)
    return result


class RelayConnection:
    def __init__(self, relay_url, connect_timeout=7.0):
        parsed = urlparse(relay_url)
        if parsed.scheme not in ("ws", "wss"):
            raise RelayError("relay scheme must be ws or wss: " + relay_url)
        self.relay_url = relay_url
        self.secure = parsed.scheme == "wss"
        self.host = parsed.hostname
        self.path = parsed.path or "/"
        port = parsed.port or (443 if self.secure else 80)
        if not self.host:
            raise RelayError("relay without host: " + relay_url)
        self.socket = socket.create_connection((self.host, port), timeout=connect_timeout)
        self.socket.settimeout(connect_timeout)
        if self.secure:
            context = ssl.create_default_context()
            self.socket = context.wrap_socket(self.socket, server_hostname=self.host)
        self._handshake()

    def _handshake(self):
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        request = (
            "GET %s HTTP/1.1\r\n"
            "Host: %s\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            "Sec-WebSocket-Key: %s\r\n"
            "Sec-WebSocket-Version: 13\r\n"
            "\r\n" % (self.path, self.host, key)
        )
        self.socket.sendall(request.encode("ascii"))
        expected = base64.b64encode(
            hashlib.sha1((key + GUID).encode("ascii")).digest()
        ).decode("ascii")
        buffer = b""
        while b"\r\n\r\n" not in buffer:
            chunk = self.socket.recv(4096)
            if not chunk:
                raise RelayError("relay closed during handshake")
            buffer += chunk
            if len(buffer) > 65536:
                raise RelayError("relay handshake too large")
        header_text = buffer.split(b"\r\n\r\n", 1)[0].decode("latin-1")
        lines = header_text.split("\r\n")
        status = lines[0] if lines else ""
        if " 101 " not in status:
            raise RelayError("relay handshake failed: " + status.strip())
        accept = None
        for line in lines[1:]:
            name, _, value = line.partition(":")
            if name.strip().lower() == "sec-websocket-accept":
                accept = value.strip()
        if accept != expected:
            raise RelayError("relay handshake accept mismatch")

    def _read_exact(self, count):
        buffer = b""
        while len(buffer) < count:
            chunk = self.socket.recv(count - len(buffer))
            if not chunk:
                raise ConnectionClosed("socket closed")
            buffer += chunk
        return buffer

    def _read_frame(self):
        header = self._read_exact(2)
        opcode = header[0] & 0x0F
        masked = bool(header[1] & 0x80)
        length = header[1] & 0x7F
        if length == 126:
            length = struct.unpack(">H", self._read_exact(2))[0]
        elif length == 127:
            length = struct.unpack(">Q", self._read_exact(8))[0]
        if masked:
            mask = self._read_exact(4)
        payload = self._read_exact(length) if length else b""
        if masked:
            payload = bytes(payload[i] ^ mask[i % 4] for i in range(len(payload)))
        return opcode, payload

    def _send_frame(self, opcode, payload=b""):
        mask = os.urandom(4)
        header = bytearray()
        header.append(0x80 | opcode)
        length = len(payload)
        if length < 126:
            header.append(0x80 | length)
        elif length < 65536:
            header.append(0x80 | 126)
            header.extend(struct.pack(">H", length))
        else:
            header.append(0x80 | 127)
            header.extend(struct.pack(">Q", length))
        masked = bytes(payload[i] ^ mask[i % 4] for i in range(length))
        self.socket.sendall(bytes(header) + mask + masked)

    def send_text(self, text):
        self._send_frame(OP_TEXT, text.encode("utf-8"))

    def recv_message(self, deadline):
        buffer = b""
        current_opcode = None
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise RelayError("timeout waiting for relay message")
            self.socket.settimeout(remaining)
            opcode, payload = self._read_frame()
            if opcode == OP_PING:
                self._send_frame(OP_PONG, payload)
                continue
            if opcode == OP_CLOSE:
                raise ConnectionClosed("relay closed connection")
            if opcode == OP_TEXT:
                return payload.decode("utf-8", "replace")
            if opcode == OP_CONT:
                if current_opcode is None:
                    raise ProtocolError("unexpected continuation frame")
                buffer += payload
                return buffer.decode("utf-8", "replace")
            if opcode == OP_PONG:
                continue

    def close(self):
        try:
            self._send_frame(OP_CLOSE, b"")
        except Exception:
            pass
        try:
            self.socket.close()
        except Exception:
            pass


def verify_event_id(event):
    try:
        payload = json.dumps(
            [
                0,
                event["pubkey"],
                event["created_at"],
                event["kind"],
                event["tags"],
                event["content"],
            ],
            separators=(",", ":"),
            ensure_ascii=False,
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest() == event["id"]
    except (KeyError, TypeError, ValueError):
        return False


def query_one_relay(relay_url, filters, deadline):
    events = []
    error = None
    sub = "kodi-repo-" + os.urandom(4).hex()
    opened = False
    try:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise RelayError("timed out before connecting")
        connection = RelayConnection(relay_url, min(remaining, 7.0))
        opened = True
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise RelayError("timed out after connecting")
        connection.socket.settimeout(max(remaining, 0.1))
        connection.send_text(json.dumps(["REQ", sub] + list(filters)))
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                error = "timed out"
                break
            message = connection.recv_message(deadline)
            data = json.loads(message)
            if not isinstance(data, list) or not data:
                continue
            kind = data[0]
            if kind == "EVENT" and len(data) > 2 and data[1] == sub and isinstance(data[2], dict):
                events.append(data[2])
            elif kind == "EOSE" and data[1] == sub:
                break
            elif kind == "CLOSED" and data[1] == sub:
                error = str(data[2]) if len(data) > 2 else "closed"
                break
    except ConnectionClosed:
        if not opened:
            raise
    except (socket.timeout, TimeoutError):
        error = "timed out"
    if opened and (events or error is None):
        return events, error
    if opened:
        return events, error
    raise RelayError(error or "could not connect")


def query_events(relays, filters, timeout=RELAY_TIMEOUT):
    relay_list = normalize_relay_list(relays)[:8]
    results = []
    lock = threading.Lock()
    deadline = time.monotonic() + timeout

    def worker(url):
        try:
            events, error = query_one_relay(url, filters, deadline)
        except Exception as exc:
            events, error = [], str(exc)
        with lock:
            results.append((url, events, error))

    threads = []
    for url in relay_list:
        thread = threading.Thread(target=worker, args=(url,), daemon=True)
        thread.start()
        threads.append(thread)
    for thread in threads:
        thread.join(timeout + 5.0)

    by_id = {}
    for _url, events, _error in results:
        for event in events:
            if not isinstance(event, dict):
                continue
            if not verify_event_id(event):
                continue
            event_id = event["id"]
            current = by_id.get(event_id)
            if current is None or event.get("created_at", 0) > current.get("created_at", 0):
                by_id[event_id] = event
    events_list = sorted(by_id.values(), key=lambda ev: ev.get("created_at", 0), reverse=True)
    reports = [{"url": url, "ok": bool(events), "events": len(events), "error": error}
               for url, events, error in results]
    reports.sort(key=lambda report: report["url"])
    return {"events": events_list, "relays": reports}
