CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"


def polymod(values):
    gen = [0x3B6A57B2, 0x26508E6D, 0x1EA119FA, 0x3D4233DD, 0x2A1462B3]
    chk = 1
    for value in values:
        top = chk >> 25
        chk = (chk & 0x1FFFFFF) << 5 ^ value
        for i in range(5):
            chk ^= gen[i] if ((top >> i) & 1) else 0
    return chk


def hrp_expand(hrp):
    return [ord(x) >> 5 for x in hrp] + [0] + [ord(x) & 31 for x in hrp]


def decode(bech):
    if any(ord(x) < 33 or ord(x) > 126 for x in bech):
        raise ValueError("bech32: invalid characters")
    if bech.lower() != bech and bech.upper() != bech:
        raise ValueError("bech32: mixed case")
    bech = bech.lower()
    pos = bech.rfind("1")
    if pos < 1 or pos + 7 > len(bech) or len(bech) > 96:
        raise ValueError("bech32: invalid length")
    hrp = bech[:pos]
    data = []
    for char in bech[pos + 1:]:
        idx = CHARSET.find(char)
        if idx < 0:
            raise ValueError("bech32: invalid character")
        data.append(idx)
    if polymod(hrp_expand(hrp) + data) != 1:
        raise ValueError("bech32: checksum failed")
    return hrp, data[:-6]


def convertbits(data, frombits, tobits, pad=True):
    acc = 0
    bits = 0
    ret = []
    maxv = (1 << tobits) - 1
    for value in data:
        acc = (acc << frombits) | value
        bits += frombits
        while bits >= tobits:
            bits -= tobits
            ret.append((acc >> bits) & maxv)
    if pad:
        if bits:
            ret.append((acc << (tobits - bits)) & maxv)
    elif bits >= frombits or ((acc << (tobits - bits)) & maxv):
        raise ValueError("bech32: invalid padding")
    return ret


def npub_to_hex(value):
    hrp, words = decode(value)
    if hrp != "npub":
        raise ValueError("bech32: expected npub")
    raw = bytes(convertbits(words, 5, 8, False))
    if len(raw) != 32:
        raise ValueError("bech32: wrong pubkey length")
    return raw.hex().lower()


def hex_to_npub(pubkey_hex):
    raw = bytes.fromhex(pubkey_hex)
    if len(raw) != 32:
        raise ValueError("bech32: wrong pubkey length")
    hrp = "npub"
    words = convertbits(raw, 8, 5, True)
    values = hrp_expand(hrp) + words
    mod = polymod(values + [0, 0, 0, 0, 0, 0]) ^ 1
    checksum = [(mod >> 5 * (5 - i)) & 31 for i in range(6)]
    return hrp + "1" + "".join(CHARSET[d] for d in words + checksum)
