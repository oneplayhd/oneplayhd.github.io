import json

import bech32
import blossom

REPO_ANNOUNCEMENT_KIND = 30617
REPO_STATE_KIND = 30618
NGIT_PROTOCOL = "ngit/1"


def tags_by_name(event):
    tags = event.get("tags") or []
    mapping = {}
    if not isinstance(tags, list):
        return mapping
    for tag in tags:
        if not isinstance(tag, list) or not tag:
            continue
        mapping.setdefault(str(tag[0]), []).append(tag)
    return mapping


def tag_values(mapping, name):
    return [tag[1] for tag in mapping.get(name, []) if len(tag) > 1]


def tag_value(mapping, name):
    values = tag_values(mapping, name)
    return values[0] if values else None


def parse_state_event(event):
    if not isinstance(event, dict) or event.get("kind") != REPO_STATE_KIND:
        return None
    mapping = tags_by_name(event)
    project = tag_value(mapping, "d")
    if not project:
        return None
    branch = tag_value(mapping, "branch")
    if not branch:
        head = tag_value(mapping, "HEAD") or ""
        prefix = "ref: refs/heads/"
        if head.startswith(prefix):
            branch = head[len(prefix):]
    refs = {}
    for key, tags in mapping.items():
        if isinstance(key, str) and key.startswith("refs/heads/"):
            refs[key[len("refs/heads/"):]] = tag_value(mapping, key)
    if not branch and refs:
        branch = sorted(refs.keys())[0]
    commit = tag_value(mapping, "commit")
    if not commit and branch:
        commit = refs.get(branch)
    servers = [str(x).rstrip("/") for x in tag_values(mapping, "blossom")]
    manifest = blossom.parse_descriptor(tag_value_desc(mapping, "manifest"))
    bundle = blossom.parse_descriptor(tag_value_desc(mapping, "bundle"))
    extra_servers = []
    try:
        content = json.loads(event.get("content") or "{}")
        for server in content.get("manifest", {}).get("servers", []):
            extra_servers.append(str(server).rstrip("/"))
    except (ValueError, AttributeError):
        pass
    if not (branch or commit or manifest):
        return None
    return {
        "id": event.get("id"),
        "pubkey": event.get("pubkey"),
        "createdAt": event.get("created_at"),
        "project": project,
        "branch": branch,
        "commit": commit,
        "refs": refs,
        "blossomServers": servers,
        "manifest": manifest,
        "bundle": bundle,
        "extraServers": extra_servers,
        "event": event,
    }


def tag_value_desc(mapping, name):
    for tag in mapping.get(name, []):
        return tag
    return None


def parse_announcement_event(event):
    if not isinstance(event, dict) or event.get("kind") != REPO_ANNOUNCEMENT_KIND:
        return None
    mapping = tags_by_name(event)
    project = tag_value(mapping, "d")
    if not project:
        return None
    return {
        "id": event.get("id"),
        "pubkey": event.get("pubkey"),
        "createdAt": event.get("created_at"),
        "project": project,
        "name": tag_value(mapping, "name") or project,
        "description": str(event.get("content") or ""),
        "relays": tag_values(mapping, "relays"),
        "blossomServers": [str(x).rstrip("/") for x in tag_values(mapping, "blossom")],
        "tags": event.get("tags") or [],
    }


def pick_latest(events, kind, pubkey=None, project=None):
    best = None
    for event in events:
        if kind is not None and event.get("kind") != kind:
            continue
        if pubkey and event.get("pubkey") != pubkey:
            continue
        if project:
            mapping = tags_by_name(event)
            if tag_value(mapping, "d") != project:
                continue
        if best is None or event.get("created_at", 0) > best.get("created_at", 0):
            best = event
    return best


def normalize_pubkey(value):
    raw = str(value or "").strip()
    if not raw:
        raise ValueError("empty pubkey")
    if raw.startswith("npub1"):
        return bech32.npub_to_hex(raw)
    raw = raw.lower()
    if len(raw) == 64:
        try:
            int(raw, 16)
        except ValueError:
            raise ValueError("invalid pubkey")
        return raw
    raise ValueError("provide npub1... or 64 hex chars")


def pubkey_to_npub(pubkey_hex):
    return bech32.hex_to_npub(pubkey_hex)


def parse_nostr_address(value):
    raw = str(value or "").strip()
    if raw.startswith("nostr://"):
        raw = raw[len("nostr://"):]
    elif raw.startswith("ngit://"):
        raw = raw[len("ngit://"):]
    raw = raw.strip("/")
    if not raw:
        raise ValueError("invalid address")
    identity, _, project = raw.partition("/")
    pubkey = normalize_pubkey(identity)
    return {"pubkey": pubkey, "project": project or None}


def parse_sources(values):
    sources = []
    for value in values or []:
        try:
            address = parse_nostr_address(value)
        except ValueError:
            continue
        sources.append(address)
    return sources


def state_filter(pubkeys, projects=None, limit=1000):
    assets = {
        "kinds": [REPO_STATE_KIND],
        "authors": list(pubkeys),
        "limit": int(limit),
    }
    if projects:
        assets["#d"] = list(projects)
    return assets


def announcement_filter(pubkeys, tag=None, limit=300):
    wanted = ["ngit"]
    if tag:
        wanted.append(tag)
    return {
        "kinds": [REPO_ANNOUNCEMENT_KIND],
        "#t": wanted,
        "limit": int(limit),
    }


def announcement_has_tag(event, tag):
    if not tag:
        return True
    return any(isinstance(t, list) and len(t) > 1 and t[0] == "t" and t[1] == tag
               for t in event.get("tags", []))
