# -*- coding: utf-8 -*-
import io
import json
import os
import random
import socket
import struct
import time
import xbmc

DNS_OVERRIDE_SETTING = "dns_override"

_DNS_PATCH_STATE = {
    "installed": False,
    "original_getaddrinfo": socket.getaddrinfo,
    "resolver": None,
    "instance": None,
}


def _dns_debug(message):
    try:
        xbmc.log("DNS: %s" % message, level=xbmc.LOGDEBUG)
    except Exception:
        pass


def _dns_exception(context, exc):
    try:
        xbmc.log("DNS: %s: %s (%s)" % (context, exc, exc.__class__.__name__),
                 level=xbmc.LOGWARNING)
    except Exception:
        pass


class customdns:
    def __init__(self, cache_file, cache_ttl=3600, dns_servers=None):
        self.dns_server = list(dns_servers or [
            "94.140.14.140",   # adguard
            "94.140.14.141",   # adguard
            "208.67.222.222",  # OpenDNS
            "208.67.220.220",  # OpenDNS
            "1.1.1.1",         # Cloudflare
            "8.8.8.8",         # Google DNS
        ])
        self.original_getaddrinfo = _DNS_PATCH_STATE.get(
            "original_getaddrinfo", socket.getaddrinfo
        )
        self.cache_file = cache_file
        self.cache_ttl = cache_ttl
        self.cache = self._load_cache()
        self.negative = {}
        self.negative_ttl = 300.0
        self.mode_logger = False

        # Override DNS only once per runtime. Guardamos a funcao exata para
        # poder restaurar com seguranca se o usuario desligar a opcao depois.
        if not _DNS_PATCH_STATE.get("installed"):
            resolver = self._resolver
            _DNS_PATCH_STATE["original_getaddrinfo"] = socket.getaddrinfo
            _DNS_PATCH_STATE["resolver"] = resolver
            _DNS_PATCH_STATE["instance"] = self
            socket.getaddrinfo = resolver
            _DNS_PATCH_STATE["installed"] = True
        _dns_debug("Override DNS iniciado; servidores configurados={}.".format(len(self.dns_server)))

    def _read_cache_file(self, report_error=False):
        """Le somente entradas DNS ainda validas sem tocar no resolvedor."""
        try:
            if not os.path.exists(self.cache_file):
                return {}
            with io.open(self.cache_file, "r", encoding="utf-8") as handle:
                cache = json.load(handle)
            if not isinstance(cache, dict):
                return {}
            now = time.time()
            return {
                domain: data for domain, data in cache.items()
                if isinstance(data, dict) and float(data.get("expires", 0) or 0) > now
            }
        except Exception as exc:
            if report_error:
                _dns_exception("Erro ao carregar cache DNS", exc)
            return {}

    def _load_cache(self):
        return self._read_cache_file(report_error=True)

    def _acquire_cache_lock(self):
        """Lock curto via arquivo para serializar invokers Kodi independentes."""
        lock_file = self.cache_file + ".lock"
        deadline = time.monotonic() + 0.42
        while time.monotonic() < deadline:
            try:
                fd = os.open(lock_file, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                try:
                    os.write(fd, str(os.getpid() if hasattr(os, "getpid") else 0).encode("ascii"))
                finally:
                    os.close(fd)
                return lock_file
            except OSError:
                try:
                    age = time.time() - os.path.getmtime(lock_file)
                    if age > 6.0:
                        os.remove(lock_file)
                        continue
                except Exception:
                    pass
                time.sleep(0.035 + random.random() * 0.020)
        return ""

    def _release_cache_lock(self, lock_file):
        try:
            if lock_file and os.path.exists(lock_file):
                os.remove(lock_file)
        except Exception:
            pass

    def _replace_cache_file(self, temp_file):
        """Troca atomica com pequenas tentativas contra lock momentaneo."""
        last_exc = None
        for attempt in range(5):
            try:
                os.replace(temp_file, self.cache_file)
                return True
            except OSError as exc:
                last_exc = exc
                if attempt + 1 < 5:
                    time.sleep(0.035 * (attempt + 1))
        if last_exc is not None:
            raise last_exc
        return False

    def _save_cache(self):
        """Salva cache DNS sem corrida entre invokers e sem travar rede."""
        lock_file = ""
        temp_file = "{}.tmp.{}.{}.{}".format(
            self.cache_file,
            os.getpid() if hasattr(os, "getpid") else 0,
            int(time.time() * 1000),
            random.randint(0, 999999),
        )
        try:
            lock_file = self._acquire_cache_lock()
            if not lock_file:
                return False
            disk_cache = self._read_cache_file(report_error=False)
            merged = dict(disk_cache)
            for domain, data in (self.cache or {}).items():
                if not isinstance(data, dict):
                    continue
                previous = merged.get(domain) or {}
                if float(data.get("expires", 0) or 0) >= float(previous.get("expires", 0) or 0):
                    merged[domain] = data
            self.cache = merged
            with io.open(temp_file, "w", encoding="utf-8") as handle:
                json.dump(merged, handle, ensure_ascii=False, separators=(",", ":"))
            self._replace_cache_file(temp_file)
            return True
        except Exception as exc:
            _dns_exception("Erro ao salvar cache DNS", exc)
            return False
        finally:
            try:
                if os.path.exists(temp_file):
                    os.remove(temp_file)
            except Exception:
                pass
            self._release_cache_lock(lock_file)

    def is_valid_ipv4(self, ip):
        try:
            socket.inet_aton(ip)
            return True
        except socket.error:
            return False

    def is_valid_ipv6(self, ip):
        try:
            if hasattr(socket, "inet_pton"):
                socket.inet_pton(socket.AF_INET6, ip)
                return True
            return False
        except socket.error:
            return False

    def _build_dns_query(self, domain):
        transaction_id = random.randint(0, 65535)
        flags = 0x0100
        header = struct.pack(">HHHHHH", transaction_id, flags, 1, 0, 0, 0)
        qname = b"".join(
            bytes([len(part)]) + part.encode("ascii") for part in domain.split(".")
        ) + b"\x00"
        qtype = 1    # A record
        qclass = 1   # IN
        return header + qname + struct.pack(">HH", qtype, qclass)

    @staticmethod
    def _skip_dns_name(data, offset):
        """Avanca sobre nome DNS normal ou comprimido com validacao de limites."""
        size = len(data or b"")
        jumps = 0
        while offset < size:
            length = data[offset]
            if not isinstance(length, int):
                length = ord(length)
            if length == 0:
                return offset + 1
            if (length & 0xC0) == 0xC0:
                if offset + 1 >= size:
                    raise ValueError("ponteiro DNS truncado")
                return offset + 2
            if length & 0xC0:
                raise ValueError("label DNS invalido")
            if length > 63 or offset + 1 + length > size:
                raise ValueError("label DNS fora dos limites")
            offset += 1 + length
            jumps += 1
            if jumps > 128:
                raise ValueError("nome DNS excessivamente longo")
        raise ValueError("nome DNS truncado")

    def _parse_dns_response(self, data, expected_transaction_id=None):
        """Extrai somente resposta A/IN valida e correspondente a consulta enviada."""
        if not data or len(data) < 12:
            return None
        try:
            transaction_id = struct.unpack(">H", data[:2])[0]
            flags = struct.unpack(">H", data[2:4])[0]
            question_count = struct.unpack(">H", data[4:6])[0]
            answer_count = struct.unpack(">H", data[6:8])[0]
        except Exception:
            return None
        if expected_transaction_id is not None and int(transaction_id) != int(expected_transaction_id):
            return None
        if not (flags & 0x8000) or (flags & 0x000F) != 0:
            return None
        if question_count < 1 or answer_count < 1:
            return None

        try:
            offset = 12
            for _ in range(question_count):
                offset = self._skip_dns_name(data, offset)
                if offset + 4 > len(data):
                    return None
                offset += 4

            for _ in range(answer_count):
                offset = self._skip_dns_name(data, offset)
                if offset + 10 > len(data):
                    return None
                rtype, rclass, ttl, rdlength = struct.unpack(
                    ">HHIH", data[offset:offset + 10]
                )
                offset += 10
                if rdlength < 0 or offset + rdlength > len(data):
                    return None
                if rtype == 1 and rclass == 1 and rdlength == 4:
                    raw_ip = data[offset:offset + 4]
                    try:
                        return socket.inet_ntoa(raw_ip)
                    except Exception:
                        return ".".join(map(str, struct.unpack(">BBBB", raw_ip)))
                offset += rdlength
        except Exception:
            return None
        return None

    def resolve(self, domain, dns_server):
        if domain in self.cache:
            if self.cache[domain]["expires"] > time.time():
                return self.cache[domain]["ip"]
            del self.cache[domain]
            self._save_cache()

        try:
            domain_clean = domain.strip(".")
            query = self._build_dns_query(domain_clean)
            expected_transaction_id = struct.unpack(">H", query[:2])[0]

            if self.is_valid_ipv6(dns_server):
                sock = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
                addr = (dns_server, 53, 0, 0)
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                addr = (dns_server, 53)

            sock.settimeout(3)
            sock.sendto(query, addr)
            data, _ = sock.recvfrom(512)
            sock.close()

            ip = self._parse_dns_response(data, expected_transaction_id=expected_transaction_id)
            if ip:
                self.cache[domain] = {
                    "ip": ip,
                    "expires": time.time() + self.cache_ttl,
                }
                self._save_cache()
                return ip
        except Exception as exc:
            _dns_debug("erro ao resolver {} via {}: {}".format(domain, dns_server, exc))
        return None

    def _resolver(self, host, port, *args, **kwargs):
        """Resolver DNS que respeita a intencao do socket chamador.

        Mantem o resolvedor nativo para IPv6 explicito, localhost, .local e
        tipos de socket nao convencionais.
        """
        try:
            family = args[0] if len(args) > 0 else kwargs.get("family", 0)
            socktype = args[1] if len(args) > 1 else kwargs.get("type", 0)
            proto = args[2] if len(args) > 2 else kwargs.get("proto", 0)
            flags = args[3] if len(args) > 3 else kwargs.get("flags", 0)
            host_text = (
                host.decode("utf-8", "ignore") if isinstance(host, bytes)
                else str(host or "").strip()
            )
            lowered = host_text.lower().rstrip(".")
            ai_numeric = getattr(socket, "AI_NUMERICHOST", 0)
            if (not host_text or lowered in ("localhost", "localhost.localdomain") or
                    lowered.endswith(".local") or lowered.endswith(".lan") or
                    family == getattr(socket, "AF_INET6", 10) or
                    (flags and ai_numeric and (flags & ai_numeric))):
                return self.original_getaddrinfo(host, port, *args, **kwargs)
            if self.is_valid_ipv4(host_text) or self.is_valid_ipv6(host_text):
                return self.original_getaddrinfo(host, port, *args, **kwargs)
            if socktype not in (0, socket.SOCK_STREAM, socket.SOCK_DGRAM):
                return self.original_getaddrinfo(host, port, *args, **kwargs)
            negative = self.negative.get(lowered)
            now = time.monotonic()
            if negative and now - negative < self.negative_ttl:
                return self.original_getaddrinfo(host, port, *args, **kwargs)
            any_answer = False
            for dns_server in self.dns_server:
                ip = self.resolve(host_text, dns_server)
                if ip:
                    any_answer = True
                    resolved_type = socktype or socket.SOCK_STREAM
                    resolved_proto = proto or (
                        socket.IPPROTO_UDP if resolved_type == socket.SOCK_DGRAM
                        else socket.IPPROTO_TCP
                    )
                    return [(socket.AF_INET, resolved_type, resolved_proto, "", (ip, port))]
            if not any_answer:
                self.negative[lowered] = time.monotonic()
            _dns_debug("DNS alternativo sem resposta para {}; usando resolvedor do sistema.".format(host_text))
        except Exception as exc:
            _dns_exception("Erro no resolvedor alternativo", exc)
        return self.original_getaddrinfo(host, port, *args, **kwargs)


def disable_customdns():
    """Restaura o resolvedor nativo somente se este addon ainda for o dono."""
    try:
        if not _DNS_PATCH_STATE.get("installed"):
            return False
        resolver = _DNS_PATCH_STATE.get("resolver")
        original = _DNS_PATCH_STATE.get("original_getaddrinfo")
        if resolver is not None and socket.getaddrinfo is resolver and original is not None:
            socket.getaddrinfo = original
        _DNS_PATCH_STATE["installed"] = False
        _DNS_PATCH_STATE["resolver"] = None
        _DNS_PATCH_STATE["instance"] = None
        return True
    except Exception:
        return False


def _override_enabled():
    return True


def apply_configured_override(cache_file):
    """Aplica o DNS alternativo (bypass do DNS do sistema).

    Retorna True quando o override permanece ativo.
    """
    if not _override_enabled():
        disable_customdns()
        _dns_debug("DNS alternativo desligado; resolvedor do sistema preservado.")
        return False
    try:
        if not _DNS_PATCH_STATE.get("installed"):
            customdns(cache_file)
        active = bool(_DNS_PATCH_STATE.get("installed"))
        return active
    except Exception as exc:
        _dns_exception("Falha ao aplicar DNS alternativo", exc)
        return False
