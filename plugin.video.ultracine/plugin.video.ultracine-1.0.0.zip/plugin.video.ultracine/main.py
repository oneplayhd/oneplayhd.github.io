﻿# -*- coding: utf-8 -*-
# UltraCine (plugin.video.ultracine)
# Fonte: kairou.space (catálogo/streams/legendas) + metadados TMDB (pt-BR)
import gzip
import http.client
import json
import re
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import xbmcaddon

ADDON_ID = "plugin.video.ultracine"
ADDON = xbmcaddon.Addon(id=ADDON_ID)
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON_PATH = ADDON.getAddonInfo("path")
DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/%s" % ADDON_ID)

SITE = "https://kairou.space"
TMDB_API = "https://api.themoviedb.org/3"
TMDB_IMG = "https://image.tmdb.org/t/p"
TMDB_TOKEN = ("Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI4MjljMjk3OTUwZTYxZTBjNzE3OGI1ZmQ5YzllN"
              "mZhMCIsIm5iZiI6MTc1MTgyNDMyMC40NTcsInN1YiI6IjY4NmFiN2MwZDQ4OWE5YzMyYTUzZmFjNC"
              "IsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.IBBf0y2Nv9mzgXSpswQC2MsezfsD"
              "KAkhtKTC3211BpY")

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
FF_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:158.0) Gecko/20100101 Firefox/158.0"
HDR_SITE = {"User-Agent": UA, "Referer": SITE + "/", "Accept": "application/json"}
TLS_CTX = ssl.create_default_context()
TLS_CTX.check_hostname = False
TLS_CTX.verify_mode = ssl.CERT_NONE
CACHE = {}

try:
    import requests as _requests
    import urllib3
    urllib3.disable_warnings()
except Exception:
    _requests = None


def log(msg):
    try:
        xbmc.log("UltraCine: %s" % msg, xbmc.LOGINFO)
    except Exception:
        pass


def _requests_get(url, headers, timeout):
    s = _requests.Session()
    s.trust_env = False
    s.verify = False
    s.headers.update(headers)
    with s.get(url, timeout=timeout, stream=True) as r:
        if r.status_code >= 400:
            return "", r.status_code
        data = b""
        for chunk in r.iter_content(chunk_size=65536):
            if chunk:
                data += chunk
        return data.decode("utf-8", "replace"), r.status_code


def _urllib_get(url, headers, timeout):
    req = urllib.request.Request(url, headers=headers)

    def read_all(resp):
        data = b""
        while True:
            try:
                chunk = resp.read(65536)
            except http.client.IncompleteRead as e:
                data += (e.partial or b"")
                break
            except Exception:
                break
            if not chunk:
                break
            data += chunk
        return data

    data = None
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=TLS_CTX) as r:
            if r.status >= 400:
                return read_all(r).decode("utf-8", "replace"), r.status
            data = read_all(r)
    except urllib.error.HTTPError as e:
        return read_all(e).decode("utf-8", "replace"), e.code
    except Exception:
        pass
    if data is None:
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=TLS_CTX) as r:
                if r.status >= 400:
                    return read_all(r).decode("utf-8", "replace"), r.status
                data = read_all(r)
        except urllib.error.HTTPError as e:
            return read_all(e).decode("utf-8", "replace"), e.code
        except Exception as e:
            log("GET re-falhou (%s): %s" % (url[:80], e))
            return "", 0
    if data[:2] == b"\x1f\x8b":
        try:
            data = gzip.decompress(data)
        except Exception:
            pass
    return data.decode("utf-8", "replace"), 200


def _get(url, headers, timeout=40):
    if _requests is not None:
        try:
            return _requests_get(url, headers, timeout)[0]
        except Exception as e:
            log("requests falhou (%s): %s" % (url[:80], e))
    body, code = _urllib_get(url, headers, timeout)
    return body


def tmdb(path, params=None):
    qs = {"language": "pt-BR", "include_adult": "false"}
    if params:
        qs.update({k: str(v) for k, v in params.items() if v not in (None, "")})
    url = "%s/%s?%s" % (TMDB_API, path.strip("/"), urllib.parse.urlencode(qs))
    key = "T" + url
    hit = CACHE.get(key)
    if hit and time.time() - hit[0] < 900:
        return hit[1]
    raw = _get(url, {"User-Agent": UA, "Accept": "application/json", "Authorization": TMDB_TOKEN}, 30)
    try:
        data = json.loads(raw)
    except Exception:
        data = {}
    CACHE[key] = (time.time(), data)
    return data


def _pref_audio():
    try:
        v = ADDON.getSetting("pref_audio")
        return v or "all"
    except Exception:
        return "all"


def kairou_extract(itype, tmdb_id, title, season=None, episode=None, imdb_id=None):
    p = {"type": itype, "tmdbId": tmdb_id, "title": title}
    if itype == "series":
        p["season"] = season or 1
        p["episode"] = episode or 1
        if imdb_id:
            p["imdbId"] = imdb_id
    else:
        p["season"] = 1
        p["episode"] = 1
    key = "E%s" % json.dumps(p, sort_keys=True)
    hit = CACHE.get(key)
    if hit and time.time() - hit[0] < 600:
        return hit[1]
    url = "%s/api/extract?%s" % (SITE, urllib.parse.urlencode({k: str(v) for k, v in p.items()}))
    raw = _get(url, HDR_SITE)
    try:
        streams = json.loads(raw).get("streams") or []
    except Exception:
        streams = []
    streams.sort(key=_stream_sort_key)
    CACHE[key] = (time.time(), streams)
    return streams


def _qual_score(q):
    q = (q or "").lower()
    if "4k" in q or "2160" in q:
        return 4
    if "1080" in q:
        return 3
    if "720" in q:
        return 2
    return 1


def _stream_sort_key(s):
    pref = _pref_audio()
    audio = 0
    if pref == "dub":
        audio = 0 if s.get("isDub") else 1
    elif pref == "legendado":
        audio = 0 if not s.get("isDub") else 1
    return (1 if s.get("isIframe") else 0, audio, -_qual_score(s.get("quality")), s.get("priority", 99))


def absolute_url(u):
    if not u:
        return ""
    u = u.replace("\\/", "/").replace("&amp;", "&")
    if u.startswith("//"):
        return "https:" + u
    if u.startswith("/"):
        return SITE + u
    return u


def is_hls(u):
    low = (u or "").lower()
    return any(x in low for x in (".m3u8", "hls.php", "format=hls", "/hls/"))


def probe_hls(url):
    """Checa content-type/primeiros bytes pra decidir InputStream Adaptive."""
    hit = CACHE.get("P" + url)
    if hit and time.time() - hit[0] < 600:
        return hit[1]
    res = False
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Range": "bytes=0-4095", "Referer": SITE + "/", "Accept": "*/*"})
        with urllib.request.urlopen(req, timeout=15, context=TLS_CTX) as r:
            ct = (r.headers.get("Content-Type") or "").lower()
            chunk = r.read(4096).decode("utf-8", "replace").lstrip()
            res = ("mpegurl" in ct) or chunk.startswith("#EXTM3U") or (".m3u8" in chunk[:60].lower())
    except urllib.error.HTTPError:
        res = False
    except Exception as e:
        log("probe falhou (%s): %s" % (url[:80], e))
    CACHE["P" + url] = (time.time(), res)
    return res


def listitem(label, info=None, art=None, playable=False):
    li = xbmcgui.ListItem(label=label)
    if info:
        li.setInfo("video", info)
    if art:
        li.setArt(art)
    if playable:
        li.setProperty("IsPlayable", "true")
    return li


def add_folder(args, label, info=None, art=None, content=None):
    if content:
        xbmcplugin.setContent(HANDLE, content)
    u = "%s?%s" % (BASE_URL, urllib.parse.urlencode(args))
    return xbmcplugin.addDirectoryItem(HANDLE, u, listitem(label, info, art), True)


def add_stream(label, url, subs=None, info=None, art=None):
    li = listitem(label, info, art, playable=True)
    if is_hls(url) or probe_hls(url):
        headers = "User-Agent=%s&Referer=%s" % (urllib.parse.quote(UA), urllib.parse.quote(SITE + "/"))
        li.setProperty("inputstream", "inputstream.adaptive")
        li.setProperty("inputstream.adaptive.manifest_type", "hls")
        li.setProperty("inputstream.adaptive.stream_headers", headers)
    if subs:
        try:
            li.setSubtitles(subs)
        except Exception:
            pass
    return xbmcplugin.addDirectoryItem(HANDLE, url, li, False)


def title_of(item):
    return item.get("title") or item.get("name") or "?"


def year_of(item):
    d = item.get("release_date") or item.get("first_air_date") or ""
    return int(d[:4]) if d[:4].isdigit() else 0


def type_of(item):
    if item.get("media_type") in ("movie", "tv"):
        return item.get("media_type")
    if item.get("title") or item.get("release_date"):
        return "movie"
    if item.get("name") or item.get("first_air_date"):
        return "tv"
    return "movie"


def art_for(item):
    out = {}
    pp = item.get("poster_path") or item.get("profile_path") or item.get("still_path")
    if pp:
        out["poster"] = "%s/w500%s" % (TMDB_IMG, pp)
        out["thumb"] = "%s/w300%s" % (TMDB_IMG, pp)
    bp = item.get("backdrop_path")
    if bp:
        out["fanart"] = "%s/w780%s" % (TMDB_IMG, bp)
    return out


def info_of(item, mediatype=None):
    mt = mediatype or ("movie" if type_of(item) == "movie" else "tvshow")
    return {"title": title_of(item), "year": year_of(item), "plot": item.get("overview") or "",
            "rating": item.get("vote_average") or 0, "mediatype": mt}


def item_arg(item):
    return json.dumps({"id": item["id"], "title": title_of(item)})


CATALOG = [
    ("__alta", "Em Alta"),
    ("__movies_popular", "Filmes Populares"),
    ("__movies_top", "Filmes Melhor Avaliados"),
    ("__movies_now", "Filmes em Cartaz"),
    ("__movies_soon", "Lançamentos de Filmes"),
    ("__tv_popular", "Séries Populares"),
    ("__tv_top", "Séries Melhor Avaliadas"),
    ("__tv_air", "Séries em Exibição"),
    ("__animes_pop", "Animes Populares"),
    ("__animes_top", "Animes Melhor Avaliados"),
]

LISTS = {
    "__alta": ("trending/all/week", {}),
    "__movies_popular": ("movie/popular", {}),
    "__movies_top": ("movie/top_rated", {}),
    "__movies_now": ("movie/now_playing", {}),
    "__movies_soon": ("movie/upcoming", {}),
    "__tv_popular": ("tv/popular", {}),
    "__tv_top": ("tv/top_rated", {}),
    "__tv_air": ("tv/on_the_air", {}),
    "__animes_pop": ("discover/tv", {"with_genres": 16, "with_original_language": "ja"}),
    "__animes_top": ("discover/tv", {"with_genres": 16, "with_original_language": "ja",
                                     "sort_by": "vote_average.desc", "vote_count.gte": 150}),
}


def browse_list(key, page):
    path, params = LISTS.get(key, (None, None))
    if not path:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    data = tmdb(path, dict(params, page=page))
    is_tv = path.startswith("tv/") or path.startswith("discover/tv") or path.startswith("trending")
    for item in data.get("results", []):
        med = type_of(item)
        if med == "person":
            continue
        if med == "movie":
            add_folder({"action": "open_movie", "item": item_arg(item)}, title_of(item),
                       info=info_of(item, "movie"), art=art_for(item), content="movies")
        else:
            add_folder({"action": "open_series", "item": item_arg(item)}, title_of(item),
                       info=info_of(item, "tvshow"), art=art_for(item), content="tvshows")
    results = data.get("results", [])
    total = data.get("total_pages", 1) or 1
    if page < min(total, 20) and results:
        add_folder({"action": "list", "key": key, "page": page + 1}, "Próxima página (%d/%s)" % (page + 1, total))
    xbmcplugin.setContent(HANDLE, "tvshows" if is_tv else "movies")
    xbmcplugin.endOfDirectory(HANDLE)


def _server_streams(streams):
    pref = _pref_audio()
    out = []
    for s in streams:
        if s.get("isIframe") or not s.get("url"):
            continue
        if pref == "dub" and not s.get("isDub"):
            continue
        if pref == "legendado" and s.get("isDub"):
            continue
        out.append(s)
    return out


def _subs_of(streams):
    subs_all = []
    for s in streams:
        for y in s.get("subtitles", []):
            u = absolute_url(y.get("url"))
            if u and u not in subs_all:
                subs_all.append(u)
    return subs_all


def open_movie(item):
    data = tmdb("movie/%s" % item["id"], {"append_to_response": "external_ids"})
    imdb = (data.get("external_ids") or {}).get("imdb_id") or ""
    streams = kairou_extract("movie", str(item["id"]), title_of(data or item), imdb_id=imdb or None)
    filt = _server_streams(streams)
    if not filt:
        xbmcgui.Dialog().ok("UltraCine", "Nenhum servidor disponível para este título no momento.")
        return
    subs_all = _subs_of(streams)
    label0 = title_of(data or item)
    plot = (data or {}).get("overview") or ""
    art = art_for(data or item)
    for s in filt:
        add_stream(s.get("providerName") or "Servidor", absolute_url(s["url"]), subs=subs_all[:6],
                   info={"title": label0, "plot": plot, "mediatype": "movie"}, art=art)
    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.endOfDirectory(HANDLE)


def open_series(item):
    data = tmdb("tv/%s" % item["id"], {"append_to_response": "external_ids"})
    imdb = (data.get("external_ids") or {}).get("imdb_id") or ""
    for s in data.get("seasons", []):
        num = s.get("season_number")
        art = {"poster": "%s/w300%s" % (TMDB_IMG, s["poster_path"])} if s.get("poster_path") else None
        add_folder({"action": "season", "item": json.dumps({"id": item["id"], "title": title_of(item),
                                                            "imdb": imdb, "season": num,
                                                            "poster": data.get("poster_path") or "",
                                                            "plot": data.get("overview") or ""})},
                   "Temporada %d — %s episódios" % (num, s.get("episode_count") or "?"),
                   info={"title": "Temporada %d" % num}, art=art, content="seasons")
    xbmcplugin.setContent(HANDLE, "seasons")
    xbmcplugin.endOfDirectory(HANDLE)


def open_season(item):
    data = tmdb("tv/%s/season/%s" % (item["id"], item["season"]), {})
    for e in data.get("episodes", []):
        args = {"action": "episode", "item": json.dumps({
            "id": item["id"], "title": item.get("title") or item.get("name") or "",
            "imdb": item.get("imdb") or "",
            "season": item["season"], "episode": e.get("episode_number"),
            "poster": item.get("poster") or "", "plot": item.get("plot") or "",
        })}
        add_folder(args, "E%02d · %s" % (e.get("episode_number") or 0, e.get("name") or ""),
                   info={"title": e.get("name"), "season": item["season"], "episode": e.get("episode_number"),
                         "plot": e.get("overview"), "year": year_of(e), "mediatype": "episode"},
                   art={"thumb": "%s/w300%s" % (TMDB_IMG, e["still_path"])} if e.get("still_path") else None,
                   content="episodes")
    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE)


def open_episode(item):
    streams = kairou_extract("series", str(item["id"]), item.get("title") or "",
                             season=item["season"], episode=item["episode"],
                             imdb_id=(item.get("imdb") or None))
    filt = _server_streams(streams)
    if not filt:
        xbmcgui.Dialog().ok("UltraCine", "Nenhum servidor para este episódio no momento.")
        return
    subs_all = _subs_of(streams)
    label_sr = "%s · T%s E%s" % (item.get("title") or "", item["season"], item["episode"])
    art = {"thumb": "%s/w500%s" % (TMDB_IMG, item["poster"])} if item.get("poster") else {}
    plot = item.get("plot") or ""
    for s in filt:
        add_stream(s.get("providerName") or "Servidor", absolute_url(s["url"]), subs=subs_all[:6],
                   info={"title": label_sr, "season": item["season"], "episode": item["episode"],
                         "plot": plot, "mediatype": "episode"}, art=art)
    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE)


def search_prompt():
    kb = xbmc.Keyboard("", "UltraCine — buscar")
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        return
    q = kb.getText().strip()
    if not q:
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        return
    do_search(q, 1)


def do_search(query, page):
    data = tmdb("search/multi", {"query": query, "page": page})
    results = data.get("results", [])
    if not results and page == 1:
        xbmcgui.Dialog().notification("UltraCine", "Nada encontrado: %s" % query, xbmcgui.NOTIFICATION_INFO, 4000)
    for item in results:
        med = type_of(item)
        if med == "person":
            continue
        if med == "movie":
            add_folder({"action": "open_movie", "item": item_arg(item)}, title_of(item),
                       info=info_of(item, "movie"), art=art_for(item), content="movies")
        else:
            add_folder({"action": "open_series", "item": item_arg(item)}, title_of(item),
                       info=info_of(item, "tvshow"), art=art_for(item), content="tvshows")
    total = data.get("total_pages", 1) or 1
    if page < min(total, 20) and results:
        add_folder({"action": "list", "key": "__search", "query": query, "page": page + 1}, "Mais resultados...")
    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


# ---------- CANAIS ----------

def _unescape(s):
    if "\\u" in s:
        s = re.sub(r"\\u([0-9a-fA-F]{4})", lambda m: chr(int(m.group(1), 16)), s)
    return s


def _load_channels_local():
    src = ADDON_PATH + "/resources/channels.json"
    try:
        with xbmcvfs.File(src) as f:
            raw = f.read()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", "replace")
        chs = json.loads(raw)
        if isinstance(chs, list) and chs:
            return chs
    except Exception as e:
        log("channels.json falhou: %s" % e)
    return []


def _load_channels_profile():
    src = DATA_DIR + "channels.json"
    try:
        with xbmcvfs.File(src) as f:
            raw = f.read()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", "replace")
        chs = json.loads(raw)
        if isinstance(chs, list) and chs:
            return chs
    except Exception:
        pass
    return []


def _save_channels_profile(chs):
    try:
        if not xbmcvfs.exists(DATA_DIR):
            xbmcvfs.mkdir(DATA_DIR)
        with xbmcvfs.File(DATA_DIR + "channels.json", "w") as f:
            f.write(json.dumps(chs, ensure_ascii=False))
    except Exception as e:
        log("salvar canais falhou: %s" % e)


def _nat_key(t):
    return [int(p) if p.isdigit() else p for p in re.split(r"(\d+)", t or "")]


def load_channel_channels():
    hit = CACHE.get("channels")
    if hit:
        return hit
    prof = _load_channels_profile()
    chs = []
    if prof:
        chs = prof
        log("canais do perfil: %d" % len(chs))
    else:
        chs = _load_channels_local()
        log("canais do resource: %d" % len(chs))
        if chs:
            _save_channels_profile(chs)
    # refresh de fundo quando der
    try:
        if not chs or (hit and time.time() - hit[0] > 43200):
            raw = _get(SITE, {"User-Agent": UA, "Accept": "text/html,*/*", "Referer": SITE + "/"}, 25)
            m = re.search(r'/assets/index-[\w\-]+\.js', raw)
            if m:
                js = _get(SITE + m.group(0), {"User-Agent": UA, "Referer": SITE + "/", "Accept": "*/*"}, 40)
                pat = re.compile(r'\{id:"([\w\-]+)",slug:"([\w\-]+)",title:"([^"]+)",'
                                 r'genre:"([\w\-]+)",category:"([^"]+)",logo:"([^"]+)"')
                fresh = [{"slug": mm.group(2), "title": mm.group(3),
                          "genre": mm.group(4), "cat": mm.group(5), "logo": mm.group(6)} for mm in pat.finditer(js)]
                for c in fresh:
                    c["title"] = _unescape(c["title"])
                if len(fresh) >= max(100, len(chs)):
                    chs = fresh
                    _save_channels_profile(fresh)
                    log("canais atualizados: %d" % len(chs))
    except Exception as e:
        log("refresh canais falhou: %s" % e)
    if chs:
        chs.sort(key=lambda c: _nat_key((c.get("cat") or "") + "·" + (c.get("title") or "")))
    CACHE["channels"] = chs
    return chs


def channel_menu(cat=None):
    chs = load_channel_channels()
    if not chs:
        xbmcgui.Dialog().ok("UltraCine", "Lista de canais indisponível no momento.")
        xbmcplugin.endOfDirectory(HANDLE)
        return
    if not cat:
        groups = {}
        for c in chs:
            groups.setdefault(c.get("cat") or "Geral", []).append(c)
        for cat_name in sorted(groups):
            first_logo = groups[cat_name][0].get("logo") or ""
            add_folder({"action": "channels", "cat": cat_name},
                       "%s  (%d)" % (cat_name, len(groups[cat_name])),
                       art={"thumb": first_logo, "poster": first_logo, "fanart": first_logo},
                       content="files")
    else:
        add_folder({"action": "channels"}, "· · · Todas as categorias", content="files")
        for c in chs:
            if (c.get("cat") or "Geral") != cat:
                continue
            logo = c.get("logo") or ""
            u = "%s?%s" % (BASE_URL, urllib.parse.urlencode({"action": "channel", "slug": c["slug"]}))
            li = xbmcgui.ListItem(label=c["title"])
            li.setArt({"thumb": logo, "poster": logo})
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(HANDLE, u, li, False)
    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(HANDLE)


def page_follow(opener, url, headers, timeout=40):
    """urllib fallback: GET seguindo cookies do opener."""
    try:
        req = urllib.request.Request(url, headers=headers)
        with opener.open(req, timeout=timeout) as r:
            data = b""
            while True:
                try:
                    chunk = r.read(65536)
                except Exception:
                    break
                if not chunk:
                    break
                data += chunk
            return data.decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        try:
            return e.read(200000).decode("utf-8", "replace")
        except Exception:
            return ""
    except Exception as e:
        log("page_follow falhou (%s): %s" % (url[:70], e))
        return ""


def _opener():
    cj = urllib.request.HTTPCookieProcessor()
    hs = urllib.request.HTTPSHandler(context=TLS_CTX)
    return urllib.request.build_opener(cj, hs)


def _rfollow(sess, url, headers, timeout=40):
    """requests: GET com sessão/cookies persistentes; guarda a URL final em sess._last_url."""
    try:
        r = sess.get(url, headers=headers, timeout=timeout, verify=False)
        sess._last_url = r.url
        return r.text
    except Exception as e:
        log("get falhou (%s): %s" % (url[:70], e))
        return ""


def _rpost(sess, url, headers, timeout=40):
    try:
        r = sess.post(url, headers=headers, timeout=timeout, verify=False)
        sess._last_url = r.url
        return r.text
    except Exception as e:
        log("post falhou (%s): %s" % (url[:70], e))
        return ""


def _rsess():
    s = _requests.Session()
    s.trust_env = False
    s.headers["User-Agent"] = UA
    return s


def resolve_channel(slug):
    sess = _rsess()
    sess.headers["User-Agent"] = FF_UA
    data = {}
    try:
        raw = _rfollow(sess, SITE + "/api/channels?slug=" + urllib.parse.quote(slug),
                       {"User-Agent": FF_UA, "Referer": SITE + "/", "Accept": "application/json"}, 25)
        data = json.loads(raw or "{}")
    except Exception as e:
        log("channels api falhou: %s" % e)
    stream_url = data.get("streamUrl") or data.get("fallbackRdse") or ""
    if not stream_url:
        return None, "Canal sem stream configurado."
    p1 = _rfollow(sess, stream_url, {"Accept": "text/html,*/*", "Referer": SITE + "/"})
    m = re.search(r'src="(https://[^"]*__play[^"]+)"', p1)
    if not m:
        return None, "Proteção Cloudflare na página do canal."
    play_url = m.group(1).replace("&amp;", "&")
    p2 = _rfollow(sess, play_url, {"Accept": "text/html,*/*", "Referer": stream_url})
    fm = re.search(r'src="(https://[^"]+)"', p2)
    if not fm:
        return None, "Player intermediário bloqueado."
    final_url = fm.group(1).replace("&amp;", "&")
    p3 = _rfollow(sess, final_url, {"Accept": "*/*", "Referer": stream_url,
                                    "Cache-Control": "no-cache", "Pragma": "no-cache"})
    refs = []
    for mm in re.finditer(r'"ref"\s*:\s*"([^"]+)"', p3):
        ref = mm.group(1).replace("\\/", "/")
        if len(ref) > 30:
            refs.append(ref)
    if not refs:
        return None, "Sem fontes no player (proteção)."
    base = (getattr(sess, "_last_url", "") or final_url).split("?")[0].rstrip("/")
    hh = {
        "Accept": "application/json",
        "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        "Referer": base + "/",
        "Origin": base,
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "Pragma": "no-cache",
        "Cache-Control": "no-cache",
        "Content-Length": "0",
    }
    for ref in refs[:6]:
        resp = _rpost(sess, base + ref, hh)
        try:
            src = (json.loads(resp) or {}).get("src") or ""
        except Exception:
            src = ""
        if src:
            src = src.replace("\\/", "/")
            return src, ""
    return None, "Stream do canal não liberado. Tente de novo mais tarde."


def channel_action(slug):
    prog = xbmcgui.DialogProgressBG()
    prog.create("UltraCine", "Resolvendo stream...")
    try:
        url, err = resolve_channel(slug)
    finally:
        prog.close()
    if not url:
        xbmcgui.Dialog().notification("UltraCine", err or "Falha", xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(path=""))
        return
    li = listitem(slug, {"title": slug, "mediatype": "movie"})
    headers = "User-Agent=%s&Referer=%s" % (urllib.parse.quote(FF_UA), urllib.parse.quote(SITE + "/"))
    li.setProperty("inputstream", "inputstream.adaptive")
    li.setProperty("inputstream.adaptive.manifest_type", "hls")
    li.setProperty("inputstream.adaptive.stream_headers", headers)
    li.setPath(url)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


# ---------- MENU / ROUTES ----------

def do_root():
    xbmcplugin.setContent(HANDLE, "files")
    for key, label in CATALOG:
        add_folder({"action": "list", "key": key}, label)
    add_folder({"action": "search"}, "Buscar")
    add_folder({"action": "channels"}, "Canais Ao Vivo")
    xbmcplugin.endOfDirectory(HANDLE)


def route():
    params = dict(urllib.parse.parse_qsl(sys.argv[2].replace("?", "")))
    a = params.get("action", "root")
    try:
        if a == "root":
            do_root()
        elif a == "list":
            key = params.get("key", "")
            page = int(params.get("page") or 1)
            if key == "__search":
                q = params.get("query") or ""
                if q:
                    do_search(q, page)
                else:
                    search_prompt()
            else:
                browse_list(key, page)
        elif a == "search":
            search_prompt()
        elif a == "open_movie":
            open_movie(json.loads(params.get("item", "{}")))
        elif a == "open_series":
            open_series(json.loads(params.get("item", "{}")))
        elif a == "season":
            open_season(json.loads(params.get("item", "{}")))
        elif a == "episode":
            open_episode(json.loads(params.get("item", "{}")))
        elif a == "channels":
            channel_menu(params.get("cat"))
        elif a == "channel":
            channel_action(params.get("slug"))
        else:
            do_root()
    except SystemExit:
        raise
    except Exception as e:
        xbmc.log("UltraCine error: %s" % e, xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().notification("UltraCine", "Erro: %s" % e, xbmcgui.NOTIFICATION_ERROR, 5000)
        except Exception:
            pass
        xbmcplugin.endOfDirectory(HANDLE)


if __name__ == "__main__":
    route()
