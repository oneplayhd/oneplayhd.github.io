import xbmc
import xbmcgui
import threading
import time
import re
import socket
import struct
import random
import os
import gzip
import zlib
import binascii
import ssl
import unicodedata
import urllib.request
import urllib.error
import json
from collections import deque
from urllib.parse import parse_qs, urlparse, unquote, urljoin, quote
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from wsgiref.simple_server import make_server

# ==================== CONFIGURAÇÕES ====================
VOICE_PORT = 8088
PROXY_PORT = 9095
CACHE_DURATION_SECONDS = 3
CACHE_MAX_CHUNKS = 250
MAX_RETRIES = 7
RETRY_DELAY = 0.5
BUFFER_SIZE = 32768
AOVIVO_M3U8 = True

M3U_LIST_URL = "http://listas.oneplayhd.com/lista01.txt"
M3U_REFRESH_SECONDS = 3600

# ==================== TMDB API KEY ====================
# COLOQUE SUA CHAVE AQUI (https://www.themoviedb.org/settings/api)
TMDB_API_KEY = "1865f43a0549ca50d341dd9ab8b29f49"

# ==================== STREMIO ADDON (FENIXFLIX) ====================
STREMIO_ADDON_BASE = "https://fenixflix.fenixhub.online"
STREMIO_ADDON_QUALITIES = "1080p"
STREMIO_ADDON_AUDIO = "dublado"
STREMIO_ADDON_CATALOGS = "populares_movie,populares_series,recentes_movie,recentes_series"

CHROME_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/130.0.0.0 Safari/537.36"
)


# ==================== DNS CUSTOM ====================
class SimpleDNS:
    def __init__(self):
        self.cache = {}
        self.dns_servers = ["1.1.1.1", "8.8.8.8", "208.67.222.222"]
        self.original_getaddrinfo = socket.getaddrinfo
        socket.getaddrinfo = self._resolver

    def _build_query(self, domain):
        transaction_id = random.randint(0, 65535)
        header = struct.pack(">HHHHHH", transaction_id, 0x0100, 1, 0, 0, 0)
        qname = b"".join(
            bytes([len(part)]) + part.encode() for part in domain.split(".")
        ) + b"\x00"
        return header + qname + struct.pack(">HH", 1, 1)

    def _parse_response(self, data):
        try:
            answer_count = struct.unpack(">H", data[6:8])[0]
            offset = 12
            while data[offset] != 0:
                offset += 1
            offset += 5
            for _ in range(answer_count):
                offset += 2
                rtype, _, _, rdlength = struct.unpack(">HHIH", data[offset:offset + 10])
                offset += 10
                if rtype == 1 and rdlength == 4:
                    ip = struct.unpack(">BBBB", data[offset:offset + 4])
                    return ".".join(map(str, ip))
                offset += rdlength
        except Exception:
            pass
        return None

    def resolve(self, domain):
        if domain in self.cache and self.cache[domain]["expires"] > time.time():
            return self.cache[domain]["ip"]
        for dns in self.dns_servers:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.settimeout(2)
                query = self._build_query(domain)
                sock.sendto(query, (dns, 53))
                data, _ = sock.recvfrom(512)
                sock.close()
                ip = self._parse_response(data)
                if ip:
                    self.cache[domain] = {"ip": ip, "expires": time.time() + 3600}
                    return ip
            except Exception:
                continue
        return None

    def _resolver(self, host, port, *args, **kwargs):
        try:
            socket.inet_aton(host)
            return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (host, port))]
        except Exception:
            ip = self.resolve(host)
            if ip:
                return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (ip, port))]
        return self.original_getaddrinfo(host, port, *args, **kwargs)


dns = SimpleDNS()


# ==================== CACHE CIRCULAR ====================
class CircularBuffer:
    def __init__(self, max_seconds=5, max_chunks=250):
        self.buffer = deque(maxlen=max_chunks)
        self.timestamps = deque(maxlen=max_chunks)
        self.max_seconds = max_seconds
        self.total_bytes = 0
        self.lock = threading.Lock()
        self.last_update = 0
        self.stream_started = False

    def add_chunk(self, chunk):
        with self.lock:
            self.buffer.append(chunk)
            self.timestamps.append(time.time())
            self.total_bytes += len(chunk)
            self.last_update = time.time()
            cutoff = time.time() - self.max_seconds
            while self.timestamps and self.timestamps[0] < cutoff:
                removed = self.buffer.popleft()
                self.timestamps.popleft()
                self.total_bytes -= len(removed)

    def get_recovery_chunks(self, duration=3):
        with self.lock:
            if not self.buffer:
                return []
            cutoff = time.time() - duration
            recovery = [self.buffer[i] for i, ts in enumerate(self.timestamps) if ts >= cutoff]
            if not recovery and self.buffer:
                recovery = list(self.buffer)[-20:]
            return recovery

    def get_continuous_chunks(self, count=30):
        with self.lock:
            if not self.buffer:
                return []
            return list(self.buffer)[-count:]

    def clear(self):
        with self.lock:
            self.buffer.clear()
            self.timestamps.clear()
            self.total_bytes = 0
            self.stream_started = False


class MP4Cache:
    def __init__(self, max_chunks=250):
        self.chunks = {}
        self.max_chunks = max_chunks
        self.lock = threading.Lock()
        self.total_size = 0
        self.content_length = None

    def add_chunk(self, start_byte, data):
        if not data:
            return
        with self.lock:
            if start_byte not in self.chunks:
                self.chunks[start_byte] = data
                self.total_size += len(data)
                while len(self.chunks) > self.max_chunks:
                    oldest = min(self.chunks.keys())
                    self.total_size -= len(self.chunks[oldest])
                    del self.chunks[oldest]

    def get_range(self, start, end):
        with self.lock:
            keys = sorted(self.chunks.keys())
            if not keys:
                return None
            result = bytearray()
            pos = start
            while pos < end:
                found = False
                for chunk_start in keys:
                    chunk = self.chunks[chunk_start]
                    chunk_end = chunk_start + len(chunk)
                    if chunk_start <= pos < chunk_end:
                        offset = pos - chunk_start
                        take = min(end - pos, chunk_end - pos)
                        result.extend(chunk[offset:offset + take])
                        pos += take
                        found = True
                        break
                if not found:
                    return None
            return bytes(result)


# ==================== PROXY ====================
class UnifiedProxy:
    def __init__(self):
        self.channel_caches = {}
        self.mp4_caches = {}
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE
        self.stream_lock = threading.Lock()
        self.cache_lock = threading.Lock()

    def get_random_user_agent(self):
        random_bytes = binascii.b2a_hex(os.urandom(20))[:32].decode('ascii')
        return f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{random_bytes} Safari/537.36"

    def get_local_ip(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
        except Exception:
            ip = "127.0.0.1"
        finally:
            s.close()
        return ip

    def build_proxy_url(self, url):
        return f"http://127.0.0.1:{PROXY_PORT}/?url={quote(url, safe='')}"

    def extract_url_from_path(self, path):
        if '/tsdownloader' in path and '?url=' in path:
            params = path.split('?', 1)[1]
            for param in params.split('&'):
                if param.startswith('url='):
                    return unquote(param[4:])
        if path.startswith('/?url='):
            url_part = path[6:]
            if '&' in url_part:
                url_part = url_part.split('&', 1)[0]
            return unquote(url_part)
        if path.startswith('/http://') or path.startswith('/https://'):
            return unquote(path[1:])
        if path.startswith('http://') or path.startswith('https://'):
            return unquote(path)
        return None

    def get_channel_cache(self, url):
        clean_url = re.sub(r'(_=\d+|timestamp=\d+|t=\d+|seq=\d+)', '', url)
        with self.stream_lock:
            if clean_url not in self.channel_caches:
                self.channel_caches[clean_url] = CircularBuffer(CACHE_DURATION_SECONDS, CACHE_MAX_CHUNKS)
            return self.channel_caches[clean_url]

    def get_mp4_cache(self, url):
        clean_url = re.sub(r'(_=\d+|timestamp=\d+|t=\d+|seq=\d+)', '', url)
        with self.cache_lock:
            if clean_url not in self.mp4_caches:
                self.mp4_caches[clean_url] = MP4Cache(CACHE_MAX_CHUNKS)
            return self.mp4_caches[clean_url]

    def fetch_channel_with_fallback(self, url, headers=None, range_header=None, cache=None):
        if headers is None:
            headers = {}
        for attempt in range(MAX_RETRIES):
            if attempt == 0:
                user_agent = CHROME_UA
            else:
                user_agent = self.get_random_user_agent()
            req_headers = {
                'User-Agent': user_agent,
                'Accept': '*/*',
                'Accept-Language': 'pt-BR,pt;q=0.9',
                'Connection': 'keep-alive'
            }
            for key, value in headers.items():
                if key.lower() not in ['host', 'connection', 'content-length', 'range', 'user-agent', 'accept-encoding']:
                    req_headers[key] = value
            if range_header:
                req_headers['Range'] = range_header
            try:
                req = Request(url, headers=req_headers)
                if url.startswith('https'):
                    response = urlopen(req, timeout=15, context=self.ssl_context)
                else:
                    response = urlopen(req, timeout=15)
                status_code = response.getcode()
                content_encoding = response.headers.get('content-encoding', '').lower()
                if status_code not in [200, 206]:
                    return None, status_code, None
                return response, status_code, content_encoding
            except HTTPError as e:
                if e.code in [400, 401, 403, 404, 406, 451, 500, 502, 503, 504, 523]:
                    return None, e.code, None
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_DELAY * (attempt + 1))
                    continue
                return None, e.code, None
            except Exception:
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_DELAY * (attempt + 1))
                    continue
                return None, 0, None
        return None, 0, None

    def rewrite_m3u8_urls(self, playlist_content, base_url, proxy_host):
        try:
            segments_number = int(playlist_content.count('/hl'))
            NEXT_SEGMENT = segments_number * 2
            ENABLE_AOVIVO = True
        except Exception:
            ENABLE_AOVIVO = False

        def replace_url(match):
            segment = match.group(0).strip()
            if segment.startswith('#') or not segment:
                return segment
            try:
                absolute = urljoin(base_url + '/', segment)
                if absolute.endswith('.ts') or absolute.endswith('.m3u8') or '/hl' in absolute.lower() or 'track' in absolute.lower():
                    if AOVIVO_M3U8 and '/hl' in absolute and '.ts' in absolute and ENABLE_AOVIVO:
                        try:
                            atual_ts = '_' + re.findall(r'_(.*?).ts', absolute)[0] + '.ts'
                            new_ts = '_' + str(int(re.findall(r'_(.*?).ts', absolute)[0]) + NEXT_SEGMENT) + '.ts'
                            new_absolute = absolute.replace(atual_ts, new_ts)
                            return f"http://{proxy_host}/tsdownloader?url={quote(new_absolute)}"
                        except Exception:
                            pass
                    return f"http://{proxy_host}/tsdownloader?url={quote(absolute)}"
                return segment
            except Exception:
                return segment

        return re.sub(r'^(?!#)\S+', replace_url, playlist_content, flags=re.MULTILINE)

    def handle_channel_stream(self, url, headers, client_socket):
        cache = self.get_channel_cache(url)
        response = None
        stream_active = True
        try:
            response, status_code, content_encoding = self.fetch_channel_with_fallback(url, headers, None, cache)
            if response is None:
                recovery_chunks = cache.get_recovery_chunks(CACHE_DURATION_SECONDS)
                if recovery_chunks:
                    headers_line = "HTTP/1.1 200 OK\r\nContent-Type: video/mp2t\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache\r\nConnection: keep-alive\r\n\r\n"
                    client_socket.send(headers_line.encode())
                    for chunk in recovery_chunks:
                        try:
                            client_socket.send(chunk)
                            time.sleep(0.03)
                        except Exception:
                            stream_active = False
                            break
                else:
                    self.send_error(client_socket, 503, "Sem cache disponível")
                    return
            if response and status_code in [200, 206]:
                content_type = response.headers.get('content-type', '').lower()
                content_url = response.geturl()
                if 'mpegurl' in content_type or '.m3u8' in content_url.lower():
                    raw_content = response.read()
                    try:
                        if content_encoding == 'gzip':
                            content = gzip.decompress(raw_content)
                        elif content_encoding == 'deflate':
                            content = zlib.decompress(raw_content)
                        else:
                            content = raw_content
                    except Exception:
                        content = raw_content
                    try:
                        playlist_text = content.decode('utf-8', errors='ignore')
                        proxy_host = f"{self.get_local_ip()}:{PROXY_PORT}"
                        base_url = content_url.rsplit('/', 1)[0]
                        rewritten = self.rewrite_m3u8_urls(playlist_text, base_url, proxy_host)
                        response.close()
                        response_headers = (
                            "HTTP/1.1 200 OK\r\n"
                            "Content-Type: application/vnd.apple.mpegurl\r\n"
                            f"Content-Length: {len(rewritten)}\r\n"
                            "Access-Control-Allow-Origin: *\r\n"
                            "Cache-Control: no-cache\r\n\r\n"
                        )
                        client_socket.send(response_headers.encode())
                        client_socket.send(rewritten.encode('utf-8'))
                        return
                    except Exception as e:
                        xbmc.log(f"Erro M3U8 proxy: {e}", xbmc.LOGERROR)
                        return
                status = 206 if status_code == 206 else 200
                headers_line = (
                    f"HTTP/1.1 {status} OK\r\n"
                    "Content-Type: video/mp2t\r\n"
                    "Access-Control-Allow-Origin: *\r\n"
                    "Cache-Control: no-cache\r\n"
                    "Connection: keep-alive\r\n"
                )
                if 'content-length' in response.headers:
                    headers_line += f"Content-Length: {response.headers['content-length']}\r\n"
                headers_line += "\r\n"
                client_socket.send(headers_line.encode())
                cache.stream_started = True
                consecutive_errors = 0
                cache_mode = False
                while stream_active:
                    try:
                        if response:
                            chunk = response.read(BUFFER_SIZE)
                            if chunk:
                                cache.add_chunk(chunk)
                                client_socket.send(chunk)
                                consecutive_errors = 0
                                cache_mode = False
                            else:
                                break
                        else:
                            if not cache_mode:
                                cache_mode = True
                            cache_chunks = cache.get_continuous_chunks(30)
                            if cache_chunks:
                                for chunk in cache_chunks:
                                    try:
                                        client_socket.send(chunk)
                                        time.sleep(0.03)
                                    except Exception:
                                        stream_active = False
                                        break
                            try:
                                new_response, new_status, _ = self.fetch_channel_with_fallback(
                                    url, headers, f"bytes={cache.total_bytes}-", cache
                                )
                                if new_response and new_status in [200, 206]:
                                    if response:
                                        response.close()
                                    response = new_response
                                    cache_mode = False
                                    continue
                            except Exception:
                                pass
                            time.sleep(1)
                    except (socket.error, BrokenPipeError):
                        break
                    except Exception:
                        consecutive_errors += 1
                        if not cache_mode:
                            cache_mode = True
                        if consecutive_errors >= 3:
                            try:
                                if response:
                                    response.close()
                                    response = None
                                new_response, new_status, _ = self.fetch_channel_with_fallback(
                                    url, headers, f"bytes={cache.total_bytes}-", cache
                                )
                                if new_response and new_status in [200, 206]:
                                    response = new_response
                                    cache_mode = False
                                    consecutive_errors = 0
                                    continue
                            except Exception:
                                pass
                        if cache_mode:
                            cache_chunks = cache.get_continuous_chunks(20)
                            for chunk in cache_chunks:
                                try:
                                    client_socket.send(chunk)
                                    time.sleep(0.03)
                                except Exception:
                                    stream_active = False
                                    break
        except Exception as e:
            xbmc.log(f"Erro stream canal: {e}", xbmc.LOGERROR)
        finally:
            if response:
                try:
                    response.close()
                except Exception:
                    pass

    def fetch_mp4_with_retry(self, url, range_header=None, method='GET'):
        for attempt in range(MAX_RETRIES):
            try:
                parsed = urlparse(url)
                referer = f"{parsed.scheme}://{parsed.netloc}/"
                headers = {
                    'User-Agent': CHROME_UA,
                    'Accept': 'video/mp4,video/*;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'pt-BR,pt;q=0.9',
                    'Accept-Encoding': 'identity',
                    'Connection': 'keep-alive',
                    'Referer': referer,
                    'Origin': f"{parsed.scheme}://{parsed.netloc}",
                }
                if range_header:
                    headers['Range'] = range_header
                req = Request(url, headers=headers, method=method)
                if url.startswith('https'):
                    response = urlopen(req, timeout=30, context=self.ssl_context)
                else:
                    response = urlopen(req, timeout=30)
                return response
            except Exception:
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_DELAY)
                    continue
                return None

    def _parse_range(self, range_header):
        if not range_header:
            return None
        match = re.search(r'bytes=(\d+)-(\d*)', range_header)
        if not match:
            return None
        start = int(match.group(1))
        end = int(match.group(2)) if match.group(2) else None
        return start, end

    def _parse_total_size(self, headers):
        content_range = headers.get('Content-Range', '') or headers.get('content-range', '')
        match = re.search(r"/(\d+)$", content_range)
        if match:
            return int(match.group(1))
        content_length = headers.get('Content-Length') or headers.get('content-length')
        if content_length and content_length.isdigit():
            return int(content_length)
        return None

    def _detect_mp4(self, url):
        lower = url.lower()
        if any(ext in lower for ext in ['.mp4', '.mkv', '.webm', '.f4v', '.mov', '.avi']):
            return True
        if '/play/' in lower:
            return True
        if 'xtream' in lower and ('/movie/' in lower or '/series/' in lower):
            return True
        return False

    def handle_mp4_stream(self, url, method, req_headers, client_socket):
        cache = self.get_mp4_cache(url)
        range_header = req_headers.get('range')
        parsed_range = self._parse_range(range_header)
        if parsed_range and parsed_range[1] is not None:
            start, end = parsed_range
            cached = cache.get_range(start, end + 1)
            if cached:
                total = cache.content_length or '*'
                self.send_response(
                    client_socket, status=206, reason='Partial Content',
                    headers={
                        'Content-Type': 'video/mp4',
                        'Accept-Ranges': 'bytes',
                        'Content-Length': str(len(cached)),
                        'Content-Range': f'bytes {start}-{start + len(cached) - 1}/{total}',
                    },
                )
                if method not in ('HEAD', 'OPTIONS'):
                    client_socket.send(cached)
                return
        upstream = self.fetch_mp4_with_retry(url, range_header=range_header, method=method)
        if not upstream and range_header:
            upstream = self.fetch_mp4_with_retry(url, range_header='bytes=0-', method=method)
        if not upstream:
            self.send_error(client_socket, 503, 'Falha ao conectar')
            return
        status = upstream.getcode()
        reason = {200: 'OK', 206: 'Partial Content', 416: 'Range Not Satisfiable'}.get(status, 'OK')
        total_size = self._parse_total_size(upstream.headers)
        if total_size:
            cache.content_length = total_size
        upstream_headers = {
            'Content-Type': upstream.headers.get('Content-Type', 'video/mp4'),
            'Accept-Ranges': upstream.headers.get('Accept-Ranges', 'bytes'),
        }
        if upstream.headers.get('Content-Length'):
            upstream_headers['Content-Length'] = upstream.headers.get('Content-Length')
        if upstream.headers.get('Content-Range'):
            upstream_headers['Content-Range'] = upstream.headers.get('Content-Range')
        self.send_response(client_socket, status=status, reason=reason, headers=upstream_headers)
        if method in ('HEAD', 'OPTIONS'):
            upstream.close()
            return
        pos = 0
        if status == 206:
            content_range = upstream.headers.get('Content-Range', '')
            match = re.search(r'bytes\s+(\d+)-', content_range)
            if match:
                pos = int(match.group(1))
            elif parsed_range:
                pos = parsed_range[0]
        try:
            while True:
                chunk = upstream.read(BUFFER_SIZE)
                if not chunk:
                    break
                cache.add_chunk(pos, chunk)
                pos += len(chunk)
                client_socket.send(chunk)
        except (BrokenPipeError, socket.error):
            pass
        except Exception as e:
            xbmc.log(f"Erro stream MP4: {e}", xbmc.LOGERROR)
        finally:
            upstream.close()

    def send_response(self, sock, status=200, reason='OK', headers=None):
        response = f"HTTP/1.1 {status} {reason}\r\n"
        base_headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
            'Access-Control-Allow-Headers': 'Range, Origin, Content-Type, Accept',
            'Connection': 'close',
            'Cache-Control': 'no-cache',
        }
        if headers:
            base_headers.update(headers)
        for k, v in base_headers.items():
            response += f"{k}: {v}\r\n"
        response += "\r\n"
        sock.send(response.encode('utf-8', errors='ignore'))

    def send_error(self, client_socket, code, message):
        reason = {
            400: 'Bad Request', 404: 'Not Found', 416: 'Range Not Satisfiable',
            500: 'Internal Server Error', 503: 'Service Unavailable',
        }.get(code, 'Error')
        body = message.encode('utf-8', errors='ignore')
        self.send_response(
            client_socket, status=code, reason=reason,
            headers={'Content-Type': 'text/plain; charset=utf-8', 'Content-Length': str(len(body))},
        )
        try:
            client_socket.send(body)
        except Exception:
            pass

    def handle_request(self, client_socket, request_data):
        try:
            request_str = request_data.decode('utf-8', errors='ignore')
            lines = request_str.split('\r\n')
            if not lines:
                return
            first_line = lines[0].split(' ')
            if len(first_line) < 2:
                return
            method = first_line[0].upper()
            path = first_line[1]
            if method == 'OPTIONS':
                self.send_response(client_socket, 200, 'OK')
                return
            normalized_headers = {}
            for line in lines[1:]:
                if ': ' in line:
                    key, value = line.split(': ', 1)
                    normalized_headers[key.lower()] = value
            url = self.extract_url_from_path(path)
            if not url:
                body = b"<html><body><h2>Unified Proxy ativo</h2></body></html>"
                self.send_response(
                    client_socket, 200, 'OK',
                    {'Content-Type': 'text/html; charset=utf-8', 'Content-Length': str(len(body))},
                )
                client_socket.send(body)
                return
            if self._detect_mp4(url):
                self.handle_mp4_stream(url, method, normalized_headers, client_socket)
            else:
                self.handle_channel_stream(url, normalized_headers, client_socket)
        except Exception as e:
            xbmc.log(f"Erro proxy request: {e}", xbmc.LOGERROR)
            try:
                self.send_error(client_socket, 500, str(e))
            except Exception:
                pass


# ==================== SERVIDOR PROXY ====================
class UnifiedServer:
    def __init__(self, proxy, port=PROXY_PORT):
        self.port = port
        self.proxy = proxy
        self.running = True
        self._server_socket = None

    def handle_client(self, client_socket, addr):
        try:
            client_socket.settimeout(30)
            request_data = b''
            while True:
                try:
                    chunk = client_socket.recv(8192)
                    if not chunk:
                        break
                    request_data += chunk
                    if b'\r\n\r\n' in request_data:
                        break
                except socket.timeout:
                    break
            if request_data:
                self.proxy.handle_request(client_socket, request_data)
        except Exception as e:
            xbmc.log(f"Erro cliente proxy {addr}: {e}", xbmc.LOGERROR)
        finally:
            try:
                client_socket.close()
            except Exception:
                pass

    def start(self):
        self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self._server_socket.bind(('0.0.0.0', self.port))
            self._server_socket.listen(100)
        except Exception as e:
            xbmc.log(f"Proxy não pôde iniciar na porta {self.port}: {e}", xbmc.LOGERROR)
            return
        local_ip = self.proxy.get_local_ip()
        xbmc.log(f"Proxy unificado iniciado em http://{local_ip}:{self.port}", xbmc.LOGINFO)
        while self.running:
            try:
                client_socket, addr = self._server_socket.accept()
                t = threading.Thread(target=self.handle_client, args=(client_socket, addr))
                t.daemon = True
                t.start()
            except Exception:
                if not self.running:
                    break
                time.sleep(0.1)

    def stop(self):
        self.running = False
        try:
            if self._server_socket:
                self._server_socket.close()
        except Exception:
            pass


# ==================== INSTÂNCIA GLOBAL DO PROXY ====================
PROXY = UnifiedProxy()

_proxy_thread = None
_proxy_server = None
_start_lock = threading.Lock()


def ensure_proxy_running():
    global _proxy_thread, _proxy_server
    with _start_lock:
        if _proxy_thread is not None and _proxy_thread.is_alive():
            return
        _proxy_server = UnifiedServer(PROXY, PROXY_PORT)
        _proxy_thread = threading.Thread(target=_proxy_server.start, daemon=True)
        _proxy_thread.start()
        for _ in range(50):
            time.sleep(0.05)
            try:
                s = socket.create_connection(('127.0.0.1', PROXY_PORT), timeout=0.2)
                s.close()
                break
            except Exception:
                continue
        xbmc.log("ensure_proxy_running: proxy pronto", xbmc.LOGINFO)


def build_proxy_url(url):
    return f"http://127.0.0.1:{PROXY_PORT}/?url={quote(url, safe='')}"


def play_via_proxy(url, label=""):
    """Toca URL através do proxy (canais M3U/TS)."""
    ensure_proxy_running()
    proxied = build_proxy_url(url)
    xbmc.log(f"play_via_proxy [{label}]: {proxied}", xbmc.LOGINFO)
    player = xbmc.Player()
    player.play(proxied, xbmcgui.ListItem(label or 'Canal'))


def play_direct(url, label=""):
    """Toca URL diretamente no player, SEM proxy (filmes/séries Stremio)."""
    xbmc.log(f"play_direct [{label}]: {url}", xbmc.LOGINFO)
    li = xbmcgui.ListItem(label=label or 'Vídeo')
    li.setPath(url)
    try:
        li.setInfo('video', {'title': label or 'Vídeo'})
    except Exception:
        pass
    player = xbmc.Player()
    player.play(url, li)


# ==================== HELPERS KODI (sem RPC HTTP) ====================
def _kodi_execute_jsonrpc(payload):
    """Executa JSON-RPC internamente no Kodi (sem rede, sem porta)."""
    try:
        raw = xbmc.executeJSONRPC(json.dumps(payload))
        data = json.loads(raw)
        if 'error' in data:
            xbmc.log(f"Kodi JSONRPC erro: {data['error']}", xbmc.LOGERROR)
            return None
        return data.get('result')
    except Exception as e:
        xbmc.log(f"Kodi JSONRPC exception: {e}", xbmc.LOGERROR)
        return None


def _get_active_player_id():
    """Retorna o playerid ativo ou None."""
    result = _kodi_execute_jsonrpc({
        "jsonrpc": "2.0",
        "method": "Player.GetActivePlayers",
        "id": 1,
    })
    if result and isinstance(result, list) and len(result) > 0:
        return result[0].get('playerid')
    return None


def kodi_seek_relative(seconds):
    """Avança (positivo) ou retrocede (negativo) X segundos na reprodução atual."""
    playerid = _get_active_player_id()
    if playerid is None:
        xbmc.log("kodi_seek_relative: nenhum player ativo", xbmc.LOGWARNING)
        return False

    result = _kodi_execute_jsonrpc({
        "jsonrpc": "2.0",
        "method": "Player.Seek",
        "params": {
            "playerid": playerid,
            "value": {"relative": {"seconds": int(seconds)}}
        },
        "id": 1,
    })

    if result is not None:
        return True

    # fallback: PlayerControl
    try:
        if seconds > 0:
            if seconds >= 60:
                xbmc.executebuiltin('PlayerControl(BigSkipForward)')
            else:
                xbmc.executebuiltin('PlayerControl(SmallSkipForward)')
        else:
            if abs(seconds) >= 60:
                xbmc.executebuiltin('PlayerControl(BigSkipBackward)')
            else:
                xbmc.executebuiltin('PlayerControl(SmallSkipBackward)')
        return True
    except Exception as e:
        xbmc.log(f"kodi_seek_relative fallback erro: {e}", xbmc.LOGERROR)
        return False


def kodi_shutdown():
    """Fecha o Kodi internamente (sem rede)."""
    result = _kodi_execute_jsonrpc({
        "jsonrpc": "2.0",
        "method": "Application.Quit",
        "id": 1,
    })
    if result == "OK":
        return True

    try:
        xbmc.executebuiltin('Quit')
        return True
    except Exception as e:
        xbmc.log(f"kodi_shutdown fallback erro: {e}", xbmc.LOGERROR)
        return False


# ==================== PARSER DE COMANDO DE SEEK ====================
def parse_seek_command(text_norm):
    """
    Recebe texto normalizado (lowercase, sem acento) e retorna
    (direção, segundos) ou None.
    Direção: 'forward' ou 'backward'
    """
    if not text_norm:
        return None

    forward_kw = ('avancar', 'avanca', 'adiantar', 'adianta', 'pular', 'pula', 'frente')
    backward_kw = ('retroceder', 'retrocede', 'voltar', 'volta', 'atras', 'tras', 'retornar', 'retorna')

    direction = None
    for kw in forward_kw:
        if kw in text_norm:
            direction = 'forward'
            break
    if direction is None:
        for kw in backward_kw:
            if kw in text_norm:
                direction = 'backward'
                break

    if direction is None:
        return None

    total_seconds = 0

    m = re.search(r'(\d+)\s*(?:horas?|hrs?|h)\b', text_norm)
    if m:
        total_seconds += int(m.group(1)) * 3600
    m = re.search(r'(\d+)\s*(?:minutos?|mins?|min|m)\b', text_norm)
    if m:
        total_seconds += int(m.group(1)) * 60
    m = re.search(r'(\d+)\s*(?:segundos?|segs?|seg|s)\b', text_norm)
    if m:
        total_seconds += int(m.group(1))

    if total_seconds == 0:
        m = re.search(r'(\d+)\s*([hms])\b', text_norm)
        if m:
            qty = int(m.group(1))
            unit = m.group(2)
            total_seconds = qty * 3600 if unit == 'h' else (qty * 60 if unit == 'm' else qty)

    if total_seconds == 0:
        m = re.search(r'(\d+)', text_norm)
        if m:
            total_seconds = int(m.group(1))

    if total_seconds <= 0:
        return None

    return (direction, total_seconds)


# ==================== LISTA M3U REMOTA ====================
def normalize(s):
    if not s:
        return ''
    s = unicodedata.normalize('NFKD', s)
    s = ''.join(c for c in s if not unicodedata.combining(c))
    s = s.lower()
    s = re.sub(r'\[[^\]]*\]', ' ', s)
    s = re.sub(r'[^a-z0-9\s]', ' ', s)
    s = re.sub(r'\s+', ' ', s).strip()
    return s


class M3UChannel:
    __slots__ = ('name', 'logo', 'group', 'url', 'norm_name')
    def __init__(self, name, logo, group, url):
        self.name = name
        self.logo = logo or ''
        self.group = group or ''
        self.url = url
        self.norm_name = normalize(self.name)


class M3UList:
    def __init__(self):
        self.channels = []
        self.last_fetch = 0
        self.lock = threading.Lock()
        self._loaded = threading.Event()

    def _parse(self, text):
        out = []
        lines = text.splitlines()
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if line.startswith('#EXTINF'):
                name = ''
                logo = ''
                group = ''
                for attr in ('tvg-name', 'tvg-logo', 'group-title'):
                    m = re.search(rf'{attr}="([^"]*)"', line)
                    if m:
                        val = m.group(1)
                        if attr == 'tvg-name':
                            name = val
                        elif attr == 'tvg-logo':
                            logo = val
                        elif attr == 'group-title':
                            group = val
                if ',' in line:
                    after = line.rsplit(',', 1)[1].strip()
                    if after:
                        name = after
                j = i + 1
                while j < len(lines) and (not lines[j].strip() or lines[j].strip().startswith('#')):
                    j += 1
                if j < len(lines):
                    url = lines[j].strip()
                    if url.startswith(('http://', 'https://', 'rtmp://', 'rtsp://')):
                        out.append(M3UChannel(name, logo, group, url))
                        i = j
            i += 1
        return out

    def fetch(self):
        try:
            req = urllib.request.Request(
                M3U_LIST_URL,
                headers={
                    'User-Agent': CHROME_UA,
                    'Accept': '*/*',
                    'Accept-Language': 'pt-BR,pt;q=0.9',
                },
            )
            with urllib.request.urlopen(req, timeout=30) as r:
                raw = r.read()
                try:
                    text = raw.decode('utf-8')
                except UnicodeDecodeError:
                    text = raw.decode('latin-1', errors='ignore')

            parsed = self._parse(text)
            with self.lock:
                self.channels = parsed
                self.last_fetch = time.time()
            xbmc.log(f"M3UList: {len(parsed)} canais carregados", xbmc.LOGINFO)
            self._loaded.set()
            return True
        except Exception as e:
            xbmc.log(f"M3UList: falha ao baixar lista: {e}", xbmc.LOGERROR)
            return False

    def ensure_loaded(self, timeout=15):
        if self._loaded.is_set():
            if time.time() - self.last_fetch < M3U_REFRESH_SECONDS:
                return True
            threading.Thread(target=self.fetch, daemon=True).start()
            return True
        threading.Thread(target=self.fetch, daemon=True).start()
        return self._loaded.wait(timeout)

    def search(self, query, max_results=10):
        self.ensure_loaded()
        with self.lock:
            chans = list(self.channels)

        q = normalize(query)
        if not q:
            return []

        q_tokens = [t for t in re.split(r'\s+', q) if len(t) >= 2]
        results = []
        for ch in chans:
            name = ch.norm_name
            if not name:
                continue
            score = 0
            if q == name:
                score = 100
            elif name.startswith(q):
                score = 90
            elif q in name:
                score = 75
            elif name in q:
                score = 70
            elif q_tokens and all(t in name for t in q_tokens):
                score = 60
            elif q_tokens:
                hits = sum(1 for t in q_tokens if t in name)
                if hits > 0:
                    score = 30 + 10 * hits
            else:
                continue
            if score > 0:
                results.append((score, ch))

        results.sort(key=lambda x: (-x[0], len(x[1].name)))
        return results[:max_results]

    def find_best(self, query):
        r = self.search(query, max_results=1)
        return r[0][1] if r else None


M3U = M3UList()


def play_m3u_channel(channel):
    xbmc.log(f"play_m3u_channel: {channel.name} -> {channel.url}", xbmc.LOGINFO)
    ensure_proxy_running()
    proxied = build_proxy_url(channel.url)
    li = xbmcgui.ListItem(label=channel.name)
    if channel.logo:
        li.setArt({'thumb': channel.logo, 'icon': channel.logo})
    try:
        li.setInfo('video', {'title': channel.name, 'plot': f"Grupo: {channel.group}"})
    except Exception:
        pass
    xbmc.Player().play(proxied, li)


# ==================== TMDB + STREMIO (FILMES/SÉRIES) ====================
def tmdb_search_imdb_id(title, media_type="movie", year=None):
    """
    Busca o imdb_id de um título via TMDB.
    Se year for informado, filtra por ano; se não achar com ano, tenta sem.
    """
    if not TMDB_API_KEY or TMDB_API_KEY == "SUA_CHAVE_TMDB_AQUI":
        xbmc.log("TMDB: API key não configurada", xbmc.LOGERROR)
        return None

    def _search(year_param=None):
        try:
            encoded = quote(title)
            if media_type == "movie":
                url = (
                    f"https://api.themoviedb.org/3/search/movie"
                    f"?api_key={TMDB_API_KEY}&query={encoded}&language=pt-BR"
                )
                if year_param:
                    url += f"&year={year_param}"
            else:
                url = (
                    f"https://api.themoviedb.org/3/search/tv"
                    f"?api_key={TMDB_API_KEY}&query={encoded}&language=pt-BR"
                )
                if year_param:
                    url += f"&first_air_date_year={year_param}"

            req = Request(url, headers={'User-Agent': CHROME_UA, 'Accept': 'application/json'})
            with urlopen(req, timeout=15) as r:
                data = json.loads(r.read().decode('utf-8'))
            return data.get('results', []) or []
        except Exception as e:
            xbmc.log(f"TMDB search erro: {e}", xbmc.LOGERROR)
            return []

    results = []
    if year:
        results = _search(year)
        if not results:
            xbmc.log(f"TMDB: sem resultado com ano={year}, tentando sem ano", xbmc.LOGINFO)
            results = _search(None)
    else:
        results = _search(None)

    if not results:
        xbmc.log(f"TMDB: nenhum resultado para '{title}'", xbmc.LOGINFO)
        return None

    item = results[0]

    # se year foi passado, prioriza resultado cujo ano bata
    if year:
        def _item_year(it):
            if media_type == "movie":
                d = it.get('release_date') or ''
            else:
                d = it.get('first_air_date') or ''
            return int(d[:4]) if d[:4].isdigit() else None

        matched = [it for it in results if _item_year(it) == int(year)]
        if matched:
            item = matched[0]
        else:
            xbmc.log(f"TMDB: nenhum resultado com ano exato {year}, usando primeiro", xbmc.LOGINFO)

    tmdb_id = item.get('id')
    if not tmdb_id:
        return None

    try:
        if media_type == "movie":
            detail_url = f"https://api.themoviedb.org/3/movie/{tmdb_id}?api_key={TMDB_API_KEY}&language=pt-BR"
        else:
            detail_url = f"https://api.themoviedb.org/3/tv/{tmdb_id}/external_ids?api_key={TMDB_API_KEY}"

        req2 = Request(detail_url, headers={'User-Agent': CHROME_UA, 'Accept': 'application/json'})
        with urlopen(req2, timeout=15) as r2:
            detail = json.loads(r2.read().decode('utf-8'))

        imdb_id = detail.get('imdb_id')
        if imdb_id:
            year_str = f" ({year})" if year else ""
            xbmc.log(f"TMDB: '{title}'{year_str} -> {imdb_id}", xbmc.LOGINFO)
            return imdb_id

        xbmc.log(f"TMDB: imdb_id não encontrado para '{title}'", xbmc.LOGINFO)
        return None
    except Exception as e:
        xbmc.log(f"TMDB detail erro: {e}", xbmc.LOGERROR)
        return None


def stremio_get_streams(imdb_id, media_type="movie", season=1, episode=1):
    """Consulta o addon Stremio e retorna lista de streams (urls)."""
    try:
        if media_type == "movie":
            stream_id = imdb_id
        else:
            stream_id = f"{imdb_id}:{season}:{episode}"

        base = STREMIO_ADDON_BASE.rstrip('/')
        config = f"qualities={STREMIO_ADDON_QUALITIES}|audio={STREMIO_ADDON_AUDIO}|catalogs={STREMIO_ADDON_CATALOGS}"
        url = f"{base}/{config}/stream/{media_type}/{stream_id}.json"

        xbmc.log(f"Stremio: consultando {url}", xbmc.LOGINFO)
        req = Request(url, headers={'User-Agent': CHROME_UA, 'Accept': 'application/json'})
        with urlopen(req, timeout=20) as r:
            data = json.loads(r.read().decode('utf-8'))

        streams = data.get('streams', [])
        urls = []
        for s in streams:
            u = s.get('url')
            if u and u.startswith(('http://', 'https://')):
                urls.append({
                    'url': u,
                    'name': s.get('name', ''),
                    'title': s.get('title', ''),
                })
        xbmc.log(f"Stremio: {len(urls)} streams encontrados", xbmc.LOGINFO)
        return urls
    except Exception as e:
        xbmc.log(f"Stremio erro: {e}", xbmc.LOGERROR)
        return []


def check_url_alive(url, timeout=5):
    """Verifica se a URL responde (HEAD ou GET com Range)."""
    try:
        req = Request(url, method='HEAD', headers={
            'User-Agent': CHROME_UA,
            'Accept': '*/*',
        })
        with urlopen(req, timeout=timeout) as r:
            return r.getcode() in (200, 206)
    except Exception:
        try:
            req = Request(url, headers={
                'User-Agent': CHROME_UA,
                'Accept': '*/*',
                'Range': 'bytes=0-1024',
            })
            with urlopen(req, timeout=timeout) as r:
                return r.getcode() in (200, 206)
        except Exception:
            return False


def play_stremio_stream(imdb_id, media_type="movie", season=1, episode=1, label=""):
    """Consulta Stremio e toca o primeiro stream que responder, DIRETO (sem proxy)."""
    streams = stremio_get_streams(imdb_id, media_type, season, episode)
    if not streams:
        xbmc.log("Stremio: nenhum stream disponível", xbmc.LOGERROR)
        return False

    for i, s in enumerate(streams):
        url = s['url']
        xbmc.log(f"Stremio: testando stream {i+1}/{len(streams)}: {url[:80]}...", xbmc.LOGINFO)
        if check_url_alive(url):
            xbmc.log(f"Stremio: stream {i+1} respondeu, tocando DIRETO", xbmc.LOGINFO)
            play_direct(url, label or s.get('name', 'Stremio'))
            return True
        else:
            xbmc.log(f"Stremio: stream {i+1} não respondeu, tentando próximo", xbmc.LOGINFO)

    xbmc.log("Stremio: nenhum stream respondeu", xbmc.LOGERROR)
    return False


def play_movie_or_series(title, media_type="movie", season=1, episode=1, year=None):
    """Pipeline: TMDB (com ano opcional) -> imdb_id -> Stremio -> player (direto)."""
    imdb_id = tmdb_search_imdb_id(title, media_type, year=year)
    if not imdb_id:
        xbmc.log(f"play_movie_or_series: não achou imdb_id para '{title}' (ano={year})", xbmc.LOGERROR)
        return False

    if media_type == "series":
        label = f"{title} S{season:02d}E{episode:02d}"
    else:
        label = f"{title}" + (f" ({year})" if year else "")

    return play_stremio_stream(imdb_id, media_type, season, episode, label)


# ==================== PARSERS DE COMANDO ====================
def parse_movie_command(text):
    """
    Recebe o texto após remover o prefixo 'filme '.
    Retorna (title, year_or_None).
    """
    if not text:
        return ("", None)

    s = unicodedata.normalize('NFKD', text)
    s = ''.join(c for c in s if not unicodedata.combining(c))
    s = s.lower().strip()

    year = None
    m = re.search(r'\b(19\d{2}|20\d{2}|2100)\b', s)
    if m:
        year = int(m.group(1))
        s = re.sub(r'\b' + m.group(1) + r'\b', ' ', s)

    title = re.sub(r'\s+', ' ', s).strip()
    return (title, year)


def parse_series_command(text):
    """
    Recebe o texto após remover o prefixo 'série '.
    Retorna (title, season, episode, year_or_None).
    Aceita:
      - "supernatural temporada 1 episodio 1"
      - "supernatural temporada 1 episodio 1 2005"
      - "supernatural 2005 temporada 1 episodio 1"
      - "supernatural t1 e1"
      - "supernatural 1x1"
      - "supernatural 1 1"
      - "supernatural 2005"
      - "supernatural"
    """
    if not text:
        return ("", 1, 1, None)

    s = unicodedata.normalize('NFKD', text)
    s = ''.join(c for c in s if not unicodedata.combining(c))
    s = s.lower().strip()

    season = 1
    episode = 1
    year = None
    title_part = s

    # --- PASSO 1: extrair S/E ---
    matched_se = None

    m = re.search(r'^(.*?)\s+temporada\s+(\d+)\s+(?:episodio|ep|e)\s*(\d+)\s*$', s)
    if m:
        matched_se = (m.group(1), int(m.group(2)), int(m.group(3)))

    if not matched_se:
        m = re.search(r'^(.*?)\s+(?:temp|temporada)\s+(\d+)\s+(?:ep|episodio|e)\s*(\d+)\s*$', s)
        if m:
            matched_se = (m.group(1), int(m.group(2)), int(m.group(3)))

    if not matched_se:
        m = re.search(r'^(.*?)\s+t(\d+)\s+(?:e|ep)\s*(\d+)\s*$', s)
        if m:
            matched_se = (m.group(1), int(m.group(2)), int(m.group(3)))

    if not matched_se:
        m = re.search(r'^(.*?)\s+(\d+)\s*x\s*(\d+)\s*$', s)
        if m:
            matched_se = (m.group(1), int(m.group(2)), int(m.group(3)))

    if not matched_se:
        m = re.search(r'^(.*?)\s+(\d+)\s+(\d+)\s*$', s)
        if m:
            a, b = int(m.group(2)), int(m.group(3))
            # filtra anos plausíveis (evita "2005 2010" virar S2005E2010)
            if a <= 50 and b <= 300:
                matched_se = (m.group(1), a, b)

    if matched_se:
        title_part = matched_se[0]
        season = matched_se[1]
        episode = matched_se[2]

    # --- PASSO 2: extrair ano ---
    for candidate in (title_part, s):
        m_year = re.search(r'\b(19\d{2}|20\d{2}|2100)\b', candidate)
        if m_year:
            year = int(m_year.group(1))
            title_part = re.sub(r'\b' + m_year.group(1) + r'\b', ' ', title_part)
            break

    title_clean = re.sub(r'\s+', ' ', title_part).strip()
    return (title_clean, season, episode, year)


# ==================== APLICAÇÃO WSGI ====================
def application(environ, start_response):
    path = environ.get('PATH_INFO', '/')
    query = parse_qs(environ.get('QUERY_STRING', ''))
    method = environ.get('REQUEST_METHOD', 'GET')

    cors_headers = [
        ('Access-Control-Allow-Origin', '*'),
        ('Access-Control-Allow-Methods', 'GET, POST, OPTIONS'),
        ('Access-Control-Allow-Headers', 'Content-Type, Authorization'),
        ('Access-Control-Max-Age', '86400'),
    ]

    if method == 'OPTIONS':
        start_response('204 No Content', cors_headers)
        return [b'']

    status = '200 OK'
    headers = [('Content-type', 'text/plain; charset=utf-8')] + cors_headers

    # ---- Endpoint de busca (debug) ----
    if path == '/search':
        q = query.get('q', [''])[0]
        results = M3U.search(q, max_results=10)
        start_response(status, headers)
        if not results:
            body = f'nenhum resultado para "{q}"'
        else:
            body = '\n'.join(f"{s:3d} | {c.name} | {c.url}" for s, c in results)
        return [body.encode('utf-8')]

    # ---- Endpoint de lista carregada ----
    if path == '/channels':
        M3U.ensure_loaded()
        with M3U.lock:
            total = len(M3U.channels)
        start_response(status, headers)
        return [f'{total} canais carregados'.encode('utf-8')]

    # ---- Endpoint de teste TMDB+Stremio ----
    if path == '/movie':
        title = query.get('title', [''])[0]
        mtype = query.get('type', ['movie'])[0]
        season = int(query.get('s', ['1'])[0])
        episode = int(query.get('e', ['1'])[0])
        year_q = query.get('year', [''])[0]
        year = int(year_q) if year_q.isdigit() else None
        if not title:
            start_response(status, headers)
            return [b'uso: /movie?title=Nome&type=movie|series&s=1&e=1&year=2023']

        ok = play_movie_or_series(title, mtype, season, episode, year=year)
        start_response(status, headers)
        return [f'{"OK: tocando" if ok else "FALHA: nenhum stream respondeu"}'.encode('utf-8')]

    # ---- Comando principal ----
    if path == '/cmd':
        text = query.get('text', [''])[0]
        if not text:
            start_response(status, headers)
            return [b'Erro: Sem texto']

        xbmc.log(f"Recebido comando de voz: {text}", xbmc.LOGINFO)

        try:
            if isinstance(text, bytes):
                text = text.decode('utf-8')
        except Exception:
            pass

        text_l = text.lower()

        # ---- CONTROLE DE PLAYER ----
        if 'pausar' in text_l or 'pausa' in text_l:
            try:
                xbmc.Player().pause()
            except Exception as e:
                xbmc.log(f"Erro ao pausar: {e}", xbmc.LOGERROR)
            start_response(status, headers)
            return [b'OK: Pausado']

        if 'continuar' in text_l or 'despausar' in text_l or text_l.strip() == 'play':
            try:
                xbmc.Player().pause()
            except Exception as e:
                xbmc.log(f"Erro ao despausar: {e}", xbmc.LOGERROR)
            start_response(status, headers)
            return [b'OK: Retomado']

        if 'parar' in text_l or 'stop' in text_l:
            try:
                xbmc.Player().stop()
            except Exception as e:
                xbmc.log(f"Erro ao parar: {e}", xbmc.LOGERROR)
            start_response(status, headers)
            return [b'OK: Parado']

        # ---- FECHAR KODI ----
        if re.search(r'\b(fechar|fecha|encerrar|encerra|desligar|desliga)\b', text_l) or \
           ('kodi' in text_l and ('fechar' in text_l or 'encerrar' in text_l)):
            ok = kodi_shutdown()
            start_response(status, headers)
            return [b'OK: Fechando Kodi' if ok else b'FALHA: nao consegui fechar']

        # ---- SEEK (avancar/retroceder) ----
        _tn = unicodedata.normalize('NFKD', text)
        _tn = ''.join(c for c in _tn if not unicodedata.combining(c)).lower().strip()

        seek_info = parse_seek_command(_tn)
        if seek_info:
            direction, seconds = seek_info
            signed = seconds if direction == 'forward' else -seconds
            ok = kodi_seek_relative(signed)
            label = f"{'+' if signed > 0 else ''}{signed}s"
            start_response(status, headers)
            return [f'OK: Seek {label}'.encode('utf-8') if ok
                    else f'FALHA: seek {label}'.encode('utf-8')]

        # ---- FILME ----
        movie_match = re.match(r'^(?:filme|movie)\s+(.+)$', text, re.IGNORECASE)
        if movie_match:
            raw_title = movie_match.group(1).strip()
            title, year = parse_movie_command(raw_title)
            if not title:
                start_response(status, headers)
                return [b'FALHA: titulo vazio']
            year_str = f" ({year})" if year else ""
            xbmc.log(f"Filme parse: title='{title}'{year_str}", xbmc.LOGINFO)
            ok = play_movie_or_series(title, "movie", year=year)
            start_response(status, headers)
            return [f'OK: Filme "{title}"{year_str}'.encode('utf-8') if ok
                    else f'FALHA: "{title}"{year_str} (sem stream)'.encode('utf-8')]

        # ---- SÉRIE ----
        series_match = re.match(r'^(?:serie|série|series)\s+(.+)$', text, re.IGNORECASE)
        if series_match:
            rest = series_match.group(1).strip()
            title, season, episode, year = parse_series_command(rest)
            if not title:
                start_response(status, headers)
                return [b'FALHA: titulo vazio']
            year_str = f" ({year})" if year else ""
            xbmc.log(f"Serie parse: title='{title}'{year_str} S{season:02d}E{episode:02d}", xbmc.LOGINFO)
            ok = play_movie_or_series(title, "series", season, episode, year=year)
            start_response(status, headers)
            return [f'OK: Série "{title}"{year_str} S{season:02d}E{episode:02d}'.encode('utf-8') if ok
                    else f'FALHA: "{title}"{year_str} S{season:02d}E{episode:02d} (sem stream)'.encode('utf-8')]

        # ---- CANAIS M3U ----
        q = text
        for prefix in ('abrir ', 'tocar ', 'canal ', 'colocar ', 'abre ', 'toca ',
                       'coloca ', 'assistir ', 'ver ', 'quero ver ', 'coloque '):
            if text_l.startswith(prefix):
                q = text[len(prefix):].strip()
                break

        if q:
            channel = M3U.find_best(q)
            if channel:
                play_m3u_channel(channel)
                start_response(status, headers)
                return [f'OK: Tocando "{channel.name}" via proxy'.encode('utf-8')]

            start_response(status, headers)
            return [f'Nao encontrado: "{q}"'.encode('utf-8')]

        start_response(status, headers)
        return [f'OK: Recebido - {text}'.encode('utf-8')]

    start_response(status, headers)
    return [b'Voz Kodi Servidor Ativo']


def run_voice_server():
    try:
        httpd = make_server('', VOICE_PORT, application)
        xbmc.log(f"Servidor de voz iniciado na porta {VOICE_PORT}", xbmc.LOGINFO)
        httpd.serve_forever()
    except Exception as e:
        xbmc.log(f"Erro no servidor de voz: {e}", xbmc.LOGERROR)


class VozKodiService(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        ensure_proxy_running()
        threading.Thread(target=M3U.ensure_loaded, kwargs={'timeout': 20}, daemon=True).start()
        self.voice_thread = threading.Thread(target=run_voice_server, daemon=True)
        self.voice_thread.start()

    def onSettingsChanged(self):
        pass


if __name__ == '__main__':
    monitor = VozKodiService()
    try:
        while not monitor.abortRequested():
            if monitor.waitForAbort(10):
                break
    finally:
        if _proxy_server:
            _proxy_server.stop()