try:
    from libs.browser import request, UA  # kodi
except:
    from browser import request, UA  # vscode

from bs4 import BeautifulSoup
import re
import base64
import html as htmllib
try:
    import json
except:
    import simplejson as json
try:
    from urllib.parse import urlparse, parse_qs, quote_plus, urljoin  # python 3
except ImportError:
    from urlparse import urlparse, parse_qs  # python 2
    from urllib import quote_plus
    from urlparse import urljoin

# Configurações gerais
homepage = 'https://www.redtube.com.br'
search_page = homepage + '/?search='
# Headers para burlar verificação de idade e definir User-Agent moderno
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/120.0.0.0 Safari/537.36",
    "Cookie": "age_verified=1"
}

def index():
    lista_menu = [
        ('Recomendados', homepage + '/recommended'),
        ('Mais Vistos', homepage + '/mostviewed'),
        ('Populares', homepage + '/hot?cc=br'),
        ('Mais Novos', homepage + '/newest')
    ]
    return lista_menu

def index_page(url):
    html = request.get_url(url, headers=HEADERS)
    soup = BeautifulSoup(html, 'html.parser')
    a = soup.find_all("a", class_=re.compile("^video_link"))
    lista_pagina = []
    if a:
        for i in a:
            href = urljoin(homepage, i.get("href") or '')
            img = i.find("img").get("data-o_thumb") or i.find("img").get("data-src", "")
            name = i.find("img").get("alt") or 'Nome desconhecido!'
            lista_pagina.append((name, img, href))
    try:
        next = soup.find("link", {"rel": "next"}).get('href')
        next_url = urljoin(homepage, next) if next else False
    except:
        next_url = False
    return lista_pagina, next_url

def categorias():
    url = homepage + '/categories'
    html = request.get_url(url, headers=HEADERS)
    soup = BeautifulSoup(html, 'html.parser')
    ul = soup.find("ul", {"id": "categories_list_block"})
    div_list = ul.find_all("div", class_=re.compile("^category_item_wrapper")) if ul else []
    lista_categorias = []
    if div_list:
        for i in div_list:
            href = urljoin(homepage, i.find("a").get("href") or '')
            name = i.find("img").get("alt") or 'Nome desconhecido!'
            img = i.find("img").get("data-src", "")
            lista_categorias.append((name, href, img))
    return lista_categorias

class RedResolver:
    def _safe_decode(self, html):
        if isinstance(html, bytes):
            for enc in ("utf-8", "latin-1"):
                try:
                    return html.decode(enc)
                except Exception:
                    continue
            return html.decode("utf-8", errors="replace")
        return html

    def _safe_json_loads(self, txt):
        try:
            return json.loads(txt)
        except Exception:
            try:
                fixed = txt.replace("'", '"')
                fixed = re.sub(r",\s*]", "]", fixed)
                fixed = re.sub(r",\s*}", "}", fixed)
                return json.loads(fixed)
            except Exception:
                return None

    def resolve(self, url):
        try:
            print(f"[RedResolver] Resolvendo URL: {url}")
            html = request.get_url(url, headers=HEADERS)
            if not html:
                print("[RedResolver] Falha ao obter HTML")
                return False

            html = self._safe_decode(html)
            referer = url
            url_parsed = urlparse(url)
            origin = f"{url_parsed.scheme}://{url_parsed.netloc}"

            def wrap(u):
                # Corrigir URL relativa
                abs_url = urljoin(origin, u)
                return (
                    f"{abs_url}|User-Agent={quote_plus(HEADERS['User-Agent'])}"
                    f"&Origin={quote_plus(origin)}"
                    f"&Referer={quote_plus(referer)}"
                )

                        # prepare unescaped version (some endpoints return JSON with escaped slashes)
            text = html
            text_unesc = text.replace('\\/', '/')


            # 0) se a resposta for JSON (ex: endpoint /media/hls?s=...), tentar parsear e extrair videoUrl
            txt_strip = text.strip()
            if txt_strip.startswith('[') or txt_strip.startswith('{'):
                try:
                    # tentar normalizar barras escapadas e carregar
                    j = self._safe_json_loads(text_unesc) or self._safe_json_loads(text)
                    if j:
                        # coletar possíveis objetos de mídia (listas/dicts aninhados)
                        def collect_dict_items(obj):
                            items = []
                            if isinstance(obj, dict):
                                items.append(obj)
                                for v in obj.values():
                                    if isinstance(v, (dict, list)):
                                        items += collect_dict_items(v)
                            elif isinstance(obj, list):
                                for it in obj:
                                    items += collect_dict_items(it)
                            return items

                        items = collect_dict_items(j)

                        media_candidates = []
                        for it in items:
                            if not isinstance(it, dict):
                                continue
                            # vários nomes possíveis para o link
                            url = it.get("videoUrl") or it.get("url") or it.get("file") or it.get("src")
                            if not url:
                                continue
                            # limpar barras escapadas
                            url = url.replace('\\\\/', '/').replace('\\/', '/')
                            quality = str(it.get("quality") or it.get("label") or "").strip()
                            media_candidates.append({"url": url, "quality": quality})

                        # Se achou candidatos, escolher sempre a maior qualidade numérica disponível
                        if media_candidates:
                            def quality_value(c):
                                try:
                                    import re as _re
                                    nums = _re.findall(r"\d+", c.get("quality","") or "")
                                    if nums:
                                        # pegar o maior número presente (ex: "1080P_4000K" -> 1080)
                                        return int(max(nums, key=lambda x: int(x)))
                                    # fallback: inferir qualidade a partir da URL (ex: '1080P' no nome)
                                    nums_url = _re.findall(r"\d+", c.get("url","") or "")
                                    if nums_url:
                                        return int(max(nums_url, key=lambda x: int(x)))
                                    return 0
                                except:
                                    return 0
                            best = sorted(media_candidates, key=quality_value, reverse=True)[0]
                            return wrap(best["url"])

                        # 3) fallback: procurar por qualquer URL .m3u8/.mp4 no JSON (mantendo compatibilidade)
                        def find_urls(obj):
                            urls = []
                            if isinstance(obj, dict):
                                for k, v in obj.items():
                                    if isinstance(v, (dict, list)):
                                        urls += find_urls(v)
                                    elif isinstance(v, str):
                                        if '.m3u8' in v.lower() or '.mp4' in v.lower():
                                            urls.append(v.replace('\\\\/', '/').replace('\\/', '/'))
                            elif isinstance(obj, list):
                                for it in obj:
                                    urls += find_urls(it)
                            return urls

                        found = find_urls(j)
                        if found:
                            print(f"[RedResolver] URLs extraídas do JSON: {len(found)}")
                            return wrap(found[0])
                except Exception as e:
                    print("[RedResolver] falha ao parsear JSON da resposta:", e)            # 1) procura direto por m3u8 na versão des-escapada
            m3u8s = re.findall(r"https?://[^'\"\\s<>]+\\.m3u8[^'\"\\s<>]*", text_unesc, flags=re.I)
            print(f"[RedResolver] m3u8 encontrados (unescaped): {len(m3u8s)}")
            if m3u8s:
                return wrap(m3u8s[0])

            # 1b) procura videoUrl em JSON/strings escapadas
            video_urls = re.findall(r'"videoUrl"\\s*:\\s*"([^\\"]+)"', text, flags=re.I)
            if video_urls:
                for v in video_urls:
                    v_clean = v.replace('\\\\/', '/')
                    if '.m3u8' in v_clean.lower() or '.mp4' in v_clean.lower():
                        print(f"[RedResolver] videoUrl extraído: {v_clean}")
                        return wrap(v_clean)

            # fallback: procura m3u8 na versão original
            m3u8s_raw = re.findall(r"https?://[^'\"\\s<>]+\\.m3u8[^'\"\\s<>]*", text, flags=re.I)
            if m3u8s_raw:
                print(f"[RedResolver] m3u8 encontrados (raw): {len(m3u8s_raw)}")
                return wrap(m3u8s_raw[0])
            # mediaDefinition
            media_defs = []
            m = re.search(r'mediaDefinition\s*=\s*(\[[^\]]+\])', html, flags=re.S)
            if m:
                media_defs = self._safe_json_loads(m.group(1)) or []

                        # Se não é o endpoint e não achou na carga JSON, tentar localizar endpoint /media/hls?s=... no HTML (inclui versão des-escapada)
            m = re.search(r'(https?://[^\'"\\s<>]+/media/hls\?s=[A-Za-z0-9._\-=%]+)', text_unesc)
            if not m:
                m = re.search(r'(https?://[^\'"\\s<>]+/media/hls\?s=[^\'"\\s<>]+)', text_unesc)
            if not m:
                m = re.search(r'(https?://[^\'"\\s<>]+/media/hls\?s=[^\'"\\s<>]+)', html)
            if not m:
                m = re.search(r'(/media/hls\?s=[A-Za-z0-9._\-=%]+)', text_unesc)
            if m:
                hls_url = m.group(1)
                if hls_url.startswith('/'):
                    hls_url = origin + hls_url
                print("[RedResolver] Encontrado endpoint media/hls (extraído): %s" % hls_url)
                return self.resolve(hls_url)

            if not media_defs:
                m = re.search(r'"mediaDefinition"\s*:\s*(\[[^\]]+\])', html, flags=re.S)
                if m:
                    media_defs = self._safe_json_loads(m.group(1)) or []

            if not media_defs:
                m = re.search(r'flashvars_[\w\d]+\s*=\s*(\{.*?\});', html, flags=re.S)
                if m:
                    jsobj = self._safe_json_loads(m.group(1))
                    if isinstance(jsobj, dict):
                        media_defs = jsobj.get('mediaDefinitions') or jsobj.get('mediaDefinition') or []

            if not media_defs:
                m = re.search(r'"mediaDefinitions"\s*:\s*(\[[^\]]+\])', html, flags=re.S)
                if m:
                    media_defs = self._safe_json_loads(m.group(1)) or []

            if media_defs and isinstance(media_defs, list):
                qmap = {"1080": [], "720": [], "480": [], "360": [], "240": []}
                for it in media_defs:
                    if not isinstance(it, dict):
                        continue
                    link = it.get("videoUrl") or it.get("url") or it.get("file") or it.get("src")
                    quality = str(it.get("quality") or it.get("label") or "")
                    if not link:
                        continue
                    quality = quality.replace("p", "").strip()
                    if quality in qmap:
                        qmap[quality].append(link)
                    else:
                        try:
                            qnum = int(re.sub(r"\D", "", quality))
                            if qnum >= 1000:
                                qmap["1080"].append(link)
                            elif qnum >= 700:
                                qmap["720"].append(link)
                            elif qnum >= 400:
                                qmap["480"].append(link)
                            else:
                                qmap["360"].append(link)
                        except:
                            qmap["360"].append(link)
                for q in ("1080", "720", "480", "360", "240"):
                    if qmap[q]:
                        return wrap(qmap[q][0])

            # mp4 direto
            mp4s = re.findall(r'https?://[^\'"\\s<>]+\.mp4[^\'"\\s<>]*', html, flags=re.I)
            if mp4s:
                return wrap(mp4s[0])

            return False

        except Exception as e:
            print("[RedResolver] ERRO GERAL:", e)
            return False

RedtubeResolver = RedResolver()