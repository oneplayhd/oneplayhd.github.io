try:
    from libs.browser import request, UA  # kodi
except:
    from browser import request, UA  # vscode

from bs4 import BeautifulSoup
import re
try:
    import json
except:
    import simplejson as json
try:
    from urllib.parse import urlparse, parse_qs, quote_plus  # python 3
except ImportError:
    from urlparse import urlparse, parse_qs  # python 2
    from urllib import quote_plus

homepage = 'https://pt.pornhub.com'
search_page = homepage + '/video/search?search='


def index():
    html = request.get_url(homepage + '/')
    soup = BeautifulSoup(html, 'html.parser')

    anchors = soup.find_all('a', href=True)
    candidates = {}
    for a in anchors:
        href = a['href']
        text = (a.get_text(" ", strip=True) or a.get('title') or '').strip()
        if not text:
            continue
        if href.startswith('/'):
            full = homepage + href
        elif href.startswith('http'):
            full = href
        else:
            continue
        if '/video?' in href or ('/video' in href and 'view_video.php' not in href):
            if 'o=ht' in href and 'ht' not in candidates:
                candidates['ht'] = (text, full)
            if 'o=mv' in href and 'mv' not in candidates:
                candidates['mv'] = (text, full)
            if 'o=tr' in href and 'tr' not in candidates:
                candidates['tr'] = (text, full)
            if 'p=homemade' in href and 'homemade' not in candidates:
                candidates['homemade'] = (text, full)

    fallback_names = []
    for key in ('tr', 'ht', 'mv', 'homemade'):
        if key in candidates:
            fallback_names.append(candidates[key])

    if not fallback_names:
        try:
            return categorias()
        except:
            return []

    return fallback_names


def index_page(url):
    html = request.get_url(url)
    soup = BeautifulSoup(html, 'html.parser')
    lista_pagina = []

    anchors = soup.find_all('a', href=True)
    seen = set()
    for a in anchors:
        href = a['href']
        if 'view_video.php' in href or '/embed/' in href or '/watch/' in href:
            if href.startswith('/'):
                full = homepage + href
            elif href.startswith('http'):
                full = href
            else:
                continue
            if full in seen:
                continue

            # Nome do vídeo
            name = a.get('title') or a.get('data-title') or a.get_text(" ", strip=True)
            name = (name or "").strip()

            # Filtro para remover entradas indesejadas
            if not name or name.lower() in ('reproduzir todos', 'play all'):
                continue
            if len(name) < 4:
                continue
            if any(cls in (a.get('class') or []) for cls in ['playAll', 'all', 'js-playAll']):
                continue

            # Thumbnail
            img_tag = a.find('img') or a.find_next('img')
            img = ''
            if img_tag:
                for attr in ('data-src', 'data-thumb_url', 'data-image', 'data-mediumthumb', 'data-mediumthumb-url', 'data-srcset', 'src'):
                    val = img_tag.get(attr)
                    if val:
                        img = val
                        break
                if not img and img_tag.get('src'):
                    img = img_tag.get('src')

            if not name and img_tag:
                name = img_tag.get('alt') or ''

            if not name:
                title_meta = a.find(attrs={'data-title': True})
                if title_meta:
                    name = title_meta.get('data-title')

            lista_pagina.append((name, img, full))
            seen.add(full)

    # Paginação
    next_tag = soup.find('link', rel='next')
    if next_tag and next_tag.get('href'):
        next_url = next_tag['href']
        if next_url.startswith('/'):
            next_url = homepage + next_url
    else:
        try:
            next_btn = soup.find("li", {"class": "page_next"})
            next_url = homepage + next_btn.find("a").get('href') if next_btn and next_btn.find("a") else False
        except:
            next_url = False

    return lista_pagina, next_url


def categorias():
    """
    Retorna lista de categorias como (name, full_url, img)
    Busca em vários pontos do HTML para suportar mudanças de markup.
    """
    url = homepage + '/categories'
    try:
        html = request.get_url(url) or ''
    except Exception:
        return []

    soup = BeautifulSoup(html, 'html.parser')
    lista_categorias = []
    seen = set()

    anchors = []
    ul = soup.find("ul", {"class": "catHeaderSubMenu"})
    if ul:
        anchors = ul.find_all("a", href=True)

    if not anchors:
        menu_div = soup.find(lambda tag: tag.name == 'div' and tag.get('class') and any('categoriesMenu' in c for c in tag.get('class')))
        if menu_div:
            anchors = menu_div.find_all("a", href=True)

    if not anchors:
        anchors = soup.find_all("a", href=True)

    for a in anchors:
        href = a.get('href') or ''
        if not href:
            continue

        if href.startswith('/'):
            full = homepage.rstrip('/') + href
        elif href.startswith('http'):
            full = href
        else:
            full = homepage.rstrip('/') + '/' + href.lstrip('/')

        if not any(x in href for x in ['/video?c=', '/categories', '/vr', '/video?']):
            if not (a.get('class') or a.get('data-menu-clog') or a.get('data-menu-taste')):
                continue

        if full in seen:
            continue

        name = ''
        strong = a.find('strong')
        if strong and strong.string:
            name = strong.string.strip()
        else:
            span = a.find('span')
            if span:
                name = span.get_text(" ", strip=True)
            else:
                name = a.get_text(" ", strip=True)

        if not name:
            img_tag_tmp = a.find('img')
            if img_tag_tmp:
                name = (img_tag_tmp.get('alt') or img_tag_tmp.get('title') or '').strip()
        if not name:
            name = ''

        img = ''
        img_tag = a.find('img')
        if img_tag:
            img = img_tag.get('data-image') or img_tag.get('data-src') or img_tag.get('src') or ''

        lista_categorias.append((name, full, img))
        seen.add(full)

    return lista_categorias


class PornResolver:
    def sort_sources_list(self, sources):
        if len(sources) > 1:
            try:
                sources.sort(key=lambda x: int(re.sub(r"\D", "", x[0])), reverse=True)
            except:
                try:
                    sources.sort(key=lambda x: re.sub("[^a-zA-Z]", "", x[0].lower()))
                except:
                    pass
        return sources

    def pick_source(self, sources):
        if len(sources) == 1:
            return sources[0][1]
        elif len(sources) > 1:
            return sources[0][1]
        else:
            return ''

    def resolve(self, url):
        html = request.get_url(url)
        referer = url
        url_parsed = urlparse(url)
        origin = '%s://%s' % (url_parsed.scheme, url_parsed.netloc)
        try:
            html = html.decode('utf-8')
        except:
            pass
        sources = []
        qvars = re.search(r'qualityItems_[^\[]+([^;]+)', html)
        if qvars:
            sources = json.loads(qvars.group(1))
            sources = [(src.get('text'), src.get('url')) for src in sources if src.get('url')]
        if not sources:
            sections = re.findall(r'(var\sra[a-z0-9]+=.+?);flash', html)
            for section in sections:
                pvars = re.findall(r'var\s(ra[a-z0-9]+)=([^;]+)', section)
                link = re.findall(r'var\smedia_\d+=([^;]+)', section)[0]
                link = re.sub(r"/\*.+?\*/", '', link)
                for key, value in pvars:
                    link = re.sub(key, value, link)
                link = link.replace('"', '').split('+')
                link = [i.strip() for i in link]
                link = ''.join(link)
                if 'urlset' not in link:
                    r = re.findall(r'(\d+p)', link, re.I)
                    if r:
                        sources.append((r[0], link))
        if not sources:
            fvars = re.search(r'flashvars_\d+\s*=\s*(.+?);\s', html)
            if fvars:
                sources = json.loads(fvars.group(1)).get('mediaDefinitions')
                sources = [(src.get('quality'), src.get('videoUrl')) for src in sources if
                           type(src.get('quality')) is not list and src.get('videoUrl')]
        if sources:
            sorted_sources = self.sort_sources_list(sources)
            picked_source = self.pick_source(sorted_sources)
            stream = picked_source + '|User-Agent=' + quote_plus(UA) + '&Origin=' + quote_plus(origin) + '&Referer=' + quote_plus(referer)
        else:
            stream = False
        return stream


PornhubResolver = PornResolver()
