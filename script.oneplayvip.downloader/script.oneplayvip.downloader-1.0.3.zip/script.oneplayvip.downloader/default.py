# default.py
# -*- coding: utf-8 -*-
import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
from scrapy import listar_apks
import ntpath

addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')

# Pasta de download (em Android)
FOLDER_DOWNLOADS = '/storage/emulated/0/Download'

def platform():
    """
    Retorna a plataforma atual (apenas 'android' ou outra).
    """
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux') or xbmc.getCondVisibility('system.platform.linux.Raspberrypi'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios') or xbmc.getCondVisibility('system.platform.darwin'):
        return 'ios'
    return None

def infoDialog(message, heading=addonname, iconimage=None, time=3000, sound=False):
    """
    Mostra uma notificação simples.
    """
    if iconimage is None:
        iconimage = icon
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR

    xbmcgui.Dialog().notification(heading, message, iconimage, time, sound=sound)

def download_apk(url, dest):
    """
    Chama o downloader.py para baixar o APK.
    """
    try:
        # importa o módulo corrigido sem causar import circular
        import downloader
        filename = ntpath.basename(url)
        dp = xbmcgui.DialogProgress()
        dp.create(f'Baixando {filename}...', 'Por favor, aguarde...')
        downloader.download(url, filename, dest, dp=dp)
        infoDialog('Download concluído', iconimage='INFO')
    except Exception:
        infoDialog('Erro ao baixar o APK', iconimage='WARNING')

def select_apk(namelist):
    """
    Abre uma lista de seleção e retorna o índice escolhido.
    """
    return xbmcgui.Dialog().select('SELECIONE UM APK ABAIXO', namelist)

def build_itens():
    """
    Busca a lista de APKs via scrapy.listar_apks() e retorna a URL selecionada.
    """
    itens = listar_apks()
    if not itens:
        return False

    names = [name for name, _url in itens]
    urls  = [_url for _name, _url in itens]

    escolha = select_apk(names)
    if escolha >= 0:
        return urls[escolha]
    return False

def baixar_apk():
    """
    Fluxo principal: verifica plataforma, escolhe APK, faz download e informa usuário.
    """
    if platform() == 'android':
        url = build_itens()
        if not url:
            return

        if url.lower().endswith('.apk'):
            name = ntpath.basename(url)

            # garante que a pasta exista
            if not xbmcvfs.exists(FOLDER_DOWNLOADS):
                xbmcvfs.mkdirs(FOLDER_DOWNLOADS)

            dest = os.path.join(FOLDER_DOWNLOADS, name)

            # remove residuais
            if os.path.isfile(dest):
                try:
                    os.remove(dest)
                except:
                    pass

            download_apk(url, dest)

            if os.path.isfile(dest):
                # Informa ao usuário que o APK está na pasta Downloads
                xbmcgui.Dialog().ok(
                addonname,
                '[COLOR yellow]Download concluído com êxito![/COLOR]\n'
                'O arquivo APK foi salvo em:\n'
                '[COLOR lime]' + dest + '[/COLOR]\n'
                '[COLOR white]Feche o Kodi, abra o gerenciador de arquivos do Android e instale o aplicativo manualmente.[/COLOR]')

    else:
        xbmcgui.Dialog().ok(addonname, 'Este dispositivo não é Android!')

if __name__ == '__main__':
    baixar_apk()
