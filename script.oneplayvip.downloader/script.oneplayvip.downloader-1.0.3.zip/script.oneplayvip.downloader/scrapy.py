# scrapy.py
# -*- coding: utf-8 -*-
import ntpath
import base64

# Lista de tuplas (nome de exibição)
APKS_LIST = [
    ("OnePlay Alpha",   "aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL09uZVBsYXlBbHBoYS5hcGs="),
    ("OnePlay Xtream",  "aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL09uZVBsYXlYdHJlYW0uYXBr"),
    ("Aptoide TV",      "aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL0FwdG9pZFRWLmFwaw=="),
]

def listar_apks():
    """
    Retorna uma lista de tuplas (nome, url) a partir de APKS_LIST.
    O 'nome' será exibido no diálogo, e o 'url' (decodificado de Base64)
    será usado para download.
    """
    resultado = []
    for nome, b64 in APKS_LIST:
        # decodifica o link em Base64 de volta para string UTF-8
        url = base64.b64decode(b64.encode("utf-8")).decode("utf-8")
        resultado.append((nome, url))
    return resultado
