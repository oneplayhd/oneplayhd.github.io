# -*- coding: utf-8 -*-
import os
import sys
import json
import shutil

from kodi_six import xbmcaddon, xbmc, xbmcgui, xbmcplugin, xbmcvfs

try:
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode, unquote_plus
except ImportError:
    from urllib2 import urlopen, Request
    from urllib import urlencode, unquote_plus

try:
    from .tmdb import tmdb_to_imdb
except (ImportError, ValueError):
    from lib.tmdb import tmdb_to_imdb

addon = xbmcaddon.Addon()
handle = int(sys.argv[1])

# translatePath compatível Py2 / Py3
try:
    from xbmcvfs import translatePath
except (ImportError, AttributeError):
    from xbmc import translatePath

__profile__ = translatePath(addon.getAddonInfo('profile'))
__temp__ = os.path.join(__profile__, 'temp')

if not xbmcvfs.exists(__temp__):
    xbmcvfs.mkdirs(__temp__)

# --------------------------------------------------
# HTTP CLIENT (Chrome UA)
# --------------------------------------------------

__HEADERS__ = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/122.0.0.0 Safari/537.36'
    )
}

def http_get(url, timeout=15):
    print('HTTP GET:', url)
    req = Request(url, headers=__HEADERS__)
    return urlopen(req, timeout=timeout).read()

# --------------------------------------------------

def subtitle_clear():
    if xbmcvfs.exists(__temp__):
        shutil.rmtree(__temp__)
    xbmcvfs.mkdirs(__temp__)

def set_subtitle(sub):
    li = xbmcgui.ListItem(label2=os.path.basename(sub))
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=sub,
        listitem=li,
        isFolder=False
    )
    xbmcplugin.endOfDirectory(handle)

# --------------------------------------------------

def get_video_info():
    tag = xbmc.Player().getVideoInfoTag()
    imdb = tag.getIMDBNumber()
    try:
        season = tag.getSeason()
        if season != -1:
            season = str(season)
        else:
            season = None
    except:
        season = None
    try:
        episode = tag.getEpisode()
        if episode != -1:
            episode = str(episode)
        else:
            episode = None
    except:
        episode = None

    return {
        'imdb': imdb,
        'season': season,
        'episode': episode
    }

# --------------------------------------------------

def fetch_subs(imdb, season=None, episode=None):
    if season and episode:
        url = (
            'https://sub.wyzie.ru/search?id=%s&language=pb'
            '&season=%s&episode=%s'
        ) % (imdb, season, episode)
    else:
        url = 'https://sub.wyzie.ru/search?id=%s&language=pb' % imdb
    try:
        data = http_get(url)
    except:
        return []
    return json.loads(data.decode('utf-8'))

# --------------------------------------------------

def search_subtitle(lang, manual=None):
    video = get_video_info()
    imdb = video.get('imdb')

    if manual:
        imdb = tmdb_to_imdb(manual)

    if not imdb:
        xbmcgui.Dialog().notification(
            'Wyzie Subs',
            'IMDB não encontrado',
            xbmcgui.NOTIFICATION_ERROR
        )
        return
    
    if manual and video.get('season') and video.get('episode'):
        subs = []
        subs1 = fetch_subs(
            imdb,
            video.get('season'),
            video.get('episode')
        )
        subs2 = fetch_subs(imdb, None, None)
        subs = subs1 + subs2
    else:
        subs = fetch_subs(
            imdb,
            video.get('season'),
            video.get('episode')
        )

    for sub in subs:
        li = xbmcgui.ListItem(
            label=sub.get('display', 'Portuguese'),
            label2=sub.get('release', '')
        )

        li.setProperty('sync', 'true')
        li.setProperty(
            'hearing_imp',
            'true' if sub.get('isHearingImpaired') else 'false'
        )
        li.setProperty('language', sub.get('language', 'pb'))

        if sub.get('flagUrl'):
            li.setArt({
                'thumb': sub['flagUrl'],
                'icon': sub['flagUrl']
            })

        url = sys.argv[0] + '?' + urlencode({
            'action': 'download',
            'sub': sub['url']
        })

        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=url,
            listitem=li,
            isFolder=False
        )

    xbmcplugin.endOfDirectory(handle)

# --------------------------------------------------

def download_(url):
    try:
        url = unquote_plus(url)
    except:
        pass
    subtitle_clear()

    data = http_get(url)

    filename = os.path.basename(url.split('?')[0])
    if not filename.lower().endswith('.srt'):
        filename = 'subtitle.srt'

    dest = os.path.join(__temp__, filename)

    with open(dest, 'wb') as f:
        f.write(data)

    list_subtitle()

# --------------------------------------------------

def list_subtitle():
    names = []
    links = []

    for root, _, files in os.walk(__temp__):
        for file in files:
            if file.lower().endswith('.srt'):
                names.append(file)
                links.append(os.path.join(root, file))

    if not names:
        return

    index = xbmcgui.Dialog().select('Selecionar legenda', names)
    if index >= 0:
        set_subtitle(links[index])
