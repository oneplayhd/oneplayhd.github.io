# -*- coding: utf-8 -*-
import sys
import os
import shutil
from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

try:
    from xbmcvfs import translatePath
except (ImportError, AttributeError):
    from xbmc import translatePath

from lib.service import search_subtitle, download_

addon = xbmcaddon.Addon()
profile = translatePath(addon.getAddonInfo('profile'))
temp_dir = os.path.join(profile, 'temp')

if xbmcvfs.exists(temp_dir):
    shutil.rmtree(temp_dir)
xbmcvfs.mkdirs(temp_dir)

def get_params():
    params = {}
    if len(sys.argv) > 2:
        arg = sys.argv[2].lstrip('?')
        for pair in arg.split('&'):
            if '=' in pair:
                k, v = pair.split('=', 1)
                params[k] = v
    return params

params = get_params()
action = params.get('action')

if action in ('search', 'manualsearch'):
    preferred = params.get('preferredlanguage', 'pb')
    if 'searchstring' in params:
        search_subtitle(preferred, manual=params['searchstring'])
    else:
        search_subtitle(preferred)

elif action == 'download':
    download_(params.get('sub'))
