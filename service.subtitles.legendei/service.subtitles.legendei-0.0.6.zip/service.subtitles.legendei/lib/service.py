# -*- coding: utf-8 -*-

import os
import sys
import re
import platform
from difflib import SequenceMatcher
PY3 = sys.version_info[0] == 3

try:
    from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
except:
    pass

try:
    try:
        from kodi_six.xbmcvfs import translatePath
    except (ImportError, AttributeError):
        from kodi_six.xbmc import translatePath    
except:
    pass

import requests
from bs4 import BeautifulSoup
import zipfile

if PY3:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode
else:
    from urlparse import urlparse, parse_qs
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode

import shutil

try:
    plugin = sys.argv[0]
    handle = int(sys.argv[1])
    __addon__ = xbmcaddon.Addon()
    __addonname__ = __addon__.getAddonInfo('name')
    __version__ = __addon__.getAddonInfo('version')
    __profile__ = translatePath(__addon__.getAddonInfo('profile'))
    __temp__ = translatePath(os.path.join(__profile__,'temp',''))    
except:
    __addonname__ = 'Debug tester'

__headers__ = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'}
__website__ = 'https://legendei.net/'

def infoDialog(message, heading=__addonname__, iconimage='', time=3000, sound=False):
    if iconimage == '':
        iconimage = ''
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR
    xbmcgui.Dialog().notification(heading, message, iconimage, time, sound=sound)

def log(module, msg):
    xbmc.log((u"### [%s] - %s" % (module,msg,)),level=xbmc.LOGDEBUG)

class Download:
    def __init__(self,url,dest):
        with open(dest, 'wb') as f:
            res = requests.get(url,headers=__headers__,stream=True,allow_redirects=True)
            for chunk in res.iter_content(chunk_size=1024):
                f.write(chunk)

class ExtractZip:
    def __init__(self,path,dest):
        special_packages = 'special://home/addons/packages'
        packages = translatePath(special_packages)
        path2 = os.path.join(packages, 'legendei.zip')
        shutil.copy2(path, path2)         
        try:
            zin = zipfile.ZipFile(path2, 'r')
            zin.extractall(dest)
        except Exception as e:
            pass
        try:
            os.remove(path2)
        except:
            pass         

class ExtractRAR:
    def __init__(self,path,dest):
        special_packages = 'special://home/addons/packages'
        packages = translatePath(special_packages)
        path2 = os.path.join(packages, 'legendei.rar')   
        shutil.copy2(path, path2)   
        self.unzip_rar(path2,dest)
        try:
            os.remove(path2)
        except:
            pass
    def unzip_rar(self,path, dest, format='rar'):
        path = quote_plus(path)
        root = format + '://' + path + '/'
        dirs, files = xbmcvfs.listdir(root)
        if dirs:
            self.unzip_recursive(root, dirs, dest)
        for file in files:
            self.unzip_file(os.path.join(root, file), os.path.join(dest, file))

    def unzip_recursive(self, path, dirs, dest):
        for directory in dirs:
            dirs_dir = os.path.join(path, directory)
            dest_dir = os.path.join(dest, directory)          
            xbmcvfs.mkdir(dest_dir)

            dirs2, files = xbmcvfs.listdir(dirs_dir)

            if dirs2:
                self.unzip_recursive(dirs_dir, dirs2, dest_dir)
            for file in files:
                self.unzip_file(os.path.join(dirs_dir, file), os.path.join(dest_dir, file)) 

    def unzip_file(self, path, dest):
        xbmcvfs.copy(path, dest)

def subitem(params):
    url = '%s?%s'%(plugin, urlencode(params))
    language = params.get("language")
    subname = params.get("subname") 
    rating = params.get("rating")
    flag = params.get("flag")
    sub = params.get("sub")
    if language and subname and rating and flag:
        li=xbmcgui.ListItem(label=language,label2=subname)
        li.setArt({"icon": rating, "thumb": flag})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    elif sub:
        li=xbmcgui.ListItem(label2=os.path.basename(sub))
        xbmcplugin.addDirectoryItem(handle=handle, url=sub, listitem=li, isFolder=False)

def originaltitle_imdb(imdb):
    url = 'https://m.imdb.com/pt/title/%s/' % imdb
    headers = {
        'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Mobile Safari/537.36'
    }
    
    try:
        r = requests.get(url, headers=headers, timeout=15)
        if not r or r.status_code != 200:
            return False, ''
        
        soup = BeautifulSoup(r.text, 'html.parser')
        
        title_pt = ''
        hero = soup.find('h1', {'data-testid': 'hero__pageTitle'})
        if hero:
            span = hero.find('span')
            title_pt = (span.text if span else hero.text).strip()
        
        original_title = ''
        
        orig_block = soup.find('div', {'data-testid': 'hero-title-block__original-title'})
        if orig_block:
            txt = orig_block.get_text(strip=True)
            original_title = re.sub(r'^(T[íi]tulo original|Original title)[:\s]*', '', txt, flags=re.I).strip()
        
        if not original_title:
            m = re.search(r'T[íi]tulo original[:\s]*["\']?([^<"\']+)["\']?', r.text, re.I)
            if m:
                original_title = m.group(1).strip()
        
        if not original_title and title_pt:
            original_title = title_pt
        
        year = ''
        
        year_link = soup.find('a', href=re.compile(r'/releaseinfo'))
        if year_link:
            y = re.search(r'\d{4}', year_link.text)
            if y:
                year = y.group(0)
        
        if not year:
            release_li = soup.find('li', {'data-testid': 'title-details-releasedate'})
            if release_li:
                y = re.search(r'\d{4}', release_li.get_text())
                if y:
                    year = y.group(0)
        
        if not year:
            y = re.search(r'\b(19|20)\d{2}\b', r.text[:6000])
            if y:
                year = y.group(0)
        
        if original_title:
            original_title = re.sub(r'\s*\(\d{4}[–\-]?\d{0,4}\)\s*$', '', original_title).strip()
        
        if not original_title:
            original_title = False
        
        return original_title, year
        
    except Exception as e:
        return False, ''

def get_kodi_log_path():
    try:
        special_log = translatePath('special://logpath/kodi.log')
        if os.path.exists(special_log):
            return special_log
    except:
        pass
    
    try:
        special_temp = translatePath('special://temp/kodi.log')
        if os.path.exists(special_temp):
            return special_temp
    except:
        pass
    
    return os.path.expanduser('~/.kodi/temp/kodi.log')

def extract_info_from_log(log_path=None):
    info = {
        'title': None,
        'original_name': None,
        'originaltitle': None,
        'season': None,
        'episode': None,
        'year': None
    }
    
    if log_path is None:
        log_path = get_kodi_log_path()
    
    try:
        if not os.path.exists(log_path):
            return info
            
        with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()[-800:]
        
        for line in reversed(lines):
            if '[Legendei]' in line or '### [Legendei]' in line:
                continue
                
            has_info = False
            is_movie = False
            
            if 'title=' in line and 'season=' in line and 'episode=' in line:
                has_info = True
            elif 'serie_name=' in line and 'season_num=' in line and 'episode_num=' in line:
                has_info = True
            elif ('name=' in line or 'movie&name=' in line) and 'season=' not in line and 'episode=' not in line:
                has_info = True
                is_movie = True
            
            if has_info:
                try:
                    if not info['original_name']:
                        original_name_match = re.search(r'original_name=([^&\'\)]+)', line)
                        if original_name_match:
                            original_name = unquote_plus(original_name_match.group(1)).strip()
                            if not is_movie and ('season' in line or 'episode' in line or 'season_num' in line or 'episode_num' in line):
                                if ' - ' in original_name:
                                    original_name = original_name.split(' - ')[0].strip()
                            if is_movie:
                                original_name = re.sub(r'\s+\d{4}$', '', original_name).strip()
                            info['original_name'] = original_name
                    
                    if not info['originaltitle']:
                        originaltitle_match = re.search(r'originaltitle=([^&\'\)]+)', line)
                        if originaltitle_match:
                            originaltitle = unquote_plus(originaltitle_match.group(1)).strip()
                            if not is_movie and ('season' in line or 'episode' in line or 'season_num' in line or 'episode_num' in line):
                                if ' - ' in originaltitle:
                                    originaltitle = originaltitle.split(' - ')[0].strip()
                            if is_movie:
                                originaltitle = re.sub(r'\s+\d{4}$', '', originaltitle).strip()
                            info['originaltitle'] = originaltitle
                    
                    if not info['title'] and not info['original_name'] and not info['originaltitle']:
                        title_match = re.search(r'title=([^&\'\)]+)', line)
                        if not title_match:
                            title_match = re.search(r'serie_name=([^&\'\)]+)', line)
                        if not title_match:
                            title_match = re.search(r'movie&name=([^&\'\)]+)', line)
                        if not title_match:
                            title_match = re.search(r'name=([^&\'\)]+)', line)
                        
                        if title_match:
                            title = unquote_plus(title_match.group(1)).strip()
                            if not is_movie and ('season' in line or 'episode' in line or 'season_num' in line or 'episode_num' in line):
                                if ' - ' in title:
                                    title = title.split(' - ')[0].strip()
                            if is_movie:
                                title = re.sub(r'\s+\d{4}$', '', title).strip()
                            info['title'] = title
                    
                    if not is_movie:
                        if not info['season']:
                            season_match = re.search(r'season=(\d+)', line)
                            if not season_match:
                                season_match = re.search(r'season_num=(\d+)', line)
                            if season_match:
                                info['season'] = int(season_match.group(1))
                        
                        if not info['episode']:
                            episode_match = re.search(r'episode=(\d+)', line)
                            if not episode_match:
                                episode_match = re.search(r'episode_num=(\d+)', line)
                            if episode_match:
                                info['episode'] = int(episode_match.group(1))
                    
                    year_match = re.search(r'year=(\d{4})', line)
                    if year_match and not info['year']:
                        info['year'] = year_match.group(1)
                        
                except:
                    continue
                    
            if is_movie:
                if (info.get('original_name') or info.get('originaltitle') or info.get('title')) and info.get('year'):
                    break
            else:
                if (info.get('original_name') or info.get('originaltitle') or info.get('title')) and \
                   info.get('season') is not None and info.get('episode') is not None:
                    break
                
    except Exception as e:
        pass
    
    
    return info

def clean_search_term(term):
    if not term:
        return ''
    term = term.replace(':', ' ')
    term = term.replace('-', ' ')
    term = ' '.join(term.split())
    term = re.sub(r'\s*\(\d{4}[–\-]?\d{0,4}\)\s*$', '', term).strip()
    return term

def detect_info():
    tag = xbmc.Player().getVideoInfoTag()
    imdb = tag.getIMDBNumber()
    year = ''
    search = False
    
    
    log_info = extract_info_from_log()
    
    if log_info.get('original_name'):
        search = log_info['original_name']
    elif log_info.get('originaltitle'):
        search = log_info['originaltitle']
    elif log_info.get('title'):
        search = log_info['title']
    elif imdb !='-1' and imdb !=False and imdb !=-1 and imdb !=None and imdb !='':
        originaltitle, imdb_year = originaltitle_imdb(imdb)
        search = originaltitle
        if imdb_year:
            year = imdb_year
    else:
        search = False
        infoDialog('Without imdb', iconimage='INFO')
    
    if not year or year == '':
        year = log_info.get('year', '')
    
    try:
        season = tag.getSeason()
    except:
        season = False
    
    try:
        episode = tag.getEpisode()
    except:
        episode = False
    
    if (not season or season == -1) and log_info.get('season'):
        season = log_info.get('season', False)
    
    if (not episode or episode == -1) and log_info.get('episode'):
        episode = log_info.get('episode', False)
    
    
    return search, season, episode, year, log_info

def calculate_similarity(search_term, result_name):
    search_lower = search_term.lower()
    result_lower = result_name.lower()
    
    similarity = SequenceMatcher(None, search_lower, result_lower).ratio()
    
    if search_lower in result_lower:
        similarity = max(similarity, 0.7)
    
    search_words = set(search_lower.split())
    result_words = set(result_lower.split())
    common_words = search_words.intersection(result_words)
    
    if common_words:
        word_match_ratio = len(common_words) / len(search_words)
        similarity = max(similarity, word_match_ratio * 0.85)
    
    if len(search_words) >= 2:
        search_list = search_lower.split()
        important_words = set(search_list[:min(3, len(search_list))])
        important_matches = important_words.intersection(result_words)
        
        if len(important_matches) == len(important_words):
            similarity = max(similarity, 0.75)
    
    return similarity

def legendei(sch, category=None):
    
    sch = unquote_plus(sch)
    
    sch_cleaned = sch
    
    sch_cleaned = sch_cleaned.replace(':', ' ')
    sch_cleaned = sch_cleaned.replace('-', ' ')
    sch_cleaned = ' '.join(sch_cleaned.split())
    
    original_search = sch_cleaned
    
    sch = sch_cleaned.replace(' ', '+')
    if not category:
        link = '%s?s=%s'%(__website__,sch)
    elif category == 'serie':
        link = '%scategory/%s/?s=%s'%(__website__,category,sch)
    elif category == 'filmes':
        link = '%scategory/%s/?s=%s'%(__website__,category,sch)
    if '+TV' in link:
        link = link.replace('+TV','')
    if '+Series' in link:
        link = link.replace('+Series','')
    
    
    src = ''
    try:
        r = requests.get(link,headers=__headers__)
        src += r.text
        soup = BeautifulSoup(src, 'html.parser')
        try:
            next_link = soup.find('a', {'class': 'sfwppa-pages sfwppa-link sfwppa-link-next'}).get('href', '')
        except:
            next_link = False
        if next_link:
            count = 0
            while next_link:
                count += 1
                r = requests.get(next_link,headers=__headers__)
                src_base = r.text
                src += src_base
                soup = BeautifulSoup(src_base, 'html.parser')
                try:
                    next_link = soup.find('a', {'class': 'sfwppa-pages sfwppa-link sfwppa-link-next'}).get('href', False)
                except:
                    next_link = False
                if next_link == False or count == 13:
                    break
    except Exception as e:
        pass
    itens = []
    if src:
        try:
            soup = BeautifulSoup(src, 'html.parser')
            spans = soup.find_all("span", style=re.compile(r"font-size:\s*14px"))
            SIMILARITY_THRESHOLD = 0.4
            all_results = []
            for s in spans:
                a = s.find('a')
                link = a.get('href', '')
                name = a.get('title', '')
                if name:
                    similarity = calculate_similarity(original_search, name)
                    all_results.append((name, link, similarity))
            filtered_results = [r for r in all_results if r[2] >= SIMILARITY_THRESHOLD]
            filtered_results.sort(key=lambda x: x[2], reverse=True)
            for name, link, similarity in filtered_results:
                itens.append((name, link))
        except Exception as e:
            pass
    if itens:
        for name, link in itens:
            try:
                subitem({'language': 'Portuguese (Brasil)', 'subname': name, 'rating': '5', 'flag': 'pb', 'action': 'download', 'sub_download': link})
            except:
                pass
        try:
            xbmcplugin.endOfDirectory(handle)
        except:
            pass
    return itens

def subtitle_clear():
    for r, d, f in os.walk(__temp__):
        for file in f:
            if file.endswith(".srt"):
                try:
                    os.remove(os.path.join(r, file))
                except:
                    pass
            if file.endswith(".url"):
                try:
                    os.remove(os.path.join(r, file))
                except:
                    pass 
            if file.endswith(".rar"):
                try:
                    os.remove(os.path.join(r, file))
                except:
                    pass
            if file.endswith(".zip"):
                try:
                    os.remove(os.path.join(r, file))
                except:
                    pass
    for name in os.listdir(__temp__):
        try:
            os.rmdir(os.path.join(__temp__, name))
        except:
            pass


def subs_site(lang,manualsearch=False):
    
    if lang == 'pt':
        if manualsearch:
            sch = quote(manualsearch)
            legendei(sch)
        else:
            search, season, episode, year, log_info = detect_info()
            
            
            if season !='-1' and season !=False and season !=-1:
                season = season
            else:
                season = False
            if episode !='-1' and episode !=False and episode !=-1:
                episode = episode
            else:
                episode = False
            
            if search and season:
                if int(season) < 10:
                    sdesc = '0%s'%str(season)
                else:
                    sdesc = str(season)
                
                if episode and int(episode) < 10:
                    edesc = '0%s'%str(episode)
                elif episode:
                    edesc = str(episode)
                else:
                    edesc = None
                
                if edesc:
                    sch = '%s S%sE%s'%(search, sdesc, edesc)
                else:
                    sch = '%s S%s'%(search, sdesc)
                
                sch = quote(sch)
                legendei(sch, category='serie')
                
            elif search:
                if year and year != '-1' and year != False and year != -1:
                    sch = '%s %s'%(search, year)
                else:
                    sch = search
                
                sch = quote(sch)
                legendei(sch, category='filmes')

def search_subtitle(default_subtitle,manualsearch=False):
    subtitle_clear()
    if 'Portuguese' in default_subtitle:
        lang = 'pt'
    else:
        lang = 'pt'
    if manualsearch:
        subs_site(lang,manualsearch)
    else:
        subs_site(lang)

def list_subtitle():
    names = []
    links = []
    for r, d, f in os.walk(__temp__):
        for file in f:
            if file.endswith(".rar"):
                try:
                    ExtractRAR(os.path.join(r, file),__temp__)
                except:
                    pass
    for r, d, f in os.walk(__temp__):
        for file in f:
            if file.endswith(".zip"): 
                try:
                    ExtractZip(os.path.join(r, file),__temp__)
                except:
                    pass 
    for r, d, f in os.walk(__temp__):
        for file in f:              
            if file.endswith(".srt"):
                filename = file
                link = os.path.join(r, file)
                names.append(filename)
                links.append(link) 
    if names and links:
        index = xbmcgui.Dialog().select('Select a subtitle', names)
        if index >=0:
            link = links[index]
            set_subtitle(link)
                
def download_(url):
    url = unquote_plus(url)
    subtitle_clear()
    try:
        r = requests.get(url, headers=__headers__, allow_redirects=True)
        
        final_url = r.url
        content_type = r.headers.get('Content-Type', '')
        
        if 'text/html' in content_type:
            src = r.text
            soup = BeautifulSoup(src, 'html.parser')
            post_attachment = soup.find('p', {'class': 'post-attachment'})
            
            if post_attachment:
                download_link = post_attachment.find('a').get('href', '')
                
                if download_link:
                    if not download_link.startswith('http'):
                        download_link = __website__.rstrip('/') + '/' + download_link.lstrip('/')
                    
                    special_packages = 'special://home/addons/packages'
                    packages = translatePath(special_packages)
                    filename = 'legendei.subpack'
                    dest = os.path.join(packages, filename)
                    
                    try:
                        Download(download_link, dest)
                    except:
                        pass
                    
                    zip_file = dest
                    extract_folder = __temp__
                    
                    try:
                        ExtractRAR(zip_file, extract_folder)
                    except:
                        pass
                    
                    try:
                        ExtractZip(zip_file, extract_folder)
                    except:
                        pass
                    
                    try:
                        os.remove(zip_file)
                    except:
                        pass
                    
                    list_subtitle()
        else:
            special_packages = 'special://home/addons/packages'
            packages = translatePath(special_packages)
            filename = 'legendei.subpack'
            dest = os.path.join(packages, filename)
            
            with open(dest, 'wb') as f:
                f.write(r.content)
            
            zip_file = dest
            extract_folder = __temp__
            
            try:
                ExtractRAR(zip_file, extract_folder)
            except:
                pass
            
            try:
                ExtractZip(zip_file, extract_folder)
            except:
                pass
            
            try:
                os.remove(zip_file)
            except:
                pass
            
            list_subtitle()
    except:
        pass

def set_subtitle(sub):
    subitem({'sub': sub})
    xbmcplugin.endOfDirectory(handle)