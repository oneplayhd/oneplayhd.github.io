## Instalar as seguintes dependências para assistir tv ao vivo

[Download script.module.netunblock](https://github.com/icarok99/OneRepo/raw/refs/heads/master/matrix/script.module.netunblock/script.module.netunblock-0.0.2.zip)

[Download script.module.flask](https://github.com/icarok99/OneRepo/raw/refs/heads/master/matrix/script.module.flask/script.module.flask-2.1.3.zip)

[Download plugin.video.f4mTester](https://github.com/OnePlayHD/OneRepo/raw/refs/heads/master/plugin.video.f4mTester/plugin.video.f4mTester-4.2.5.zip)

