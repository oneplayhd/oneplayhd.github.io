# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import threading
import time
import urllib.parse
import re
import json
import shutil
import os
from resources.lib.http_server import start_stream_server, stop_stream_server

# Hook para capturar execuções do Kodi
ORIGINAL_EXECUTEBUILTIN = xbmc.executebuiltin
ORIGINAL_SETRESOLVEDURL = xbmcplugin.setResolvedUrl

class CustomPlayer(xbmc.Player):
    """Player customizado para capturar reproduções."""
    
    def __init__(self, service):
        super().__init__()
        self.service = service
        
    def play(self, item, listitem=None, windowed=False):
        """Sobrescreve o método play para capturar URLs."""
        try:
            # Captura o path do item
            path = None
            if hasattr(item, 'getPath'):
                path = item.getPath()
            elif isinstance(item, str):
                path = item
                
            if path and self.service.should_capture_url(path):
                xbmc.log(f"[PureTorrent] CustomPlayer.play capturado: {path[:150]}...", xbmc.LOGINFO)
                magnet = self.service.extract_magnet_from_url(path)
                if magnet:
                    self.service.process_captured_magnet(magnet, "CustomPlayer", path)
                    
        except Exception as e:
            xbmc.log(f"[PureTorrent] Erro no CustomPlayer.play: {str(e)}", xbmc.LOGERROR)
            
        # Chama o método original
        return super().play(item, listitem, windowed)


class TorrentService(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.addon = xbmcaddon.Addon()
        self.custom_player = None
        self.port = int(self.addon.getSetting("server_port") or 8089)
        self.server_thread = None
        self.monitor_thread = None
        self.running = False
        
        # Armazena magnets capturados
        self.captured_magnets = []
        self.processed_magnets = []
        self.last_captured = None
        self.capture_count = 0
        
        # Controle para evitar duplicação
        self.processing_lock = threading.Lock()
        self.last_capture_time = 0
        self.capture_cooldown = 2
        
        # Limpa o cache de torrents ao iniciar
        self.clear_torrent_cache()
        
        # Instala hooks
        self.install_hooks()
        
    def clear_torrent_cache(self):
        """Limpa completamente o cache de torrents na inicialização."""
        try:
            # Obtém o caminho do cache
            cache_dir = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.puretorrent/torrent_cache/')
            
            xbmc.log(f"[PureTorrent] Limpando cache em: {cache_dir}", xbmc.LOGINFO)
            
            # Verifica se o diretório existe
            if not xbmcvfs.exists(cache_dir):
                xbmc.log("[PureTorrent] Diretório de cache não encontrado. Criando...", xbmc.LOGINFO)
                # Cria o diretório se não existir
                if not xbmcvfs.mkdirs(cache_dir):
                    xbmc.log("[PureTorrent] Erro ao criar diretório de cache", xbmc.LOGERROR)
                    return
            
            # Usa shutil para remover todo o conteúdo
            import shutil
            
            # Lista todos os itens no diretório
            items = xbmcvfs.listdir(cache_dir)
            
            if not items or len(items) == 0:
                xbmc.log("[PureTorrent] Cache já está vazio", xbmc.LOGINFO)
                return
                
            # Conta itens removidos
            removed_count = 0
            total_size = 0
            removed_folders = []
            removed_files = []
            
            # Processa pastas (items[0]) e arquivos (items[1])
            for folder_name in items[0]:  # Pastas
                folder_path = os.path.join(cache_dir, folder_name)
                try:
                    # Calcula o tamanho da pasta
                    folder_size = self.get_folder_size(folder_path)
                    total_size += folder_size
                    
                    # Remove a pasta completamente
                    shutil.rmtree(folder_path)
                    removed_count += 1
                    removed_folders.append(folder_name)
                    xbmc.log(f"[PureTorrent] Pasta removida: {folder_name} ({self.format_size(folder_size)})", xbmc.LOGDEBUG)
                except Exception as e:
                    xbmc.log(f"[PureTorrent] Erro ao remover pasta {folder_name}: {str(e)}", xbmc.LOGERROR)
                    
            for file_name in items[1]:  # Arquivos
                file_path = os.path.join(cache_dir, file_name)
                try:
                    file_size = os.path.getsize(file_path)
                    total_size += file_size
                    
                    os.remove(file_path)
                    removed_count += 1
                    removed_files.append(file_name)
                    xbmc.log(f"[PureTorrent] Arquivo removido: {file_name} ({self.format_size(file_size)})", xbmc.LOGDEBUG)
                except Exception as e:
                    xbmc.log(f"[PureTorrent] Erro ao remover arquivo {file_name}: {str(e)}", xbmc.LOGERROR)
            
            # Log do resultado
            if removed_count > 0:
                xbmc.log(f"[PureTorrent] ═══ CACHE LIMPO ═══", xbmc.LOGINFO)
                xbmc.log(f"[PureTorrent] Total: {removed_count} itens removidos", xbmc.LOGINFO)
                xbmc.log(f"[PureTorrent] Pastas: {len(removed_folders)}", xbmc.LOGINFO)
                xbmc.log(f"[PureTorrent] Arquivos: {len(removed_files)}", xbmc.LOGINFO)
                xbmc.log(f"[PureTorrent] Espaço liberado: {self.format_size(total_size)}", xbmc.LOGINFO)
                
                # Mostra notificação (se habilitado)
                if self.addon.getSettingBool("show_cache_notification"):
                    xbmcgui.Dialog().notification(
                        "PureTorrent",
                        f"Cache limpo: {removed_count} itens\n{self.format_size(total_size)} liberados",
                        xbmcgui.NOTIFICATION_INFO,
                        5000
                    )
            else:
                xbmc.log("[PureTorrent] Nenhum item para remover", xbmc.LOGINFO)
                
        except Exception as e:
            xbmc.log(f"[PureTorrent] Erro ao limpar cache: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)
    
    def get_folder_size(self, folder_path):
        """Calcula o tamanho total de uma pasta."""
        total_size = 0
        try:
            for dirpath, dirnames, filenames in os.walk(folder_path):
                for f in filenames:
                    fp = os.path.join(dirpath, f)
                    if os.path.exists(fp):
                        total_size += os.path.getsize(fp)
        except:
            pass
        return total_size
    
    def format_size(self, size_bytes):
        """Formata o tamanho em bytes para formato legível."""
        if size_bytes == 0:
            return "0 B"
        size_names = ("B", "KB", "MB", "GB", "TB")
        i = 0
        while size_bytes >= 1024 and i < len(size_names) - 1:
            size_bytes /= 1024.0
            i += 1
        return f"{size_bytes:.2f} {size_names[i]}"
        
    def clear_torrent_cache_manual(self):
        """Limpa o cache de torrents manualmente (chamado por usuário)."""
        try:
            cache_dir = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.puretorrent/magnets/torrent_cache/')
            
            if not xbmcvfs.exists(cache_dir):
                xbmcgui.Dialog().notification(
                    "PureTorrent",
                    "Diretório de cache não encontrado",
                    xbmcgui.NOTIFICATION_WARNING,
                    3000
                )
                return
                
            # Conta itens
            items = xbmcvfs.listdir(cache_dir)
            if not items or len(items) == 0 or (len(items[0]) == 0 and len(items[1]) == 0):
                xbmcgui.Dialog().notification(
                    "PureTorrent",
                    "Cache já está vazio",
                    xbmcgui.NOTIFICATION_INFO,
                    3000
                )
                return
                
            total_items = len(items[0]) + len(items[1])
            
            # Pergunta ao usuário
            dialog = xbmcgui.Dialog()
            if not dialog.yesno(
                "PureTorrent",
                f"Limpar cache de torrents?",
                f"{total_items} pastas/arquivos serão removidos.",
                "Tem certeza?"
            ):
                return
                
            # Remove os itens
            removed_count = 0
            for folder_name in items[0]:
                folder_path = os.path.join(cache_dir, folder_name)
                try:
                    shutil.rmtree(folder_path)
                    removed_count += 1
                except:
                    pass
                    
            for file_name in items[1]:
                file_path = os.path.join(cache_dir, file_name)
                try:
                    os.remove(file_path)
                    removed_count += 1
                except:
                    pass
                    
            xbmcgui.Dialog().notification(
                "PureTorrent",
                f"Cache limpo: {removed_count} itens removidos",
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
            
        except Exception as e:
            xbmc.log(f"[PureTorrent] Erro ao limpar cache manual: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification(
                "PureTorrent",
                f"Erro ao limpar cache: {str(e)}",
                xbmcgui.NOTIFICATION_ERROR,
                5000
            )
    
    def decode_url_recursive(self, url, max_depth=5):
        """Decodifica URL recursivamente."""
        try:
            if not url or max_depth == 0:
                return url
                
            decoded = urllib.parse.unquote(url)
            if decoded != url:
                return self.decode_url_recursive(decoded, max_depth - 1)
            return url
            
        except Exception as e:
            xbmc.log(f"[PureTorrent] Erro ao decodificar: {str(e)}", xbmc.LOGERROR)
            return url
            
    def extract_magnet_from_url(self, url):
        """Extrai magnet de qualquer URL."""
        try:
            if not url:
                return None
                
            xbmc.log(f"[PureTorrent] Analisando URL: {url[:200]}...", xbmc.LOGDEBUG)
            
            # Decodifica a URL completamente
            decoded_url = self.decode_url_recursive(url)
            
            # 1. URL direta do Elementum
            if 'plugin://plugin.video.elementum/play' in decoded_url:
                if 'uri=' in decoded_url:
                    match = re.search(r'uri=([^&]+)', decoded_url)
                    if match:
                        magnet = urllib.parse.unquote(match.group(1))
                        if magnet and magnet.startswith('magnet:'):
                            xbmc.log(f"[PureTorrent] Magnet encontrado na URL do Elementum", xbmc.LOGINFO)
                            return magnet
                            
            # 2. URL do plugin streaming com mode=12
            if 'plugin.video.pluginstreaming' in decoded_url:
                if 'mode=12' in decoded_url:
                    xbmc.log(f"[PureTorrent] Detectado plugin streaming com mode=12", xbmc.LOGDEBUG)
                    # Extrai o parâmetro url
                    match = re.search(r'url=([^&]+)', decoded_url)
                    if match:
                        nested_url = urllib.parse.unquote(match.group(1))
                        xbmc.log(f"[PureTorrent] URL aninhada: {nested_url[:150]}...", xbmc.LOGDEBUG)
                        # Tenta extrair magnet da URL aninhada
                        magnet = self.extract_magnet_from_url(nested_url)
                        if magnet:
                            return magnet
                            
            # 3. Magnet link direto
            if decoded_url.startswith('magnet:'):
                return decoded_url
                
            # 4. Busca por magnet na URL
            magnet_match = re.search(r'magnet:\?xt=urn:btih:[a-fA-F0-9]+[^\s"\']*', decoded_url)
            if magnet_match:
                return magnet_match.group(0)
                
            # 5. Hash puro
            hash_match = re.search(r'[a-fA-F0-9]{40}', decoded_url)
            if hash_match:
                return f"magnet:?xt=urn:btih:{hash_match.group(0)}"
                
            return None
            
        except Exception as e:
            xbmc.log(f"[PureTorrent] Erro ao extrair magnet: {str(e)}", xbmc.LOGERROR)
            return None
            
    def should_capture_url(self, url):
        """Verifica se a URL deve ser capturada."""
        if not url:
            return False
            
        # 1. Elementum
        if 'plugin.video.elementum' in url:
            return True
            
        # 2. Mode=12
        if 'mode=12' in url:
            return True
            
        # 3. Magnet
        if 'magnet:' in url:
            return True
            
        # 4. Plugin streaming com url
        if 'plugin.video.pluginstreaming' in url and 'url=' in url:
            return True
            
        return False
        
    def process_captured_magnet(self, magnet, source="Desconhecido", raw_url=""):
        """Processa um magnet capturado."""
        try:
            if not magnet or not magnet.startswith('magnet:'):
                return
                
            # Verifica cooldown e duplicação
            with self.processing_lock:
                current_time = time.time()
                
                if magnet in self.processed_magnets:
                    xbmc.log(f"[PureTorrent] Magnet já processado", xbmc.LOGDEBUG)
                    return
                    
                if current_time - self.last_capture_time < self.capture_cooldown:
                    xbmc.log("[PureTorrent] Cooldown ativo", xbmc.LOGDEBUG)
                    return
                    
                self.last_capture_time = current_time
                
            self.capture_count += 1
            xbmc.log(f"[PureTorrent] ═══ MAGNET CAPTURADO #{self.capture_count} ═══", xbmc.LOGINFO)
            xbmc.log(f"[PureTorrent] Fonte: {source}", xbmc.LOGINFO)
            xbmc.log(f"[PureTorrent] Magnet: {magnet[:150]}...", xbmc.LOGINFO)
            if raw_url:
                xbmc.log(f"[PureTorrent] URL original: {raw_url[:150]}...", xbmc.LOGINFO)
            
            # Adiciona à lista
            self.captured_magnets.append(magnet)
            self.processed_magnets.append(magnet)
            self.last_captured = magnet
            
            # Extrai informações
            info = self.extract_magnet_info(magnet)
            
            # Mostra notificação
            self.show_notification(info, source)
            
            # Salva em arquivo
            self.save_magnet_to_file(magnet, info, source, raw_url)
            
            # Chama callback
            self.on_magnet_captured(magnet, info, source)
            
        except Exception as e:
            xbmc.log(f"[PureTorrent] Erro ao processar magnet: {str(e)}", xbmc.LOGERROR)
            
    def extract_magnet_info(self, magnet):
        """Extrai informações do magnet."""
        info = {
            'magnet': magnet,
            'hash': None,
            'name': None,
            'trackers': []
        }
        
        try:
            # Hash
            hash_match = re.search(r'xt=urn:btih:([a-fA-F0-9]+)', magnet, re.IGNORECASE)
            if hash_match:
                info['hash'] = hash_match.group(1)
                
            # Nome
            dn_match = re.search(r'dn=([^&]+)', magnet)
            if dn_match:
                info['name'] = urllib.parse.unquote(dn_match.group(1))
                
            # Trackers
            tr_matches = re.findall(r'tr=([^&]+)', magnet)
            if tr_matches:
                info['trackers'] = [urllib.parse.unquote(t) for t in tr_matches]
                
        except Exception as e:
            xbmc.log(f"[PureTorrent] Erro ao extrair info: {str(e)}", xbmc.LOGERROR)
            
        return info
        
    def show_notification(self, info, source):
        """Mostra notificação do magnet capturado."""
        try:
            hash_short = info.get('hash', '')[:8] if info.get('hash') else 'N/A'
            name = info.get('name', 'Desconhecido')
            if len(name) > 40:
                name = name[:37] + '...'
                
            message = f"Hash: {hash_short}\nArquivo: {name}\nFonte: {source}"
            
            # xbmcgui.Dialog().notification(
            #     f"⚡ Magnet Capturado #{self.capture_count}",
            #     message,
            #     xbmcgui.NOTIFICATION_INFO,
            #     8000
            # )
            
        except Exception as e:
            xbmc.log(f"[PureTorrent] Erro na notificação: {str(e)}", xbmc.LOGERROR)
            
    def save_magnet_to_file(self, magnet, info, source, raw_url=""):
        """Salva magnet em arquivo."""
        try:
            data_dir = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.puretorrent/magnets/')
            if not xbmcvfs.exists(data_dir):
                xbmcvfs.mkdirs(data_dir)
                
            timestamp = time.strftime('%Y%m%d_%H%M%S')
            hash_id = info.get('hash', 'unknown')[:8]
            filename = f"{data_dir}magnet_{timestamp}_{hash_id}.txt"
            
            with open(filename, 'w', encoding='utf-8') as f:
                f.write("="*70 + "\n")
                f.write(f"MAGNET CAPTURADO #{self.capture_count}\n")
                f.write("="*70 + "\n")
                f.write(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Fonte: {source}\n")
                f.write(f"Hash: {info.get('hash', 'N/A')}\n")
                f.write(f"Arquivo: {info.get('name', 'N/A')}\n")
                f.write(f"Trackers: {len(info.get('trackers', []))}\n")
                if raw_url:
                    f.write(f"\nURL Original:\n{raw_url}\n")
                f.write("\n" + "="*70 + "\n")
                f.write("MAGNET LINK:\n")
                f.write(magnet + "\n")
                f.write("="*70 + "\n")
                
            xbmc.log(f"[PureTorrent] Magnet salvo: {filename}", xbmc.LOGINFO)
            
            # Salva último
            last_file = f"{data_dir}ultimo.txt"
            with open(last_file, 'w', encoding='utf-8') as f:
                f.write(magnet)
                
        except Exception as e:
            xbmc.log(f"[PureTorrent] Erro ao salvar: {str(e)}", xbmc.LOGERROR)
            
    def on_magnet_captured(self, magnet, info, source):
        """Callback quando um magnet é capturado."""
        # Implemente sua lógica aqui
        from default import play_torrent
        play_torrent(magnet)
        
    def install_hooks(self):
        """Instala hooks para capturar reprodução (exceto Player.play)."""
        
        # Hook para xbmc.executebuiltin
        def hooked_executebuiltin(command):
            try:
                if command and isinstance(command, str):
                    # Verifica se contém URL para capturar
                    if 'PlayMedia' in command or 'RunPlugin' in command:
                        if self.should_capture_url(command):
                            xbmc.log(f"[PureTorrent] executebuiltin capturado: {command[:150]}...", xbmc.LOGINFO)
                            magnet = self.extract_magnet_from_url(command)
                            if magnet:
                                self.process_captured_magnet(magnet, "executebuiltin", command)
                                
            except Exception as e:
                xbmc.log(f"[PureTorrent] Erro no hook executebuiltin: {str(e)}", xbmc.LOGERROR)
                
            return ORIGINAL_EXECUTEBUILTIN(command)
            
        # Hook para xbmcplugin.setResolvedUrl
        def hooked_setresolvedurl(handle, succeeded, listitem):
            try:
                if listitem and succeeded:
                    path = listitem.getPath()
                    if path:
                        if self.should_capture_url(path):
                            xbmc.log(f"[PureTorrent] setResolvedUrl capturado: {path[:150]}...", xbmc.LOGINFO)
                            magnet = self.extract_magnet_from_url(path)
                            if magnet:
                                self.process_captured_magnet(magnet, "setResolvedUrl", path)
                                
            except Exception as e:
                xbmc.log(f"[PureTorrent] Erro no hook setResolvedUrl: {str(e)}", xbmc.LOGERROR)
                
            return ORIGINAL_SETRESOLVEDURL(handle, succeeded, listitem)
            
        # Substitui as funções (exceto Player.play)
        xbmc.executebuiltin = hooked_executebuiltin
        xbmcplugin.setResolvedUrl = hooked_setresolvedurl
        
        xbmc.log("[PureTorrent] Hooks instalados (executebuiltin e setResolvedUrl)!", xbmc.LOGINFO)
        
    def monitor_playlist(self):
        """Monitora a playlist do Kodi em busca de URLs."""
        xbmc.log("[PureTorrent] Iniciando monitor de playlist...", xbmc.LOGINFO)
        
        last_playlist = ""
        
        while not self.abortRequested():
            if self.waitForAbort(1):
                break
                
            try:
                # Obtém a playlist atual
                playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                current_playlist = ""
                
                for i in range(playlist.size()):
                    try:
                        item = playlist[i]
                        if item:
                            path = item.getPath()
                            if path:
                                current_playlist += path + "|"
                    except:
                        pass
                        
                # Se mudou, verifica se tem URLs para capturar
                if current_playlist and current_playlist != last_playlist:
                    xbmc.log(f"[PureTorrent] Playlist atualizada, verificando...", xbmc.LOGDEBUG)
                    
                    for url in current_playlist.split('|'):
                        if url and self.should_capture_url(url):
                            xbmc.log(f"[PureTorrent] URL encontrada na playlist: {url[:150]}...", xbmc.LOGINFO)
                            magnet = self.extract_magnet_from_url(url)
                            if magnet:
                                self.process_captured_magnet(magnet, "Playlist", url)
                                
                    last_playlist = current_playlist
                    
            except Exception as e:
                xbmc.log(f"[PureTorrent] Erro no monitor de playlist: {str(e)}", xbmc.LOGERROR)
                
    def monitor_player(self):
        """Monitora o player."""
        xbmc.log("[PureTorrent] Iniciando monitor do player...", xbmc.LOGINFO)
        
        last_url = None
        
        while not self.abortRequested():
            if self.waitForAbort(0.2):
                break
                
            try:
                # Usa o custom_player se disponível
                if self.custom_player and self.custom_player.isPlaying():
                    current_url = self.custom_player.getPlayingFile()
                    if current_url and current_url != last_url:
                        if self.should_capture_url(current_url):
                            xbmc.log(f"[PureTorrent] Player detectou: {current_url[:150]}...", xbmc.LOGINFO)
                            magnet = self.extract_magnet_from_url(current_url)
                            if magnet:
                                self.process_captured_magnet(magnet, "Player", current_url)
                            last_url = current_url
                            
            except Exception as e:
                xbmc.log(f"[PureTorrent] Erro no monitor: {str(e)}", xbmc.LOGERROR)
                
    def start(self):
        """Inicia o serviço."""
        xbmc.log("[PureTorrent] Iniciando serviço de captura de magnets...", xbmc.LOGINFO)
        self.running = True
        
        # Cria o CustomPlayer (substitui o player padrão)
        self.custom_player = CustomPlayer(self)
        
        # Thread do servidor HTTP
        self.server_thread = threading.Thread(
            target=start_stream_server,
            args=(self.port, self)
        )
        self.server_thread.daemon = True
        self.server_thread.start()
        
        # Thread do monitor do player
        self.monitor_thread = threading.Thread(target=self.monitor_player)
        self.monitor_thread.daemon = True
        self.monitor_thread.start()
        
        # Thread do monitor de playlist
        self.playlist_thread = threading.Thread(target=self.monitor_playlist)
        self.playlist_thread.daemon = True
        self.playlist_thread.start()
        
        xbmc.log("[PureTorrent] Serviço iniciado com CustomPlayer!", xbmc.LOGINFO)
        
    def onSettingsChanged(self):
        """Configurações alteradas."""
        try:
            new_port = int(self.addon.getSetting("server_port") or 8089)
            if new_port != self.port:
                xbmc.log(f"[PureTorrent] Porta alterada para: {new_port}", xbmc.LOGINFO)
                self.port = new_port
                self.stop_server()
                self.start()
        except Exception as e:
            xbmc.log(f"[PureTorrent] Erro nas configurações: {str(e)}", xbmc.LOGERROR)
            
    def stop_server(self):
        """Para o servidor."""
        xbmc.log("[PureTorrent] Encerrando servidor...", xbmc.LOGINFO)
        self.running = False
        stop_stream_server()
        
        # Restaura funções originais
        xbmc.executebuiltin = ORIGINAL_EXECUTEBUILTIN
        xbmcplugin.setResolvedUrl = ORIGINAL_SETRESOLVEDURL
        
        # Limpa o custom_player
        self.custom_player = None
        
        for thread in [self.server_thread, self.monitor_thread, self.playlist_thread]:
            if thread and thread.is_alive():
                thread.join(timeout=2)
            
    def onAbortRequested(self):
        """Abort solicitado."""
        xbmc.log("[PureTorrent] Abort solicitado!", xbmc.LOGINFO)
        self.running = False
        self.stop_server()
        
    def get_captured_magnets(self):
        """Retorna os magnets capturados."""
        return self.captured_magnets.copy()
        
    def get_last_magnet(self):
        """Retorna o último magnet capturado."""
        return self.last_captured
        
    def get_capture_count(self):
        """Retorna o número de magnets capturados."""
        return self.capture_count


def main():
    """Função principal."""
    service = TorrentService()
    service.start()
    xbmcgui.Dialog().notification(
        "PureTorrent",
        "Servico iniciado",
        xbmcgui.NOTIFICATION_WARNING,
        3000
    )    
    
    # Loop principal
    while not service.abortRequested():
        if not service.running:
            xbmc.log("[PureTorrent] Serviço parou, reiniciando...", xbmc.LOGWARNING)
            service.start()
        xbmc.sleep(1000)
        
    xbmc.log("[PureTorrent] Serviço encerrado.", xbmc.LOGINFO)


if __name__ == "__main__":
    main()