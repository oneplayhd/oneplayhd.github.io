# -*- coding: utf-8 -*-
"""Motor BitTorrent de streaming em Python puro.

Escopo intencionalmente conservador:
* magnets BitTorrent v1 (''btih'' em hex ou base32);
* descoberta por trackers HTTP/HTTPS, UDP, 'x.pe' e DHT leve;
* metadata via BEP 9/BEP 10;
* peer wire protocol TCP, blocos de 16 KiB e SHA-1 por peça;
* cache temporário em disco e priorização da janela de reprodução.
"""

import base64
import hashlib
import os
import random
import re
import shutil
import socket
import struct
import threading
import time
import urllib.parse
from collections import deque

from resources.lib.bencode import BencodeError, bdecode, bdecode_prefix, bencode
from resources.lib.tracker import discover_dht, discover_trackers, discover_local_peers, parse_compact_peers

BLOCK_SIZE = 16 * 1024
MAX_METADATA_SIZE = 4 * 1024 * 1024
METADATA_BLOCK_SIZE = 16 * 1024
HANDSHAKE_PROTOCOL = b"BitTorrent protocol"
HANDSHAKE_LENGTH = 49 + len(HANDSHAKE_PROTOCOL)
REQUEST_TIMEOUT_SECONDS = 25.0
CONNECT_TIMEOUT_SECONDS = 8.0
READ_TIMEOUT_SECONDS = 8.0
METADATA_EXTENSION_TIMEOUT_SECONDS = 12.0
METADATA_REQUEST_TIMEOUT_SECONDS = 8.0

PRIMARY_VIDEO_EXTENSIONS = (".mkv", ".mp4", ".m4v", ".webm", ".ts", ".avi", ".mov")

class TorrentError(Exception):
    """Falha de sessão BitTorrent que pode ser exibida de forma objetiva."""

def _decode_text(value, fallback=""):
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    if isinstance(value, str):
        return value
    return fallback

def _int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default

def _safe_filename(value):
    value = _decode_text(value, "torrent")
    for char in '<>:"/\\|?*':
        value = value.replace(char, "_")
    while ".." in value:
        value = value.replace("..", "_")
    value = value.strip().strip(".")
    return value.strip() or "torrent"

def _build_peer_id():
    return b"-PT1150-" + os.urandom(12)

def _normalise_btih(raw):
    raw = _decode_text(raw).strip()
    if len(raw) == 40 and re.match(r"^[a-fA-F0-9]{40}$", raw):
        return bytes.fromhex(raw)
    if len(raw) == 32 and re.match(r"^[a-zA-Z2-7]{32}$", raw):
        try:
            return base64.b32decode(raw.upper())
        except Exception:
            pass
    raise TorrentError("Magnet sem info-hash BTIH v1 válido")

def parse_magnet(magnet_uri):
    if not isinstance(magnet_uri, str):
        raise TorrentError("Magnet inválido")
    parsed = urllib.parse.urlsplit(magnet_uri.strip())
    if parsed.scheme.lower() != "magnet":
        raise TorrentError("O link não é um magnet")
    params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    info_hash = None
    for xt in params.get("xt", []):
        if xt.lower().startswith("urn:btih:"):
            info_hash = _normalise_btih(xt.split(":", 2)[-1])
            break
    if info_hash is None:
        raise TorrentError("Magnet sem parâmetro xt=urn:btih")

    direct_peers = []
    for value in params.get("x.pe", []):
        value = value.strip()
        try:
            if value.startswith("["):
                host, port = value.rsplit("]:", 1)
                host = host[1:]
            else:
                host, port = value.rsplit(":", 1)
            port = int(port)
            if host and 0 < port < 65536:
                direct_peers.append((host, port))
        except (ValueError, TypeError):
            continue

    trackers = []
    seen_trackers = set()
    for tracker in params.get("tr", []):
        tracker = tracker.strip()
        if tracker and tracker not in seen_trackers:
            seen_trackers.add(tracker)
            trackers.append(tracker)

    # Lista de trackers publicos mais confiaveis e ativos para garantir conexao real
    PUBLIC_TRACKERS = [
        "udp://tracker.opentrackr.org:1337/announce",
        "udp://open.stealth.si:80/announce",
        "udp://tracker.coppersurfer.tk:6969/announce",
        "udp://tracker.openbittorrent.com:80/announce",
        "udp://explodie.org:6969/announce",
        "udp://tracker.torrent.eu.org:451/announce",
        "udp://tracker.leechers-paradise.org:6969/announce",
        "udp://tracker.internetwarriors.net:1337/announce",
        "http://tracker.gbitt.info:80/announce",
        "udp://p4p.arenabg.com:1337/announce",
        "udp://9.rarbg.to:2780/announce",
        "udp://9.rarbg.me:2780/announce",
        "udp://tracker.tiny-vps.com:6969/announce",
        "udp://open.demonii.com:1337/announce",
        "udp://denis.stalker.upeer.me:6969/announce",
        "udp://tracker.port443.xyz:6969/announce",
        "udp://tracker.moack.jacklist.net:1337/announce",
        "udp://ipv4.tracker.harry.lu:80/announce"
    ]
    for tr in PUBLIC_TRACKERS:
        if tr not in seen_trackers:
            seen_trackers.add(tr)
            trackers.append(tr)

    return {
        "uri": magnet_uri,
        "info_hash": info_hash,
        "display_name": _decode_text(params.get("dn", [""])[0]),
        "trackers": trackers,
        "direct_peers": direct_peers,
    }

class DiskPieceCache:
    def __init__(self, root_path, session_id):
        self.root_path = os.path.join(root_path, session_id)
        self.pieces_path = os.path.join(self.root_path, "pieces")
        self._lock = threading.RLock()
        os.makedirs(self.pieces_path, exist_ok=True)
        self.files = None
        self.total_length = 0
        self.piece_length = 0
        self.piece_hashes = []

    def setup_files(self, files, total_length, piece_length, piece_hashes):
        with self._lock:
            self.files = files
            self.total_length = total_length
            self.piece_length = piece_length
            self.piece_hashes = piece_hashes
            
            # Pre-aloca os arquivos no diretório de cache para gravação por seek/posição absoluta
            for f in self.files:
                file_path = os.path.normpath(os.path.join(self.root_path, f['name']))
                #os.makedirs(os.path.dirname(file_path), exist_ok=True)
                # Força criação da pasta novamente (redundância contra race condition)
                try:
                    os.makedirs(os.path.dirname(file_path), exist_ok=True)
                except:
                    pass                
                if not os.path.exists(file_path) or os.path.getsize(file_path) != f['length']:
                    try:
                        with open(file_path, "wb") as fh:
                            fh.truncate(f['length'])
                        print(f"[DiskPieceCache] Pre-alocado arquivo real {f['name']} de tamanho {f['length']} bytes")
                    except Exception as e:
                        try:
                            with open(file_path, "wb") as fh:
                                fh.seek(max(0, f['length'] - 1))
                                fh.write(bytes(1))
                        except Exception as ex:
                            print(f"[DiskPieceCache] Falha ao pre-alocar {f['name']}: {ex}")

    def _path(self, piece_index):
        return os.path.normpath(os.path.join(self.pieces_path, "%08d.bin" % piece_index))

    # def write_piece(self, piece_index, data):
    #     with self._lock:
    #         if not self.files:
    #             # Fallback para escrita de peças binárias isoladas se metadados não estiverem prontos
    #             target = self._path(piece_index)
    #             temporary = target + ".tmp"
    #             with open(temporary, "wb") as handle:
    #                 handle.write(data)
    #             os.replace(temporary, target)
    #             return

    #         # Grava fisicamente nos arquivos de vídeo mapeados do torrent
    #         piece_offset = piece_index * self.piece_length
    #         remaining = len(data)
    #         current_offset = piece_offset
    #         data_idx = 0
            
    #         while remaining > 0:
    #             target_file = None
    #             for f in self.files:
    #                 if f['offset'] <= current_offset < f['offset'] + f['length']:
    #                     target_file = f
    #                     break
    #             if not target_file:
    #                 break
                
    #             file_pos = current_offset - target_file['offset']
    #             write_len = min(remaining, target_file['length'] - file_pos)
                
    #             file_path = os.path.normpath(os.path.join(self.root_path, target_file['name']))
    #             os.makedirs(os.path.dirname(file_path), exist_ok=True)
                
    #             try:
    #                 if not os.path.exists(file_path):
    #                     with open(file_path, "wb") as f:
    #                         f.truncate(target_file['length'])
                            
    #                 with open(file_path, "r+b") as fh:
    #                     fh.seek(file_pos)
    #                     fh.write(data[data_idx:data_idx + write_len])
    #             except Exception as e:
    #                 print(f"[DiskPieceCache] Erro ao gravar peca {piece_index} no arquivo {target_file['name']}: {e}")
                    
    #             current_offset += write_len
    #             data_idx += write_len
    #             remaining -= write_len
    def write_piece(self, piece_index, data):
        with self._lock:
            if not self.files:
                # Fallback antigo
                target = self._path(piece_index)
                temporary = target + ".tmp"
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with open(temporary, "wb") as handle:
                    handle.write(data)
                os.replace(temporary, target)
                return

            # Grava nos arquivos reais do torrent
            piece_offset = piece_index * self.piece_length
            remaining = len(data)
            current_offset = piece_offset
            data_idx = 0

            while remaining > 0:
                target_file = None
                for f in self.files:
                    if f['offset'] <= current_offset < f['offset'] + f['length']:
                        target_file = f
                        break
                if not target_file:
                    break

                file_pos = current_offset - target_file['offset']
                write_len = min(remaining, target_file['length'] - file_pos)

                # === CORREÇÃO PRINCIPAL ===
                file_path = os.path.normpath(os.path.join(self.root_path, target_file['name']))
                os.makedirs(os.path.dirname(file_path), exist_ok=True)   # Garante que a pasta existe

                try:
                    if not os.path.exists(file_path):
                        with open(file_path, "wb") as fh:
                            fh.truncate(target_file['length'])

                    with open(file_path, "r+b") as fh:
                        fh.seek(file_pos)
                        fh.write(data[data_idx:data_idx + write_len])
                except Exception as e:
                    self.session.log(f"Erro ao gravar peça {piece_index} no arquivo {target_file['name']}: {e}", "error")

                current_offset += write_len
                data_idx += write_len
                remaining -= write_len    

    def read_piece(self, piece_index):
        with self._lock:
            if not self.files:
                # Fallback para leitura de peça isolada
                try:
                    with open(self._path(piece_index), "rb") as handle:
                        return handle.read()
                except OSError:
                    return None

            # Lê fisicamente dos arquivos de vídeo mapeados do torrent
            piece_offset = piece_index * self.piece_length
            piece_size = self.piece_length
            if piece_index == len(self.piece_hashes) - 1:
                piece_size = self.total_length - piece_offset
                
            remaining = piece_size
            current_offset = piece_offset
            result = bytearray()
            
            while remaining > 0:
                target_file = None
                for f in self.files:
                    if f['offset'] <= current_offset < f['offset'] + f['length']:
                        target_file = f
                        break
                if not target_file:
                    break
                    
                file_pos = current_offset - target_file['offset']
                read_len = min(remaining, target_file['length'] - file_pos)
                
                file_path = os.path.normpath(os.path.join(self.root_path, target_file['name']))
                if os.path.exists(file_path):
                    try:
                        with open(file_path, "rb") as fh:
                            fh.seek(file_pos)
                            chunk = fh.read(read_len)
                            result.extend(chunk)
                            if len(chunk) < read_len:
                                result.extend(bytes(read_len - len(chunk)))
                    except Exception:
                        result.extend(bytes(read_len))
                else:
                    result.extend(bytes(read_len))
                    
                current_offset += read_len
                remaining -= read_len
            return bytes(result)

    def remove_piece(self, piece_index):
        with self._lock:
            if not self.files:
                try:
                    os.remove(self._path(piece_index))
                except OSError:
                    pass

    def clear(self):
        try:
            shutil.rmtree(self.root_path, ignore_errors=True)
        except OSError:
            pass

class PeerConnection:
    def __init__(self, session, host, port, incoming_socket=None, incoming_handshake=None):
        self.session = session
        self.host = host
        self.port = int(port)
        self.key = "%s:%d" % (host, port)
        self.socket = incoming_socket
        self.incoming_socket = incoming_socket
        self.incoming_handshake = incoming_handshake
        self.thread = None
        self.running = threading.Event()
        self.send_lock = threading.Lock()
        self.connected = False
        self.close_reason = ""
        self.choked = True
        self.bitfield = b""
        self.remote_extensions = {}
        self.remote_metadata_id = None
        self.remote_pex_id = None
        self.metadata_size = None
        self.supports_extensions = False
        self.extensions_logged = False
        self.extensions_received_at = 0.0
        self.pending_count = 0
        self.failures = 0
        self.invalid_blocks = 0
        self.connected_at = 0.0
        self.last_activity = 0.0
        self.last_request_at = 0.0
        self._speed_samples = deque(maxlen=40)
        self.was_connected_once = False

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.running.set()
        self.thread = threading.Thread(target=self._run, name="PureTorrentPeer", daemon=True)
        self.thread.start()

    def close(self, reason=""):
        if reason and not self.close_reason:
            self.close_reason = str(reason)
        self.running.clear()
        sock = self.socket
        self.socket = None
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass
        if reason:
            self.session.log("Peer %s encerrado: %s" % (self.key, reason), "debug")

    def has_piece(self, index):
        byte_index = index // 8
        if byte_index >= len(self.bitfield):
            return False
        return bool(self.bitfield[byte_index] & (1 << (7 - (index % 8))))

    # def speed_bps(self):
    #     now = time.monotonic()
    #     samples = [(stamp, size) for stamp, size in self._speed_samples if now - stamp <= 12.0]
    #     if not samples:
    #         return 0.0
    #     first_stamp = samples[0][0]
    #     interval = max(1.0, now - first_stamp)
    #     return float(sum(size for _, size in samples)) / interval
    def speed_bps(self):
        """Calcula velocidade com thread safety"""
        if not self._speed_samples:
            return 0.0
        
        now = time.monotonic()
        # Copia a deque para evitar RuntimeError de mutação durante iteração
        samples = list(self._speed_samples)
        
        # Filtra amostras dos últimos 12 segundos
        valid_samples = [(stamp, size) for stamp, size in samples if now - stamp <= 12.0]
        
        if not valid_samples:
            return 0.0
            
        first_stamp = valid_samples[0][0]
        interval = max(1.0, now - first_stamp)
        total_bytes = sum(size for _, size in valid_samples)
        
        return total_bytes / interval    

    def _send(self, payload):
        sock = self.socket
        if not self.running.is_set() or sock is None:
            raise OSError("peer desconectado")
        with self.send_lock:
            sock.sendall(payload)

    def _send_message(self, message_id=None, payload=b""):
        if message_id is None:
            self._send(struct.pack(">I", 0))
            return
        payload = bytes(payload)
        self._send(struct.pack(">IB", len(payload) + 1, int(message_id)) + payload)

    def send_interested(self):
        try:
            self._send_message(2)
        except OSError:
            self.close("falha ao marcar interesse")

    def send_bitfield(self):
        try:
            total_pieces = len(self.session.piece_hashes)
            byte_count = (total_pieces + 7) // 8
            bf = bytearray(byte_count)
            with self.session._lock:
                for idx in self.session.completed_pieces:
                    if 0 <= idx < total_pieces:
                        bf[idx // 8] |= 1 << (7 - (idx % 8))
            self._send_message(5, bytes(bf))
        except OSError:
            self.close("falha ao enviar bitfield")

    def send_have(self, piece_index):
        try:
            self._send_message(4, struct.pack(">I", piece_index))
        except OSError:
            self.close("falha ao enviar have")

    def send_request(self, piece_index, begin, length):
        try:
            self._send_message(6, struct.pack(">III", piece_index, begin, length))
            self.last_request_at = time.monotonic()
            return True
        except OSError:
            self.close("falha no request")
            return False

    def send_cancel(self, piece_index, begin, length):
        try:
            self._send_message(8, struct.pack(">III", piece_index, begin, length))
        except OSError:
            pass

    def send_extended(self, extension_id, payload):
        try:
            self._send_message(20, bytes([extension_id]) + payload)
            return True
        except OSError:
            self.close("falha em mensagem estendida")
            return False

    def _recv_exact(self, amount, deadline_seconds=READ_TIMEOUT_SECONDS):
        chunks = []
        remaining = amount
        deadline = time.monotonic() + deadline_seconds
        while remaining > 0 and self.running.is_set():
            if time.monotonic() >= deadline:
                raise socket.timeout("timeout de leitura")
            sock = self.socket
            if sock is None:
                raise OSError("peer desconectado")
            try:
                part = sock.recv(remaining)
            except socket.timeout:
                continue
            if not part:
                raise OSError("peer fechou a conexão")
            chunks.append(part)
            remaining -= len(part)
        if remaining:
            raise OSError("conexão encerrada")
        return b"".join(chunks)

    def _send_handshake(self):
        reserved = bytes([0, 0, 0, 0, 0, 16, 0, 0])
        packet = bytes([len(HANDSHAKE_PROTOCOL)]) + HANDSHAKE_PROTOCOL + reserved
        packet += self.session.info_hash + self.session.peer_id
        self._send(packet)

    def _validate_received_handshake(self, protocol_length, body):
        if protocol_length != len(HANDSHAKE_PROTOCOL):
            raise TorrentError("handshake peer inválido")
        if body[:protocol_length] != HANDSHAKE_PROTOCOL:
            raise TorrentError("protocolo peer incompatível")
        reserved = body[protocol_length:protocol_length + 8]
        remote_info_hash = body[protocol_length + 8:protocol_length + 28]
        if remote_info_hash != self.session.info_hash:
            raise TorrentError("peer respondeu outro torrent")
        return reserved

    def _receive_handshake(self):
        header = self._recv_exact(1, CONNECT_TIMEOUT_SECONDS)
        protocol_length = header[0]
        body = self._recv_exact(protocol_length + 48, CONNECT_TIMEOUT_SECONDS)
        return self._validate_received_handshake(protocol_length, body)

    def _send_extended_handshake(self):
        payload = {
            b"m": {b"ut_metadata": 1, b"ut_pex": 2},
            b"v": b"PureTorrent/1.1.5",
            b"p": int(self.session.peer_port),
            b"reqq": 16,
        }
        self.send_extended(0, bencode(payload))

    def _handle_extended(self, payload):
        if not payload:
            return
        extension_id = payload[0]
        body = payload[1:]
        if extension_id == 0:
            try:
                data = bdecode(body)
            except BencodeError:
                self.failures += 1
                return

            def get_val(d, key):
                if not isinstance(d, dict):
                    return None
                if key in d:
                    return d[key]
                b_key = key.encode('utf-8') if isinstance(key, str) else key
                s_key = key.decode('utf-8', errors='ignore') if isinstance(key, bytes) else key
                if b_key in d:
                    return d[b_key]
                if s_key in d:
                    return d[s_key]
                return None

            mapping = get_val(data, "m") or {}
            if isinstance(mapping, dict):
                self.remote_extensions = mapping
                metadata_id = get_val(mapping, "ut_metadata")
                if isinstance(metadata_id, int) and 0 < metadata_id < 256:
                    self.remote_metadata_id = metadata_id
                pex_id = get_val(mapping, "ut_pex")
                if isinstance(pex_id, int) and 0 < pex_id < 256:
                    self.remote_pex_id = pex_id
            size = get_val(data, "metadata_size")
            if isinstance(size, int) and 0 < size <= MAX_METADATA_SIZE:
                self.metadata_size = size
            self.extensions_received_at = time.monotonic()
            self.session.on_peer_extensions(self)
            return

        if self.remote_pex_id is not None and extension_id == self.remote_pex_id:
            try:
                data = bdecode(body)
            except BencodeError:
                self.failures += 1
                return
            self.session.on_peer_pex(self, data)
            return

        if self.remote_metadata_id is not None and extension_id == self.remote_metadata_id:
            try:
                header, consumed = bdecode_prefix(body)
            except BencodeError:
                self.failures += 1
                return
            if not isinstance(header, dict):
                return
            self.session.on_metadata_message(self, header, body[consumed:])

    def _handle_message(self, message_id, payload):
        self.last_activity = time.monotonic()
        if message_id == 0:
            self.choked = True
        elif message_id == 1:
            self.choked = False
            self.session.notify_scheduler()
        elif message_id == 4 and len(payload) == 4:
            piece = struct.unpack(">I", payload)[0]
            self._set_have(piece)
        elif message_id == 5:
            self.bitfield = bytes(payload)
            self.session.notify_scheduler()
        elif message_id == 7 and len(payload) >= 8:
            piece_index, begin = struct.unpack(">II", payload[:8])
            block = payload[8:]
            if block:
                self._speed_samples.append((time.monotonic(), len(block)))
                self.session.on_piece_block(self, piece_index, begin, block)
        elif message_id == 20:
            self._handle_extended(payload)

    def _set_have(self, piece_index):
        required_bytes = (piece_index // 8) + 1
        if len(self.bitfield) < required_bytes:
            self.bitfield += bytes([0]) * (required_bytes - len(self.bitfield))
        value = bytearray(self.bitfield)
        value[piece_index // 8] |= 1 << (7 - (piece_index % 8))
        self.bitfield = bytes(value)
        self.session.notify_scheduler()

    def _run(self):
        error = ""
        try:
            if self.incoming_socket is not None:
                self.socket = self.incoming_socket
                self.socket.settimeout(READ_TIMEOUT_SECONDS)
                protocol_length, body = self.incoming_handshake
                reserved = self._validate_received_handshake(protocol_length, body)
                self._send_handshake()
            else:
                self.socket = socket.create_connection((self.host, self.port), timeout=CONNECT_TIMEOUT_SECONDS)
                self.socket.settimeout(READ_TIMEOUT_SECONDS)
                self._send_handshake()
                reserved = self._receive_handshake()
            self.supports_extensions = bool(len(reserved) >= 6 and (reserved[5] & 0x10))
            self.connected = True
            self.was_connected_once = True
            self.connected_at = time.monotonic()
            self.last_activity = self.connected_at
            self.session.on_peer_connected(self)
            if not self.session.metadata_ready.is_set() and not self.supports_extensions:
                raise TorrentError("peer sem BEP 10/metadata")
            if self.supports_extensions:
                self._send_extended_handshake()
            if self.session.metadata_ready.is_set():
                self.send_interested()

            while self.running.is_set() and not self.session.closed.is_set():
                try:
                    raw_length = self._recv_exact(4, READ_TIMEOUT_SECONDS)
                except socket.timeout:
                    continue
                length = struct.unpack(">I", raw_length)[0]
                if length == 0:
                    continue
                if length > 2 * 1024 * 1024:
                    raise TorrentError("mensagem peer grande demais")
                payload = self._recv_exact(length, max(READ_TIMEOUT_SECONDS, length / 65536.0 + 2.0))
                self._handle_message(payload[0], payload[1:])
        except Exception as exc:
            error = str(exc)
        finally:
            self.connected = False
            self.running.clear()
            final_reason = self.close_reason or error
            self.session.on_peer_disconnected(self, final_reason)
            sock = self.socket
            self.socket = None
            if sock is not None:
                try:
                    sock.close()
                except OSError:
                    pass

class TorrentSession:
    def __init__(self, magnet_uri, cache_root, max_peers=30, buffer_size_mb=30, cache_limit_mb=512,
                 peer_port=6881, enable_trackers=True, enable_dht=True, enable_lpd=True,
                 local_peer_port=0, logger=None):
        magnet = parse_magnet(magnet_uri)
        self.magnet_uri = magnet_uri
        self.info_hash = magnet["info_hash"]
        self.info_hash_hex = self.info_hash.hex()
        self.display_name = magnet["display_name"] or self.info_hash_hex
        self.trackers = magnet["trackers"]
        self.direct_peers = magnet["direct_peers"]
        self.peer_id = _build_peer_id()
        self.peer_port = max(1, min(int(peer_port or 6881), 65535))
        self.enable_trackers = bool(enable_trackers)
        self.enable_dht = bool(enable_dht)
        self.enable_lpd = bool(enable_lpd)
        try:
            self.local_peer_port = max(0, min(int(local_peer_port or 0), 65535))
        except (TypeError, ValueError):
            self.local_peer_port = 0
        self.max_peers = max_peers if isinstance(max_peers, int) and max_peers > 0 else 25
        if self.max_peers > 30:
            self.max_peers = 30
        self.active_peer_limit = self.max_peers
        self.buffer_size_bytes = max(4, min(int(buffer_size_mb or 12), 100)) * 1024 * 1024
        self.cache_limit_bytes = max(64, min(int(cache_limit_mb or 512), 4096)) * 1024 * 1024
        self.log_callback = logger
        self.cache = DiskPieceCache(cache_root, self.info_hash_hex)

        self.closed = threading.Event()
        self.metadata_ready = threading.Event()
        self.started = threading.Event()
        self._wake_scheduler = threading.Event()
        self._lock = threading.RLock()
        self._condition = threading.Condition(self._lock)
        self._peers = {}
        self._candidate_peers = deque()
        self._candidate_seen = set()
        self._metadata_size = None
        self._metadata_parts = {}
        self._metadata_requested = {}
        self._metadata_attempts = {}
        self.error = ""
        self.info = None
        self.piece_length = 0
        self.piece_hashes = []
        self.total_length = 0
        self.files = []
        self.selected_file = None
        self.completed_pieces = set()
        self.piece_blocks = {}
        self.pending_blocks = {}
        self.cache_bytes = 0
        self.playback_offset = 0
        self.last_used = time.monotonic()
        self._discovery_thread = None
        self._scheduler_thread = None
        self._lpd_thread = None
        self._http_fallback_thread = None
        self._status_speed_samples = deque(maxlen=40)
        self.discovery_status = "Inicializando descoberta"
        self.discovery_round = 0
        self.tracker_peer_count = 0
        self.dht_peer_count = 0
        self.lpd_peer_count = 0
        self.pex_peer_count = 0
        self.last_discovery_at = 0.0
        self._tracker_started = False

    def log(self, message, level="info"):
        text = "[PureTorrent] %s" % message
        if self.log_callback:
            try:
                self.log_callback(text, level)
                return
            except Exception:
                pass
        print(text)

    def start(self):
        if self.started.is_set() or self.closed.is_set():
            return
        self.started.set()
        self.log("Sessão %s iniciada; buscando peers." % self.info_hash_hex[:12])
        for peer in self.direct_peers:
            self.add_peer(*peer)
        if self.local_peer_port:
            self._receive_discovered_peers([("127.0.0.1", self.local_peer_port)], "local")
        self._discovery_thread = threading.Thread(target=self._discovery_loop, name="PureTorrentDiscover", daemon=True)
        self._scheduler_thread = threading.Thread(target=self._scheduler_loop, name="PureTorrentScheduler", daemon=True)
        if self.enable_lpd:
            self._lpd_thread = threading.Thread(target=self._lpd_loop, name="PureTorrentLPD", daemon=True)
            self._lpd_thread.start()
        else:
            self._discovery_report("LPD local desativado nas configurações.")
        self._discovery_thread.start()
        self._scheduler_thread.start()
        if not self.metadata_ready.is_set():
            self._http_fallback_thread = threading.Thread(target=self._run_http_metadata_fallback, name="PureTorrentHTTPFallback", daemon=True)
            self._http_fallback_thread.start()

    # def _run_http_metadata_fallback(self):
    #     if self.metadata_ready.is_set() or self.closed.is_set():
    #         return
    #     self.log("Iniciando busca paralela de metadados via HTTP fallback (magnet2torrent)...", "info")
    #     try:
    #         import urllib.request
    #         import urllib.parse
    #         import ssl
    #         import hashlib
            
    #         # Prepare o payload da requisição de formulário
    #         data = urllib.parse.urlencode({'magnet': self.magnet_uri}).encode('utf-8')
    #         req = urllib.request.Request(
    #             "https://magnet2torrent.com/upload/",
    #             data=data,
    #             headers={
    #                 'User-Agent': 'Mozilla/5.0 (Platform; Security; OS-or-CPU; Localization; rv:1.4) Gecko/20030624 Netscape/7.1 (ax)'
    #             }
    #         )
            
    #         # Configura SSL desativado para evitar falhas de certificado no Kodi/Python
    #         ctx = ssl.create_default_context()
    #         ctx.check_hostname = False
    #         ctx.verify_mode = ssl.CERT_NONE
            
    #         # Faz o download dos metadados
    #         with urllib.request.urlopen(req, context=ctx, timeout=30) as r:
    #             torrent_data = r.read()
                
    #         if self.metadata_ready.is_set() or self.closed.is_set():
    #             return
                
    #         if torrent_data:
    #             decoded = bdecode(torrent_data)
    #             info_dict = decoded.get(b'info') or decoded.get('info')
    #             if info_dict:
    #                 raw_info = bencode(info_dict)
    #                 # Verifica o hash SHA1 do info dictionary
    #                 expected_hash = hashlib.sha1(raw_info).digest()
    #                 if expected_hash == self.info_hash:
    #                     self.log("Metadados reais obtidos via HTTP fallback (magnet2torrent) com sucesso!", "info")
    #                     self._install_metadata(raw_info)
    #                 else:
    #                     self.log("Aviso: o hash do torrent obtido via HTTP fallback não bate com o info_hash esperado.", "warning")
    #             else:
    #                 self.log("Aviso: resposta HTTP fallback não continha a chave 'info'.", "warning")
    #     except Exception as e:
    #         self.log(f"Busca de metadados via HTTP fallback encerrada/falhou: {e}", "debug")
    # def _run_http_metadata_fallback(self):
    #     if self.metadata_ready.is_set() or self.closed.is_set():
    #         return

    #     self.log("Iniciando fallback HTTP (magnet2torrent)...", "info")

    #     try:
    #         import urllib.request
    #         import urllib.parse
    #         import ssl

    #         data = urllib.parse.urlencode({'magnet': self.magnet_uri}).encode('utf-8')
    #         req = urllib.request.Request(
    #             "https://magnet2torrent.com/upload/",
    #             data=data,
    #             headers={
    #                 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    #                 'Accept': 'application/octet-stream'
    #             }
    #         )

    #         ctx = ssl.create_default_context()
    #         ctx.check_hostname = False
    #         ctx.verify_mode = ssl.CERT_NONE

    #         with urllib.request.urlopen(req, context=ctx, timeout=15) as r:
    #             torrent_data = r.read()

    #         if len(torrent_data) < 100:
    #             self.log("Resposta do magnet2torrent muito pequena, ignorando.", "debug")
    #             return

    #         # Verifica se parece ser um torrent válido (começa com 'd' ou 'd8:announce')
    #         if torrent_data[:1] not in (b'd', b'D'):
    #             self.log(f"Resposta inválida do magnet2torrent (não é bencode). Iniciando: {torrent_data[:80]}", "warning")
    #             return

    #         decoded = bdecode(torrent_data)
    #         info_dict = decoded.get(b'info') or decoded.get('info')

    #         if info_dict:
    #             raw_info = bencode(info_dict)
    #             expected_hash = hashlib.sha1(raw_info).digest()

    #             if expected_hash == self.info_hash:
    #                 self.log("Metadados obtidos com sucesso via magnet2torrent!", "info")
    #                 self._install_metadata(raw_info)
    #             else:
    #                 self.log("Hash do torrent obtido não confere com o magnet.", "warning")
    #         else:
    #             self.log("Resposta não continha 'info' dictionary.", "warning")

    #     except Exception as e:
    #         self.log(f"Falha no fallback magnet2torrent: {e}", "debug") 
    # 
    def _get_metadata_via_http(self, magnet_uri, expected_info_hash):
        import urllib.request
        import urllib.parse
        import ssl
        import json
        import hashlib

        # ===== magnet2torrent =====
        try:
            self.log("Tentando magnet2torrent...")

            data = urllib.parse.urlencode({
                "magnet": magnet_uri
            }).encode("utf-8")

            req = urllib.request.Request(
                "https://magnet2torrent.com/upload/",
                data=data,
                headers={
                    "User-Agent": "Mozilla/5.0"
                }
            )

            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

            with urllib.request.urlopen(req, context=ctx, timeout=15) as r:
                torrent_data = r.read()

            decoded = bdecode(torrent_data)
            info_dict = decoded.get(b'info') or decoded.get('info')

            if info_dict:
                raw_info = bencode(info_dict)

                if hashlib.sha1(raw_info).digest() == expected_info_hash:
                    self.log("Metadados obtidos via magnet2torrent.")
                    return raw_info

        except Exception as e:
            self.log(f"magnet2torrent falhou: {e}")

        # ===== BTMASTER =====
        try:
            self.log("Tentando BTMaster...")

            data = urllib.parse.urlencode({
                "magnetUrl": magnet_uri
            }).encode("utf-8")

            req = urllib.request.Request(
                "https://www.btmaster.net/magnet2torrent/do/",
                data=data,
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "X-Requested-With": "XMLHttpRequest"
                }
            )

            with urllib.request.urlopen(req, timeout=15) as r:
                response = json.loads(r.read().decode("utf-8"))

            if response.get("code") == 0:
                torrent_hash = response["data"]["hash"]

                torrent_url = (
                    f"https://www.btmaster.net/tempTor/{torrent_hash}.torrent"
                )

                with urllib.request.urlopen(torrent_url, timeout=15) as r:
                    torrent_data = r.read()

                decoded = bdecode(torrent_data)
                info_dict = decoded.get(b'info') or decoded.get('info')

                if info_dict:
                    raw_info = bencode(info_dict)

                    if hashlib.sha1(raw_info).digest() == expected_info_hash:
                        self.log("Metadados obtidos via BTMaster.")
                        return raw_info

        except Exception as e:
            self.log(f"BTMaster falhou: {e}")

        return None

    def _run_http_metadata_fallback(self):
        if self.metadata_ready.is_set() or self.closed.is_set():
            return

        self.log("Iniciando fallback HTTP para obter metadados...", "info")

        try:
            raw_info = self._get_metadata_via_http(
                self.magnet_uri,
                self.info_hash
            )

            if raw_info:
                self.log("Metadados obtidos via fallback HTTP!", "info")
                self._install_metadata(raw_info)
                return

        except Exception as e:
            self.log(f"Fallback HTTP falhou: {e}", "debug")

        self.log(
            "Todos os fallbacks HTTP falharam. Dependendo apenas dos peers.",
            "warning"
        )    

    # def _run_http_metadata_fallback(self):
    #     if self.metadata_ready.is_set() or self.closed.is_set():
    #         return

    #     self.log("Iniciando fallback HTTP para obter metadados...", "info")

    #     sites = [
    #         ("https://magnet2torrent.com/upload/", "magnet2torrent"),
    #         ("https://webtor.io/magnet-to-torrent", "webtor.io")
    #     ]

    #     for url, site_name in sites:
    #         try:
    #             import urllib.request
    #             import urllib.parse
    #             import ssl

    #             self.log(f"Tentando obter metadados via {site_name}...", "debug")

    #             data = urllib.parse.urlencode({'magnet': self.magnet_uri}).encode('utf-8')
                
    #             req = urllib.request.Request(
    #                 url,
    #                 data=data,
    #                 headers={
    #                     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    #                     'Accept': 'application/octet-stream, */*'
    #                 }
    #             )

    #             ctx = ssl.create_default_context()
    #             ctx.check_hostname = False
    #             ctx.verify_mode = ssl.CERT_NONE

    #             with urllib.request.urlopen(req, context=ctx, timeout=18) as r:
    #                 torrent_data = r.read()

    #             if len(torrent_data) < 200:
    #                 continue

    #             # Verifica se é um torrent válido (deve começar com 'd')
    #             if torrent_data[:1] not in (b'd', b'D'):
    #                 self.log(f"{site_name} retornou conteúdo inválido", "debug")
    #                 continue

    #             decoded = bdecode(torrent_data)
    #             info_dict = decoded.get(b'info') or decoded.get('info')

    #             if info_dict:
    #                 raw_info = bencode(info_dict)
    #                 if hashlib.sha1(raw_info).digest() == self.info_hash:
    #                     self.log(f"✅ Metadados obtidos com sucesso via {site_name}!", "info")
    #                     self._install_metadata(raw_info)
    #                     return

    #         except Exception as e:
    #             self.log(f"Falha no {site_name}: {e}", "debug")
    #             continue

    #     self.log("Todos os fallbacks HTTP falharam. Dependendo apenas dos peers.", "warning")      

    def add_peer(self, host, port):
        if isinstance(host, bytes):
            host = host.decode('utf-8', errors='ignore')
        try:
            port = int(port)
        except (TypeError, ValueError):
            return False
        if not host or not (0 < port < 65536) or self.closed.is_set():
            return False
        key = "%s:%d" % (host, port)
        with self._lock:
            if self.closed.is_set() or key in self._candidate_seen or key in self._peers:
                return False
            self._candidate_seen.add(key)
            self._candidate_peers.append((host, port))
        self.notify_scheduler()
        return True

    def _set_discovery_status(self, text):
        with self._lock:
            self.discovery_status = str(text or "Aguardando descoberta")
            self.last_discovery_at = time.monotonic()

    def _discovery_report(self, message, level="debug"):
        self.log("Descoberta: %s" % message, level)

    def _receive_discovered_peers(self, peers, source="tracker"):
        if self.closed.is_set():
            return
        accepted = 0
        for peer in peers or []:
            try:
                host, port = peer
            except (TypeError, ValueError):
                continue
            if self.add_peer(host, port):
                accepted += 1
        if not accepted:
            return
        source_key = str(source or "tracker").lower()
        source_names = {
            "dht": "DHT",
            "lpd": "LPD local",
            "local": "Loopback configurado",
            "pex": "PEX",
        }
        source_name = source_names.get(source_key, "Tracker")
        with self._lock:
            if source_key == "dht":
                self.dht_peer_count += accepted
            elif source_key in ("lpd", "local"):
                self.lpd_peer_count += accepted
            elif source_key == "pex":
                self.pex_peer_count += accepted
            else:
                self.tracker_peer_count += accepted
            queued = len(self._candidate_peers)
            tracker_count = self.tracker_peer_count
            dht_count = self.dht_peer_count
            lpd_count = self.lpd_peer_count
            pex_count = self.pex_peer_count
        self._set_discovery_status("%s entregou %d peer(s); T:%d DHT:%d LAN:%d PEX:%d fila:%d" % (
            source_name, accepted, tracker_count, dht_count, lpd_count, pex_count, queued))

    def _lpd_loop(self):
        try:
            discover_local_peers(
                self.info_hash,
                announce_port=self.peer_port,
                reporter=self._discovery_report,
                peer_callback=self._receive_discovered_peers,
                stop_event=self.closed,
                listen_seconds=None,
                announce_interval=8.0,
            )
        except Exception as exc:
            self._discovery_report("LPD interrompido: %s" % exc, "warning")

    def _discovery_loop(self):
        while not self.closed.is_set():
            self.discovery_round += 1
            round_number = self.discovery_round
            left = self.total_length if self.total_length > 0 else 1
            round_stop = threading.Event()
            results = {"tracker": [], "dht": []}
            workers = []
            with self._lock:
                self.tracker_peer_count = 0
                self.dht_peer_count = 0

            def receiver(peers, source="tracker"):
                self._receive_discovered_peers(peers, source)

            def run_trackers():
                if not self.enable_trackers:
                    self._discovery_report("Trackers desativados nas configurações.")
                    return
                if not self.trackers:
                    self._discovery_report("Magnet sem tracker informado.")
                    return
                self._set_discovery_status("Trackers em paralelo (%d fonte(s))" % len(self.trackers))
                results["tracker"] = discover_trackers(
                    self.trackers,
                    self.info_hash,
                    self.peer_id,
                    left=left,
                    limit=80,
                    port=self.peer_port,
                    event="started" if not self._tracker_started else None,
                    reporter=self._discovery_report,
                    peer_callback=receiver,
                    stop_event=round_stop,
                    max_workers=4,
                    round_timeout=18.0,
                    http_timeout=4.0,
                    udp_timeout=3.0,
                )
                self._tracker_started = True

            def run_dht():
                if not self.enable_dht:
                    self._discovery_report("DHT desativado nas configurações.")
                    return
                self._set_discovery_status("DHT em paralelo com trackers")
                results["dht"] = discover_dht(
                    self.info_hash,
                    max_queries=18,
                    timeout=0.45,
                    reporter=self._discovery_report,
                    peer_callback=receiver,
                    stop_event=round_stop,
                )

            if self.enable_trackers and self.trackers:
                workers.append(threading.Thread(target=run_trackers, name="PureTorrentTrackers", daemon=True))
            if self.enable_dht:
                workers.append(threading.Thread(target=run_dht, name="PureTorrentDHT", daemon=True))

            for worker in workers:
                worker.start()

            round_deadline = time.monotonic() + 20.0
            while not self.closed.is_set() and time.monotonic() < round_deadline:
                if all(not worker.is_alive() for worker in workers):
                    break
                self.closed.wait(0.10)
            round_stop.set()
            for worker in workers:
                if worker.is_alive() and worker is not threading.current_thread():
                    worker.join(timeout=0.20)

            with self._lock:
                tracker_count = self.tracker_peer_count
                dht_count = self.dht_peer_count
                lpd_count = self.lpd_peer_count
                pex_count = self.pex_peer_count
                queued = len(self._candidate_peers)
                connected = sum(1 for peer in self._peers.values() if peer.connected)
            found = tracker_count + dht_count + lpd_count + pex_count
            if found:
                status = "Rodada %d: %d peer(s) liberado(s)" % (round_number, found)
                self._set_discovery_status("%s [T:%d DHT:%d LAN:%d PEX:%d fila:%d conectados:%d]" % (
                    status, tracker_count, dht_count, lpd_count, pex_count, queued, connected))
            else:
                status = "Rodada %d: nenhuma fonte retornou peer" % round_number
                self._set_discovery_status("%s [T:%d DHT:%d LAN:%d PEX:%d]" % (status, tracker_count, dht_count, lpd_count, pex_count))

            retry_seconds = 25.0 if not self.metadata_ready.is_set() and connected == 0 else 90.0
            if self.closed.wait(retry_seconds):
                break

    def _connect_candidates(self):
        with self._lock:
            connected_or_starting = sum(1 for peer in self._peers.values() if peer.running.is_set())
            open_slots = self.max_peers - connected_or_starting
            candidates = []
            while open_slots > 0 and self._candidate_peers:
                candidates.append(self._candidate_peers.popleft())
                open_slots -= 1
        for host, port in candidates:
            peer = PeerConnection(self, host, port)
            with self._lock:
                if peer.key in self._peers:
                    continue
                self._peers[peer.key] = peer
            peer.start()

    def accept_incoming_peer(self, conn, address, handshake):
        host, port = address[0], int(address[1])
        key = "%s:%d" % (host, port)
        with self._lock:
            active = sum(1 for peer in self._peers.values() if peer.running.is_set())
            if self.closed.is_set() or key in self._peers or active >= self.max_peers:
                try:
                    conn.close()
                except OSError:
                    pass
                return False
            peer = PeerConnection(self, host, port, incoming_socket=conn, incoming_handshake=handshake)
            self._peers[key] = peer
        peer.start()
        return True

    def on_peer_connected(self, peer):
        if self.metadata_ready.is_set():
            peer.send_interested()
            peer.send_bitfield()
        self.notify_scheduler()

    def on_peer_disconnected(self, peer, reason=""):
        was_connected = getattr(peer, "was_connected_once", False)
        with self._lock:
            self._peers.pop(peer.key, None)
            for block_key, owners in list(self.pending_blocks.items()):
                if peer.key in owners:
                    owners.pop(peer.key, None)
                    peer.pending_count = max(0, peer.pending_count - 1)
                if not owners:
                    self.pending_blocks.pop(block_key, None)
            self._condition.notify_all()
        self.notify_scheduler()
        
        if reason:
            reason_lower = reason.lower()
            diag = ""
            if "timed out" in reason_lower or "timeout" in reason_lower:
                diag = " (Possivel bloqueio de firewall/NAT agressivo, roteador sem UPnP, ou peer offline)"
            elif "refused" in reason_lower or "recusada" in reason_lower:
                diag = " (Conexao recusada: firewall de saida local bloqueando ou porta remota fechada)"
            elif "reset" in reason_lower or "redefinida" in reason_lower:
                diag = " (Conexao redefinida pelo peer: conexao encerrada abruptamente)"
            elif "bep 10" in reason_lower or "metadata" in reason_lower:
                diag = " (Peer conectado mas nao tem suporte ao protocolo de metadados ut_metadata)"
            elif "handshake" in reason_lower:
                diag = " (Falha de handshake BitTorrent: versao ou info_hash incompativel)"
            
            status_str = "Conexao com" if was_connected else "Tentativa de conexao a"
            action_str = "encerrada" if was_connected else "falhou"
            self.log(f"[{peer.key}] {status_str} peer {action_str}: {reason}{diag}", "debug")

    def on_peer_extensions(self, peer):
        if not peer.extensions_logged:
            peer.extensions_logged = True
        with self._lock:
            if self.metadata_ready.is_set() or peer.remote_metadata_id is None:
                return
            if peer.metadata_size and (self._metadata_size is None or peer.metadata_size < self._metadata_size):
                self._metadata_size = peer.metadata_size
            if self._metadata_size is None:
                return
            if self._metadata_size > MAX_METADATA_SIZE:
                self.set_error("Metadata do torrent excede o limite permitido")
                return
            total_parts = (self._metadata_size + METADATA_BLOCK_SIZE - 1) // METADATA_BLOCK_SIZE
            for index in range(total_parts):
                if index in self._metadata_parts:
                    continue
                owner = self._metadata_requested.get(index)
                if owner and time.monotonic() - owner[1] < 8.0:
                    continue
                self._metadata_requested[index] = (peer.key, time.monotonic())
                self._metadata_attempts[index] = self._metadata_attempts.get(index, 0) + 1
                peer.send_extended(peer.remote_metadata_id, bencode({b"msg_type": 0, b"piece": index}))
                if sum(1 for key, value in self._metadata_requested.items() if value[0] == peer.key) >= 4:
                    break

    def on_peer_pex(self, peer, payload):
        if not isinstance(payload, dict) or self.closed.is_set():
            return
        def get_val(d, key):
            if not isinstance(d, dict):
                return None
            if key in d:
                return d[key]
            b_key = key.encode('utf-8') if isinstance(key, str) else key
            s_key = key.decode('utf-8', errors='ignore') if isinstance(key, bytes) else key
            if b_key in d:
                return d[b_key]
            if s_key in d:
                return d[s_key]
            return None

        peers = []
        added = get_val(payload, "added")
        if isinstance(added, (bytes, bytearray)):
            peers.extend(parse_compact_peers(added, socket.AF_INET))
        added6 = get_val(payload, "added6")
        if isinstance(added6, (bytes, bytearray)):
            peers.extend(parse_compact_peers(added6, socket.AF_INET6))
        if peers:
            self._receive_discovered_peers(peers, "pex")

    def on_metadata_message(self, peer, header, data):
        def get_val(d, key):
            if not isinstance(d, dict):
                return None
            if key in d:
                return d[key]
            b_key = key.encode('utf-8') if isinstance(key, str) else key
            s_key = key.decode('utf-8', errors='ignore') if isinstance(key, bytes) else key
            if b_key in d:
                return d[b_key]
            if s_key in d:
                return d[s_key]
            return None

        message_type = get_val(header, "msg_type")
        piece_index = get_val(header, "piece")
        if message_type != 1 or not isinstance(piece_index, int) or piece_index < 0:
            return
        total_size = get_val(header, "total_size")
        with self._lock:
            if isinstance(total_size, int) and 0 < total_size <= MAX_METADATA_SIZE:
                if self._metadata_size is None:
                    self._metadata_size = total_size
                elif self._metadata_size != total_size:
                    peer.failures += 1
                    return
            if self._metadata_size is None:
                return
            expected = min(METADATA_BLOCK_SIZE, self._metadata_size - piece_index * METADATA_BLOCK_SIZE)
            if expected <= 0 or len(data) < expected:
                peer.failures += 1
                return
            self._metadata_parts[piece_index] = bytes(data[:expected])
            self._metadata_requested.pop(piece_index, None)
            part_count = (self._metadata_size + METADATA_BLOCK_SIZE - 1) // METADATA_BLOCK_SIZE
            if len(self._metadata_parts) < part_count:
                self.on_peer_extensions(peer)
                return
            raw_info = b"".join(self._metadata_parts[index] for index in range(part_count))[:self._metadata_size]
        self._install_metadata(raw_info)

    def _install_metadata(self, raw_info):
        try:
            info = bdecode(raw_info)
            if not isinstance(info, dict):
                raise TorrentError("metadata sem dicionário info")
            expected_hash = hashlib.sha1(bencode(info)).digest()
            if expected_hash != self.info_hash:
                raise TorrentError("hash do metadata não confere com o magnet")
            self._parse_info(info)
        except (BencodeError, TorrentError, ValueError) as exc:
            self.set_error("Falha ao validar metadata: %s" % exc)
            return

        with self._lock:
            if self.metadata_ready.is_set():
                return
            self.info = info
            self.metadata_ready.set()
            self.playback_offset = self.selected_file["offset"] if self.selected_file else 0
            self._condition.notify_all()
        for peer in list(self._peers.values()):
            if peer.connected:
                peer.send_interested()
                peer.send_bitfield()
        self.notify_scheduler()

    def _parse_info(self, info):
        def get_val(d, key):
            if not isinstance(d, dict):
                return None
            if key in d:
                return d[key]
            b_key = key.encode('utf-8') if isinstance(key, str) else key
            s_key = key.decode('utf-8', errors='ignore') if isinstance(key, bytes) else key
            if b_key in d:
                return d[b_key]
            if s_key in d:
                return d[s_key]
            return None

        piece_length = get_val(info, "piece length")
        pieces = get_val(info, "pieces")
        if not isinstance(piece_length, int) or piece_length < BLOCK_SIZE or piece_length > 16 * 1024 * 1024:
            raise TorrentError("piece length inválido")
        if not isinstance(pieces, bytes) or not pieces or len(pieces) % 20:
            raise TorrentError("hashes de peças inválidos")

        files = []
        offset = 0
        root_bytes = get_val(info, "name") or self.display_name.encode("utf-8", "replace")
        root_name = _safe_filename(root_bytes)
        
        info_files = get_val(info, "files")
        if isinstance(info_files, list):
            for entry in info_files:
                if not isinstance(entry, dict):
                    continue
                length = get_val(entry, "length")
                parts = get_val(entry, "path")
                if not isinstance(length, int) or length < 0 or not isinstance(parts, list):
                    continue
                clean_parts = [_safe_filename(part) for part in parts if isinstance(part, (bytes, str))]
                # Mantém o caminho completo para o cache, mas também expõe o caminho
                # relativo para que a interface possa navegar por temporadas/subpastas.
                file_name = "/".join([root_name] + clean_parts) if clean_parts else root_name
                relative_path = "/".join(clean_parts) if clean_parts else root_name
                files.append({
                    "index": len(files),
                    "name": file_name,
                    "relative_path": relative_path,
                    "basename": clean_parts[-1] if clean_parts else root_name,
                    "length": length,
                    "offset": offset,
                })
                offset += length
        else:
            length = get_val(info, "length")
            if not isinstance(length, int) or length < 0:
                raise TorrentError("torrent sem tamanho de arquivo")
            files.append({
                "index": 0,
                "name": root_name,
                "relative_path": root_name,
                "basename": root_name,
                "length": length,
                "offset": 0,
            })
            offset = length

        if not files or offset <= 0:
            raise TorrentError("torrent sem arquivos reproduzíveis")
        expected_pieces = (offset + piece_length - 1) // piece_length
        if expected_pieces != len(pieces) // 20:
            raise TorrentError("quantidade de hashes não bate com o tamanho")

        self.piece_length = piece_length
        self.piece_hashes = [pieces[index:index + 20] for index in range(0, len(pieces), 20)]
        self.total_length = offset
        self.files = files
        self.selected_file = self._select_video_file(files)
        if self.selected_file is None:
            raise TorrentError("torrent não possui arquivo de vídeo compatível")
        self.cache.setup_files(self.files, self.total_length, self.piece_length, self.piece_hashes)

    @staticmethod
    def _select_video_file(files):
        priority = {".mkv": 0, ".mp4": 1, ".m4v": 2, ".webm": 3}
        
        candidates = []
        for item in files:
            name_lower = item["name"].lower()
            ext = os.path.splitext(name_lower)[1]
            if ext in priority:
                score = priority[ext]
                candidates.append((score, -item["length"], item))
        
        if not candidates:
            # Fallback: maior arquivo
            return max(files, key=lambda x: x["length"]) if files else None
            
        candidates.sort()
        return candidates[0][2]    
    # def _select_video_file(files):
    #     priority = {".mkv": 0, ".mp4": 1, ".m4v": 2, ".webm": 3, ".ts": 4, ".avi": 5, ".mov": 6}
    #     candidates = []
    #     for item in files:
    #         name = item["name"].lower()
    #         extension = os.path.splitext(name)[1]
    #         if extension in priority:
    #             candidates.append((priority[extension], -item["length"], item))
    #     if not candidates:
    #         return None
    #     candidates.sort(key=lambda row: (row[0], row[1], row[2]["name"]))
    #     return candidates[0][2]

    @staticmethod
    def _public_file(item):
        if not item:
            return None
        return {
            "index": int(item["index"]),
            "name": item["name"],
            "relative_path": item.get("relative_path", item["name"]),
            "basename": item.get("basename", os.path.basename(item["name"])),
            "length": int(item["length"]),
            "extension": os.path.splitext(item["name"].lower())[1],
        }

    def list_primary_video_files(self):
        if not self.metadata_ready.is_set():
            return []
        with self._lock:
            return [
                self._public_file(item)
                for item in self.files
                if os.path.splitext(item["name"].lower())[1] in PRIMARY_VIDEO_EXTENSIONS
                and item["length"] > 0
            ]

    def select_video_file(self, file_index):
        try:
            file_index = int(file_index)
        except (TypeError, ValueError):
            raise TorrentError("Índice de arquivo inválido")
        if not self.metadata_ready.is_set():
            raise TorrentError("metadata ainda não disponível")

        with self._lock:
            selected = None
            for item in self.files:
                if item.get("index") == file_index:
                    selected = item
                    break
            if selected is None:
                raise TorrentError("Arquivo selecionado não existe neste torrent")
            
            changed = self.selected_file is None or self.selected_file.get("index") != selected["index"]
            self.selected_file = selected
            self.playback_offset = selected["offset"]
            self.last_used = time.monotonic()
            self._condition.notify_all()

        self.notify_scheduler()
        return self._public_file(selected)

    def selected_file_info(self):
        if not self.metadata_ready.is_set():
            return None
        with self._lock:
            return self._public_file(self.selected_file)

    def _piece_size(self, piece_index):
        if piece_index < 0 or piece_index >= len(self.piece_hashes):
            return 0
        if piece_index == len(self.piece_hashes) - 1:
            return self.total_length - (piece_index * self.piece_length)
        return self.piece_length

    def _piece_indices_for_range(self, start, length):
        if not self.metadata_ready.is_set() or length <= 0:
            return []
        end = min(self.total_length - 1, start + length - 1)
        if start < 0 or end < start:
            return []
        return list(range(start // self.piece_length, end // self.piece_length + 1))

    def _wanted_pieces(self):
        if not self.metadata_ready.is_set() or not self.selected_file:
            return []
        file_start = self.selected_file["offset"]
        file_end = file_start + self.selected_file["length"]
        cursor = min(max(self.playback_offset, file_start), max(file_start, file_end - 1))
        
        # Janela urgente (buffer inicial de reprodução de alta prioridade)
        window_end = min(file_end, cursor + self.buffer_size_bytes)
        urgent = self._piece_indices_for_range(cursor, max(1, window_end - cursor))
        
        # Janela estendida (download contínuo em segundo plano de até 100MB ou 5x o buffer)
        background_size = max(200 * 1024 * 1024, self.buffer_size_bytes * 8)
        background_end = min(file_end, cursor + background_size)
        background = self._piece_indices_for_range(cursor, max(1, background_end - cursor))
        
        behind_start = max(file_start, cursor - 4 * 1024 * 1024)
        behind = self._piece_indices_for_range(behind_start, cursor - behind_start)
        
        ordered = []
        # Prioriza primeiro peças urgentes, depois peças recentes anteriores, e depois background
        for index in urgent + behind + background:
            if index not in self.completed_pieces and index not in ordered:
                ordered.append(index)
        return ordered

    def _availability(self, piece_index):
        return sum(1 for peer in self._peers.values() if peer.connected and peer.has_piece(piece_index))

    def _peer_has_rare_urgent_piece(self, peer):
        for index in self._wanted_pieces()[:24]:
            if peer.has_piece(index) and self._availability(index) <= 1:
                return True
        return False

    def _peer_score(self, peer, piece_index):
        if not peer.connected or peer.choked or not peer.has_piece(piece_index):
            return float("-inf")
        speed = peer.speed_bps()
        urgency = 8.0 if piece_index in self._wanted_pieces()[:4] else 0.0
        rarity = 3.0 / max(1, self._availability(piece_index))
        load_penalty = peer.pending_count * 1.75
        failure_penalty = (peer.failures + peer.invalid_blocks * 3) * 3.0
        return min(speed / 32768.0, 20.0) + urgency + rarity - load_penalty - failure_penalty

    def _next_missing_block(self, piece_index):
        piece_size = self._piece_size(piece_index)
        blocks = self.piece_blocks.get(piece_index, {})
        for begin in range(0, piece_size, BLOCK_SIZE):
            size = min(BLOCK_SIZE, piece_size - begin)
            if begin in blocks:
                continue
            if (piece_index, begin) not in self.pending_blocks:
                return begin, size
        return None

    def _reap_stale_requests(self):
        now = time.monotonic()
        with self._lock:
            for block_key, owners in list(self.pending_blocks.items()):
                for peer_key, started_at in list(owners.items()):
                    if now - started_at > REQUEST_TIMEOUT_SECONDS:
                        owners.pop(peer_key, None)
                        peer = self._peers.get(peer_key)
                        if peer:
                            peer.pending_count = max(0, peer.pending_count - 1)
                            peer.failures += 1
                if not owners:
                    self.pending_blocks.pop(block_key, None)

    def _maintain_metadata_peers(self):
        if self.metadata_ready.is_set():
            return
        now = time.monotonic()
        retry_peers = []
        close_peers = []
        with self._lock:
            for index, owner in list(self._metadata_requested.items()):
                peer_key, requested_at = owner
                if now - requested_at <= METADATA_REQUEST_TIMEOUT_SECONDS:
                    continue
                self._metadata_requested.pop(index, None)
                peer = self._peers.get(peer_key)
                if peer:
                    peer.failures += 1
            for peer in self._peers.values():
                if not peer.connected:
                    continue
                age = now - peer.connected_at
                if not peer.supports_extensions:
                    close_peers.append((peer, "peer sem BEP 10/metadata"))
                    continue
                if not peer.extensions_received_at:
                    if age >= METADATA_EXTENSION_TIMEOUT_SECONDS:
                        close_peers.append((peer, "não enviou handshake estendido"))
                    continue
                if peer.remote_metadata_id is None or not peer.metadata_size:
                    if age >= METADATA_EXTENSION_TIMEOUT_SECONDS:
                        close_peers.append((peer, "não oferece ut_metadata"))
                    continue
                retry_peers.append(peer)
        for peer, reason in close_peers:
            peer.close(reason)
        for peer in retry_peers:
            self.on_peer_extensions(peer)

    # def _schedule_piece_requests(self):
    #     wanted = self._wanted_pieces()
    #     if not wanted:
    #         return
    #     peers = [peer for peer in self._peers.values() if peer.connected and not peer.choked]
    #     peers.sort(key=lambda peer: peer.speed_bps(), reverse=True)
    #     active = peers[:self.active_peer_limit]
    #     for peer in active:
    #         #pipeline = max(2, min(8, 2 + int(peer.speed_bps() / (96 * 1024))))
    #         pipeline = max(3, min(12, 4 + int(peer.speed_bps() / (64 * 1024))))
    #         while peer.pending_count < pipeline:
    #             selected = None
    #             for piece_index in wanted:
    #                 candidate = self._next_missing_block(piece_index)
    #                 if candidate is None or not peer.has_piece(piece_index):
    #                     continue
    #                 score = self._peer_score(peer, piece_index)
    #                 if score == float("-inf"):
    #                     continue
    #                 selected = (piece_index, candidate[0], candidate[1])
    #                 break
    #             if selected is None:
    #                 break
    #             piece_index, begin, size = selected
    #             block_key = (piece_index, begin)
    #             with self._lock:
    #                 self.pending_blocks.setdefault(block_key, {})[peer.key] = time.monotonic()
    #                 peer.pending_count += 1
    #             if not peer.send_request(piece_index, begin, size):
    #                 with self._lock:
    #                     owners = self.pending_blocks.get(block_key, {})
    #                     owners.pop(peer.key, None)
    #                     if not owners:
    #                         self.pending_blocks.pop(block_key, None)
    #                     peer.pending_count = max(0, peer.pending_count - 1)
    #                 break
    def _schedule_piece_requests(self):
        """Agenda os pedidos de blocos para os peers conectados."""
        wanted = self._wanted_pieces()
        if not wanted:
            return

        # Proteção contra RuntimeError (deque mutated during iteration)
        with self._lock:
            peers = [peer for peer in self._peers.values() 
                    if peer.connected and not peer.choked]

        if not peers:
            return

        # Ordena por velocidade (usando a versão thread-safe do speed_bps)
        peers.sort(key=lambda peer: peer.speed_bps(), reverse=True)

        # Limita aos peers mais rápidos
        active_peers = peers[:self.active_peer_limit]

        for peer in active_peers:
            # Pipeline dinâmico (quantos requests simultâneos por peer)
            pipeline = max(3, min(12, 4 + int(peer.speed_bps() / (64 * 1024))))

            while peer.pending_count < pipeline:
                selected = None
                for piece_index in wanted:
                    candidate = self._next_missing_block(piece_index)
                    if candidate is None:
                        continue
                    if not peer.has_piece(piece_index):
                        continue

                    score = self._peer_score(peer, piece_index)
                    if score == float("-inf"):
                        continue

                    selected = (piece_index, candidate[0], candidate[1])
                    break

                if selected is None:
                    break

                piece_index, begin, size = selected
                block_key = (piece_index, begin)

                with self._lock:
                    if block_key in self.pending_blocks and peer.key in self.pending_blocks[block_key]:
                        continue
                    self.pending_blocks.setdefault(block_key, {})[peer.key] = time.monotonic()
                    peer.pending_count += 1

                if not peer.send_request(piece_index, begin, size):
                    # Se falhar ao enviar, desfaz o agendamento
                    with self._lock:
                        owners = self.pending_blocks.get(block_key, {})
                        owners.pop(peer.key, None)
                        if not owners:
                            self.pending_blocks.pop(block_key, None)
                        peer.pending_count = max(0, peer.pending_count - 1)
                    break    

    def _prune_slow_peers(self):
        now = time.monotonic()
        peers = list(self._peers.values())
        if len(peers) <= self.active_peer_limit:
            return
        for peer in peers:
            if not peer.connected or peer.pending_count:
                continue
            age = now - peer.connected_at
            if age < 60.0: 
                continue
            #if peer.speed_bps() < 2 * 1024 and not self._peer_has_rare_urgent_piece(peer):
            if peer.speed_bps() < 1024 and not self._peer_has_rare_urgent_piece(peer):
                peer.close("lento e sem peça rara na janela")

    def _purge_cache_if_needed(self):
        if self.cache_bytes <= self.cache_limit_bytes or not self.metadata_ready.is_set():
            return
        cursor_piece = self.playback_offset // self.piece_length
        background_size = max(100 * 1024 * 1024, self.buffer_size_bytes * 5)
        protected = set(self._piece_indices_for_range(
            max(0, self.playback_offset - 4 * 1024 * 1024),
            background_size + 4 * 1024 * 1024,
        ))
        candidates = sorted(
            [index for index in self.completed_pieces if index not in protected],
            key=lambda index: abs(index - cursor_piece),
            reverse=True,
        )
        for index in candidates:
            if self.cache_bytes <= self.cache_limit_bytes:
                break
            size = self._piece_size(index)
            self.cache.remove_piece(index)
            self.completed_pieces.discard(index)
            self.cache_bytes = max(0, self.cache_bytes - size)

    def _scheduler_loop(self):
        while not self.closed.is_set():
            self._connect_candidates()
            self._reap_stale_requests()
            self._unchoke_peers() 
            if self.metadata_ready.is_set():
                self._schedule_piece_requests()
                self._prune_slow_peers()
                self._purge_cache_if_needed()
            else:
                self._maintain_metadata_peers()
            self._wake_scheduler.wait(0.18)
            self._wake_scheduler.clear()

    def notify_scheduler(self):
        self._wake_scheduler.set()

    def _unchoke_peers(self):
        """Tenta manter peers interessados"""
        with self._lock:
            for peer in self._peers.values():
                if peer.connected and peer.choked and peer.pending_count == 0:
                    try:
                        peer.send_interested()
                    except:
                        peer.close("falha ao enviar interested")    

    def on_piece_block(self, peer, piece_index, begin, block):
        if not self.metadata_ready.is_set():
            return
        expected_piece_size = self._piece_size(piece_index)
        expected_length = min(BLOCK_SIZE, expected_piece_size - begin)
        if expected_piece_size <= 0 or begin < 0 or expected_length <= 0 or len(block) != expected_length:
            peer.invalid_blocks += 1
            return

        block_key = (piece_index, begin)
        with self._lock:
            owners = self.pending_blocks.pop(block_key, {})
            for owner_key in owners:
                owner = self._peers.get(owner_key)
                if owner:
                    owner.pending_count = max(0, owner.pending_count - 1)
            if piece_index in self.completed_pieces:
                return
            blocks = self.piece_blocks.setdefault(piece_index, {})
            if begin in blocks:
                return
            blocks[begin] = bytes(block)
            self._status_speed_samples.append((time.monotonic(), len(block)))
            expected_blocks = (expected_piece_size + BLOCK_SIZE - 1) // BLOCK_SIZE
            if len(blocks) < expected_blocks:
                self.notify_scheduler()
                return
            data = b"".join(blocks[offset] for offset in range(0, expected_piece_size, BLOCK_SIZE))
            is_mock = getattr(self, "is_mock_metadata", False)
            if len(data) != expected_piece_size or (not is_mock and hashlib.sha1(data).digest() != self.piece_hashes[piece_index]):
                self.piece_blocks.pop(piece_index, None)
                peer.invalid_blocks += 1
                self.notify_scheduler()
                return
            try:
                self.cache.write_piece(piece_index, data)
            except OSError as exc:
                self.set_error("Falha ao gravar cache local: %s" % exc)
                return
            self.completed_pieces.add(piece_index)
            self.cache_bytes += len(data)
            self.piece_blocks.pop(piece_index, None)
            self._condition.notify_all()
            # Envia HAVE para todos os peers conectados sobre a nova peça obtida
            for other_peer in list(self._peers.values()):
                if other_peer.connected:
                    other_peer.send_have(piece_index)
        self.notify_scheduler()

    def set_error(self, message):
        with self._lock:
            if not self.error:
                self.error = message
            self._condition.notify_all()

    def wait_for_metadata(self, timeout=35.0):
        self.start()
        deadline = time.monotonic() + timeout
        while not self.closed.is_set() and not self.metadata_ready.is_set():
            if self.error:
                return False
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False
            self.metadata_ready.wait(min(0.5, remaining))
        return self.metadata_ready.is_set()

    def set_playback_position(self, file_position):
        if not self.metadata_ready.is_set() or not self.selected_file:
            return
        start = self.selected_file["offset"]
        end = start + self.selected_file["length"]
        with self._lock:
            self.playback_offset = min(max(start, file_position), max(start, end - 1))
            self.last_used = time.monotonic()
        self.notify_scheduler()

    def _wait_for_piece(self, piece_index, timeout=120.0):
        deadline = time.monotonic() + timeout
        with self._condition:
            while piece_index not in self.completed_pieces and not self.closed.is_set():
                if self.error:
                    return False
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return False
                self._condition.wait(min(0.5, remaining))
        return piece_index in self.completed_pieces

    def read_file_range(self, file_position, length, timeout_per_piece=45.0):
        if not self.metadata_ready.is_set() or self.selected_file is None:
            raise TorrentError("metadata ainda não disponível")
        if file_position < 0 or length < 0 or file_position + length > self.selected_file["length"]:
            raise TorrentError("Range fora do arquivo")
        if length == 0:
            return b""

        absolute = self.selected_file["offset"] + file_position
        self.set_playback_position(absolute)
        result = bytearray()
        remaining = length
        current = absolute
        while remaining > 0 and not self.closed.is_set():
            piece_index = current // self.piece_length
            inside = current % self.piece_length
            required = min(remaining, self._piece_size(piece_index) - inside)
            if not self._wait_for_piece(piece_index, timeout_per_piece):
                raise TorrentError(f"Peca {piece_index} nao recebida a tempo (timeout de {timeout_per_piece}s)")
            piece = self.cache.read_piece(piece_index)
            if piece is None or len(piece) != self._piece_size(piece_index):
                with self._lock:
                    self.completed_pieces.discard(piece_index)
                self.notify_scheduler()
                raise TorrentError(f"Peca {piece_index} corrompida ou ausente no cache")
            result.extend(piece[inside:inside + required])
            current += required
            remaining -= required
            self.set_playback_position(current)
        return bytes(result)

    def _buffered_bytes_from_position(self):
        if not self.metadata_ready.is_set() or not self.selected_file:
            return 0
        file_start = self.selected_file["offset"]
        file_end = file_start + self.selected_file["length"]
        start = min(max(self.playback_offset, file_start), file_end)
        position = start
        while position < file_end:
            piece_index = position // self.piece_length
            if piece_index not in self.completed_pieces:
                break
            position = min(file_end, (piece_index + 1) * self.piece_length)
        return max(0, position - start)

    def _combined_speed(self):
        now = time.monotonic()
        samples = [(stamp, amount) for stamp, amount in self._status_speed_samples if now - stamp <= 12.0]
        if not samples:
            return 0.0
        return sum(amount for _, amount in samples) / max(1.0, now - samples[0][0])

    def status(self):
        self.start()
        with self._lock:
            connected = [peer for peer in self._peers.values() if peer.connected]
            active = [peer for peer in connected if peer.pending_count]
            if self.error:
                state = "erro"
            elif not self.metadata_ready.is_set():
                state = "buscando metadata"
            elif self._buffered_bytes_from_position() >= self.buffer_size_bytes:
                state = "pronto"
            else:
                state = "bufferizando"
            return {
                "state": state,
                "error": self.error,
                "bytes_buffered": self._buffered_bytes_from_position(),
                "buffer_target": self.buffer_size_bytes,
                "peers": len(connected),
                "active_peers": len(active),
                "speed_bps": int(self._combined_speed()),
                "file_name": self.selected_file["name"] if self.selected_file else self.display_name,
                "file_size": self.selected_file["length"] if self.selected_file else 0,
                "selected_file_index": self.selected_file["index"] if self.selected_file else None,
                "primary_video_count": len(self.list_primary_video_files()) if self.metadata_ready.is_set() else 0,
                "metadata_ready": self.metadata_ready.is_set(),
                "discovery": self.discovery_status,
                "discovery_round": self.discovery_round,
                "tracker_peers": self.tracker_peer_count,
                "dht_peers": self.dht_peer_count,
                "lpd_peers": self.lpd_peer_count,
                "pex_peers": self.pex_peer_count,
                "queued_peers": len(self._candidate_peers),
            }

    def close(self, remove_cache=True):
        if self.closed.is_set():
            return
        self.closed.set()
        self._wake_scheduler.set()
        with self._condition:
            self._condition.notify_all()
        for peer in list(self._peers.values()):
            peer.close("sessão finalizada")
        for thread in (self._lpd_thread, self._discovery_thread, self._scheduler_thread):
            if thread and thread.is_alive() and thread is not threading.current_thread():
                thread.join(timeout=1.5)
        if remove_cache:
            self.cache.clear()

class TorrentManager:
    def __init__(self, cache_root, settings=None, logger=None):
        self.cache_root = cache_root
        self.settings = settings or {}
        self.logger = logger
        self._lock = threading.RLock()
        self._sessions = {}
        os.makedirs(cache_root, exist_ok=True)

    def get_session(self, magnet_uri):
        descriptor = parse_magnet(magnet_uri)
        key = descriptor["info_hash"].hex()
        with self._lock:
            session = self._sessions.get(key)
            if session is None or session.closed.is_set():
                session = TorrentSession(
                    magnet_uri,
                    self.cache_root,
                    max_peers=self.settings.get("max_peers", 30),
                    buffer_size_mb=self.settings.get("buffer_size_mb", 30),
                    cache_limit_mb=self.settings.get("cache_limit_mb", 512),
                    peer_port=self.settings.get("peer_port", 6881),
                    enable_trackers=self.settings.get("enable_trackers", True),
                    enable_dht=self.settings.get("enable_dht", True),
                    enable_lpd=self.settings.get("enable_lpd", True),
                    local_peer_port=self.settings.get("local_peer_port", 0),
                    logger=self.logger,
                )
                self._sessions[key] = session
            session.last_used = time.monotonic()
        session.start()
        return session

    def get_session_by_info_hash(self, info_hash):
        if not isinstance(info_hash, (bytes, bytearray)):
            return None
        with self._lock:
            return self._sessions.get(bytes(info_hash).hex())

    def stop_session(self, magnet_uri):
        descriptor = parse_magnet(magnet_uri)
        key = descriptor["info_hash"].hex()
        with self._lock:
            session = self._sessions.pop(key, None)
        if session is not None:
            session.close(remove_cache=True)

    def cleanup_idle(self, idle_seconds=15 * 60):
        now = time.monotonic()
        with self._lock:
            stale = [key for key, session in self._sessions.items()
                     if now - session.last_used > idle_seconds]
            for key in stale:
                session = self._sessions.pop(key)
                session.close(remove_cache=True)

    def close_all(self):
        with self._lock:
            sessions = list(self._sessions.values())
            self._sessions.clear()
        for session in sessions:
            session.close(remove_cache=True)

class PiecesDataWrapper(dict):
    def __init__(self, engine):
        self.engine = engine
    def __len__(self):
        if self.engine.current_session:
            return len(self.engine.current_session.completed_pieces)
        return 0

class TorrentEngine:
    def __init__(self):
        self.info_hash = None
        self.files = []
        self.current_session = None
        self.pieces_data = PiecesDataWrapper(self)
        
        # Diretório de cache temporário em disco
        settings = {}
        try:
            import xbmcvfs
            import xbmcaddon
            addon = xbmcaddon.Addon()
            addon_profile = addon.getAddonInfo('profile')
            if not xbmcvfs.exists(addon_profile):
                xbmcvfs.mkdirs(addon_profile)
            self.cache_dir = xbmcvfs.translatePath(os.path.join(addon_profile, "torrent_cache"))
            
            # Carrega as configurações de rede e buffer do addon para sincronizar com o motor
            try:
                try:
                    max_peers = int(addon.getSetting("max_peers") or 30)
                except:
                    max_peers = 30
                try:
                    buffer_size_mb = int(addon.getSetting("buffer_size") or 30)
                except:
                    buffer_size_mb = 30
                settings = {
                    "max_peers": max_peers,
                    "buffer_size_mb": buffer_size_mb,
                }
            except Exception as e:
                print(f"[TorrentEngine] Erro ao carregar configurações do addon: {e}")
        except Exception:
            import tempfile
            self.cache_dir = os.path.join(tempfile.gettempdir(), "puretorrent_cache")
            
        self.manager = TorrentManager(self.cache_dir, settings=settings)

    def log(self, text):
        print(f"[TorrentEngine] {text}")

    @property
    def piece_length(self):
        if self.current_session and self.current_session.metadata_ready.is_set():
            return self.current_session.piece_length
        return 1048576

    @property
    def total_pieces(self):
        if self.current_session and self.current_session.metadata_ready.is_set():
            return len(self.current_session.piece_hashes)
        return 1500

    @property
    def peers(self):
        if self.current_session:
            return list(self.current_session._peers.keys())
        return []

    def _get_metadata_via_http(self, magnet_uri, expected_info_hash):
        import urllib.request
        import urllib.parse
        import ssl
        import json
        import hashlib

        # ===== magnet2torrent =====
        try:
            self.log("Tentando magnet2torrent...")

            data = urllib.parse.urlencode({
                "magnet": magnet_uri
            }).encode("utf-8")

            req = urllib.request.Request(
                "https://magnet2torrent.com/upload/",
                data=data,
                headers={
                    "User-Agent": "Mozilla/5.0"
                }
            )

            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

            with urllib.request.urlopen(req, context=ctx, timeout=15) as r:
                torrent_data = r.read()

            decoded = bdecode(torrent_data)
            info_dict = decoded.get(b'info') or decoded.get('info')

            if info_dict:
                raw_info = bencode(info_dict)

                if hashlib.sha1(raw_info).digest() == expected_info_hash:
                    self.log("Metadados obtidos via magnet2torrent.")
                    return raw_info

        except Exception as e:
            self.log(f"magnet2torrent falhou: {e}")

        # ===== BTMASTER =====
        try:
            self.log("Tentando BTMaster...")

            data = urllib.parse.urlencode({
                "magnetUrl": magnet_uri
            }).encode("utf-8")

            req = urllib.request.Request(
                "https://www.btmaster.net/magnet2torrent/do/",
                data=data,
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "X-Requested-With": "XMLHttpRequest"
                }
            )

            with urllib.request.urlopen(req, timeout=15) as r:
                response = json.loads(r.read().decode("utf-8"))

            if response.get("code") == 0:
                torrent_hash = response["data"]["hash"]

                torrent_url = (
                    f"https://www.btmaster.net/tempTor/{torrent_hash}.torrent"
                )

                with urllib.request.urlopen(torrent_url, timeout=15) as r:
                    torrent_data = r.read()

                decoded = bdecode(torrent_data)
                info_dict = decoded.get(b'info') or decoded.get('info')

                if info_dict:
                    raw_info = bencode(info_dict)

                    if hashlib.sha1(raw_info).digest() == expected_info_hash:
                        self.log("Metadados obtidos via BTMaster.")
                        return raw_info

        except Exception as e:
            self.log(f"BTMaster falhou: {e}")

        return None        

    def load_magnet(self, magnet_uri, monitor, wait_metadata=True):
        try:
            self.current_session = self.manager.get_session(magnet_uri)
            
            # Busca preferencial e síncrona via HTTP fallback
            if wait_metadata and not self.current_session.metadata_ready.is_set():
                self.log("Tentando obter metadados via serviços HTTP...")

                try:
                    raw_info = self._get_metadata_via_http(
                        magnet_uri,
                        self.current_session.info_hash
                    )

                    if raw_info and not self.current_session.metadata_ready.is_set():
                        self.current_session._install_metadata(raw_info)
                        self.log("Metadados instalados via HTTP.")

                except Exception as e:
                    self.log(f"Falha HTTP: {e}")

                if not self.current_session.metadata_ready.is_set():
                    self.log("Todos os fallbacks HTTP falharam. Tentando obter metadados pelos peers.")
                    # anular metadados dos peers
                    raise
            
            if not wait_metadata:
                files_info = self.current_session.files if self.current_session.metadata_ready.is_set() else []
                return {
                    'files': files_info,
                    'piece_length': self.current_session.piece_length if self.current_session.metadata_ready.is_set() else 1048576,
                    'total_pieces': len(self.current_session.piece_hashes) if self.current_session.metadata_ready.is_set() else 0
                }
                
            self.log("Aguardando metadados reais do torrent...")
            start_time = time.monotonic()
            last_log_time = 0
            #timeout_seconds = 120.0
            timeout_seconds = 180.0
            
            while not self.current_session.metadata_ready.is_set():
                if monitor and hasattr(monitor, 'isAborted') and monitor.isAborted():
                    self.log("Cancelado pelo usuário ou Kodi fechando.")
                    return None
                if self.current_session.closed.is_set():
                    self.log("Sessão fechada antes de obter metadados.")
                    return None
                if self.current_session.error:
                    self.log(f"Erro na sessão: {self.current_session.error}")
                    raise TorrentError(self.current_session.error)
                
                connected_count = sum(1 for p in self.current_session._peers.values() if p.connected)
                candidates_count = len(self.current_session._candidate_peers)
                
                now = time.monotonic()
                if now - last_log_time > 3.0:
                    self.log(f"Buscando metadados reais... Peers conectados: {connected_count} | Candidatos na fila: {candidates_count}")
                    last_log_time = now
                
                if now - start_time > timeout_seconds:
                    if connected_count == 0:
                        raise TorrentError("Não foi possível encontrar nenhum peer ativo na rede BitTorrent após 2 minutos. Verifique sua conexão ou se o torrent possui sementes (seeders) ativos.")
                    else:
                        raise TorrentError("Conectado a peers, mas nenhum enviou os metadados reais do torrent a tempo. Tente um torrent mais saudável.")
                
                if self.current_session.metadata_ready.wait(0.5):
                    break
            
            if not self.current_session.metadata_ready.is_set():
                raise TorrentError("Falha ao obter metadados do torrent.")
                
            self.log("Metadados reais recebidos com sucesso!")
            self.files = self.current_session.files
            return {
                'files': self.current_session.files,
                'piece_length': self.current_session.piece_length,
                'total_pieces': len(self.current_session.piece_hashes)
            }
        except Exception as e:
            self.log(f"Erro ao carregar o torrent: {e}")
            raise

    # def get_file_bytes(self, offset, length, monitor):
    #     if not self.current_session:
    #         return b""
            
    #     target_file = None
    #     for f in self.current_session.files:
    #         if f['offset'] <= offset < f['offset'] + f['length']:
    #             target_file = f
    #             break
    #     if not target_file:
    #         return b""
            
    #     file_pos = offset - target_file['offset']
    #     if self.current_session.selected_file is None or self.current_session.selected_file['index'] != target_file['index']:
    #         self.current_session.select_video_file(target_file['index'])
            
    #     try:
    #         # Tenta baixar a peça fisicamente de forma puramente real
    #         return self.current_session.read_file_range(file_pos, length, timeout_per_piece=90.0)
    #     except Exception as e:
    #         self.log(f"Erro ao ler bytes reais do torrent: {e}. Usando fallback determinístico de segurança para player não travar.")
    #         # Retorna bytes determinísticos baseados na posição para que o reprodutor do Kodi continue transmitindo sem congelar
    #         # piece_idx = offset // self.piece_length
    #         # #return bytes([piece_idx % 256]) * length
    #         # return bytes([piece_idx % 256]) * length
    #         if length < 4096:
    #             return b'\x00' * length                    # zeros para blocos pequenos
    #         else:
    #             # Padrão mais natural (melhor que repetir um único byte)
    #             pattern = b'\x00\xFF\x00\xFF\x55\xAA\x55\xAA'
    #             return (pattern * (length // len(pattern) + 1))[:length]    
    # 
    # def get_file_bytes(self, offset, length, monitor):
    #     if not self.current_session:
    #         return b'\x00' * length
            
    #     target_file = None
    #     for f in self.current_session.files:
    #         if f['offset'] <= offset < f['offset'] + f['length']:
    #             target_file = f
    #             break
    #     if not target_file:
    #         return b'\x00' * length
            
    #     file_pos = offset - target_file['offset']
    #     if self.current_session.selected_file is None or self.current_session.selected_file['index'] != target_file['index']:
    #         self.current_session.select_video_file(target_file['index'])
            
    #     try:
    #         # Tenta ler dados reais do torrent
    #         return self.current_session.read_file_range(file_pos, length, timeout_per_piece=120.0)
    #     except Exception as e:
    #         self.log(f"Erro ao ler bytes reais (piece {offset // self.piece_length}): {e}. Usando fallback seguro.")
            
    #         # === FALLBACK MELHORADO ===
    #         if length <= 4096:
    #             return b'\x00' * length
    #         else:
    #             # Padrão mais "amigável" para o decoder de vídeo
    #             pattern = b'\x00' * 64 + b'\xFF\x00\x00\x00' * 16
    #             return (pattern * (length // len(pattern) + 1))[:length]
    def get_file_bytes(self, offset, length, monitor):
        if not self.current_session or not self.current_session.metadata_ready.is_set():
            return b'\x00' * length

        target_file = None
        for f in self.current_session.files:
            if f['offset'] <= offset < f['offset'] + f['length']:
                target_file = f
                break

        if not target_file:
            return b'\x00' * length

        file_pos = offset - target_file['offset']

        # Seleciona o arquivo automaticamente se ainda não estiver selecionado
        if self.current_session.selected_file is None or self.current_session.selected_file['index'] != target_file['index']:
            self.current_session.select_video_file(target_file['index'])

        try:
            # TENTA LER DIRETO DO CACHE EM DISCO (melhor performance)
            piece_index = (target_file['offset'] + file_pos) // self.current_session.piece_length
            piece_offset = (target_file['offset'] + file_pos) % self.current_session.piece_length

            # Verifica se a peça já está completa no cache
            if piece_index in self.current_session.completed_pieces:
                data = self.current_session.cache.read_piece(piece_index)
                if data and len(data) > piece_offset:
                    available = len(data) - piece_offset
                    read_len = min(length, available)
                    return data[piece_offset : piece_offset + read_len]

            # Se não estiver completa, tenta ler com timeout maior
            return self.current_session.read_file_range(file_pos, length, timeout_per_piece=90.0)

        except Exception as e:
            self.log(f"Erro ao ler bytes (offset {offset}, piece {piece_index if 'piece_index' in locals() else 'N/A'}): {e}")
            # Fallback seguro
            if length <= 8192:
                return b'\x00' * length
            else:
                pattern = b'\x00' * 128 + b'\xFF\x00\x00\x00' * 32
                return (pattern * (length // len(pattern) + 1))[:length]                

    def close_all(self):
        if self.manager:
            self.manager.close_all()