# -*- coding: utf-8 -*-
# Decodificador e Codificador Bencode - Implementação em Python Puro

def decode_int(x, f):
    f += 1
    newf = x.index(b'e', f)
    return int(x[f:newf]), newf + 1

def decode_string(x, f):
    colon = x.index(b':', f)
    n = int(x[f:colon])
    colon += 1
    return x[colon:colon+n], colon + n

def decode_list(x, f):
    r, f = [], f + 1
    while x[f:f+1] != b'e':
        v, f = decode_func[x[f:f+1]](x, f)
        r.append(v)
    return r, f + 1

def decode_dict(x, f):
    r, f = {}, f + 1
    while x[f:f+1] != b'e':
        k, f = decode_string(x, f)
        v, f = decode_func[x[f:f+1]](x, f)
        r[k.decode('utf-8', errors='ignore')] = v
    return r, f + 1

decode_func = {
    b'i': decode_int,
    b'l': decode_list,
    b'd': decode_dict,
}
for i in range(10):
    decode_func[str(i).encode('ascii')] = decode_string

class BencodeError(Exception):
    pass

def bdecode(x):
    """Decodifica uma string de bytes Bencode em estruturas nativas do Python."""
    try:
        return decode_func[x[0:1]](x, 0)[0]
    except Exception as e:
        raise BencodeError("Falha ao decodificar Bencode: " + str(e))

def bdecode_prefix(x):
    """Decodifica o primeiro item bencoded em x e retorna o objeto e o número de bytes consumidos."""
    try:
        return decode_func[x[0:1]](x, 0)
    except Exception as e:
        raise BencodeError("Falha ao decodificar prefixo Bencode: " + str(e))

def bencode(x):
    """Codifica objetos Python em strings de bytes codificadas no formato Bencode."""
    if isinstance(x, int):
        return f"i{x}e".encode('ascii')
    elif isinstance(x, str):
        encoded = x.encode('utf-8')
        return f"{len(encoded)}:".encode('ascii') + encoded
    elif isinstance(x, bytes):
        return f"{len(x)}:".encode('ascii') + x
    elif isinstance(x, list):
        return b"l" + b"".join([bencode(i) for i in x]) + b"e"
    elif isinstance(x, dict):
        keys = sorted(x.keys())
        return b"d" + b"".join([bencode(k) + bencode(x[k]) for k in keys]) + b"e"
    raise TypeError(f"Tipo não suportado pela serialização Bencode: {type(x)}")