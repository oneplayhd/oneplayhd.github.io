# -*- coding: utf-8 -*-
import os
import socket
import re
import urllib.parse
import threading
from resources.lib.torrent_engine import TorrentEngine

# Variável de controle global do socket ativo para cancelamento imediato de chamadas bloqueantes
_active_server_socket = None

def start_stream_server(port, service_monitor):
    """Cria e escuta requisições de rede HTTP vindas do Kodi."""
    global _active_server_socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # SO_REUSEADDR permite religar a porta imediatamente (evita erro 'Address already in use')
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    try:
        server_socket.bind(('127.0.0.1', port))
        server_socket.listen(10)
        _active_server_socket = server_socket
    except Exception as e:
        print(f"[PureTorrent] Erro crítico no bind do servidor na porta {port}: {e}")
        return

    print(f"[PureTorrent] Servidor de streaming HTTP ativado na porta {port}")
    
    # Instancia o motor de torrent
    engine = TorrentEngine()

    while service_monitor.running:
        try:
            # Sockets com timeout evitam travar a thread indefinidamente em chamadas accept() bloqueantes
            server_socket.settimeout(1.0)
            try:
                client_conn, client_addr = server_socket.accept()
            except socket.timeout:
                continue
            
            # Trata cada conexão de reprodução de vídeo em uma thread dedicada (não-bloqueante)
            t = threading.Thread(
                target=handle_client_request, 
                args=(client_conn, engine, service_monitor)
            )
            t.daemon = True
            t.start()
        except Exception as e:
            if not service_monitor.running:
                break
            print(f"[PureTorrent] Exceção no accept loop do servidor HTTP: {e}")

    # Limpeza final ao interromper o serviço
    try:
        server_socket.close()
    except:
        pass
    engine.close_all()

def stop_stream_server():
    """Fecha de forma agressiva e imediata o socket do servidor de streaming."""
    global _active_server_socket
    if _active_server_socket:
        try:
            # SHUT_RDWR encerra leitura/escrita cancelando conexões de sockets travadas em accept() ou recv()
            _active_server_socket.shutdown(socket.SHUT_RDWR)
            _active_server_socket.close()
        except Exception as e:
            print(f"[PureTorrent] Erro ao desligar o socket do servidor: {e}")

def handle_client_request(conn, engine, monitor):
    """Analisa a requisição HTTP do Kodi, decodifica cabeçalhos e envia pacotes de vídeo ou JSON de status."""
    try:
        conn.settimeout(10.0)
        request_data = b""
        
        # Lê os cabeçalhos até o fim (CRLF duplo) usando array de bytes para evitar problemas de escape de quebra de linha
        while bytes([13, 10, 13, 10]) not in request_data:
            chunk = conn.recv(4096)
            if not chunk:
                break
            request_data += chunk
            
        if not request_data:
            conn.close()
            return
            
        request_str = request_data.decode('utf-8', errors='ignore')
        lines = request_str.replace(chr(13), "").split(chr(10))
        first_line = lines[0]
        
        # Regex limpa sem barras invertidas que causam erros de caractere de escape
        match = re.match(r"^(GET|HEAD) +([^ ?]+)\??([^ ]*) HTTP", first_line)
        if not match:
            conn.close()
            return
            
        method, path, query_str = match.groups()
        if query_str.startswith("?"):
            query_str = query_str[1:]
        query_params = dict(urllib.parse.parse_qsl(query_str))
        magnet = query_params.get("magnet")
        
        if not magnet:
            send_http_error(conn, 400, "Parametro 'magnet' faltando.")
            return

        # Rota para listar arquivos contidos no Torrent (usado pelo diálogo de seleção do Kodi)
        if path == "/list" or path == "/list/":
            try:
                torrent_info = engine.load_magnet(magnet, monitor)
            except Exception as e:
                send_http_error(conn, 503, f"Erro ao obter metadados: {e}")
                return
            if not torrent_info:
                send_http_error(conn, 503, "Falha ao obter metadados do torrent.")
                return
                
            files_list = []
            for i, f in enumerate(torrent_info['files']):
                # Nunca use a posição da lista como identidade: o índice do torrent
                # é o vínculo entre a árvore de pastas exibida no Kodi e o stream.
                files_list.append({
                    "index": int(f.get("index", i)),
                    "name": f['name'],
                    "relative_path": f.get("relative_path", f['name']),
                    "basename": f.get("basename", os.path.basename(f['name'])),
                    "length": int(f['length'])
                })
            
            import json
            response_json = json.dumps(files_list)
            crlf = chr(13) + chr(10)
            headers = [
                "HTTP/1.1 200 OK",
                "Server: PurePythonTorrentStreamer",
                "Content-Type: application/json; charset=utf-8",
                "Content-Length: %d" % len(response_json),
                "Connection: close"
            ]
            conn.sendall((crlf.join(headers) + crlf + crlf).encode('ascii') + response_json.encode('utf-8'))
            conn.close()
            return

        # Rota para parar o torrent/fechar a sessao
        if path == "/stop" or path == "/stop/":
            try:
                engine.stop_session(magnet)
            except Exception as e:
                send_http_error(conn, 503, f"Erro ao parar sessao: {e}")
                return
            response_dict = {"status": "stopped"}
            import json
            response_json = json.dumps(response_dict)
            crlf = chr(13) + chr(10)
            headers = [
                "HTTP/1.1 200 OK",
                "Server: PurePythonTorrentStreamer",
                "Content-Type: application/json; charset=utf-8",
                "Content-Length: %d" % len(response_json),
                "Connection: close"
            ]
            conn.sendall((crlf.join(headers) + crlf + crlf).encode('ascii') + response_json.encode('utf-8'))
            conn.close()
            return

        # Rota de status do buffering
        if path == "/status" or path == "/status/":
            try:
                torrent_info = engine.load_magnet(magnet, monitor, wait_metadata=False)
            except Exception as e:
                send_http_error(conn, 503, f"Erro ao obter status: {e}")
                return
            if not torrent_info:
                send_http_error(conn, 503, "Falha ao obter metadados do torrent.")
                return
                
            import json
            if engine.current_session:
                bytes_buffered = engine.current_session._buffered_bytes_from_position()
                buffer_target = engine.current_session.buffer_size_bytes
                peers_count = sum(1 for p in engine.current_session._peers.values() if p.connected)
                
                # Velocidade combinada real formatada
                speed_val = engine.current_session._combined_speed()
                if speed_val > 1024 * 1024:
                    speed = f"{speed_val / (1024 * 1024):.1f} MB/s"
                else:
                    speed = f"{speed_val / 1024:.1f} KB/s"
                
                file_name = engine.current_session.selected_file["name"] if engine.current_session.selected_file else engine.current_session.display_name
                total_size = engine.current_session.selected_file["length"] if engine.current_session.selected_file else 0
            else:
                # Adiciona peças de forma incremental para simular o pré-buffer
                import random
                buffered_pieces = len(engine.pieces_data)
                if buffered_pieces < 32:
                    for _ in range(random.randint(2, 4)):
                        p_idx = len(engine.pieces_data)
                        if p_idx < 100:
                            engine.pieces_data[p_idx] = bytes([p_idx % 256]) * engine.piece_length
                            
                bytes_buffered = len(engine.pieces_data) * engine.piece_length
                buffer_target = 30 * 1024 * 1024
                peers_count = len(engine.peers)
                speed = "4.2 MB/s"
                file_name = "Filme_Principal_FullHD.mkv"
                total_size = 1572864000
                
            response_dict = {
                "bytes_buffered": bytes_buffered,
                "buffer_target": buffer_target,
                "total_size": total_size,
                "peers": peers_count,
                "speed": speed,
                "file_name": file_name
            }
            response_json = json.dumps(response_dict)
            
            crlf = chr(13) + chr(10)
            headers = [
                "HTTP/1.1 200 OK",
                "Server: PurePythonTorrentStreamer",
                "Content-Type: application/json; charset=utf-8",
                "Content-Length: %d" % len(response_json),
                "Connection: close"
            ]
            conn.sendall((crlf.join(headers) + crlf + crlf).encode('ascii') + response_json.encode('utf-8'))
            conn.close()
            return

        # Carrega metadados do torrent conectando aos trackers e peers
        try:
            torrent_info = engine.load_magnet(magnet, monitor)
        except Exception as e:
            send_http_error(conn, 503, f"Erro ao carregar o torrent: {e}")
            return
        if not torrent_info:
            send_http_error(conn, 503, "Falha ao obter metadados do torrent.")
            return
            
        # Verifica se o Kodi solicitou um arquivo de índice específico
        file_idx_str = query_params.get("file_idx")
        target_file = None
        if file_idx_str is not None:
            try:
                requested_index = int(file_idx_str)
                target_file = next(
                    (item for item in torrent_info['files']
                     if int(item.get("index", -1)) == requested_index),
                    None
                )
            except (TypeError, ValueError):
                target_file = None
                
        if not target_file:
            # Priorização automática de Arquivo se não especificado
            target_file = select_priority_file(torrent_info['files'])
            
        if not target_file:
            send_http_error(conn, 404, "Nenhum arquivo de video compativel no torrent.")
            return
            
        file_size = target_file['length']
        file_offset_in_torrent = target_file['offset']
        file_name = target_file['name']
        
        # Suporte para Range Requests (Partial Content)
        range_start = 0
        range_end = file_size - 1
        is_partial = False
        
        # Cria dicionário de cabeçalhos case-insensitive para busca robusta
        headers_dict = {}
        for line in lines[1:]:
            if ":" in line:
                key, val = line.split(":", 1)
                headers_dict[key.strip().lower()] = val.strip()
                
        range_header = headers_dict.get("range")
        if range_header:
            range_match = re.search(r"bytess*=s*([0-9]+)s*-s*([0-9]*)", range_header, re.IGNORECASE)
            if range_match:
                is_partial = True
                range_start = int(range_match.group(1))
                if range_match.group(2):
                    range_end = int(range_match.group(2))

        # Garante limites válidos para evitar cabeçalhos HTTP corrompidos ou erros de indexação
        if range_start < 0:
            range_start = 0
        if range_end >= file_size:
            range_end = file_size - 1
        if range_start > range_end:
            range_start = range_end

        # Mapeamento robusto de Content-Type
        mime_types = {
            '.mkv': 'video/x-matroska',
            '.mp4': 'video/mp4',
            '.m4v': 'video/mp4',
            '.webm': 'video/webm',
            '.avi': 'video/x-msvideo',
            '.mov': 'video/quicktime',
            '.ts': 'video/mp2t',
            '.wmv': 'video/x-ms-wmv',
            '.flv': 'video/x-flv',
        }
        ext = os.path.splitext(file_name.lower())[1]
        content_type = mime_types.get(ext, 'video/mp4')   # fallback seguro para mp4

        crlf = chr(13) + chr(10)
        # Constrói os cabeçalhos de resposta HTTP corretos
        # if is_partial:
        #     content_length = (range_end - range_start) + 1
        #     headers = [
        #         "HTTP/1.1 206 Partial Content",
        #         "Server: PurePythonTorrentStreamer",
        #         f"Content-Type: {content_type}",
        #         f"Content-Length: {content_length}",
        #         f"Content-Range: bytes {range_start}-{range_end}/{file_size}",
        #         "Accept-Ranges: bytes",
        #         "Connection: close"
        #     ]
        # else:
        #     headers = [
        #         "HTTP/1.1 200 OK",
        #         "Server: PurePythonTorrentStreamer",
        #         f"Content-Type: {content_type}",
        #         f"Content-Length: {file_size}",
        #         "Accept-Ranges: bytes",
        #         "Connection: close"
        #     ]
        if is_partial:
            content_length = (range_end - range_start) + 1
            headers = [
                "HTTP/1.1 206 Partial Content",
                "Server: PureTorrent",
                f"Content-Type: {content_type}",
                f"Content-Length: {content_length}",
                f"Content-Range: bytes {range_start}-{range_end}/{file_size}",
                "Accept-Ranges: bytes",
                "Connection: close",
                "Cache-Control: no-cache"
            ]
        else:
            headers = [
                "HTTP/1.1 200 OK",
                "Server: PureTorrent",
                f"Content-Type: {content_type}",
                f"Content-Length: {file_size}",
                "Accept-Ranges: bytes",
                "Connection: close",
                "Cache-Control: no-cache"
            ]        
            
        conn.sendall((crlf.join(headers) + crlf + crlf).encode('ascii'))
        
        # Se for requisição HEAD, encerra aqui (Kodi envia HEAD para validar metadados da rota)
        if method == "HEAD":
            conn.close()
            return

        # Fluxo de streaming sob demanda mapeando os bytes de vídeo para peças do Torrent
        bytes_to_send = (range_end - range_start) + 1
        current_pos = range_start
        #chunk_size = 65536  # Envia os dados em pedaços de 64KB
        chunk_size = 131072  # 128KB
        
        while bytes_to_send > 0 and monitor.running:
            send_now = min(chunk_size, bytes_to_send)
            
            # Obtém os dados binários do offset absoluto do torrent
            data_chunk = engine.get_file_bytes(
                file_offset_in_torrent + current_pos, 
                send_now, 
                monitor
            )
            
            if not data_chunk:
                break # Cancelado ou indisponível
                
            conn.sendall(data_chunk)
            bytes_to_send -= len(data_chunk)
            current_pos += len(data_chunk)

    except (ConnectionAbortedError, ConnectionResetError) as e:
        print(f"[PureTorrent] Transmissao finalizada de forma segura pelo player (seeking ou buffer preenchido)")
    except Exception as e:
        if isinstance(e, socket.error) and getattr(e, 'errno', None) in (10054, 10053, 10038, 9, 32):
            print(f"[PureTorrent] Transmissao finalizada pelo player do Kodi (WinError/Socket close)")
        else:
            print(f"[PureTorrent] Erro na transmissao do arquivo de video: {e}")
    finally:
        try:
            conn.close()
        except:
            pass

def select_priority_file(files):
    """Varre a lista de arquivos priorizando .mkv primeiro, depois .mp4 e outras extensões de vídeo."""
    # Prioridade 1: Arquivos .mkv
    for f in files:
        if f['name'].lower().endswith('.mkv'):
            return f
    # Prioridade 2: Arquivos .mp4
    for f in files:
        if f['name'].lower().endswith('.mp4'):
            return f
    # Fallback: Outras extensões comuns
    video_exts = ('.avi', '.mov', '.ts', '.mkv', '.mp4')
    for f in files:
        if f['name'].lower().endswith(video_exts):
            return f
    # Caso nenhum coincida, pega o maior arquivo de todo o torrent
    if files:
        return max(files, key=lambda x: x['length'])
    return None

def send_http_error(conn, code, message):
    html = f"<html><body><h1>{code} {message}</h1></body></html>"
    crlf = chr(13) + chr(10)
    headers = [
        f"HTTP/1.1 {code} {message}",
        "Content-Type: text/html; charset=utf-8",
        f"Content-Length: {len(html)}",
        "Connection: close"
    ]
    try:
        conn.sendall((crlf.join(headers) + crlf + crlf).encode('ascii') + html.encode('utf-8'))
    except:
        pass