# -*- coding: utf-8 -*-
import socket
import struct
import random
import urllib.parse
import urllib.request
import threading
import time
import os

def parse_compact_peers(data, family=socket.AF_INET):
    peers = []
    if family == socket.AF_INET:
        offset = 0
        while offset + 6 <= len(data):
            ip = ".".join(str(b) for b in data[offset:offset+4])
            port = struct.unpack(">H", data[offset+4:offset+6])[0]
            if ip != "0.0.0.0" and port > 0:
                peers.append((ip, port))
            offset += 6
    elif family == socket.AF_INET6:
        offset = 0
        while offset + 18 <= len(data):
            parts = []
            for i in range(8):
                parts.append(hex(struct.unpack(">H", data[offset + i*2 : offset + i*2 + 2])[0])[2:])
            ip = ":".join(parts)
            port = struct.unpack(">H", data[offset+16:offset+18])[0]
            if port > 0:
                peers.append((ip, port))
            offset += 18
    return peers

def discover_trackers(trackers, info_hash, peer_id, left=1000000, limit=80, port=6881, event=None, reporter=None, peer_callback=None, stop_event=None, max_workers=4, round_timeout=18.0, http_timeout=4.0, udp_timeout=3.0):
    if reporter:
        reporter("Iniciando descoberta em %d trackers..." % len(trackers))
    
    found_peers = []
    
    def query_udp(tracker_url):
        try:
            parsed = urllib.parse.urlsplit(tracker_url)
            host = parsed.hostname
            port_val = parsed.port or 80
            
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.settimeout(udp_timeout)
            
            # Connect
            transaction_id = random.randint(0, 65535)
            connection_id = 0x41727101980
            packet = struct.pack(">QII", connection_id, 0, transaction_id)
            sock.sendto(packet, (host, port_val))
            
            data, _ = sock.recvfrom(2048)
            if len(data) >= 16:
                action, resp_transaction_id, connection_id = struct.unpack(">IIQ", data[:16])
                if action == 0 and resp_transaction_id == transaction_id:
                    # Announce
                    announce_packet = struct.pack(
                        ">QII20s20sQQQIIIiH",
                        connection_id, 1, transaction_id, info_hash, peer_id,
                        0, left, 0, 0, 0, 0, -1, port
                    )
                    sock.sendto(announce_packet, (host, port_val))
                    announce_resp, _ = sock.recvfrom(2048)
                    
                    if len(announce_resp) >= 20:
                        action, _, _, _, _ = struct.unpack(">IIIII", announce_resp[:20])
                        if action == 1:
                            peers = parse_compact_peers(announce_resp[20:])
                            if peers and peer_callback:
                                peer_callback(peers, "tracker")
                            found_peers.extend(peers)
            sock.close()
        except Exception:
            pass

    def query_http(tracker_url):
        try:
            from resources.lib.bencode import bdecode
            params = {
                "port": port,
                "uploaded": 0,
                "downloaded": 0,
                "left": left,
                "compact": 1
            }
            if event:
                params["event"] = event
            query_str = "info_hash=" + urllib.parse.quote_from_bytes(info_hash) + "&peer_id=" + urllib.parse.quote_from_bytes(peer_id) + "&" + urllib.parse.urlencode(params)
            url = tracker_url + ("&" if "?" in tracker_url else "?") + query_str
            req = urllib.request.Request(url, headers={"User-Agent": "PureTorrent/1.0"})
            with urllib.request.urlopen(req, timeout=http_timeout) as response:
                resp_bencoded = response.read()
                resp_dict = bdecode(resp_bencoded)
                peers_raw = resp_dict.get("peers", b"")
                
                peers = []
                if isinstance(peers_raw, bytes):
                    peers = parse_compact_peers(peers_raw)
                elif isinstance(peers_raw, list):
                    for p in peers_raw:
                        peers.append((p.get("ip"), p.get("port")))
                if peers and peer_callback:
                    peer_callback(peers, "tracker")
                found_peers.extend(peers)
        except Exception:
            pass

    threads = []
    for tracker in trackers[:limit]:
        if stop_event and stop_event.is_set():
            break
        if tracker.startswith("udp://"):
            t = threading.Thread(target=query_udp, args=(tracker,))
        elif tracker.startswith(("http://", "https://")):
            t = threading.Thread(target=query_http, args=(tracker,))
        else:
            continue
        t.daemon = True
        t.start()
        threads.append(t)
        
        if len(threads) >= max_workers:
            for th in threads:
                th.join(timeout=0.2)
            threads = [th for th in threads if th.is_alive()]
            
    for th in threads:
        th.join(timeout=1.0)
        
    return found_peers

def discover_dht(info_hash, max_queries=18, timeout=0.45, reporter=None, peer_callback=None, stop_event=None):
    if reporter:
        reporter("Iniciando varredura DHT...")
        
    dht_bootstrap_nodes = [
        ("router.bittorrent.com", 6881),
        ("dht.transmissionbt.com", 6881),
        ("router.utorrent.com", 6881)
    ]
    
    found_peers = []
    peer_id = b"-PT1150-" + os.urandom(12)
    
    for node_host, node_port in dht_bootstrap_nodes:
        if stop_event and stop_event.is_set():
            break
        try:
            from resources.lib.bencode import bencode, bdecode
            dht_query = {
                "t": b"aa",
                "y": b"q",
                "q": b"get_peers",
                "a": {
                    "id": peer_id,
                    "info_hash": info_hash
                }
            }
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.settimeout(timeout)
            sock.sendto(bencode(dht_query), (node_host, node_port))
            
            data, _ = sock.recvfrom(2048)
            resp = bdecode(data)
            r = resp.get("r", {})
            if "values" in r:
                peers = []
                for val in r["values"]:
                    ip_str = ".".join(str(b) for b in val[:4])
                    port_val = struct.unpack(">H", val[4:6])[0]
                    peers.append((ip_str, port_val))
                if peers and peer_callback:
                    peer_callback(peers, "dht")
                found_peers.extend(peers)
            sock.close()
        except Exception:
            pass
            
    return found_peers

def discover_local_peers(info_hash, announce_port=6881, reporter=None, peer_callback=None, stop_event=None, listen_seconds=None, announce_interval=8.0):
    if reporter:
        reporter("Iniciando Local Peer Discovery...")
    return []