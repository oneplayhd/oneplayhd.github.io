# -*- coding: utf-8 -*-
import sys
import re
import urllib.parse
import urllib.request
import json
import time
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import time


# Recupera instâncias de controle do Addon no Kodi
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1

# Mantido alinhado às extensões aceitas pelo motor e pelo servidor HTTP.
VIDEO_EXTENSIONS = (
    '.mkv', '.mp4', '.m4v', '.webm', '.ts', '.m2ts', '.mts',
    '.avi', '.mov', '.mpg', '.mpeg', '.wmv', '.flv', '.vob'
)


def list_categories():
    """Cria os itens visíveis no menu do Addon."""
    add_directory_item("Inserir Magnet Link Manualmente", "manual_magnet")
    add_directory_item("Vídeo de Teste: Big Buck Bunny (Magnet)", "play_bbb")
    xbmcplugin.endOfDirectory(HANDLE)


def add_directory_item(name, action):
    """Auxiliar para adicionar itens navegáveis na lista do Kodi."""
    url = f"{sys.argv[0]}?action={action}"
    item = xbmcgui.ListItem(label=name)
    # Define como pasta para abrir nova ação ou input do teclado
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)


def _format_size(byte_count):
    """Formata tamanhos de forma legível sem depender de APIs externas."""
    try:
        value = float(byte_count)
    except (TypeError, ValueError):
        return "0 B"

    units = ("B", "KB", "MB", "GB", "TB")
    for unit in units:
        if value < 1024.0 or unit == units[-1]:
            if unit == "B":
                return "%d %s" % (int(value), unit)
            return "%.1f %s" % (value, unit)
        value /= 1024.0
    return "0 B"


def _natural_key(value):
    """Ordena 'Temporada 2' depois de 'Temporada 1', não antes."""
    return [int(part) if part.isdigit() else part.casefold()
            for part in re.split(r"(\d+)", str(value))]


def _is_video_file(file_info):
    name = str(file_info.get("name", "")).lower()
    try:
        length = int(file_info.get("length", 0) or 0)
    except (TypeError, ValueError):
        length = 0
    return name.endswith(VIDEO_EXTENSIONS) and length > 0


def _path_parts(file_info):
    """Retorna um caminho seguro de exibição, preservando a hierarquia do torrent."""
    raw_path = (
        file_info.get("relative_path")
        or file_info.get("path")
        or file_info.get("name")
        or ""
    )
    raw_path = str(raw_path).replace("\\", "/")
    return [part.strip() for part in raw_path.split("/") if part.strip() and part.strip() not in (".", "..")]


def _remove_common_root(video_files):
    """Remove apenas a pasta-raiz comum do torrent da navegação visual.

    O caminho completo continua intacto no motor; isto serve exclusivamente para
    não repetir o nome do release antes de cada temporada/episódio.
    """
    parsed = [_path_parts(item) for item in video_files]
    if not parsed or not all(parts for parts in parsed):
        return parsed

    # A versão atual do servidor já fornece relative_path sem a pasta-raiz
    # do release. Nesse caso não se remove mais nenhum nível, pois ele pode
    # ser justamente "Temporada 01" ou uma subpasta importante.
    if all(item.get("relative_path") for item in video_files):
        return parsed

    first_parts = {parts[0].casefold() for parts in parsed}
    if len(first_parts) == 1 and any(len(parts) > 1 for parts in parsed):
        return [parts[1:] or parts for parts in parsed]
    return parsed


def build_video_tree(video_files):
    """Cria uma árvore virtual de pastas para torrents com temporadas/subpastas."""
    root = {"folders": {}, "files": []}
    for file_info, parts in zip(video_files, _remove_common_root(video_files)):
        node = root
        folder_parts = parts[:-1]
        for folder_name in folder_parts:
            node = node["folders"].setdefault(folder_name, {"folders": {}, "files": []})
        node["files"].append(file_info)
    return root


def _display_file_name(file_info):
    parts = _path_parts(file_info)
    if parts:
        return parts[-1]
    return str(file_info.get("name", "Arquivo de vídeo"))


def _select_video_from_tree(video_files):
    """Navega por pasta > subpasta > arquivo, retornando o vídeo escolhido.

    A árvore existe só na UI: o índice original retornado pelo servidor é mantido
    até a URL /stream, portanto a ordem física do torrent não é alterada.
    """
    tree = build_video_tree(video_files)
    current = tree
    trail = []

    while True:
        entries = []
        for folder_name in sorted(current["folders"], key=_natural_key):
            entries.append(("folder", folder_name, current["folders"][folder_name]))
        for file_info in sorted(current["files"], key=lambda item: _natural_key(_display_file_name(item))):
            entries.append(("file", _display_file_name(file_info), file_info))

        if not entries:
            return None

        labels = []
        if trail:
            labels.append("[..] Voltar")
        for kind, name, payload in entries:
            if kind == "folder":
                labels.append("[Pasta] %s" % name)
            else:
                labels.append("%s  (%s)" % (name, _format_size(payload.get("length", 0))))

        dialog_title = "PureTorrent — Conteúdo"
        if trail:
            dialog_title += " / " + " / ".join(trail)
        selection = xbmcgui.Dialog().select(dialog_title, labels)

        if selection == -1:
            if trail:
                # Cancelar dentro de uma temporada/subpasta volta um nível; no topo cancela tudo.
                trail.pop()
                current = tree
                for folder_name in trail:
                    current = current["folders"][folder_name]
                continue
            return None

        if trail:
            if selection == 0:
                trail.pop()
                current = tree
                for folder_name in trail:
                    current = current["folders"][folder_name]
                continue
            selection -= 1

        kind, name, payload = entries[selection]
        if kind == "folder":
            trail.append(name)
            current = payload
            continue
        return payload


def _choose_video_file(files):
    """Seleciona vídeo único automaticamente ou abre árvore para séries/coleções."""
    video_files = [file_info for file_info in files if _is_video_file(file_info)]
    if not video_files:
        return None
    if len(video_files) == 1:
        return video_files[0]
    return _select_video_from_tree(video_files)


def _stop_torrent(port, encoded_magnet):
    """Encerra sessão de modo silencioso em cancelamentos da interface."""
    try:
        stop_url = f"http://127.0.0.1:{port}/stop?magnet={encoded_magnet}"
        req = urllib.request.Request(stop_url)
        with urllib.request.urlopen(req, timeout=1.5):
            pass
    except Exception:
        pass


def play_torrent(magnet_link):
    """Carrega metadata, navega pelas pastas, faz pré-buffer e inicia a reprodução."""
    port = ADDON.getSetting("server_port") or "8089"
    encoded_magnet = urllib.parse.quote_plus(magnet_link)

    # 1. Carrega a lista de arquivos via API do servidor local (/list)
    dp_meta = xbmcgui.DialogProgress()
    dp_meta.create("PureTorrent", "Carregando metadados do torrent...")
    list_url = f"http://127.0.0.1:{port}/list?magnet={encoded_magnet}"
    files = []

    try:
        # Loop para esperar o motor resolver os metadados
        inicio = time.time()
        while True:
            if dp_meta.iscanceled():
                _stop_torrent(port, encoded_magnet)
                return

            if time.time() - inicio >= 25:
                _stop_torrent(port, encoded_magnet)
                xbmcgui.Dialog().ok("Erro", "Não foi possível carregar os metadados do torrent.")
                return

            try:
                req = urllib.request.Request(list_url)
                with urllib.request.urlopen(req, timeout=1.5) as response:
                    files = json.loads(response.read().decode("utf-8"))
                    break
            except Exception:
                time.sleep(0.5)
    finally:
        dp_meta.close()

    if not files:
        xbmcgui.Dialog().ok("Erro", "Nenhum arquivo encontrado neste torrent.")
        return

    # 2. Navega pelo conteúdo. Para torrents de série a árvore mostra temporadas e subpastas.
    chosen_file = _choose_video_file(files)
    if not chosen_file:
        if any(_is_video_file(item) for item in files):
            _stop_torrent(port, encoded_magnet)
            return  # Usuário cancelou a escolha.
        xbmcgui.Dialog().ok("Erro", "Nenhum arquivo de vídeo compatível foi encontrado neste torrent.")
        _stop_torrent(port, encoded_magnet)
        return

    selected_file_index = chosen_file['index']
    selected_display_name = _display_file_name(chosen_file)

    # 3. Inicia o pré-buffering de segurança inicializado pelo usuário
    dp = xbmcgui.DialogProgress()
    dp.create("PureTorrent Buffer", "Iniciando motor e conectando a peers...")

    try:
        buffer_size_setting = int(ADDON.getSetting("buffer_size") or 30)
    except Exception:
        buffer_size_setting = 30
    if buffer_size_setting < 4:
        buffer_size_setting = 4
    buffer_target = buffer_size_setting * 1024 * 1024
    bytes_buffered = 0

    # URL de streaming final com o índice real do arquivo escolhido.
    stream_url = f"http://127.0.0.1:{port}/stream?magnet={encoded_magnet}&file_idx={selected_file_index}"
    status_url = f"http://127.0.0.1:{port}/status?magnet={encoded_magnet}"

    while bytes_buffered < buffer_target:
        if dp.iscanceled():
            dp.close()
            _stop_torrent(port, encoded_magnet)
            return

        try:
            req = urllib.request.Request(status_url)
            with urllib.request.urlopen(req, timeout=2) as response:
                data = json.loads(response.read().decode('utf-8'))
                bytes_buffered = data.get("bytes_buffered", 0)
                # Sincroniza dinamicamente o alvo com o valor real do motor
                buffer_target = data.get("buffer_target", buffer_target)
                peers = data.get("peers", 0)
                speed = data.get("speed", "0 KB/s")

                percent = int((bytes_buffered / buffer_target) * 100) if buffer_target > 0 else 0
                percent = min(100, max(0, percent))

                mb_buffered = bytes_buffered / (1024 * 1024)
                mb_target = buffer_target / (1024 * 1024)
                msg = f"Baixando: {selected_display_name} | Buffer: {mb_buffered:.1f}MB de {mb_target:.1f}MB ({percent}%) | Peers Ativos: {peers} | Velocidade: {speed}"
                try:
                    dp.update(percent, msg)
                except TypeError:
                    dp.update(
                        percent,
                        f"Baixando: {selected_display_name}",
                        f"Buffer: {mb_buffered:.1f}MB de {mb_target:.1f}MB ({percent}%)",
                        f"Peers Ativos: {peers} | Velocidade: {speed}"
                    )
        except Exception as exc:
            xbmc.log(f"[PureTorrent] Aguardando inicializacao do servidor de streaming: {exc}", xbmc.LOGINFO)
            time.sleep(0.5)

        time.sleep(0.5)

    dp.close()

    # Informa ao Kodi que o vídeo está pronto para ser reproduzido
    list_item = xbmcgui.ListItem(selected_display_name, path=stream_url)

    # Adiciona metadados de vídeo robustos para garantir que reproduza como vídeo (não apenas áudio)
    list_item.setInfo('video', {
        'title': selected_display_name,
        'mediatype': 'video',
        'playcount': 0
    })

    # Tenta preencher as tags de vídeo modernas do Kodi Nexus/Omega
    try:
        video_info = list_item.getVideoInfoTag()
        video_info.setTitle(selected_display_name)
        video_info.setMediaType('video')
    except Exception:
        pass

    # Inicializa o Player do Kodi e dispara a reprodução nativa
    player = xbmc.Player()
    player.play(item=stream_url, listitem=list_item)


def main():
    # Analisa os parâmetros de rota enviados pelo Kodi
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get("action")
    uri = params.get("uri")

    if not action:
        list_categories()
    elif action == "manual_magnet":
        # Abre o teclado virtual do Kodi para digitação ou colagem do magnet link
        keyboard = xbmc.Keyboard("", "Insira o Magnet Link ou InfoHash:")
        keyboard.doModal()
        if keyboard.isConfirmed():
            magnet = keyboard.getText().strip()

            # Limpa double URL encoding no input inicial se houver %
            if "%" in magnet:
                try:
                    for _ in range(3):
                        decoded = urllib.parse.unquote(magnet)
                        if decoded == magnet:
                            break
                        magnet = decoded
                except Exception:
                    pass

            # Se for apenas o info_hash direto de 40 ou 32 caracteres, converte para magnet automaticamente
            if len(magnet) in (32, 40):
                magnet = "magnet:?xt=urn:btih:" + magnet

            if magnet.lower().startswith("magnet:"):
                play_torrent(magnet)
            else:
                xbmcgui.Dialog().ok("Erro", "Magnet Link ou InfoHash inserido é inválido!")
    elif action == "play_bbb":
        # Magnet Link Open Source (Big Buck Bunny) para testes rápidos
        play_torrent("magnet:?xt=urn:btih:dd8255ecdc7ca55fb0bbf81323d87062db1f6d1c&dn=Big+Buck+Bunny")
    elif action == "play_torrent" and uri:
        try:
            uri = uri[0]
        except:
            pass        
        play_torrent(uri) #plugin://plugin.video.puretorrent/?action=play_torrent&uri=magnet



if __name__ == "__main__":
    main()
