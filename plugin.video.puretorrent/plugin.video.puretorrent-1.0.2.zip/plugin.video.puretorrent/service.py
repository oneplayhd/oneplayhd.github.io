# -*- coding: utf-8 -*-
"""Serviço de ciclo de vida e interceptação conservadora do PureTorrent.

Mantém o servidor local e intercepta magnets visíveis em PlayMedia, RunPlugin e
setResolvedUrl. A interceptação encaminha somente o magnet para o próprio addon;
a leitura rápida de arquivos continua no motor, via API Wasmer.
"""

import json
import os
import re
import shutil
import threading
import time
import urllib.parse
import urllib.request
import uuid

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib.http_server import start_stream_server, stop_stream_server
from resources.lib.server_state import (
    DEFAULT_STREAM_PORT,
    clear_server_state,
    normalize_stream_port,
    publish_server_state,
)


# As referências originais são preservadas para encaminhar a chamada real e
# restaurar o Kodi limpo quando o serviço encerrar.
ORIGINAL_EXECUTEBUILTIN = xbmc.executebuiltin
ORIGINAL_SETRESOLVEDURL = xbmcplugin.setResolvedUrl
ADDON_ID = "plugin.video.puretorrent"
_CAPTURE_TTL_SECONDS = 5.0
_PLAYLIST_STOP_SUPPRESSION_SECONDS = 20.0
_MAGNET_RE = re.compile(r"magnet:\?[^\s\"'<>()[\]]+", re.IGNORECASE)


class TorrentService(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.addon = xbmcaddon.Addon()
        self.preferred_port = normalize_stream_port(self.addon.getSetting("server_port"), DEFAULT_STREAM_PORT)
        self._runtime_settings_signature = self._get_runtime_settings_signature()
        self.active_port = None
        self.server_token = None
        self.server_thread = None
        self.player_thread = None
        # Preserva a via de captura por playlist existente na 1.0.2. Ela cobre
        # addons que inserem a URL sem chamar PlayMedia/RunPlugin diretamente.
        self.playlist_thread = None
        self._last_playlist_signature = ""
        # Impede que a playlist ainda visível depois do fim reabra sozinha o
        # mesmo magnet. A supressão vale apenas para a rota playlist; um clique
        # manual continua podendo abrir o conteúdo imediatamente.
        self._playlist_stop_suppression = {}
        self.running = False
        self._lock = threading.RLock()
        self._active_magnet = None
        self._last_playing_at = 0.0

        # Estado da interceptação. O dedupe é curto: evita capturas duplicadas
        # do mesmo clique, mas deixa o mesmo magnet ser aberto novamente após Stop.
        self._capture_lock = threading.RLock()
        self._recent_captures = {}
        self.captured_magnets = []
        self.capture_count = 0
        self._hooks_installed = False

        self._cleanup_stale_cache()
        self.install_hooks()

    def _get_runtime_settings_signature(self):
        keys = ("server_port", "max_peers", "buffer_size", "peer_port", "local_peer_port")
        values = []
        for key in keys:
            try:
                values.append(str(self.addon.getSetting(key) or ""))
            except Exception:
                values.append("")
        return tuple(values)

    def _cleanup_stale_cache(self):
        """Remove somente o cache temporário do próprio addon na inicialização."""
        try:
            cache_dir = xbmcvfs.translatePath(
                "special://profile/addon_data/plugin.video.puretorrent/torrent_cache/"
            )
            if cache_dir and os.path.isdir(cache_dir):
                shutil.rmtree(cache_dir, ignore_errors=True)
            if cache_dir:
                os.makedirs(cache_dir, exist_ok=True)
        except Exception as exc:
            xbmc.log("[PureTorrent] Não foi possível limpar cache temporário: %s" % exc, xbmc.LOGWARNING)

    # ------------------------------------------------------------------
    # Interceptação de magnets
    # ------------------------------------------------------------------
    @staticmethod
    def _decode_url_recursive(value, max_depth=4):
        text = str(value or "")
        for _ in range(max(1, int(max_depth))):
            decoded = urllib.parse.unquote(text)
            if decoded == text:
                break
            text = decoded
        return text

    @staticmethod
    def _listitem_path(listitem):
        if listitem is None:
            return ""
        try:
            path = listitem.getPath()
            if path:
                return str(path)
        except Exception:
            pass
        try:
            return str(listitem.getProperty("path") or "")
        except Exception:
            return ""

    @staticmethod
    def _is_own_route(value):
        text = str(value or "").lower()
        return (
            "plugin://plugin.video.puretorrent" in text
            or "127.0.0.1" in text and "/stream" in text
            or "localhost" in text and "/stream" in text
        )

    def _normalise_magnet(self, candidate):
        """Valida somente magnets BTIH v1, inclusive base32, sem alterar trackers."""
        if not candidate:
            return None
        magnet = str(candidate).strip().rstrip(".,;")
        if not magnet.lower().startswith("magnet:"):
            return None
        try:
            parsed = urllib.parse.urlsplit(magnet)
            params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
            for xt in params.get("xt", []):
                value = str(xt)
                if value.lower().startswith("urn:btih:"):
                    raw_hash = value.split(":", 2)[-1]
                    if (len(raw_hash) == 40 and re.match(r"^[A-Fa-f0-9]{40}$", raw_hash)) or (
                        len(raw_hash) == 32 and re.match(r"^[A-Za-z2-7]{32}$", raw_hash)
                    ):
                        return magnet
        except Exception:
            return None
        return None

    def extract_magnet_from_url(self, value):
        """Extrai magnet direto, URL codificada ou aninhada de forma conservadora."""
        if not value or self._is_own_route(value):
            return None
        try:
            decoded = self._decode_url_recursive(value)
            for source in (str(value), decoded):
                match = _MAGNET_RE.search(source)
                if match:
                    magnet = self._normalise_magnet(match.group(0))
                    if magnet:
                        return magnet

            # Alguns addons passam o magnet dentro de uri/url/magnet; depois da
            # decodificação completa, parse_qs preserva o conteúdo útil.
            for source in (decoded,):
                try:
                    query = urllib.parse.urlsplit(source).query
                    for name, values in urllib.parse.parse_qs(query, keep_blank_values=True).items():
                        if name.lower() not in ("uri", "url", "magnet", "link", "source"):
                            continue
                        for nested in values:
                            magnet = self.extract_magnet_from_url(nested)
                            if magnet:
                                return magnet
                except Exception:
                    continue

            # Último recurso: info-hash BTIH puro em URL externa.
            hash_match = re.search(r"(?<![A-Za-z0-9])([A-Fa-f0-9]{40}|[A-Za-z2-7]{32})(?![A-Za-z0-9])", decoded)
            if hash_match:
                return "magnet:?xt=urn:btih:%s" % hash_match.group(1)
        except Exception as exc:
            xbmc.log("[PureTorrent] Erro ao extrair magnet: %s" % exc, xbmc.LOGERROR)
        return None

    def should_capture_url(self, value):
        if not value or self._is_own_route(value):
            return False
        decoded = self._decode_url_recursive(value).lower()
        return (
            "magnet:" in decoded
            or "plugin.video.elementum" in decoded
            or "plugin.video.pluginstreaming" in decoded and "url=" in decoded
            or "mode=12" in decoded
        )

    @staticmethod
    def _magnet_identity(magnet):
        try:
            parsed = urllib.parse.urlsplit(magnet)
            for xt in urllib.parse.parse_qs(parsed.query).get("xt", []):
                if str(xt).lower().startswith("urn:btih:"):
                    return str(xt).split(":", 2)[-1].lower()
        except Exception:
            pass
        return str(magnet).lower()

    def _build_plugin_url(self, magnet):
        return "plugin://%s/?action=play_torrent&uri=%s&origin=capture" % (
            ADDON_ID,
            urllib.parse.quote(magnet, safe=""),
        )

    def _save_capture(self, magnet, source, raw_url):
        """Mantém rastreabilidade sem reter logs gigantes nem alterar cache de peças."""
        try:
            data_dir = xbmcvfs.translatePath(
                "special://profile/addon_data/plugin.video.puretorrent/magnets/"
            )
            if data_dir:
                os.makedirs(data_dir, exist_ok=True)
                identity = self._magnet_identity(magnet)[:12] or "unknown"
                filename = os.path.join(data_dir, "magnet_%s_%s.json" % (
                    time.strftime("%Y%m%d_%H%M%S"), identity
                ))
                payload = {
                    "captured_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                    "source": source,
                    "magnet": magnet,
                    "raw_url": str(raw_url or "")[:2048],
                }
                with open(filename, "w", encoding="utf-8") as handle:
                    json.dump(payload, handle, ensure_ascii=False, indent=2)
        except Exception as exc:
            xbmc.log("[PureTorrent] Não foi possível registrar magnet capturado: %s" % exc, xbmc.LOGDEBUG)

    def process_captured_magnet(self, magnet, source="Desconhecido", raw_url=""):
        """Registra um magnet e devolve a rota interna, sem abrir UI na thread do serviço."""
        magnet = self._normalise_magnet(magnet)
        if not magnet:
            return None
        identity = self._magnet_identity(magnet)
        now = time.monotonic()
        with self._capture_lock:
            stale = [key for key, deadline in self._recent_captures.items() if deadline <= now]
            for key in stale:
                self._recent_captures.pop(key, None)
            if identity in self._recent_captures:
                xbmc.log("[PureTorrent] Magnet já encaminhado neste clique; ignorando duplicata.", xbmc.LOGDEBUG)
                return None
            self._recent_captures[identity] = now + _CAPTURE_TTL_SECONDS
            self.capture_count += 1
            self.captured_magnets.append(magnet)
            if len(self.captured_magnets) > 50:
                self.captured_magnets = self.captured_magnets[-50:]

        xbmc.log("[PureTorrent] Magnet interceptado #%d via %s: %s..." % (
            self.capture_count, source, magnet[:160]
        ), xbmc.LOGINFO)
        self._save_capture(magnet, source, raw_url)
        return self._build_plugin_url(magnet)

    def install_hooks(self):
        """Restaura os hooks existentes, com proteção contra loop do próprio addon."""
        if self._hooks_installed:
            return

        def hooked_executebuiltin(command, *args, **kwargs):
            try:
                if self.should_capture_url(command):
                    magnet = self.extract_magnet_from_url(command)
                    if magnet:
                        route = self.process_captured_magnet(magnet, "executebuiltin", command)
                        if route:
                            # Substitui PlayMedia/RunPlugin externo pela rota do
                            # PureTorrent; não executa o magnet bruto em paralelo.
                            return ORIGINAL_EXECUTEBUILTIN("RunPlugin(%s)" % route)
                        # Duplicata do mesmo clique: suprime o magnet bruto.
                        return None
            except Exception as exc:
                xbmc.log("[PureTorrent] Erro no interceptador executebuiltin: %s" % exc, xbmc.LOGERROR)
            return ORIGINAL_EXECUTEBUILTIN(command, *args, **kwargs)

        def hooked_setresolvedurl(handle, succeeded, listitem):
            try:
                path = self._listitem_path(listitem)
                if succeeded and self.should_capture_url(path):
                    magnet = self.extract_magnet_from_url(path)
                    route = self.process_captured_magnet(magnet, "setResolvedUrl", path) if magnet else None
                    if magnet:
                        # Mesmo quando executebuiltin já registrou o clique, o
                        # resolved URL externo nunca deve voltar a ser magnet bruto.
                        route = route or self._build_plugin_url(magnet)
                        replacement = xbmcgui.ListItem(path=route)
                        try:
                            replacement.setLabel(listitem.getLabel())
                        except Exception:
                            pass
                        # Encaminha a resolução para o addon, preservando o
                        # fluxo normal do Kodi em vez de abrir Player na thread
                        # do serviço.
                        return ORIGINAL_SETRESOLVEDURL(handle, True, replacement)
            except Exception as exc:
                xbmc.log("[PureTorrent] Erro no interceptador setResolvedUrl: %s" % exc, xbmc.LOGERROR)
            return ORIGINAL_SETRESOLVEDURL(handle, succeeded, listitem)

        try:
            xbmc.executebuiltin = hooked_executebuiltin
            xbmcplugin.setResolvedUrl = hooked_setresolvedurl
            self._hooks_installed = True
            xbmc.log("[PureTorrent] Interceptação de magnets ativa (executebuiltin e setResolvedUrl).", xbmc.LOGINFO)
        except Exception as exc:
            self._hooks_installed = False
            xbmc.log("[PureTorrent] Não foi possível ativar interceptação de magnets: %s" % exc, xbmc.LOGERROR)

    def restore_hooks(self):
        if not self._hooks_installed:
            return
        try:
            xbmc.executebuiltin = ORIGINAL_EXECUTEBUILTIN
            xbmcplugin.setResolvedUrl = ORIGINAL_SETRESOLVEDURL
        except Exception as exc:
            xbmc.log("[PureTorrent] Falha ao restaurar hooks: %s" % exc, xbmc.LOGDEBUG)
        finally:
            self._hooks_installed = False

    # ------------------------------------------------------------------
    # Ciclo de serviço e player
    # ------------------------------------------------------------------
    @staticmethod
    def _magnet_from_stream_url(value):
        try:
            parsed = urllib.parse.urlsplit(value or "")
            if parsed.scheme.lower() != "http" or parsed.hostname not in ("127.0.0.1", "localhost"):
                return None
            if not parsed.path.rstrip("/").endswith("/stream"):
                return None
            values = urllib.parse.parse_qs(parsed.query)
            magnet = values.get("magnet", [None])[0]
            return magnet if magnet and magnet.lower().startswith("magnet:") else None
        except Exception:
            return None

    def _suppress_playlist_magnet(self, magnet, seconds=_PLAYLIST_STOP_SUPPRESSION_SECONDS):
        identity = self._magnet_identity(magnet)
        if not identity:
            return
        with self._lock:
            self._playlist_stop_suppression[identity] = time.monotonic() + float(seconds)

    def _playlist_magnet_is_suppressed(self, magnet):
        identity = self._magnet_identity(magnet)
        now = time.monotonic()
        with self._lock:
            stale = [key for key, deadline in self._playlist_stop_suppression.items() if deadline <= now]
            for key in stale:
                self._playlist_stop_suppression.pop(key, None)
            return bool(identity and identity in self._playlist_stop_suppression)

    def _stop_active_session(self, magnet):
        if not magnet or not self.active_port:
            return
        self._suppress_playlist_magnet(magnet)
        try:
            url = "http://127.0.0.1:%d/stop?%s" % (
                int(self.active_port), urllib.parse.urlencode({"magnet": magnet})
            )
            with urllib.request.urlopen(url, timeout=2.0):
                pass
            xbmc.log("[PureTorrent] Sessão encerrada após Stop/fim de reprodução.", xbmc.LOGINFO)
        except Exception as exc:
            xbmc.log("[PureTorrent] Encerramento de sessão local falhou: %s" % exc, xbmc.LOGDEBUG)

    def _monitor_player(self):
        player = xbmc.Player()
        inactive_grace_seconds = 2.5
        while self.running and not self.abortRequested():
            try:
                playing = player.isPlaying()
                path = player.getPlayingFile() if playing else ""
                magnet = self._magnet_from_stream_url(path)
                now = time.monotonic()
                if magnet:
                    with self._lock:
                        previous = self._active_magnet
                        self._active_magnet = magnet
                        self._last_playing_at = now
                    if previous and previous != magnet:
                        self._stop_active_session(previous)
                else:
                    to_stop = None
                    with self._lock:
                        if self._active_magnet and now - self._last_playing_at >= inactive_grace_seconds:
                            to_stop = self._active_magnet
                            self._active_magnet = None
                            self._last_playing_at = 0.0
                    if to_stop:
                        self._stop_active_session(to_stop)
            except Exception as exc:
                xbmc.log("[PureTorrent] Monitor de player: %s" % exc, xbmc.LOGDEBUG)
            if self.waitForAbort(0.5):
                break

    def _monitor_playlist(self):
        """Captura magnets que chegam ao Kodi apenas pela playlist.

        A 1.0.2 já observava essa rota. A versão atual mantém o redirecionamento
        seguro para o plugin, sem chamar ``default.py`` diretamente da thread de
        serviço e sem executar o magnet bruto em paralelo.
        """
        while self.running and not self.abortRequested():
            try:
                playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                paths = []
                for index in range(playlist.size()):
                    try:
                        item = playlist[index]
                        path = item.getPath() if item else ""
                        if path:
                            paths.append(str(path))
                    except Exception:
                        continue
                signature = "|".join(paths)
                if signature and signature != self._last_playlist_signature:
                    self._last_playlist_signature = signature
                    for path in paths:
                        if not self.should_capture_url(path):
                            continue
                        magnet = self.extract_magnet_from_url(path)
                        if magnet and self._playlist_magnet_is_suppressed(magnet):
                            xbmc.log("[PureTorrent] Playlist antiga ignorada após fim de reprodução.", xbmc.LOGDEBUG)
                            continue
                        route = self.process_captured_magnet(magnet, "playlist", path) if magnet else None
                        if route:
                            # A própria rota é reconhecida como interna pelo hook.
                            ORIGINAL_EXECUTEBUILTIN("RunPlugin(%s)" % route)
            except Exception as exc:
                xbmc.log("[PureTorrent] Monitor de playlist: %s" % exc, xbmc.LOGDEBUG)
            if self.waitForAbort(1.0):
                break

    def start(self):
        if self.running:
            return
        self.install_hooks()
        self.running = True
        clear_server_state()
        self.active_port = None
        self.server_token = uuid.uuid4().hex
        self.server_thread = threading.Thread(
            target=start_stream_server,
            args=(self.preferred_port, self, self.server_token),
            name="PureTorrentServer",
            daemon=True,
        )
        self.server_thread.start()
        self.player_thread = threading.Thread(target=self._monitor_player, name="PureTorrentPlayer", daemon=True)
        self.player_thread.start()
        self.playlist_thread = threading.Thread(target=self._monitor_playlist, name="PureTorrentPlaylist", daemon=True)
        self.playlist_thread.start()
        xbmc.log("[PureTorrent] Serviço iniciado; interceptação, playlist e catálogo rápido prontos.", xbmc.LOGINFO)

    def on_stream_server_bound(self, active_port, token):
        if not self.running or token != self.server_token:
            return
        self.active_port = int(active_port)
        if publish_server_state(self.active_port, token):
            xbmc.log("[PureTorrent] Servidor HTTP pronto em 127.0.0.1:%d" % self.active_port, xbmc.LOGINFO)
        else:
            xbmc.log("[PureTorrent] Não foi possível publicar a porta do servidor.", xbmc.LOGERROR)

    def on_stream_server_stopped(self, active_port, token):
        if token == self.server_token:
            clear_server_state(token)
            if self.active_port == active_port:
                self.active_port = None

    def stop_server(self):
        """Fecha listener e sessões mesmo quando o Kodi já iniciou o abort."""
        with self._lock:
            was_running = self.running
            self.running = False
            active_magnet = self._active_magnet
            self._active_magnet = None
        if active_magnet:
            self._stop_active_session(active_magnet)
        clear_server_state(self.server_token)
        stop_stream_server()
        for thread in (self.server_thread, self.player_thread, self.playlist_thread):
            if thread and thread.is_alive() and thread is not threading.current_thread():
                thread.join(timeout=2.0)
        self.active_port = None
        self.restore_hooks()
        if was_running:
            xbmc.log("[PureTorrent] Serviço encerrado.", xbmc.LOGINFO)

    def onSettingsChanged(self):
        try:
            new_signature = self._get_runtime_settings_signature()
            if new_signature != self._runtime_settings_signature:
                new_port = normalize_stream_port(self.addon.getSetting("server_port"), DEFAULT_STREAM_PORT)
                xbmc.log("[PureTorrent] Configurações do motor alteradas; reiniciando serviço local.", xbmc.LOGINFO)
                self.stop_server()
                self.preferred_port = new_port
                self._runtime_settings_signature = new_signature
                self.start()
        except Exception as exc:
            xbmc.log("[PureTorrent] Falha ao aplicar configurações: %s" % exc, xbmc.LOGERROR)

    def onAbortRequested(self):
        xbmc.log("[PureTorrent] Kodi solicitou encerramento.", xbmc.LOGINFO)
        self.stop_server()


def main():
    service = TorrentService()
    service.start()
    while not service.abortRequested():
        if service.waitForAbort(1.0):
            break
    service.stop_server()


if __name__ == "__main__":
    main()
