# -*- coding: utf-8 -*-
import sys
import re
import urllib.parse
import urllib.request
import json
import time
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from resources.lib.server_state import read_server_state
from resources.lib.media_types import is_video_name


# Recupera instâncias de controle do Addon no Kodi
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1


# Padrão de pré-buffer do addon. Não altera o cache global do Kodi.
RECOMMENDED_INITIAL_BUFFER_MB = 30


def _server_healthcheck(port, token):
    """Confirma que a porta local pertence ao serviço desta execução."""
    try:
        token_q = urllib.parse.quote_plus(str(token))
        url = "http://127.0.0.1:%d/health?token=%s" % (int(port), token_q)
        with urllib.request.urlopen(url, timeout=0.8) as response:
            header_token = response.headers.get("X-PureTorrent-Instance", "")
            payload = json.loads(response.read().decode("utf-8"))
        return (
            header_token == str(token)
            and payload.get("service") == "puretorrent"
            and payload.get("instance") == str(token)
        )
    except Exception:
        return False


def _get_verified_server_port(wait_seconds=8.0):
    """Obtém a porta ativa sem confiar em uma porta fixa ocupada por outro addon."""
    deadline = time.time() + max(0.0, float(wait_seconds))
    while True:
        state = read_server_state()
        if state and _server_healthcheck(state["port"], state["token"]):
            return int(state["port"])
        if time.time() >= deadline:
            return None
        time.sleep(0.2)


def _get_initial_buffer_mb():
    """Restaura somente valor temporário abaixo do padrão validado de 30 MB."""
    try:
        value = int(ADDON.getSetting("buffer_size") or RECOMMENDED_INITIAL_BUFFER_MB)
    except Exception:
        value = RECOMMENDED_INITIAL_BUFFER_MB
    if value < RECOMMENDED_INITIAL_BUFFER_MB:
        value = RECOMMENDED_INITIAL_BUFFER_MB
        try:
            ADDON.setSetting("buffer_size", str(value))
        except Exception:
            pass
    return value


def list_categories():
    """Cria os itens visíveis no menu do Addon."""
    # Ação direta: não é diretório nem Container.Update. Ao clicar, abre o teclado
    # e a própria rota resolve o stream selecionado.
    add_directory_item("Inserir Magnet Link Manualmente", "manual_magnet", is_folder=False)
    # Item de vídeo não é pasta: a rota resolve uma URL de stream para o Kodi.
    add_directory_item("Vídeo de Teste: Big Buck Bunny (Magnet)", "play_bbb", is_folder=False)
    xbmcplugin.endOfDirectory(HANDLE)


def add_directory_item(name, action, is_folder=True):
    """Auxiliar para adicionar itens navegáveis na lista do Kodi."""
    url = f"{sys.argv[0]}?action={action}"
    item = xbmcgui.ListItem(label=name)
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=bool(is_folder))


def _format_size(byte_count):
    """Formata tamanhos de forma legível sem depender de APIs externas."""
    try:
        value = float(byte_count)
    except (TypeError, ValueError):
        return "0 B"

    units = ("B", "KB", "MB", "GB", "TB")
    for unit in units:
        if value < 1024.0 or unit == units[-1]:
            if unit == "B":
                return "%d %s" % (int(value), unit)
            return "%.1f %s" % (value, unit)
        value /= 1024.0
    return "0 B"


def _natural_key(value):
    """Ordena 'Temporada 2' depois de 'Temporada 1', não antes."""
    return [int(part) if part.isdigit() else part.casefold()
            for part in re.split(r"(\d+)", str(value))]


def _is_video_file(file_info):
    """Usa o mesmo registro de mídia do motor e do HTTP local."""
    try:
        length = int(file_info.get("length", 0) or 0)
    except (TypeError, ValueError):
        length = 0
    return is_video_name(file_info.get("name", "")) and length > 0


def _path_parts(file_info):
    """Retorna um caminho seguro de exibição, preservando a hierarquia do torrent."""
    raw_path = (
        file_info.get("relative_path")
        or file_info.get("path")
        or file_info.get("name")
        or ""
    )
    raw_path = str(raw_path).replace("\\", "/")
    return [part.strip() for part in raw_path.split("/") if part.strip() and part.strip() not in (".", "..")]


def _remove_common_root(video_files):
    """Remove apenas a pasta-raiz comum do torrent da navegação visual.

    O caminho completo continua intacto no motor; isto serve exclusivamente para
    não repetir o nome do release antes de cada temporada/episódio.
    """
    parsed = [_path_parts(item) for item in video_files]
    if not parsed or not all(parts for parts in parsed):
        return parsed

    # A versão atual do servidor já fornece relative_path sem a pasta-raiz
    # do release. Nesse caso não se remove mais nenhum nível, pois ele pode
    # ser justamente "Temporada 01" ou uma subpasta importante.
    if all(item.get("relative_path") for item in video_files):
        return parsed

    first_parts = {parts[0].casefold() for parts in parsed}
    if len(first_parts) == 1 and any(len(parts) > 1 for parts in parsed):
        return [parts[1:] or parts for parts in parsed]
    return parsed


def build_video_tree(video_files):
    """Cria uma árvore virtual de pastas para torrents com temporadas/subpastas."""
    root = {"folders": {}, "files": []}
    for file_info, parts in zip(video_files, _remove_common_root(video_files)):
        node = root
        folder_parts = parts[:-1]
        for folder_name in folder_parts:
            node = node["folders"].setdefault(folder_name, {"folders": {}, "files": []})
        node["files"].append(file_info)
    return root


def _display_file_name(file_info):
    parts = _path_parts(file_info)
    if parts:
        return parts[-1]
    return str(file_info.get("name", "Arquivo de vídeo"))


def _select_video_from_tree(video_files):
    """Navega por pasta > subpasta > arquivo, retornando o vídeo escolhido.

    A árvore existe só na UI: o índice original retornado pelo servidor é mantido
    até a URL /stream, portanto a ordem física do torrent não é alterada.
    """
    tree = build_video_tree(video_files)
    current = tree
    trail = []

    while True:
        entries = []
        for folder_name in sorted(current["folders"], key=_natural_key):
            entries.append(("folder", folder_name, current["folders"][folder_name]))
        for file_info in sorted(current["files"], key=lambda item: _natural_key(_display_file_name(item))):
            entries.append(("file", _display_file_name(file_info), file_info))

        if not entries:
            return None

        labels = []
        if trail:
            labels.append("[..] Voltar")
        for kind, name, payload in entries:
            if kind == "folder":
                labels.append("[Pasta] %s" % name)
            else:
                labels.append("%s  (%s)" % (name, _format_size(payload.get("length", 0))))

        dialog_title = "PureTorrent — Conteúdo"
        if trail:
            dialog_title += " / " + " / ".join(trail)
        selection = xbmcgui.Dialog().select(dialog_title, labels)

        if selection == -1:
            if trail:
                # Cancelar dentro de uma temporada/subpasta volta um nível; no topo cancela tudo.
                trail.pop()
                current = tree
                for folder_name in trail:
                    current = current["folders"][folder_name]
                continue
            return None

        if trail:
            if selection == 0:
                trail.pop()
                current = tree
                for folder_name in trail:
                    current = current["folders"][folder_name]
                continue
            selection -= 1

        kind, name, payload = entries[selection]
        if kind == "folder":
            trail.append(name)
            current = payload
            continue
        return payload


def _choose_video_file(files):
    """Seleciona vídeo único automaticamente ou abre árvore para séries/coleções."""
    video_files = [file_info for file_info in files if _is_video_file(file_info)]
    if not video_files:
        return None
    if len(video_files) == 1:
        return video_files[0]
    return _select_video_from_tree(video_files)


def _stop_torrent(port, encoded_magnet):
    """Encerra a sessão em cancelamento, erro ou retorno do player."""
    try:
        stop_url = "http://127.0.0.1:%d/stop?magnet=%s" % (int(port), encoded_magnet)
        with urllib.request.urlopen(urllib.request.Request(stop_url), timeout=2.0):
            pass
    except Exception:
        pass


def _format_speed(speed_bps):
    try:
        speed_bps = float(speed_bps or 0)
    except (TypeError, ValueError):
        speed_bps = 0.0
    if speed_bps >= 1024 * 1024:
        return "%.1f MB/s" % (speed_bps / (1024 * 1024))
    return "%.1f KB/s" % (speed_bps / 1024.0)


def _read_json(url, timeout):
    request = urllib.request.Request(url, headers={"User-Agent": "PureTorrent/1.0 Kodi"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def _progress_update(dialog, percent, title, *lines):
    """Atualiza DialogProgress sem ultrapassar o contrato do Kodi.

    Kodi aceita título + duas linhas auxiliares. Diagnósticos adicionais são
    condensados nessas duas linhas, evitando que uma melhoria visual interrompa
    o polling do /status e deixe a tela presa em "Aguardando motor local".
    """
    compact = [str(part) for part in lines if part]
    line1 = compact[0] if compact else ""
    line2 = " | ".join(compact[1:]) if len(compact) > 1 else ""
    try:
        dialog.update(int(percent), str(title), line1, line2)
    except TypeError:
        dialog.update(int(percent), " | ".join(part for part in (str(title), line1, line2) if part))


def play_torrent(magnet_link):
    """Fluxo conservador: catálogo Wasmer -> seleção -> metadata BEP 10 -> buffer real."""
    port = _get_verified_server_port()
    if port is None:
        xbmcgui.Dialog().ok("PureTorrent", "O servidor local não está disponível. Feche e abra o Kodi uma vez e tente novamente.")
        return
    encoded_magnet = urllib.parse.quote_plus(magnet_link)
    list_url = "http://127.0.0.1:%d/list?magnet=%s" % (port, encoded_magnet)

    dp_meta = xbmcgui.DialogProgress()
    dp_meta.create("PureTorrent", "Consultando catálogo do conteúdo...")
    files = []
    catalog_error = ""
    list_deadline = time.monotonic() + 60.0
    try:
        while time.monotonic() < list_deadline:
            if dp_meta.iscanceled():
                _stop_torrent(port, encoded_magnet)
                return
            try:
                payload = _read_json(list_url, timeout=15.0)
                if isinstance(payload, list):
                    files = payload
                    source = "compatível"
                else:
                    files = payload.get("files", []) if isinstance(payload, dict) else []
                    source = payload.get("source", "pendente") if isinstance(payload, dict) else "pendente"
                    catalog_error = payload.get("catalog_error", "") if isinstance(payload, dict) else ""
                if files:
                    _progress_update(dp_meta, 100, "Conteúdo identificado", "Fonte: %s" % source)
                    break
                message = "Aguardando catálogo Wasmer..."
                if catalog_error:
                    message = "API indisponível; aguardando metadata BitTorrent..."
                _progress_update(dp_meta, 0, message)
            except Exception as exc:
                xbmc.log("[PureTorrent] /list aguardando: %s" % exc, xbmc.LOGINFO)
                _progress_update(dp_meta, 0, "Conectando ao serviço local...")
            time.sleep(0.6)
    finally:
        dp_meta.close()

    if not files:
        _stop_torrent(port, encoded_magnet)
        reason = "Não foi possível identificar os arquivos do torrent."
        if catalog_error:
            reason += " A API não respondeu e os peers não forneceram metadata a tempo."
        xbmcgui.Dialog().ok("PureTorrent", reason)
        return False

    chosen_file = _choose_video_file(files)
    if not chosen_file:
        _stop_torrent(port, encoded_magnet)
        if any(_is_video_file(item) for item in files):
            return
        xbmcgui.Dialog().ok("PureTorrent", "Nenhum arquivo de vídeo compatível foi encontrado neste torrent.")
        return False

    selected_file_index = int(chosen_file["index"])
    selected_display_name = _display_file_name(chosen_file)
    stream_url = "http://127.0.0.1:%d/stream?magnet=%s&file_idx=%d" % (port, encoded_magnet, selected_file_index)
    status_url = "http://127.0.0.1:%d/status?magnet=%s&file_idx=%d" % (port, encoded_magnet, selected_file_index)

    dp = xbmcgui.DialogProgress()
    dp.create("PureTorrent Buffer", "Preparando torrent e conectando a peers...")
    buffer_target = _get_initial_buffer_mb() * 1024 * 1024
    bytes_buffered = 0
    startup_ready = False
    startup_tail_required = False
    startup_tail_bytes = 0
    startup_tail_target = 0
    buffer_deadline = time.monotonic() + 240.0
    last_error = ""
    try:
        while not startup_ready and time.monotonic() < buffer_deadline:
            if dp.iscanceled():
                _stop_torrent(port, encoded_magnet)
                return
            try:
                data = _read_json(status_url, timeout=8.0)
                last_error = data.get("error", "") or ""
                if last_error:
                    _stop_torrent(port, encoded_magnet)
                    xbmcgui.Dialog().ok("PureTorrent", "Não foi possível preparar o stream.\n%s" % last_error)
                    return
                bytes_buffered = int(data.get("bytes_buffered", 0) or 0)
                buffer_target = int(data.get("buffer_target", buffer_target) or buffer_target)
                startup_ready = bool(data.get("startup_ready", bytes_buffered >= buffer_target))
                startup_tail_required = bool(data.get("startup_tail_required", False))
                startup_tail_bytes = int(data.get("startup_tail_bytes", 0) or 0)
                startup_tail_target = int(data.get("startup_tail_target", 0) or 0)
                peers = int(data.get("peers", 0) or 0)
                metadata_ready = bool(data.get("metadata_ready"))
                state = data.get("state", "preparando torrent")
                discovery = data.get("discovery", "")
                metadata_resolution = data.get("metadata_resolution", "preparando metadata")
                percent = int((bytes_buffered * 100) / buffer_target) if buffer_target > 0 else 0
                percent = max(0, min(100, percent))
                if not metadata_ready:
                    _progress_update(
                        dp, 0, "Preparando estrutura BitTorrent...",
                        "Arquivo: %s" % selected_display_name,
                        "Metadata: %s | Peers: %d" % (metadata_resolution[:80], peers),
                    )
                else:
                    index_line = ""
                    if startup_tail_required:
                        index_line = " | Índice MP4: %.1f/%.1f MB" % (
                            startup_tail_bytes / (1024 * 1024),
                            startup_tail_target / (1024 * 1024),
                        )
                    _progress_update(
                        dp, percent, "Bufferizando: %s" % selected_display_name,
                        "%.1f MB de %.1f MB (%d%%)%s" % (
                            bytes_buffered / (1024 * 1024),
                            buffer_target / (1024 * 1024),
                            percent,
                            index_line,
                        ),
                        "Peers: %d | %s | %s" % (peers, _format_speed(data.get("speed_bps", 0)), state),
                    )
            except Exception as exc:
                xbmc.log("[PureTorrent] /status aguardando: %s" % exc, xbmc.LOGINFO)
                _progress_update(dp, 0, "Aguardando motor local...")
            time.sleep(0.6)
    finally:
        dp.close()

    if not startup_ready:
        _stop_torrent(port, encoded_magnet)
        message = last_error or "Não houve buffer real suficiente dentro do tempo de segurança. Verifique se o torrent possui seeders ativos."
        if startup_tail_required:
            message += " O índice final do MP4 também não ficou disponível a tempo."
        xbmcgui.Dialog().ok("PureTorrent", message)
        return

    list_item = xbmcgui.ListItem(selected_display_name, path=stream_url)
    list_item.setInfo("video", {"title": selected_display_name, "mediatype": "video", "playcount": 0})
    try:
        video_info = list_item.getVideoInfoTag()
        video_info.setTitle(selected_display_name)
        video_info.setMediaType("video")
    except Exception:
        pass
    # A ação do plugin precisa ser resolvida para o Kodi. Chamar Player.play()
    # diretamente deixa a rota play_bbb sem resultado formal e gera
    # GetDirectory failed no log ao retornar da ação.
    try:
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        else:
            xbmc.Player().play(item=stream_url, listitem=list_item)
        return True
    except Exception as exc:
        xbmc.log("[PureTorrent] Falha ao resolver stream para o Kodi: %s" % exc, xbmc.LOGERROR)
        _stop_torrent(port, encoded_magnet)
        return False


def main():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get("action")
    uri = params.get("uri")
    if not action:
        list_categories()
    elif action == "manual_magnet":
        # Esta rota é acionada como item de vídeo, nunca como pasta. Em cancelamento
        # ou validação inválida, finalize explicitamente a ação para o Kodi não
        # tentar navegar em um diretório que não existe.
        keyboard = xbmc.Keyboard("", "Insira o Magnet Link ou InfoHash:")
        keyboard.doModal()
        if not keyboard.isConfirmed():
            if HANDLE >= 0:
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return

        magnet = keyboard.getText().strip()
        if "%" in magnet:
            for _ in range(3):
                decoded = urllib.parse.unquote(magnet)
                if decoded == magnet:
                    break
                magnet = decoded
        if len(magnet) in (32, 40):
            magnet = "magnet:?xt=urn:btih:" + magnet
        if magnet.lower().startswith("magnet:"):
            play_torrent(magnet)
            return

        xbmcgui.Dialog().ok("PureTorrent", "Magnet Link ou InfoHash inserido é inválido!")
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    elif action == "play_bbb":
        play_torrent("magnet:?xt=urn:btih:dd8255ecdc7ca55fb0bbf81323d87062db1f6d1c&dn=Big+Buck+Bunny")
    elif action == "play_torrent" and uri:
        play_torrent(uri)


if __name__ == "__main__":
    main()
