# -*- coding: utf-8 -*-
"""Registro único de containers de vídeo do PureTorrent.

O BitTorrent entrega bytes sem informar um MIME útil ao Kodi. A extensão serve
somente para selecionar arquivos de vídeo e publicar um Content-Type coerente;
a decodificação continua sendo responsabilidade do FFmpeg/VideoPlayer.
"""

import os

# Containers comuns aceitos pelo VideoPlayer/FFmpeg do Kodi. A ordem é estável
# para auditoria, mas a seleção automática prioriza tamanho, não um formato.
VIDEO_EXTENSIONS = (
    ".mkv", ".mk3d",
    ".mp4", ".m4v", ".mov", ".qt", ".3gp", ".3g2",
    ".webm",
    ".avi", ".divx", ".xvid",
    ".ts", ".m2ts", ".mts", ".m2t", ".trp",
    ".mpeg", ".mpg", ".mpe", ".mpv",
    ".wmv", ".asf",
    ".flv", ".f4v",
    ".vob",
    ".ogv", ".ogm",
    ".rm", ".rmvb",
)
VIDEO_EXTENSION_SET = frozenset(VIDEO_EXTENSIONS)

# Somente containers ISO Base Media podem precisar de índice/átomo no fim.
# MKV, AVI, TS e os demais seguem com pré-buffer sequencial normal.
MP4_LIKE_EXTENSIONS = frozenset((".mp4", ".m4v", ".mov", ".qt", ".3gp", ".3g2"))

VIDEO_MIME_TYPES = {
    ".mkv": "video/x-matroska",
    ".mk3d": "video/x-matroska",
    ".mp4": "video/mp4",
    ".m4v": "video/mp4",
    ".mov": "video/quicktime",
    ".qt": "video/quicktime",
    ".3gp": "video/3gpp",
    ".3g2": "video/3gpp2",
    ".webm": "video/webm",
    ".avi": "video/x-msvideo",
    ".divx": "video/x-msvideo",
    ".xvid": "video/x-msvideo",
    ".ts": "video/mp2t",
    ".m2ts": "video/mp2t",
    ".mts": "video/mp2t",
    ".m2t": "video/mp2t",
    ".trp": "video/mp2t",
    ".mpeg": "video/mpeg",
    ".mpg": "video/mpeg",
    ".mpe": "video/mpeg",
    ".mpv": "video/mpeg",
    ".wmv": "video/x-ms-wmv",
    ".asf": "video/x-ms-asf",
    ".flv": "video/x-flv",
    ".f4v": "video/x-f4v",
    ".vob": "video/dvd",
    ".ogv": "video/ogg",
    ".ogm": "video/ogg",
    ".rm": "application/vnd.rn-realmedia",
    ".rmvb": "application/vnd.rn-realmedia-vbr",
}


def media_extension(file_name):
    """Extrai extensão normalizada sem inferir conteúdo por nome."""
    return os.path.splitext(str(file_name or "").strip().lower())[1]


def is_video_name(file_name):
    """Indica se o nome representa um container de vídeo suportado."""
    return media_extension(file_name) in VIDEO_EXTENSION_SET


def is_mp4_like_name(file_name):
    """Indica containers que podem depender de índice no final do arquivo."""
    return media_extension(file_name) in MP4_LIKE_EXTENSIONS


def media_mime_type(file_name):
    """Retorna MIME conservador; bytes seguem intactos para o FFmpeg."""
    return VIDEO_MIME_TYPES.get(media_extension(file_name), "application/octet-stream")
