# -*- coding: utf-8 -*-
"""Estado mínimo do servidor HTTP local do PureTorrent.

O serviço pode usar a porta preferida quando ela estiver livre ou receber uma
porta livre do próprio sistema operacional. Este módulo publica somente a porta
ativa e um token efêmero para que o plugin Kodi valide que está falando com o
servidor da mesma execução do PureTorrent — nunca com outro addon que ocupe a
mesma porta.
"""

import json
import os
import threading

import xbmcvfs

DEFAULT_STREAM_PORT = 18089
_STATE_FILENAME = "stream_server_state.json"


def normalize_stream_port(value, default=DEFAULT_STREAM_PORT):
    """Converte uma porta configurada em valor TCP válido, sem levantar erro."""
    try:
        port = int(str(value).strip())
    except (TypeError, ValueError):
        return int(default)
    return port if 1 <= port <= 65535 else int(default)


def _state_directory():
    path = xbmcvfs.translatePath(
        "special://profile/addon_data/plugin.video.puretorrent/"
    )
    return path or ""


def _state_path():
    directory = _state_directory()
    return os.path.join(directory, _STATE_FILENAME) if directory else ""


def publish_server_state(port, token):
    """Publica o endpoint ativo de forma atômica após o bind ter sido concluído."""
    port = normalize_stream_port(port)
    token = str(token or "").strip()
    if not token:
        return False

    directory = _state_directory()
    path = _state_path()
    if not directory or not path:
        return False

    try:
        if not os.path.isdir(directory):
            xbmcvfs.mkdirs(directory)
        if not os.path.isdir(directory):
            return False

        payload = {
            "version": 1,
            "port": port,
            "token": token,
        }
        temp_path = "%s.%s.%s.tmp" % (
            path,
            os.getpid(),
            threading.current_thread().ident or 0,
        )
        with open(temp_path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, separators=(",", ":"))
            handle.flush()
        os.replace(temp_path, path)
        return True
    except Exception:
        try:
            if 'temp_path' in locals() and os.path.exists(temp_path):
                os.remove(temp_path)
        except Exception:
            pass
        return False


def read_server_state():
    """Retorna estado válido ou ``None``; estado parcial/antigo é ignorado."""
    path = _state_path()
    if not path or not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if not isinstance(payload, dict):
            return None
        port = normalize_stream_port(payload.get("port"), default=0)
        token = str(payload.get("token") or "").strip()
        if not port or not token:
            return None
        return {"port": port, "token": token}
    except Exception:
        return None


def clear_server_state(expected_token=None):
    """Remove o estado local; token evita apagar uma execução mais nova."""
    path = _state_path()
    if not path:
        return
    try:
        if expected_token:
            current = read_server_state()
            if current and current.get("token") != str(expected_token):
                return
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass
