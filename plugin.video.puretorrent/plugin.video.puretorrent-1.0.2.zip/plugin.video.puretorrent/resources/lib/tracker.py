# -*- coding: utf-8 -*-
"""Descoberta de peers por trackers, DHT e Local Peer Discovery.

As rotinas mantêm o escopo leve para o Kodi: não mantêm uma tabela DHT global,
mas percorrem de forma limitada os nós retornados por ``get_peers`` e não
bloqueiam o player. LPD é opcional e falha silenciosamente em redes que não
permitem multicast (normal em algumas redes móveis/Android).
"""

import collections
import os
import random
import socket
import struct
import threading
import time
import urllib.parse
import urllib.request


def parse_compact_peers(data, family=socket.AF_INET):
    peers = []
    if not isinstance(data, (bytes, bytearray)):
        return peers
    if family == socket.AF_INET:
        offset = 0
        while offset + 6 <= len(data):
            ip = ".".join(str(b) for b in data[offset:offset + 4])
            port = struct.unpack(">H", data[offset + 4:offset + 6])[0]
            if ip != "0.0.0.0" and port > 0:
                peers.append((ip, port))
            offset += 6
    elif family == socket.AF_INET6:
        offset = 0
        while offset + 18 <= len(data):
            try:
                ip = socket.inet_ntop(socket.AF_INET6, data[offset:offset + 16])
            except (OSError, ValueError):
                ip = ""
            port = struct.unpack(">H", data[offset + 16:offset + 18])[0]
            if ip and port > 0:
                peers.append((ip, port))
            offset += 18
    return peers


def _parse_compact_nodes(data):
    """Extrai nós IPv4 DHT do formato compacto BEP 5 (20+4+2 bytes)."""
    nodes = []
    if not isinstance(data, (bytes, bytearray)):
        return nodes
    offset = 0
    while offset + 26 <= len(data):
        node_id = bytes(data[offset:offset + 20])
        ip = ".".join(str(b) for b in data[offset + 20:offset + 24])
        port = struct.unpack(">H", data[offset + 24:offset + 26])[0]
        if ip != "0.0.0.0" and port > 0:
            nodes.append((node_id, ip, port))
        offset += 26
    return nodes


def _decode_lpd_packet(payload):
    """Retorna (infohash_hex, port) para um anúncio LPD válido, ou ``None``."""
    if not isinstance(payload, (bytes, bytearray)):
        return None
    try:
        text = bytes(payload).decode("iso-8859-1", "replace")
    except Exception:
        return None
    lines = text.replace("\r\n", "\n").split("\n")
    if not lines or lines[0].strip().upper() != "BT-SEARCH * HTTP/1.1":
        return None
    headers = {}
    for line in lines[1:]:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        headers[key.strip().lower()] = value.strip()
    infohash = headers.get("infohash", "").lower()
    try:
        port = int(headers.get("port", "0"))
    except (TypeError, ValueError):
        return None
    if len(infohash) != 40 or any(char not in "0123456789abcdef" for char in infohash) or not 0 < port < 65536:
        return None
    return infohash, port


def discover_trackers(trackers, info_hash, peer_id, left=1000000, limit=80, port=6881, event=None, reporter=None, peer_callback=None, stop_event=None, max_workers=4, round_timeout=18.0, http_timeout=4.0, udp_timeout=3.0):
    if reporter:
        reporter("Iniciando descoberta em %d trackers..." % len(trackers))

    found_peers = []
    found_lock = threading.Lock()

    def register(peers, source):
        if not peers:
            return
        if peer_callback:
            try:
                peer_callback(peers, source)
            except Exception:
                pass
        with found_lock:
            found_peers.extend(peers)

    def query_udp(tracker_url):
        sock = None
        try:
            parsed = urllib.parse.urlsplit(tracker_url)
            host = parsed.hostname
            port_val = parsed.port or 80
            if not host:
                return

            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.settimeout(udp_timeout)

            transaction_id = random.randint(0, 0x7fffffff)
            connection_id = 0x41727101980
            packet = struct.pack(">QII", connection_id, 0, transaction_id)
            sock.sendto(packet, (host, port_val))

            data, _ = sock.recvfrom(2048)
            if len(data) < 16:
                return
            action, response_tx, connection_id = struct.unpack(">IIQ", data[:16])
            if action != 0 or response_tx != transaction_id:
                return

            announce_tx = random.randint(0, 0x7fffffff)
            announce_packet = struct.pack(
                ">QII20s20sQQQIIIiH",
                connection_id, 1, announce_tx, info_hash, peer_id,
                0, left, 0, 0, 0, 0, -1, port
            )
            sock.sendto(announce_packet, (host, port_val))
            announce_resp, _ = sock.recvfrom(2048)
            if len(announce_resp) < 20:
                return
            action, response_tx, _interval, _leechers, _seeders = struct.unpack(">IIIII", announce_resp[:20])
            if action == 1 and response_tx == announce_tx:
                register(parse_compact_peers(announce_resp[20:]), "tracker")
        except Exception:
            pass
        finally:
            if sock is not None:
                try:
                    sock.close()
                except OSError:
                    pass

    def query_http(tracker_url):
        try:
            from resources.lib.bencode import bdecode
            params = {
                "port": port,
                "uploaded": 0,
                "downloaded": 0,
                "left": left,
                "compact": 1
            }
            if event:
                params["event"] = event
            query_str = "info_hash=" + urllib.parse.quote_from_bytes(info_hash) + "&peer_id=" + urllib.parse.quote_from_bytes(peer_id) + "&" + urllib.parse.urlencode(params)
            url = tracker_url + ("&" if "?" in tracker_url else "?") + query_str
            req = urllib.request.Request(url, headers={"User-Agent": "PureTorrent/1.0"})
            with urllib.request.urlopen(req, timeout=http_timeout) as response:
                resp_dict = bdecode(response.read())
            peers_raw = resp_dict.get("peers", b"") if isinstance(resp_dict, dict) else b""
            peers = []
            if isinstance(peers_raw, bytes):
                peers = parse_compact_peers(peers_raw)
            elif isinstance(peers_raw, list):
                for peer in peers_raw:
                    if isinstance(peer, dict):
                        host = peer.get("ip")
                        peer_port = peer.get("port")
                        try:
                            peer_port = int(peer_port)
                        except (TypeError, ValueError):
                            peer_port = 0
                        if host and peer_port > 0:
                            peers.append((host, peer_port))
            register(peers, "tracker")
        except Exception:
            pass

    threads = []
    for tracker in (trackers or [])[:limit]:
        if stop_event and stop_event.is_set():
            break
        if tracker.startswith("udp://"):
            thread = threading.Thread(target=query_udp, args=(tracker,), name="PureTorrentTrackerUDP", daemon=True)
        elif tracker.startswith(("http://", "https://")):
            thread = threading.Thread(target=query_http, args=(tracker,), name="PureTorrentTrackerHTTP", daemon=True)
        else:
            continue
        thread.start()
        threads.append(thread)
        if len(threads) >= max_workers:
            for worker in threads:
                worker.join(timeout=0.2)
            threads = [worker for worker in threads if worker.is_alive()]

    for worker in threads:
        worker.join(timeout=1.0)
    return found_peers


def _resolve_bootstrap_nodes(bootstrap_nodes):
    resolved = []
    for host, port in bootstrap_nodes:
        try:
            for family, _socktype, _proto, _canonname, address in socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_DGRAM):
                if family == socket.AF_INET:
                    resolved.append((address[0], int(address[1])))
        except OSError:
            continue
    return resolved


def discover_dht(info_hash, max_queries=18, timeout=0.45, reporter=None, peer_callback=None, stop_event=None):
    """Consulta ``get_peers`` em uma pequena caminhada DHT IPv4.

    Não tenta ser um nó DHT completo: limita consultas, não persiste tabela e
    para assim que a sessão for encerrada. Já percorre nós retornados, ao
    contrário do comportamento antigo que consultava apenas três bootstraps.
    """
    if not isinstance(info_hash, (bytes, bytearray)) or len(info_hash) != 20:
        return []
    if reporter:
        reporter("Iniciando varredura DHT limitada...")

    from resources.lib.bencode import bdecode, bencode

    bootstrap_nodes = [
        ("router.bittorrent.com", 6881),
        ("dht.transmissionbt.com", 6881),
        ("router.utorrent.com", 6881),
    ]
    pending = collections.deque(_resolve_bootstrap_nodes(bootstrap_nodes))
    visited = set()
    found = []
    found_set = set()
    node_id = b"-PT1150-" + os.urandom(12)
    sock = None

    def register(peers):
        new_peers = []
        for host, peer_port in peers:
            key = (host, int(peer_port))
            if key in found_set:
                continue
            found_set.add(key)
            found.append(key)
            new_peers.append(key)
        if new_peers and peer_callback:
            try:
                peer_callback(new_peers, "dht")
            except Exception:
                pass

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(max(0.1, float(timeout)))
        queries = 0
        while pending and queries < max(1, int(max_queries)):
            if stop_event and stop_event.is_set():
                break
            host, port = pending.popleft()
            key = (host, int(port))
            if key in visited:
                continue
            visited.add(key)
            queries += 1
            tx = os.urandom(2)
            query = {
                "t": tx,
                "y": b"q",
                "q": b"get_peers",
                "a": {"id": node_id, "info_hash": bytes(info_hash)},
            }
            try:
                sock.sendto(bencode(query), key)
            except OSError:
                continue
            deadline = time.monotonic() + max(0.1, float(timeout))
            while time.monotonic() < deadline:
                if stop_event and stop_event.is_set():
                    break
                try:
                    data, _address = sock.recvfrom(4096)
                    response = bdecode(data)
                except socket.timeout:
                    break
                except (OSError, Exception):
                    break
                if not isinstance(response, dict) or response.get("t") != tx:
                    continue
                response_data = response.get("r", {})
                if not isinstance(response_data, dict):
                    break
                values = response_data.get("values", [])
                if isinstance(values, bytes):
                    values = [values]
                if isinstance(values, list):
                    for raw_peers in values:
                        register(parse_compact_peers(raw_peers))
                for _node_id, next_host, next_port in _parse_compact_nodes(response_data.get("nodes", b"")):
                    next_key = (next_host, next_port)
                    if next_key not in visited:
                        pending.append(next_key)
                break
    except Exception:
        pass
    finally:
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass

    if reporter:
        reporter("DHT concluiu: %d peer(s) em %d nó(s)" % (len(found), len(visited)))
    return found


def discover_local_peers(info_hash, announce_port=6881, reporter=None, peer_callback=None, stop_event=None, listen_seconds=None, announce_interval=8.0):
    """Implementa Local Peer Discovery (BEP 14) por multicast IPv4.

    Redes sem multicast simplesmente não retornam peers; a descoberta remota
    por trackers/DHT continua independente.
    """
    if not isinstance(info_hash, (bytes, bytearray)) or len(info_hash) != 20:
        return []
    if reporter:
        reporter("Iniciando Local Peer Discovery...")

    group = "239.192.152.143"
    group_port = 6771
    try:
        announce_port = int(announce_port)
    except (TypeError, ValueError):
        announce_port = 6881
    if not 0 < announce_port < 65536:
        announce_port = 6881
    expected_hash = bytes(info_hash).hex()
    found = []
    found_set = set()
    receiver = None
    sender = None
    started_at = time.monotonic()
    next_announce = 0.0

    def register(host, peer_port):
        key = (host, int(peer_port))
        if key in found_set:
            return
        found_set.add(key)
        found.append(key)
        if peer_callback:
            try:
                peer_callback([key], "lpd")
            except Exception:
                pass

    try:
        receiver = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        receiver.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            receiver.bind(("", group_port))
        except OSError:
            receiver.bind((group, group_port))
        membership = socket.inet_aton(group) + socket.inet_aton("0.0.0.0")
        receiver.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, membership)
        receiver.settimeout(1.0)

        sender = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sender.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 1)
        try:
            sender.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_LOOP, 0)
        except OSError:
            pass

        while not (stop_event and stop_event.is_set()):
            now = time.monotonic()
            if listen_seconds is not None and now - started_at >= max(0.0, float(listen_seconds)):
                break
            if now >= next_announce:
                packet = (
                    "BT-SEARCH * HTTP/1.1\r\n"
                    "Host: %s:%d\r\n"
                    "Port: %d\r\n"
                    "Infohash: %s\r\n\r\n"
                ) % (group, group_port, announce_port, expected_hash)
                try:
                    sender.sendto(packet.encode("ascii"), (group, group_port))
                except OSError:
                    pass
                next_announce = now + max(2.0, float(announce_interval))
            try:
                payload, address = receiver.recvfrom(2048)
            except socket.timeout:
                continue
            except OSError:
                break
            parsed = _decode_lpd_packet(payload)
            if not parsed:
                continue
            packet_hash, peer_port = parsed
            if packet_hash != expected_hash:
                continue
            host = address[0]
            # O loop multicast é desativado; esta guarda adicional evita que um
            # pacote local óbvio seja colocado na fila em plataformas que o
            # ignoram.
            if peer_port == announce_port and host in ("127.0.0.1", "0.0.0.0"):
                continue
            register(host, peer_port)
    except OSError as exc:
        if reporter:
            reporter("LPD indisponível nesta rede: %s" % exc)
    finally:
        for sock in (receiver, sender):
            if sock is not None:
                try:
                    sock.close()
                except OSError:
                    pass

    if reporter:
        reporter("LPD concluiu: %d peer(s) local(is)" % len(found))
    return found
