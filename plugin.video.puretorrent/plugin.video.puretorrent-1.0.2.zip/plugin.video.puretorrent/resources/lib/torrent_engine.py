# -*- coding: utf-8 -*-
"""Motor BitTorrent de streaming em Python puro.

Escopo intencionalmente conservador:
* magnets BitTorrent v1 (''btih'' em hex ou base32);
* descoberta por trackers HTTP/HTTPS, UDP, 'x.pe' e DHT leve;
* metadata via BEP 9/BEP 10;
* peer wire protocol TCP, blocos de 16 KiB e SHA-1 por peça;
* cache temporário em disco e priorização da janela de reprodução.
"""

import base64
import json
import hashlib
import os
import random
import re
import shutil
import socket
import struct
import threading
import time
import urllib.parse
import urllib.request
from collections import deque

from resources.lib.bencode import BencodeError, bdecode, bdecode_prefix, bencode
from resources.lib.tracker import discover_dht, discover_trackers, discover_local_peers, parse_compact_peers
from resources.lib.media_types import VIDEO_EXTENSIONS, is_video_name, is_mp4_like_name

BLOCK_SIZE = 16 * 1024
MAX_METADATA_SIZE = 4 * 1024 * 1024
METADATA_BLOCK_SIZE = 16 * 1024
HANDSHAKE_PROTOCOL = b"BitTorrent protocol"
HANDSHAKE_LENGTH = 49 + len(HANDSHAKE_PROTOCOL)
REQUEST_TIMEOUT_SECONDS = 25.0
CONNECT_TIMEOUT_SECONDS = 8.0
READ_TIMEOUT_SECONDS = 8.0
METADATA_EXTENSION_TIMEOUT_SECONDS = 12.0
METADATA_REQUEST_TIMEOUT_SECONDS = 8.0

PRIMARY_VIDEO_EXTENSIONS = VIDEO_EXTENSIONS
METADATA_API_URL = "https://metadata-api.wasmer.app/api.php"
METADATA_API_TIMEOUT_SECONDS = 20.0

# A API Wasmer é catálogo rápido (arquivos/trackers), não substitui o
# dicionário ``info`` canônico: o protocolo precisa de ``pieces``/SHA-1 para
# solicitar e validar blocos. Este resolvedor busca apenas .torrent validado
# pelo BTIH, em worker único e com orçamento limitado.
HTTP_METADATA_MAX_BYTES = 8 * 1024 * 1024
HTTP_METADATA_TOTAL_BUDGET_SECONDS = 20.0
HTTP_METADATA_PER_REQUEST_TIMEOUT_SECONDS = 8.0

# Limita somente conexões em fase de handshake. O teto de peers configurado
# continua válido para peers já úteis; isto evita dezenas de sockets lentos
# disputando CPU/rede em aparelhos modestos.
MAX_CONCURRENT_CONNECT_ATTEMPTS = 8
STREAM_DEMAND_STALE_SECONDS = 45.0
STREAM_URGENT_WINDOW_BYTES = 8 * 1024 * 1024

class TorrentError(Exception):
    """Falha de sessão BitTorrent que pode ser exibida de forma objetiva."""

def _decode_text(value, fallback=""):
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    if isinstance(value, str):
        return value
    return fallback

def _int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default

def _safe_filename(value):
    value = _decode_text(value, "torrent")
    for char in '<>:"/\\|?*':
        value = value.replace(char, "_")
    while ".." in value:
        value = value.replace("..", "_")
    value = value.strip().strip(".")
    return value.strip() or "torrent"

def _build_peer_id():
    return b"-PT1080-" + os.urandom(12)

def _normalise_btih(raw):
    raw = _decode_text(raw).strip()
    if len(raw) == 40 and re.match(r"^[a-fA-F0-9]{40}$", raw):
        return bytes.fromhex(raw)
    if len(raw) == 32 and re.match(r"^[a-zA-Z2-7]{32}$", raw):
        try:
            return base64.b32decode(raw.upper())
        except Exception:
            pass
    raise TorrentError("Magnet sem info-hash BTIH v1 válido")

def parse_magnet(magnet_uri):
    if not isinstance(magnet_uri, str):
        raise TorrentError("Magnet inválido")
    parsed = urllib.parse.urlsplit(magnet_uri.strip())
    if parsed.scheme.lower() != "magnet":
        raise TorrentError("O link não é um magnet")
    params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    info_hash = None
    for xt in params.get("xt", []):
        if xt.lower().startswith("urn:btih:"):
            info_hash = _normalise_btih(xt.split(":", 2)[-1])
            break
    if info_hash is None:
        raise TorrentError("Magnet sem parâmetro xt=urn:btih")

    direct_peers = []
    for value in params.get("x.pe", []):
        value = value.strip()
        try:
            if value.startswith("["):
                host, port = value.rsplit("]:", 1)
                host = host[1:]
            else:
                host, port = value.rsplit(":", 1)
            port = int(port)
            if host and 0 < port < 65536:
                direct_peers.append((host, port))
        except (ValueError, TypeError):
            continue

    trackers = []
    seen_trackers = set()
    for tracker in params.get("tr", []):
        tracker = tracker.strip()
        if tracker and tracker not in seen_trackers:
            seen_trackers.add(tracker)
            trackers.append(tracker)

    # Lista de trackers publicos mais confiaveis e ativos para garantir conexao real
    PUBLIC_TRACKERS = [
        "udp://tracker.opentrackr.org:1337/announce",
        "udp://open.stealth.si:80/announce",
        "udp://tracker.coppersurfer.tk:6969/announce",
        "udp://tracker.openbittorrent.com:80/announce",
        "udp://explodie.org:6969/announce",
        "udp://tracker.torrent.eu.org:451/announce",
        "udp://tracker.leechers-paradise.org:6969/announce",
        "udp://tracker.internetwarriors.net:1337/announce",
        "http://tracker.gbitt.info:80/announce",
        "udp://p4p.arenabg.com:1337/announce",
        "udp://9.rarbg.to:2780/announce",
        "udp://9.rarbg.me:2780/announce",
        "udp://tracker.tiny-vps.com:6969/announce",
        "udp://open.demonii.com:1337/announce",
        "udp://denis.stalker.upeer.me:6969/announce",
        "udp://tracker.port443.xyz:6969/announce",
        "udp://tracker.moack.jacklist.net:1337/announce",
        "udp://ipv4.tracker.harry.lu:80/announce"
    ]
    for tr in PUBLIC_TRACKERS:
        if tr not in seen_trackers:
            seen_trackers.add(tr)
            trackers.append(tr)

    return {
        "uri": magnet_uri,
        "info_hash": info_hash,
        "display_name": _decode_text(params.get("dn", [""])[0]),
        "trackers": trackers,
        "direct_peers": direct_peers,
    }

class DiskPieceCache:
    """Cache estritamente por peças verificadas.

    Não pré-aloca arquivos do torrent, não replica temporadas e não usa nomes
    internos do release como caminho local. Cada peça concluída é gravada de
    forma atômica em ``pieces/NNNNNNNN.bin``.
    """

    def __init__(self, root_path, session_id):
        self.root_path = os.path.join(root_path, session_id)
        self.pieces_path = os.path.join(self.root_path, "pieces")
        self._lock = threading.RLock()
        os.makedirs(self.pieces_path, exist_ok=True)
        self.files = None
        self.total_length = 0
        self.piece_length = 0
        self.piece_hashes = []

    def setup_files(self, files, total_length, piece_length, piece_hashes):
        """Registra metadata sem criar arquivos de mídia no disco."""
        with self._lock:
            self.files = files
            self.total_length = int(total_length or 0)
            self.piece_length = int(piece_length or 0)
            self.piece_hashes = list(piece_hashes or [])
            os.makedirs(self.pieces_path, exist_ok=True)

    def _path(self, piece_index):
        return os.path.normpath(os.path.join(self.pieces_path, "%08d.bin" % int(piece_index)))

    def write_piece(self, piece_index, data):
        """Persiste uma peça validada, sem pré-alocar ou tocar outros episódios."""
        if not isinstance(data, (bytes, bytearray)):
            raise OSError("dados de peça inválidos")
        target = self._path(piece_index)
        temporary = target + ".tmp"
        with self._lock:
            os.makedirs(self.pieces_path, exist_ok=True)
            with open(temporary, "wb") as handle:
                handle.write(bytes(data))
                handle.flush()
            os.replace(temporary, target)

    def read_piece(self, piece_index):
        """Retorna a peça completa, ou ``None`` quando ainda não existe."""
        with self._lock:
            try:
                with open(self._path(piece_index), "rb") as handle:
                    return handle.read()
            except OSError:
                return None

    def remove_piece(self, piece_index):
        with self._lock:
            try:
                os.remove(self._path(piece_index))
            except OSError:
                pass

    def clear(self):
        try:
            shutil.rmtree(self.root_path, ignore_errors=True)
        except OSError:
            pass

class PeerConnection:
    def __init__(self, session, host, port, incoming_socket=None, incoming_handshake=None):
        self.session = session
        self.host = host
        self.port = int(port)
        self.key = "%s:%d" % (host, port)
        self.socket = incoming_socket
        self.incoming_socket = incoming_socket
        self.incoming_handshake = incoming_handshake
        self.thread = None
        self.running = threading.Event()
        self.send_lock = threading.Lock()
        self.connected = False
        self.close_reason = ""
        self.choked = True
        self.interested = False
        self.bitfield = b""
        self.remote_extensions = {}
        self.remote_metadata_id = None
        self.remote_pex_id = None
        self.metadata_size = None
        self.supports_extensions = False
        self.extensions_logged = False
        self.extensions_received_at = 0.0
        self.pending_count = 0
        self.failures = 0
        self.invalid_blocks = 0
        self.connected_at = 0.0
        self.last_activity = 0.0
        self.last_request_at = 0.0
        self._speed_samples = deque(maxlen=40)
        self.was_connected_once = False

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.running.set()
        self.thread = threading.Thread(target=self._run, name="PureTorrentPeer", daemon=True)
        self.thread.start()

    def close(self, reason=""):
        if reason and not self.close_reason:
            self.close_reason = str(reason)
        self.running.clear()
        sock = self.socket
        self.socket = None
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass
        if reason:
            self.session.log("Peer %s encerrado: %s" % (self.key, reason), "debug")

    def has_piece(self, index):
        byte_index = index // 8
        if byte_index >= len(self.bitfield):
            return False
        return bool(self.bitfield[byte_index] & (1 << (7 - (index % 8))))

    # def speed_bps(self):
    #     now = time.monotonic()
    #     samples = [(stamp, size) for stamp, size in self._speed_samples if now - stamp <= 12.0]
    #     if not samples:
    #         return 0.0
    #     first_stamp = samples[0][0]
    #     interval = max(1.0, now - first_stamp)
    #     return float(sum(size for _, size in samples)) / interval
    def speed_bps(self):
        """Calcula velocidade com thread safety"""
        if not self._speed_samples:
            return 0.0
        
        now = time.monotonic()
        # Copia a deque para evitar RuntimeError de mutação durante iteração
        samples = list(self._speed_samples)
        
        # Filtra amostras dos últimos 12 segundos
        valid_samples = [(stamp, size) for stamp, size in samples if now - stamp <= 12.0]
        
        if not valid_samples:
            return 0.0
            
        first_stamp = valid_samples[0][0]
        interval = max(1.0, now - first_stamp)
        total_bytes = sum(size for _, size in valid_samples)
        
        return total_bytes / interval    

    def _send(self, payload):
        sock = self.socket
        if not self.running.is_set() or sock is None:
            raise OSError("peer desconectado")
        with self.send_lock:
            sock.sendall(payload)

    def _send_message(self, message_id=None, payload=b""):
        if message_id is None:
            self._send(struct.pack(">I", 0))
            return
        payload = bytes(payload)
        self._send(struct.pack(">IB", len(payload) + 1, int(message_id)) + payload)

    def send_interested(self):
        """Marca interesse uma única vez enquanto a conexão estiver ativa."""
        if self.interested:
            return True
        try:
            self._send_message(2)
            self.interested = True
            return True
        except OSError:
            self.close("falha ao marcar interesse")
            return False

    def send_bitfield(self):
        try:
            total_pieces = len(self.session.piece_hashes)
            byte_count = (total_pieces + 7) // 8
            bf = bytearray(byte_count)
            with self.session._lock:
                for idx in self.session.completed_pieces:
                    if 0 <= idx < total_pieces:
                        bf[idx // 8] |= 1 << (7 - (idx % 8))
            self._send_message(5, bytes(bf))
        except OSError:
            self.close("falha ao enviar bitfield")

    def send_have(self, piece_index):
        try:
            self._send_message(4, struct.pack(">I", piece_index))
        except OSError:
            self.close("falha ao enviar have")

    def send_request(self, piece_index, begin, length):
        try:
            self._send_message(6, struct.pack(">III", piece_index, begin, length))
            self.last_request_at = time.monotonic()
            return True
        except OSError:
            self.close("falha no request")
            return False

    def send_cancel(self, piece_index, begin, length):
        try:
            self._send_message(8, struct.pack(">III", piece_index, begin, length))
        except OSError:
            pass

    def send_extended(self, extension_id, payload):
        try:
            self._send_message(20, bytes([extension_id]) + payload)
            return True
        except OSError:
            self.close("falha em mensagem estendida")
            return False

    def _recv_exact(self, amount, deadline_seconds=READ_TIMEOUT_SECONDS):
        chunks = []
        remaining = amount
        deadline = time.monotonic() + deadline_seconds
        while remaining > 0 and self.running.is_set():
            if time.monotonic() >= deadline:
                raise socket.timeout("timeout de leitura")
            sock = self.socket
            if sock is None:
                raise OSError("peer desconectado")
            try:
                part = sock.recv(remaining)
            except socket.timeout:
                continue
            if not part:
                raise OSError("peer fechou a conexão")
            chunks.append(part)
            remaining -= len(part)
        if remaining:
            raise OSError("conexão encerrada")
        return b"".join(chunks)

    def _send_handshake(self):
        reserved = bytes([0, 0, 0, 0, 0, 16, 0, 0])
        packet = bytes([len(HANDSHAKE_PROTOCOL)]) + HANDSHAKE_PROTOCOL + reserved
        packet += self.session.info_hash + self.session.peer_id
        self._send(packet)

    def _validate_received_handshake(self, protocol_length, body):
        if protocol_length != len(HANDSHAKE_PROTOCOL):
            raise TorrentError("handshake peer inválido")
        if body[:protocol_length] != HANDSHAKE_PROTOCOL:
            raise TorrentError("protocolo peer incompatível")
        reserved = body[protocol_length:protocol_length + 8]
        remote_info_hash = body[protocol_length + 8:protocol_length + 28]
        if remote_info_hash != self.session.info_hash:
            raise TorrentError("peer respondeu outro torrent")
        return reserved

    def _receive_handshake(self):
        header = self._recv_exact(1, CONNECT_TIMEOUT_SECONDS)
        protocol_length = header[0]
        body = self._recv_exact(protocol_length + 48, CONNECT_TIMEOUT_SECONDS)
        return self._validate_received_handshake(protocol_length, body)

    def _send_extended_handshake(self):
        payload = {
            b"m": {b"ut_metadata": 1, b"ut_pex": 2},
            b"v": b"PureTorrent/1.0.8",
            b"p": int(self.session.peer_port),
            b"reqq": 16,
        }
        self.send_extended(0, bencode(payload))

    def _handle_extended(self, payload):
        if not payload:
            return
        extension_id = payload[0]
        body = payload[1:]
        if extension_id == 0:
            try:
                data = bdecode(body)
            except BencodeError:
                self.failures += 1
                return

            def get_val(d, key):
                if not isinstance(d, dict):
                    return None
                if key in d:
                    return d[key]
                b_key = key.encode('utf-8') if isinstance(key, str) else key
                s_key = key.decode('utf-8', errors='ignore') if isinstance(key, bytes) else key
                if b_key in d:
                    return d[b_key]
                if s_key in d:
                    return d[s_key]
                return None

            mapping = get_val(data, "m") or {}
            if isinstance(mapping, dict):
                self.remote_extensions = mapping
                metadata_id = get_val(mapping, "ut_metadata")
                if isinstance(metadata_id, int) and 0 < metadata_id < 256:
                    self.remote_metadata_id = metadata_id
                pex_id = get_val(mapping, "ut_pex")
                if isinstance(pex_id, int) and 0 < pex_id < 256:
                    self.remote_pex_id = pex_id
            size = get_val(data, "metadata_size")
            if isinstance(size, int) and 0 < size <= MAX_METADATA_SIZE:
                self.metadata_size = size
            self.extensions_received_at = time.monotonic()
            self.session.on_peer_extensions(self)
            return

        if self.remote_pex_id is not None and extension_id == self.remote_pex_id:
            try:
                data = bdecode(body)
            except BencodeError:
                self.failures += 1
                return
            self.session.on_peer_pex(self, data)
            return

        if self.remote_metadata_id is not None and extension_id == self.remote_metadata_id:
            try:
                header, consumed = bdecode_prefix(body)
            except BencodeError:
                self.failures += 1
                return
            if not isinstance(header, dict):
                return
            self.session.on_metadata_message(self, header, body[consumed:])

    def _handle_message(self, message_id, payload):
        self.last_activity = time.monotonic()
        if message_id == 0:
            self.choked = True
        elif message_id == 1:
            self.choked = False
            self.session.notify_scheduler()
        elif message_id == 4 and len(payload) == 4:
            piece = struct.unpack(">I", payload)[0]
            self._set_have(piece)
        elif message_id == 5:
            self.bitfield = bytes(payload)
            self.session.notify_scheduler()
        elif message_id == 7 and len(payload) >= 8:
            piece_index, begin = struct.unpack(">II", payload[:8])
            block = payload[8:]
            if block:
                self._speed_samples.append((time.monotonic(), len(block)))
                self.session.on_piece_block(self, piece_index, begin, block)
        elif message_id == 20:
            self._handle_extended(payload)

    def _set_have(self, piece_index):
        required_bytes = (piece_index // 8) + 1
        if len(self.bitfield) < required_bytes:
            self.bitfield += bytes([0]) * (required_bytes - len(self.bitfield))
        value = bytearray(self.bitfield)
        value[piece_index // 8] |= 1 << (7 - (piece_index % 8))
        self.bitfield = bytes(value)
        self.session.notify_scheduler()

    def _run(self):
        error = ""
        try:
            if self.incoming_socket is not None:
                self.socket = self.incoming_socket
                self.socket.settimeout(READ_TIMEOUT_SECONDS)
                protocol_length, body = self.incoming_handshake
                reserved = self._validate_received_handshake(protocol_length, body)
                self._send_handshake()
            else:
                self.socket = socket.create_connection((self.host, self.port), timeout=CONNECT_TIMEOUT_SECONDS)
                self.socket.settimeout(READ_TIMEOUT_SECONDS)
                self._send_handshake()
                reserved = self._receive_handshake()
            self.supports_extensions = bool(len(reserved) >= 6 and (reserved[5] & 0x10))
            self.connected = True
            self.was_connected_once = True
            self.connected_at = time.monotonic()
            self.last_activity = self.connected_at
            self.session.on_peer_connected(self)
            if not self.session.metadata_ready.is_set() and not self.supports_extensions:
                raise TorrentError("peer sem BEP 10/metadata")
            if self.supports_extensions:
                self._send_extended_handshake()
            if self.session.metadata_ready.is_set():
                self.send_interested()

            while self.running.is_set() and not self.session.closed.is_set():
                try:
                    raw_length = self._recv_exact(4, READ_TIMEOUT_SECONDS)
                except socket.timeout:
                    continue
                length = struct.unpack(">I", raw_length)[0]
                if length == 0:
                    continue
                if length > 2 * 1024 * 1024:
                    raise TorrentError("mensagem peer grande demais")
                payload = self._recv_exact(length, max(READ_TIMEOUT_SECONDS, length / 65536.0 + 2.0))
                self._handle_message(payload[0], payload[1:])
        except Exception as exc:
            error = str(exc)
        finally:
            self.connected = False
            self.running.clear()
            final_reason = self.close_reason or error
            self.session.on_peer_disconnected(self, final_reason)
            sock = self.socket
            self.socket = None
            if sock is not None:
                try:
                    sock.close()
                except OSError:
                    pass

class TorrentSession:
    def __init__(self, magnet_uri, cache_root, max_peers=30, buffer_size_mb=30, cache_limit_mb=512,
                 peer_port=6881, enable_trackers=True, enable_dht=True, enable_lpd=True,
                 local_peer_port=0, logger=None):
        magnet = parse_magnet(magnet_uri)
        self.magnet_uri = magnet_uri
        self.info_hash = magnet["info_hash"]
        self.info_hash_hex = self.info_hash.hex()
        self.display_name = magnet["display_name"] or self.info_hash_hex
        self.trackers = magnet["trackers"]
        self.direct_peers = magnet["direct_peers"]
        self.peer_id = _build_peer_id()
        # ``0`` pede uma porta efêmera; útil quando 6881 já está ocupada por
        # outro cliente BitTorrent local. A porta efetiva é anunciada somente
        # depois que o listener consegue abrir.
        try:
            configured_peer_port = int(peer_port)
        except (TypeError, ValueError):
            configured_peer_port = 6881
        self.peer_port = max(0, min(configured_peer_port, 65535))
        self.enable_trackers = bool(enable_trackers)
        self.enable_dht = bool(enable_dht)
        self.enable_lpd = bool(enable_lpd)
        try:
            self.local_peer_port = max(0, min(int(local_peer_port or 0), 65535))
        except (TypeError, ValueError):
            self.local_peer_port = 0
        self.max_peers = max_peers if isinstance(max_peers, int) and max_peers > 0 else 25
        if self.max_peers > 30:
            self.max_peers = 30
        self.active_peer_limit = self.max_peers
        self.buffer_size_bytes = max(4, min(int(buffer_size_mb or 12), 100)) * 1024 * 1024
        self.cache_limit_bytes = max(64, min(int(cache_limit_mb or 512), 4096)) * 1024 * 1024
        self.log_callback = logger
        self.cache = DiskPieceCache(cache_root, self.info_hash_hex)

        self.closed = threading.Event()
        self.metadata_ready = threading.Event()
        self.started = threading.Event()
        self._wake_scheduler = threading.Event()
        self._wake_discovery = threading.Event()
        self._lock = threading.RLock()
        self._condition = threading.Condition(self._lock)
        self._peers = {}
        self._candidate_peers = deque()
        self._candidate_seen = set()
        self._metadata_size = None
        self._metadata_parts = {}
        self._metadata_requested = {}
        self._metadata_attempts = {}
        self.error = ""
        self.info = None
        self.piece_length = 0
        self.piece_hashes = []
        self.total_length = 0
        self.files = []
        self.selected_file = None
        self.completed_pieces = set()
        self.piece_blocks = {}
        self.pending_blocks = {}
        self.cache_bytes = 0
        self.playback_offset = 0
        self.last_used = time.monotonic()
        self._discovery_thread = None
        self._scheduler_thread = None
        self._lpd_thread = None
        self._listener_thread = None
        self._listener_socket = None
        # Estado do resolvedor de metadata canônica. A Wasmer continua somente
        # como catálogo rápido; o stream depende de hashes SHA-1 de peças.
        self._http_metadata_lock = threading.RLock()
        self._http_metadata_started = False
        self._http_metadata_finished = threading.Event()
        self._http_metadata_thread = None
        self.metadata_source = ""
        self.metadata_resolution_state = "aguardando"
        self._status_speed_samples = deque(maxlen=40)
        self.discovery_status = "Inicializando descoberta"
        self.discovery_round = 0
        self.tracker_peer_count = 0
        self.dht_peer_count = 0
        self.lpd_peer_count = 0
        self.pex_peer_count = 0
        self.last_discovery_at = 0.0
        self._tracker_started = False
        # Recuperação conservadora de swarm: após metadata válida, alguns
        # trackers devolvem peers já expirados. Sem aumentar DHT, timeouts ou
        # concorrência TCP, acordamos no máximo duas rodadas normais caso nenhum
        # bloco SHA-1 validado tenha chegado.
        self._metadata_ready_at = 0.0
        self._stalled_swarm_refreshes = 0
        self._next_stalled_refresh_at = 0.0
        # Pré-buffer de inicialização: alguns MP4/MOV guardam o índice ``moov``
        # no fim do arquivo. O Kodi então faz um Range distante antes de
        # reproduzir. Mantemos uma pequena janela final pronta além do buffer
        # inicial, sem alterar o fluxo normal de MKV/TS.
        self._startup_head_target_bytes = 0
        self._startup_tail_start = None
        self._startup_tail_target_bytes = 0
        self._startup_tail_required = False
        # Uma reprodução HTTP pode ter uma leitura sequencial aberta e outro
        # Range pontual para índice/seek. Guardar demandas separadas impede que
        # a leitura antiga volte a empurrar o cursor para o início do arquivo.
        self._stream_demands = {}
        self._stream_demand_sequence = 0

    def log(self, message, level="info"):
        text = "[PureTorrent] %s" % message
        if self.log_callback:
            try:
                self.log_callback(text, level)
                return
            except Exception:
                pass
        print(text)

    def start(self):
        if self.started.is_set() or self.closed.is_set():
            return
        self.started.set()
        self._start_peer_listener()
        self.log("Sessão %s iniciada; buscando peers." % self.info_hash_hex[:12])
        for peer in self.direct_peers:
            self.add_peer(*peer)
        if self.local_peer_port:
            self._receive_discovered_peers([("127.0.0.1", self.local_peer_port)], "local")
        self._discovery_thread = threading.Thread(target=self._discovery_loop, name="PureTorrentDiscover", daemon=True)
        self._scheduler_thread = threading.Thread(target=self._scheduler_loop, name="PureTorrentScheduler", daemon=True)
        if self.enable_lpd:
            self._lpd_thread = threading.Thread(target=self._lpd_loop, name="PureTorrentLPD", daemon=True)
            self._lpd_thread.start()
        else:
            self._discovery_report("LPD local desativado nas configurações.")
        self._discovery_thread.start()
        self._scheduler_thread.start()
        # Inicia em paralelo o resolvedor canônico. Assim /status já pode
        # formar o buffer; não existe mais ciclo em que /stream era necessário
        # para buscar os hashes que o próprio /stream aguardava.
        self.request_http_metadata_once()

    def _start_peer_listener(self):
        """Abre listener TCP para conexões BitTorrent de entrada.

        Tenta primeiro a porta configurada. Caso ela esteja ocupada ou bloqueada
        no sistema, usa uma porta efêmera e anuncia somente a porta real aos
        trackers/peers. Não executa UPnP/NAT-PMP: o encaminhamento externo
        continua decisão explícita da rede do usuário.
        """
        if self.closed.is_set() or self._listener_socket is not None:
            return
        requested_ports = [self.peer_port]
        if self.peer_port != 0:
            requested_ports.append(0)
        for requested_port in requested_ports:
            listener = None
            try:
                listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                listener.bind(("0.0.0.0", int(requested_port)))
                listener.listen(max(4, min(self.max_peers, 30)))
                listener.settimeout(0.75)
                self._listener_socket = listener
                actual_port = int(listener.getsockname()[1])
                previous_port = self.peer_port
                self.peer_port = actual_port
                self._listener_thread = threading.Thread(
                    target=self._listener_loop,
                    name="PureTorrentInbound",
                    daemon=True,
                )
                self._listener_thread.start()
                if requested_port == 0 or actual_port != previous_port:
                    self.log("Listener BitTorrent ativo na porta %d (fallback seguro)." % actual_port, "debug")
                else:
                    self.log("Listener BitTorrent ativo na porta %d." % actual_port, "debug")
                return
            except OSError as exc:
                if listener is not None:
                    try:
                        listener.close()
                    except OSError:
                        pass
                last_error = exc
                continue
        self.peer_port = 0
        self._discovery_report("Listener de entrada indisponível; mantendo conexões de saída (%s)." % last_error, "warning")

    @staticmethod
    def _recv_socket_exact(sock, amount):
        chunks = []
        remaining = int(amount)
        while remaining > 0:
            data = sock.recv(remaining)
            if not data:
                raise OSError("conexão encerrada durante handshake")
            chunks.append(data)
            remaining -= len(data)
        return b"".join(chunks)

    def _listener_loop(self):
        while not self.closed.is_set():
            listener = self._listener_socket
            if listener is None:
                break
            try:
                conn, address = listener.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            try:
                conn.settimeout(CONNECT_TIMEOUT_SECONDS)
                protocol_length = self._recv_socket_exact(conn, 1)[0]
                if protocol_length != len(HANDSHAKE_PROTOCOL):
                    raise TorrentError("handshake de entrada inválido")
                body = self._recv_socket_exact(conn, protocol_length + 48)
                if body[:protocol_length] != HANDSHAKE_PROTOCOL:
                    raise TorrentError("protocolo de entrada incompatível")
                remote_info_hash = body[protocol_length + 8:protocol_length + 28]
                if remote_info_hash != self.info_hash:
                    raise TorrentError("peer de entrada para outro torrent")
                if not self.accept_incoming_peer(conn, address, (protocol_length, body)):
                    conn.close()
            except Exception as exc:
                try:
                    conn.close()
                except OSError:
                    pass
                self.log("Conexão de entrada rejeitada: %s" % exc, "debug")

    def _stop_peer_listener(self):
        listener = self._listener_socket
        self._listener_socket = None
        if listener is not None:
            try:
                listener.close()
            except OSError:
                pass

    def _canonical_info_from_torrent(self, torrent_data, expected_info_hash):
        """Extrai e valida ``info`` de um .torrent sem confiar na origem.

        O BTIH v1 é SHA-1 do bencode exato do dicionário ``info``. A validação
        impede que uma fonte HTTP troque o conteúdo apontado pelo magnet.
        """
        if not isinstance(torrent_data, (bytes, bytearray)):
            return None
        if len(torrent_data) < 64 or len(torrent_data) > HTTP_METADATA_MAX_BYTES:
            return None
        try:
            decoded = bdecode(bytes(torrent_data))
            if not isinstance(decoded, dict):
                return None
            info = decoded.get(b"info")
            if info is None:
                info = decoded.get("info")
            if not isinstance(info, dict):
                return None
            raw_info = bencode(info)
            if hashlib.sha1(raw_info).digest() != expected_info_hash:
                return None
            return raw_info
        except (BencodeError, ValueError, TypeError):
            return None

    @staticmethod
    def _read_http_response(request, timeout):
        with urllib.request.urlopen(request, timeout=max(1.0, float(timeout))) as response:
            payload = response.read(HTTP_METADATA_MAX_BYTES + 1)
        if len(payload) > HTTP_METADATA_MAX_BYTES:
            raise TorrentError("Resposta .torrent excede o limite permitido")
        return payload

    def _get_metadata_via_http(self, magnet_uri, expected_info_hash):
        """Obtém apenas metadata canônica necessária ao motor.

        A primeira fonte usa somente o BTIH; BTMaster é contingência porque
        seu endpoint exige magnet completo. Toda resposta é bdecodeada e
        validada antes de instalar hashes de peças.
        """
        hash_hex = expected_info_hash.hex()
        started = time.monotonic()

        def remaining():
            return HTTP_METADATA_TOTAL_BUDGET_SECONDS - (time.monotonic() - started)

        def fetch(label, request):
            left = remaining()
            if left <= 0 or self.closed.is_set() or self.metadata_ready.is_set():
                return None
            try:
                payload = self._read_http_response(
                    request,
                    min(HTTP_METADATA_PER_REQUEST_TIMEOUT_SECONDS, max(1.0, left)),
                )
                raw_info = self._canonical_info_from_torrent(payload, expected_info_hash)
                if raw_info:
                    with self._lock:
                        self.metadata_source = label
                    self.log("Metadata canônica validada via %s." % label, "info")
                    return raw_info
                self.log("%s retornou .torrent inválido ou de outro BTIH." % label, "debug")
            except Exception as exc:
                self.log("%s indisponível: %s" % (label, exc), "debug")
            return None

        # 1) Caminho por info-hash: não transmite o magnet completo.
        direct = urllib.request.Request(
            "https://magnet2torrent.com/download/%s" % hash_hex,
            headers={"User-Agent": "PureTorrent/1.0 Kodi", "Accept": "application/x-bittorrent, application/octet-stream"},
        )
        raw_info = fetch("magnet2torrent", direct)
        if raw_info:
            return raw_info

        # 2) BTMaster: contingência histórica do metadata.zip. O endpoint
        # entrega um hash temporário que é baixado como .torrent em seguida.
        if remaining() > 0 and not self.closed.is_set():
            try:
                form = urllib.parse.urlencode({"magnetUrl": magnet_uri}).encode("utf-8")
                request = urllib.request.Request(
                    "https://www.btmaster.net/magnet2torrent/do/",
                    data=form,
                    headers={
                        "User-Agent": "PureTorrent/1.0 Kodi",
                        "X-Requested-With": "XMLHttpRequest",
                        "Accept": "application/json",
                    },
                )
                payload = self._read_http_response(
                    request,
                    min(HTTP_METADATA_PER_REQUEST_TIMEOUT_SECONDS, max(1.0, remaining())),
                )
                response = json.loads(payload.decode("utf-8", "replace"))
                temp_hash = ""
                if isinstance(response, dict) and _int(response.get("code"), -1) == 0:
                    data = response.get("data") or {}
                    if isinstance(data, dict):
                        temp_hash = _decode_text(data.get("hash"), "").strip()
                if temp_hash:
                    raw_info = fetch(
                        "BTMaster",
                        urllib.request.Request(
                            "https://www.btmaster.net/tempTor/%s.torrent" % urllib.parse.quote(temp_hash, safe=""),
                            headers={"User-Agent": "PureTorrent/1.0 Kodi", "Accept": "application/x-bittorrent, application/octet-stream"},
                        ),
                    )
                    if raw_info:
                        return raw_info
                else:
                    self.log("BTMaster não retornou hash temporário válido.", "debug")
            except Exception as exc:
                self.log("BTMaster indisponível: %s" % exc, "debug")

        # 3) Cache por BTIH, também sem expor o magnet completo.
        if remaining() > 0 and not self.closed.is_set():
            raw_info = fetch(
                "TorrentCache",
                urllib.request.Request(
                    "https://torrentcache.net/torrent/%s.torrent" % hash_hex,
                    headers={"User-Agent": "PureTorrent/1.0 Kodi", "Accept": "application/x-bittorrent, application/octet-stream"},
                ),
            )
            if raw_info:
                return raw_info
        return None

    def _http_metadata_worker(self):
        try:
            if self.closed.is_set() or self.metadata_ready.is_set():
                return
            with self._lock:
                self.metadata_resolution_state = "resolvendo metadata canônica"
            self.log("Buscando metadata canônica para iniciar o buffer.", "info")
            raw_info = self._get_metadata_via_http(self.magnet_uri, self.info_hash)
            if raw_info and not self.closed.is_set() and not self.metadata_ready.is_set():
                self._install_metadata(raw_info)
                if self.metadata_ready.is_set():
                    with self._lock:
                        self.metadata_resolution_state = "metadata pronta via %s" % (self.metadata_source or "HTTP")
                    self.log("Metadata instalada; iniciando prioridade de buffer.", "info")
                    return
            if not self.closed.is_set() and not self.metadata_ready.is_set():
                with self._lock:
                    self.metadata_resolution_state = "aguardando metadata via peers"
                self.log("Fontes canônicas sem resposta; mantendo fallback BEP 10 pelos peers.", "warning")
        except Exception as exc:
            with self._lock:
                self.metadata_resolution_state = "fallback BEP 10"
            self.log("Resolvedor de metadata falhou: %s" % exc, "debug")
        finally:
            self._http_metadata_finished.set()
            self.notify_scheduler()

    def request_http_metadata_once(self):
        """Inicia um único worker de metadata antes do polling de buffer."""
        if self.metadata_ready.is_set() or self.closed.is_set():
            return False
        with self._http_metadata_lock:
            if self._http_metadata_started:
                return False
            self._http_metadata_started = True
            self._http_metadata_thread = threading.Thread(
                target=self._http_metadata_worker,
                name="PureTorrentMetadata",
                daemon=True,
            )
            self._http_metadata_thread.start()
            return True

    def _run_http_metadata_fallback(self):
        return self.request_http_metadata_once()

    def add_peer(self, host, port):
        if isinstance(host, bytes):
            host = host.decode('utf-8', errors='ignore')
        try:
            port = int(port)
        except (TypeError, ValueError):
            return False
        if not host or not (0 < port < 65536) or self.closed.is_set():
            return False
        key = "%s:%d" % (host, port)
        with self._lock:
            if self.closed.is_set() or key in self._candidate_seen or key in self._peers:
                return False
            self._candidate_seen.add(key)
            self._candidate_peers.append((host, port))
        self.notify_scheduler()
        return True

    def _set_discovery_status(self, text):
        with self._lock:
            self.discovery_status = str(text or "Aguardando descoberta")
            self.last_discovery_at = time.monotonic()

    def _discovery_report(self, message, level="debug"):
        self.log("Descoberta: %s" % message, level)

    def _receive_discovered_peers(self, peers, source="tracker"):
        if self.closed.is_set():
            return
        accepted = 0
        for peer in peers or []:
            try:
                host, port = peer
            except (TypeError, ValueError):
                continue
            if self.add_peer(host, port):
                accepted += 1
        if not accepted:
            return
        source_key = str(source or "tracker").lower()
        source_names = {
            "dht": "DHT",
            "lpd": "LPD local",
            "local": "Loopback configurado",
            "pex": "PEX",
        }
        source_name = source_names.get(source_key, "Tracker")
        with self._lock:
            if source_key == "dht":
                self.dht_peer_count += accepted
            elif source_key in ("lpd", "local"):
                self.lpd_peer_count += accepted
            elif source_key == "pex":
                self.pex_peer_count += accepted
            else:
                self.tracker_peer_count += accepted
            queued = len(self._candidate_peers)
            tracker_count = self.tracker_peer_count
            dht_count = self.dht_peer_count
            lpd_count = self.lpd_peer_count
            pex_count = self.pex_peer_count
        self._set_discovery_status("%s entregou %d peer(s); T:%d DHT:%d LAN:%d PEX:%d fila:%d" % (
            source_name, accepted, tracker_count, dht_count, lpd_count, pex_count, queued))

    def _lpd_loop(self):
        try:
            discover_local_peers(
                self.info_hash,
                announce_port=self.peer_port,
                reporter=self._discovery_report,
                peer_callback=self._receive_discovered_peers,
                stop_event=self.closed,
                listen_seconds=None,
                announce_interval=8.0,
            )
        except Exception as exc:
            self._discovery_report("LPD interrompido: %s" % exc, "warning")

    def _discovery_loop(self):
        while not self.closed.is_set():
            self.discovery_round += 1
            round_number = self.discovery_round
            left = self.total_length if self.total_length > 0 else 1
            round_stop = threading.Event()
            results = {"tracker": [], "dht": []}
            workers = []
            with self._lock:
                self.tracker_peer_count = 0
                self.dht_peer_count = 0

            def receiver(peers, source="tracker"):
                self._receive_discovered_peers(peers, source)

            def run_trackers():
                if not self.enable_trackers:
                    self._discovery_report("Trackers desativados nas configurações.")
                    return
                if not self.trackers:
                    self._discovery_report("Magnet sem tracker informado.")
                    return
                self._set_discovery_status("Trackers em paralelo (%d fonte(s))" % len(self.trackers))
                results["tracker"] = discover_trackers(
                    self.trackers,
                    self.info_hash,
                    self.peer_id,
                    left=left,
                    limit=80,
                    port=self.peer_port,
                    event="started" if not self._tracker_started else None,
                    reporter=self._discovery_report,
                    peer_callback=receiver,
                    stop_event=round_stop,
                    max_workers=4,
                    round_timeout=18.0,
                    http_timeout=4.0,
                    udp_timeout=3.0,
                )
                self._tracker_started = True

            def run_dht():
                if not self.enable_dht:
                    self._discovery_report("DHT desativado nas configurações.")
                    return
                self._set_discovery_status("DHT em paralelo com trackers")
                results["dht"] = discover_dht(
                    self.info_hash,
                    max_queries=18,
                    timeout=0.45,
                    reporter=self._discovery_report,
                    peer_callback=receiver,
                    stop_event=round_stop,
                )

            if self.enable_trackers and self.trackers:
                workers.append(threading.Thread(target=run_trackers, name="PureTorrentTrackers", daemon=True))
            if self.enable_dht:
                workers.append(threading.Thread(target=run_dht, name="PureTorrentDHT", daemon=True))

            for worker in workers:
                worker.start()

            round_deadline = time.monotonic() + 20.0
            while not self.closed.is_set() and time.monotonic() < round_deadline:
                if all(not worker.is_alive() for worker in workers):
                    break
                self.closed.wait(0.10)
            round_stop.set()
            for worker in workers:
                if worker.is_alive() and worker is not threading.current_thread():
                    worker.join(timeout=0.20)

            with self._lock:
                tracker_count = self.tracker_peer_count
                dht_count = self.dht_peer_count
                lpd_count = self.lpd_peer_count
                pex_count = self.pex_peer_count
                queued = len(self._candidate_peers)
                connected = sum(1 for peer in self._peers.values() if peer.connected)
            found = tracker_count + dht_count + lpd_count + pex_count
            if found:
                status = "Rodada %d: %d peer(s) liberado(s)" % (round_number, found)
                self._set_discovery_status("%s [T:%d DHT:%d LAN:%d PEX:%d fila:%d conectados:%d]" % (
                    status, tracker_count, dht_count, lpd_count, pex_count, queued, connected))
            else:
                status = "Rodada %d: nenhuma fonte retornou peer" % round_number
                self._set_discovery_status("%s [T:%d DHT:%d LAN:%d PEX:%d]" % (status, tracker_count, dht_count, lpd_count, pex_count))

            retry_seconds = 25.0 if not self.metadata_ready.is_set() and connected == 0 else 90.0
            self._wake_discovery.wait(retry_seconds)
            self._wake_discovery.clear()
            if self.closed.is_set():
                break

    def refresh_discovery(self):
        """Acorda a próxima rodada quando a Wasmer entrega trackers extras."""
        self._wake_discovery.set()

    def _maybe_refresh_stalled_swarm(self):
        """Refaz descoberta normal somente quando o swarm realmente estagnou.

        Não mexe em limite de conexões, timeout TCP, lista de trackers ou DHT.
        A primeira rodada normal pode receber peers antigos do tracker. Se a
        metadata já está íntegra, mas nenhum bloco completo foi validado e não
        há tráfego recente, uma nova rodada pode obter um anúncio atualizado.
        Há no máximo duas tentativas por sessão.
        """
        if self.closed.is_set() or not self.metadata_ready.is_set():
            return
        now = time.monotonic()
        with self._lock:
            if self.completed_pieces or self._stalled_swarm_refreshes >= 2:
                return
            if self._metadata_ready_at <= 0.0 or now < self._next_stalled_refresh_at:
                return
            # Não concorre com peer que ainda está entregando blocos; uma peça
            # pode ser grande e ainda não ter sido concluída/validada.
            if self._status_speed_samples and now - self._status_speed_samples[-1][0] < 8.0:
                self._next_stalled_refresh_at = now + 12.0
                return
            self._stalled_swarm_refreshes += 1
            attempt = self._stalled_swarm_refreshes
            # 18s para a primeira recuperação e uma única segunda janela mais
            # espaçada. Não cria ciclo infinito em swarm sem seed.
            self._next_stalled_refresh_at = now + (42.0 if attempt == 1 else 10 ** 9)
        self.log(
            "Sem bloco validado após metadata; renovando descoberta normal de trackers/DHT (tentativa %d/2)." % attempt,
            "debug",
        )
        self.refresh_discovery()

    def _connect_candidates(self):
        with self._lock:
            active = [peer for peer in self._peers.values() if peer.running.is_set()]
            connected_or_starting = len(active)
            connecting = sum(1 for peer in active if not peer.connected)
            open_slots = self.max_peers - connected_or_starting
            new_budget = max(0, MAX_CONCURRENT_CONNECT_ATTEMPTS - connecting)
            candidates = []
            while open_slots > 0 and new_budget > 0 and self._candidate_peers:
                candidates.append(self._candidate_peers.popleft())
                open_slots -= 1
                new_budget -= 1
        for host, port in candidates:
            peer = PeerConnection(self, host, port)
            with self._lock:
                if peer.key in self._peers:
                    continue
                self._peers[peer.key] = peer
            peer.start()

    def accept_incoming_peer(self, conn, address, handshake):
        host, port = address[0], int(address[1])
        key = "%s:%d" % (host, port)
        with self._lock:
            active = sum(1 for peer in self._peers.values() if peer.running.is_set())
            if self.closed.is_set() or key in self._peers or active >= self.max_peers:
                try:
                    conn.close()
                except OSError:
                    pass
                return False
            peer = PeerConnection(self, host, port, incoming_socket=conn, incoming_handshake=handshake)
            self._peers[key] = peer
        peer.start()
        return True

    def on_peer_connected(self, peer):
        if self.metadata_ready.is_set():
            # O addon não implementa upload: não anuncia HAVE/bitfield para
            # evitar prometer peças que não poderá servir ao peer remoto.
            peer.send_interested()
        self.notify_scheduler()

    def on_peer_disconnected(self, peer, reason=""):
        was_connected = getattr(peer, "was_connected_once", False)
        with self._lock:
            self._peers.pop(peer.key, None)
            for block_key, owners in list(self.pending_blocks.items()):
                if peer.key in owners:
                    owners.pop(peer.key, None)
                    peer.pending_count = max(0, peer.pending_count - 1)
                if not owners:
                    self.pending_blocks.pop(block_key, None)
            self._condition.notify_all()
        self.notify_scheduler()
        
        if reason:
            reason_lower = reason.lower()
            diag = ""
            if "timed out" in reason_lower or "timeout" in reason_lower:
                diag = " (Possivel bloqueio de firewall/NAT agressivo, roteador sem UPnP, ou peer offline)"
            elif "refused" in reason_lower or "recusada" in reason_lower:
                diag = " (Conexao recusada: firewall de saida local bloqueando ou porta remota fechada)"
            elif "reset" in reason_lower or "redefinida" in reason_lower:
                diag = " (Conexao redefinida pelo peer: conexao encerrada abruptamente)"
            elif "bep 10" in reason_lower or "metadata" in reason_lower:
                diag = " (Peer conectado mas nao tem suporte ao protocolo de metadados ut_metadata)"
            elif "handshake" in reason_lower:
                diag = " (Falha de handshake BitTorrent: versao ou info_hash incompativel)"
            
            status_str = "Conexao com" if was_connected else "Tentativa de conexao a"
            action_str = "encerrada" if was_connected else "falhou"
            self.log(f"[{peer.key}] {status_str} peer {action_str}: {reason}{diag}", "debug")

    def on_peer_extensions(self, peer):
        if not peer.extensions_logged:
            peer.extensions_logged = True
        with self._lock:
            if self.metadata_ready.is_set() or peer.remote_metadata_id is None:
                return
            if peer.metadata_size and (self._metadata_size is None or peer.metadata_size < self._metadata_size):
                self._metadata_size = peer.metadata_size
            if self._metadata_size is None:
                return
            if self._metadata_size > MAX_METADATA_SIZE:
                self.set_error("Metadata do torrent excede o limite permitido")
                return
            total_parts = (self._metadata_size + METADATA_BLOCK_SIZE - 1) // METADATA_BLOCK_SIZE
            for index in range(total_parts):
                if index in self._metadata_parts:
                    continue
                owner = self._metadata_requested.get(index)
                if owner and time.monotonic() - owner[1] < 8.0:
                    continue
                self._metadata_requested[index] = (peer.key, time.monotonic())
                self._metadata_attempts[index] = self._metadata_attempts.get(index, 0) + 1
                peer.send_extended(peer.remote_metadata_id, bencode({b"msg_type": 0, b"piece": index}))
                if sum(1 for key, value in self._metadata_requested.items() if value[0] == peer.key) >= 4:
                    break

    def on_peer_pex(self, peer, payload):
        if not isinstance(payload, dict) or self.closed.is_set():
            return
        def get_val(d, key):
            if not isinstance(d, dict):
                return None
            if key in d:
                return d[key]
            b_key = key.encode('utf-8') if isinstance(key, str) else key
            s_key = key.decode('utf-8', errors='ignore') if isinstance(key, bytes) else key
            if b_key in d:
                return d[b_key]
            if s_key in d:
                return d[s_key]
            return None

        peers = []
        added = get_val(payload, "added")
        if isinstance(added, (bytes, bytearray)):
            peers.extend(parse_compact_peers(added, socket.AF_INET))
        added6 = get_val(payload, "added6")
        if isinstance(added6, (bytes, bytearray)):
            peers.extend(parse_compact_peers(added6, socket.AF_INET6))
        if peers:
            self._receive_discovered_peers(peers, "pex")

    def on_metadata_message(self, peer, header, data):
        def get_val(d, key):
            if not isinstance(d, dict):
                return None
            if key in d:
                return d[key]
            b_key = key.encode('utf-8') if isinstance(key, str) else key
            s_key = key.decode('utf-8', errors='ignore') if isinstance(key, bytes) else key
            if b_key in d:
                return d[b_key]
            if s_key in d:
                return d[s_key]
            return None

        message_type = get_val(header, "msg_type")
        piece_index = get_val(header, "piece")
        if message_type != 1 or not isinstance(piece_index, int) or piece_index < 0:
            return
        total_size = get_val(header, "total_size")
        with self._lock:
            if isinstance(total_size, int) and 0 < total_size <= MAX_METADATA_SIZE:
                if self._metadata_size is None:
                    self._metadata_size = total_size
                elif self._metadata_size != total_size:
                    peer.failures += 1
                    return
            if self._metadata_size is None:
                return
            expected = min(METADATA_BLOCK_SIZE, self._metadata_size - piece_index * METADATA_BLOCK_SIZE)
            if expected <= 0 or len(data) < expected:
                peer.failures += 1
                return
            self._metadata_parts[piece_index] = bytes(data[:expected])
            self._metadata_requested.pop(piece_index, None)
            part_count = (self._metadata_size + METADATA_BLOCK_SIZE - 1) // METADATA_BLOCK_SIZE
            if len(self._metadata_parts) < part_count:
                self.on_peer_extensions(peer)
                return
            raw_info = b"".join(self._metadata_parts[index] for index in range(part_count))[:self._metadata_size]
        self._install_metadata(raw_info)

    def _install_metadata(self, raw_info):
        try:
            info = bdecode(raw_info)
            if not isinstance(info, dict):
                raise TorrentError("metadata sem dicionário info")
            expected_hash = hashlib.sha1(bencode(info)).digest()
            if expected_hash != self.info_hash:
                raise TorrentError("hash do metadata não confere com o magnet")
            self._parse_info(info)
        except (BencodeError, TorrentError, ValueError) as exc:
            self.set_error("Falha ao validar metadata: %s" % exc)
            return

        with self._lock:
            if self.metadata_ready.is_set():
                return
            self.info = info
            self.metadata_ready.set()
            self.playback_offset = self.selected_file["offset"] if self.selected_file else 0
            self._metadata_ready_at = time.monotonic()
            self._stalled_swarm_refreshes = 0
            self._next_stalled_refresh_at = self._metadata_ready_at + 18.0
            self._condition.notify_all()
        for peer in list(self._peers.values()):
            if peer.connected:
                peer.send_interested()
        self.notify_scheduler()

    def _parse_info(self, info):
        def get_val(d, key):
            if not isinstance(d, dict):
                return None
            if key in d:
                return d[key]
            b_key = key.encode('utf-8') if isinstance(key, str) else key
            s_key = key.decode('utf-8', errors='ignore') if isinstance(key, bytes) else key
            if b_key in d:
                return d[b_key]
            if s_key in d:
                return d[s_key]
            return None

        piece_length = get_val(info, "piece length")
        pieces = get_val(info, "pieces")
        if not isinstance(piece_length, int) or piece_length < BLOCK_SIZE or piece_length > 16 * 1024 * 1024:
            raise TorrentError("piece length inválido")
        if not isinstance(pieces, bytes) or not pieces or len(pieces) % 20:
            raise TorrentError("hashes de peças inválidos")

        files = []
        offset = 0
        root_bytes = get_val(info, "name") or self.display_name.encode("utf-8", "replace")
        root_name = _safe_filename(root_bytes)
        
        info_files = get_val(info, "files")
        if isinstance(info_files, list):
            for entry in info_files:
                if not isinstance(entry, dict):
                    continue
                length = get_val(entry, "length")
                parts = get_val(entry, "path")
                if not isinstance(length, int) or length < 0 or not isinstance(parts, list):
                    continue
                clean_parts = [_safe_filename(part) for part in parts if isinstance(part, (bytes, str))]
                # Mantém o caminho completo para o cache, mas também expõe o caminho
                # relativo para que a interface possa navegar por temporadas/subpastas.
                file_name = "/".join([root_name] + clean_parts) if clean_parts else root_name
                relative_path = "/".join(clean_parts) if clean_parts else root_name
                files.append({
                    "index": len(files),
                    "name": file_name,
                    "relative_path": relative_path,
                    "basename": clean_parts[-1] if clean_parts else root_name,
                    "length": length,
                    "offset": offset,
                })
                offset += length
        else:
            length = get_val(info, "length")
            if not isinstance(length, int) or length < 0:
                raise TorrentError("torrent sem tamanho de arquivo")
            files.append({
                "index": 0,
                "name": root_name,
                "relative_path": root_name,
                "basename": root_name,
                "length": length,
                "offset": 0,
            })
            offset = length

        if not files or offset <= 0:
            raise TorrentError("torrent sem arquivos reproduzíveis")
        expected_pieces = (offset + piece_length - 1) // piece_length
        if expected_pieces != len(pieces) // 20:
            raise TorrentError("quantidade de hashes não bate com o tamanho")

        self.piece_length = piece_length
        self.piece_hashes = [pieces[index:index + 20] for index in range(0, len(pieces), 20)]
        self.total_length = offset
        self.files = files
        self.selected_file = self._select_video_file(files)
        if self.selected_file is None:
            raise TorrentError("torrent não possui arquivo de vídeo compatível")
        self._configure_startup_prefetch()
        self.cache.setup_files(self.files, self.total_length, self.piece_length, self.piece_hashes)

    @staticmethod
    def _select_video_file(files):
        """Escolhe somente mídia de vídeo reconhecida de forma unificada.

        A seleção automática favorece o maior arquivo de vídeo, que costuma ser
        o filme/episódio principal. Em empate, a preferência apenas estabiliza o
        resultado; MKV, AVI e os demais containers continuam candidatos reais.
        """
        container_tiebreak = {
            ".mkv": 0, ".mp4": 1, ".m4v": 2, ".mov": 3, ".avi": 4,
            ".webm": 5, ".ts": 6, ".m2ts": 7, ".mts": 8,
        }
        candidates = []
        for item in files:
            name = str(item.get("name", ""))
            if not is_video_name(name):
                continue
            length = max(0, _int(item.get("length"), 0))
            if length <= 0:
                continue
            extension = os.path.splitext(name.lower())[1]
            candidates.append((
                -length,
                container_tiebreak.get(extension, 99),
                name.casefold(),
                _int(item.get("index"), 0),
                item,
            ))
        if not candidates:
            return None
        candidates.sort(key=lambda row: row[:4])
        return candidates[0][4]

    @staticmethod
    def _public_file(item):
        if not item:
            return None
        return {
            "index": int(item["index"]),
            "name": item["name"],
            "relative_path": item.get("relative_path", item["name"]),
            "basename": item.get("basename", os.path.basename(item["name"])),
            "length": int(item["length"]),
            "extension": os.path.splitext(item["name"].lower())[1],
        }

    def list_primary_video_files(self):
        if not self.metadata_ready.is_set():
            return []
        with self._lock:
            return [
                self._public_file(item)
                for item in self.files
                if is_video_name(item.get("name", ""))
                and item["length"] > 0
            ]

    def select_video_file(self, file_index):
        try:
            file_index = int(file_index)
        except (TypeError, ValueError):
            raise TorrentError("Índice de arquivo inválido")
        if not self.metadata_ready.is_set():
            raise TorrentError("metadata ainda não disponível")

        with self._lock:
            selected = None
            for item in self.files:
                if item.get("index") == file_index:
                    selected = item
                    break
            if selected is None:
                raise TorrentError("Arquivo selecionado não existe neste torrent")
            
            changed = self.selected_file is None or self.selected_file.get("index") != selected["index"]
            self.selected_file = selected
            # /status e cada Range HTTP reconfirmam o mesmo arquivo. Antes,
            # essas confirmações zeravam playback_offset, fazendo um seek alto
            # perder prioridade para o começo. Só troca de arquivo reinicia o
            # cursor e recalcula o pré-buffer de abertura.
            if changed:
                self.playback_offset = selected["offset"]
                self._configure_startup_prefetch()
                self._stream_demands.clear()
                extension = os.path.splitext(str(selected.get("name", "")).lower())[1] or "sem extensão"
                self.log("Mídia de vídeo selecionada: %s (%s)." % (selected.get("name", "arquivo"), extension), "info")
            self.last_used = time.monotonic()
            self._condition.notify_all()

        self.notify_scheduler()
        return self._public_file(selected)

    def _configure_startup_prefetch(self):
        """Configura a janela extra de abertura para containers MP4/MOV.

        MP4/MOV podem manter o átomo ``moov`` no fim. O VideoPlayer consulta
        esse trecho durante a abertura mesmo quando o usuário começou em 0.
        Para evitar timeout/arquivo parcial, o motor baixa uma pequena cauda
        somente nesses containers. O restante do buffer continua conservador.
        """
        selected = self.selected_file
        if not selected:
            self._startup_head_target_bytes = 0
            self._startup_tail_start = None
            self._startup_tail_target_bytes = 0
            self._startup_tail_required = False
            return

        file_start = int(selected.get("offset", 0))
        file_length = max(0, int(selected.get("length", 0)))
        file_end = file_start + file_length
        self._startup_head_target_bytes = min(file_length, self.buffer_size_bytes)

        mp4_like = is_mp4_like_name(selected.get("name", ""))
        if not mp4_like or file_length <= self._startup_head_target_bytes:
            self._startup_tail_start = None
            self._startup_tail_target_bytes = 0
            self._startup_tail_required = False
            return

        # Oito MiB cobre o índice final comum sem transformar o addon em
        # downloader completo. Em torrents de peças maiores, preserva pelo
        # menos quatro peças para que a borda da janela seja íntegra.
        tail_window = min(16 * 1024 * 1024, max(8 * 1024 * 1024, self.piece_length * 4))
        tail_window = min(file_length, tail_window)
        self._startup_tail_start = max(file_start, file_end - tail_window)
        self._startup_tail_target_bytes = file_end - self._startup_tail_start
        self._startup_tail_required = self._startup_tail_target_bytes > 0

    def _contiguous_completed_bytes(self, start, end):
        """Conta bytes completos consecutivos em um intervalo absoluto."""
        if not self.metadata_ready.is_set() or end <= start or self.piece_length <= 0:
            return 0
        position = int(start)
        end = int(end)
        while position < end:
            piece_index = position // self.piece_length
            if piece_index not in self.completed_pieces:
                break
            position = min(end, (piece_index + 1) * self.piece_length)
        return max(0, position - int(start))

    def _startup_buffer_state(self):
        """Estado do buffer de abertura, incluindo índice final de MP4."""
        if not self.metadata_ready.is_set() or not self.selected_file:
            return {
                "head_bytes": 0,
                "head_target": 0,
                "tail_bytes": 0,
                "tail_target": 0,
                "tail_required": False,
                "ready": False,
            }

        file_start = int(self.selected_file["offset"])
        file_end = file_start + int(self.selected_file["length"])
        head_target = min(file_end - file_start, max(0, int(self._startup_head_target_bytes)))
        head_bytes = self._contiguous_completed_bytes(file_start, file_start + head_target)

        tail_required = bool(self._startup_tail_required and self._startup_tail_start is not None)
        tail_target = int(self._startup_tail_target_bytes) if tail_required else 0
        tail_bytes = 0
        if tail_required:
            tail_bytes = self._contiguous_completed_bytes(int(self._startup_tail_start), file_end)

        ready = head_bytes >= head_target and (not tail_required or tail_bytes >= tail_target)
        return {
            "head_bytes": head_bytes,
            "head_target": head_target,
            "tail_bytes": tail_bytes,
            "tail_target": tail_target,
            "tail_required": tail_required,
            "ready": ready,
        }

    def selected_file_info(self):
        if not self.metadata_ready.is_set():
            return None
        with self._lock:
            return self._public_file(self.selected_file)

    def _piece_size(self, piece_index):
        if piece_index < 0 or piece_index >= len(self.piece_hashes):
            return 0
        if piece_index == len(self.piece_hashes) - 1:
            return self.total_length - (piece_index * self.piece_length)
        return self.piece_length

    def _piece_indices_for_range(self, start, length):
        if not self.metadata_ready.is_set() or length <= 0:
            return []
        end = min(self.total_length - 1, start + length - 1)
        if start < 0 or end < start:
            return []
        return list(range(start // self.piece_length, end // self.piece_length + 1))

    def _wanted_pieces(self):
        if not self.metadata_ready.is_set() or not self.selected_file:
            return []

        file_start = int(self.selected_file["offset"])
        file_end = file_start + int(self.selected_file["length"])
        if file_end <= file_start:
            return []

        # As leituras HTTP são independentes: o GET sequencial inicial não pode
        # rebaixar um Range do índice MP4 ou um seek que o Kodi acabou de pedir.
        demands = self._ordered_stream_demands()
        cursor = min(max(self.playback_offset, file_start), file_end - 1)

        urgent = []
        for demand in demands[:3]:
            position = min(max(file_start, int(demand.get("position", cursor))), file_end - 1)
            requested_end = min(file_end, max(position + 1, int(demand.get("end", position + 1))))
            window = max(
                min(STREAM_URGENT_WINDOW_BYTES, self.buffer_size_bytes),
                requested_end - position,
                self.piece_length * 2,
            )
            window = min(file_end - position, window)
            urgent.extend(self._piece_indices_for_range(position, max(1, window)))
            if demand.get("explicit"):
                cursor = position

        # A primeira faixa mantém o início do arquivo disponível ao player.
        head_target = min(file_end, file_start + max(1, int(self._startup_head_target_bytes or self.buffer_size_bytes)))
        prime_size = min(head_target - file_start, max(4 * 1024 * 1024, self.piece_length * 2))
        head_prime = self._piece_indices_for_range(file_start, max(1, prime_size))
        head_full = self._piece_indices_for_range(file_start, max(1, head_target - file_start))

        # Para MP4/MOV, o índice pode estar no fim. A janela final é mantida
        # como prioridade de abertura, sem concorrer com um Range explícito.
        tail = []
        if self._startup_tail_required and self._startup_tail_start is not None:
            tail = self._piece_indices_for_range(
                int(self._startup_tail_start),
                max(1, file_end - int(self._startup_tail_start)),
            )

        current_window = min(file_end, cursor + min(self.buffer_size_bytes, STREAM_URGENT_WINDOW_BYTES))
        current = self._piece_indices_for_range(cursor, max(1, current_window - cursor))
        background_size = max(96 * 1024 * 1024, self.buffer_size_bytes * 4)
        background_end = min(file_end, cursor + background_size)
        background = self._piece_indices_for_range(cursor, max(1, background_end - cursor))
        behind_start = max(file_start, cursor - 4 * 1024 * 1024)
        behind = self._piece_indices_for_range(behind_start, max(0, cursor - behind_start))

        ordered = []
        for index in urgent + head_prime + tail + current + head_full + behind + background:
            if index not in self.completed_pieces and index not in ordered:
                ordered.append(index)
        return ordered

    def _availability(self, piece_index):
        # O scheduler e as threads de peer rodam em paralelo. Copiar a lista
        # sob lock evita RuntimeError quando um peer encerra durante a iteração.
        with self._lock:
            peers = list(self._peers.values())
        return sum(1 for peer in peers if peer.connected and peer.has_piece(piece_index))

    def _peer_has_rare_urgent_piece(self, peer):
        for index in self._wanted_pieces()[:24]:
            if peer.has_piece(index) and self._availability(index) <= 1:
                return True
        return False

    def _peer_score(self, peer, piece_index, urgent_indices=None):
        if not peer.connected or peer.choked or not peer.has_piece(piece_index):
            return float("-inf")
        speed = peer.speed_bps()
        urgency = 8.0 if urgent_indices and piece_index in urgent_indices else 0.0
        rarity = 3.0 / max(1, self._availability(piece_index))
        load_penalty = peer.pending_count * 1.75
        failure_penalty = (peer.failures + peer.invalid_blocks * 3) * 3.0
        return min(speed / 32768.0, 20.0) + urgency + rarity - load_penalty - failure_penalty

    def _next_missing_block(self, piece_index):
        piece_size = self._piece_size(piece_index)
        blocks = self.piece_blocks.get(piece_index, {})
        for begin in range(0, piece_size, BLOCK_SIZE):
            size = min(BLOCK_SIZE, piece_size - begin)
            if begin in blocks:
                continue
            if (piece_index, begin) not in self.pending_blocks:
                return begin, size
        return None

    def _reap_stale_requests(self):
        now = time.monotonic()
        with self._lock:
            for block_key, owners in list(self.pending_blocks.items()):
                for peer_key, started_at in list(owners.items()):
                    if now - started_at > REQUEST_TIMEOUT_SECONDS:
                        owners.pop(peer_key, None)
                        peer = self._peers.get(peer_key)
                        if peer:
                            peer.pending_count = max(0, peer.pending_count - 1)
                            peer.failures += 1
                if not owners:
                    self.pending_blocks.pop(block_key, None)

    def _maintain_metadata_peers(self):
        if self.metadata_ready.is_set():
            return
        now = time.monotonic()
        retry_peers = []
        close_peers = []
        with self._lock:
            for index, owner in list(self._metadata_requested.items()):
                peer_key, requested_at = owner
                if now - requested_at <= METADATA_REQUEST_TIMEOUT_SECONDS:
                    continue
                self._metadata_requested.pop(index, None)
                peer = self._peers.get(peer_key)
                if peer:
                    peer.failures += 1
            for peer in list(self._peers.values()):
                if not peer.connected:
                    continue
                age = now - peer.connected_at
                if not peer.supports_extensions:
                    close_peers.append((peer, "peer sem BEP 10/metadata"))
                    continue
                if not peer.extensions_received_at:
                    if age >= METADATA_EXTENSION_TIMEOUT_SECONDS:
                        close_peers.append((peer, "não enviou handshake estendido"))
                    continue
                if peer.remote_metadata_id is None or not peer.metadata_size:
                    if age >= METADATA_EXTENSION_TIMEOUT_SECONDS:
                        close_peers.append((peer, "não oferece ut_metadata"))
                    continue
                retry_peers.append(peer)
        for peer, reason in close_peers:
            peer.close(reason)
        for peer in retry_peers:
            self.on_peer_extensions(peer)

    # def _schedule_piece_requests(self):
    #     wanted = self._wanted_pieces()
    #     if not wanted:
    #         return
    #     peers = [peer for peer in self._peers.values() if peer.connected and not peer.choked]
    #     peers.sort(key=lambda peer: peer.speed_bps(), reverse=True)
    #     active = peers[:self.active_peer_limit]
    #     for peer in active:
    #         #pipeline = max(2, min(8, 2 + int(peer.speed_bps() / (96 * 1024))))
    #         pipeline = max(3, min(12, 4 + int(peer.speed_bps() / (64 * 1024))))
    #         while peer.pending_count < pipeline:
    #             selected = None
    #             for piece_index in wanted:
    #                 candidate = self._next_missing_block(piece_index)
    #                 if candidate is None or not peer.has_piece(piece_index):
    #                     continue
    #                 score = self._peer_score(peer, piece_index)
    #                 if score == float("-inf"):
    #                     continue
    #                 selected = (piece_index, candidate[0], candidate[1])
    #                 break
    #             if selected is None:
    #                 break
    #             piece_index, begin, size = selected
    #             block_key = (piece_index, begin)
    #             with self._lock:
    #                 self.pending_blocks.setdefault(block_key, {})[peer.key] = time.monotonic()
    #                 peer.pending_count += 1
    #             if not peer.send_request(piece_index, begin, size):
    #                 with self._lock:
    #                     owners = self.pending_blocks.get(block_key, {})
    #                     owners.pop(peer.key, None)
    #                     if not owners:
    #                         self.pending_blocks.pop(block_key, None)
    #                     peer.pending_count = max(0, peer.pending_count - 1)
    #                 break
    def _schedule_piece_requests(self):
        """Agenda os pedidos de blocos para os peers conectados."""
        wanted = self._wanted_pieces()
        if not wanted:
            return

        # Proteção contra RuntimeError (deque mutated during iteration)
        with self._lock:
            peers = [peer for peer in self._peers.values() 
                    if peer.connected and not peer.choked]

        if not peers:
            return

        # Ordena por velocidade (usando a versão thread-safe do speed_bps)
        peers.sort(key=lambda peer: peer.speed_bps(), reverse=True)

        # Limita aos peers mais rápidos
        active_peers = peers[:self.active_peer_limit]
        urgent_indices = set(wanted[:8])

        for peer in active_peers:
            # Pipeline dinâmico (quantos requests simultâneos por peer)
            pipeline = max(3, min(12, 4 + int(peer.speed_bps() / (64 * 1024))))

            while peer.pending_count < pipeline:
                selected = None
                for piece_index in wanted:
                    candidate = self._next_missing_block(piece_index)
                    if candidate is None:
                        continue
                    if not peer.has_piece(piece_index):
                        continue

                    score = self._peer_score(peer, piece_index, urgent_indices)
                    if score == float("-inf"):
                        continue

                    selected = (piece_index, candidate[0], candidate[1])
                    break

                if selected is None:
                    break

                piece_index, begin, size = selected
                block_key = (piece_index, begin)

                with self._lock:
                    if block_key in self.pending_blocks and peer.key in self.pending_blocks[block_key]:
                        continue
                    self.pending_blocks.setdefault(block_key, {})[peer.key] = time.monotonic()
                    peer.pending_count += 1

                if not peer.send_request(piece_index, begin, size):
                    # Se falhar ao enviar, desfaz o agendamento
                    with self._lock:
                        owners = self.pending_blocks.get(block_key, {})
                        owners.pop(peer.key, None)
                        if not owners:
                            self.pending_blocks.pop(block_key, None)
                        peer.pending_count = max(0, peer.pending_count - 1)
                    break    

    def _prune_slow_peers(self):
        now = time.monotonic()
        peers = list(self._peers.values())
        # Acima de uma base útil de peers, libera slots de conexões antigas que
        # não entregam dados. O limite antigo era igual ao máximo total e, na
        # prática, nunca podava ninguém.
        if len(peers) <= min(8, self.active_peer_limit):
            return
        for peer in peers:
            if not peer.connected or peer.pending_count:
                continue
            age = now - peer.connected_at
            if age < 60.0: 
                continue
            #if peer.speed_bps() < 2 * 1024 and not self._peer_has_rare_urgent_piece(peer):
            if peer.speed_bps() < 1024 and not self._peer_has_rare_urgent_piece(peer):
                peer.close("lento e sem peça rara na janela")

    def _purge_cache_if_needed(self):
        if self.cache_bytes <= self.cache_limit_bytes or not self.metadata_ready.is_set():
            return
        cursor_piece = self.playback_offset // self.piece_length
        background_size = max(100 * 1024 * 1024, self.buffer_size_bytes * 5)
        protected = set(self._piece_indices_for_range(
            max(0, self.playback_offset - 4 * 1024 * 1024),
            background_size + 4 * 1024 * 1024,
        ))
        candidates = sorted(
            [index for index in self.completed_pieces if index not in protected],
            key=lambda index: abs(index - cursor_piece),
            reverse=True,
        )
        for index in candidates:
            if self.cache_bytes <= self.cache_limit_bytes:
                break
            size = self._piece_size(index)
            self.cache.remove_piece(index)
            self.completed_pieces.discard(index)
            self.cache_bytes = max(0, self.cache_bytes - size)

    def _scheduler_loop(self):
        while not self.closed.is_set():
            self._connect_candidates()
            self._reap_stale_requests()
            self._unchoke_peers() 
            if self.metadata_ready.is_set():
                self._schedule_piece_requests()
                self._maybe_refresh_stalled_swarm()
                self._prune_slow_peers()
                self._purge_cache_if_needed()
            else:
                self._maintain_metadata_peers()
            self._wake_scheduler.wait(0.18)
            self._wake_scheduler.clear()

    def notify_scheduler(self):
        self._wake_scheduler.set()

    def _unchoke_peers(self):
        """Garante estado Interested sem repetir mensagens para peers choked."""
        with self._lock:
            peers = list(self._peers.values())
        for peer in peers:
            if peer.connected and not peer.interested:
                peer.send_interested()

    def on_piece_block(self, peer, piece_index, begin, block):
        if not self.metadata_ready.is_set():
            return
        expected_piece_size = self._piece_size(piece_index)
        expected_length = min(BLOCK_SIZE, expected_piece_size - begin)
        if expected_piece_size <= 0 or begin < 0 or expected_length <= 0 or len(block) != expected_length:
            peer.invalid_blocks += 1
            return

        block_key = (piece_index, begin)
        with self._lock:
            owners = self.pending_blocks.pop(block_key, {})
            for owner_key in owners:
                owner = self._peers.get(owner_key)
                if owner:
                    owner.pending_count = max(0, owner.pending_count - 1)
            if piece_index in self.completed_pieces:
                return
            blocks = self.piece_blocks.setdefault(piece_index, {})
            if begin in blocks:
                return
            blocks[begin] = bytes(block)
            self._status_speed_samples.append((time.monotonic(), len(block)))
            expected_blocks = (expected_piece_size + BLOCK_SIZE - 1) // BLOCK_SIZE
            if len(blocks) < expected_blocks:
                self.notify_scheduler()
                return
            data = b"".join(blocks[offset] for offset in range(0, expected_piece_size, BLOCK_SIZE))
            is_mock = getattr(self, "is_mock_metadata", False)
            if len(data) != expected_piece_size or (not is_mock and hashlib.sha1(data).digest() != self.piece_hashes[piece_index]):
                self.piece_blocks.pop(piece_index, None)
                peer.invalid_blocks += 1
                self.notify_scheduler()
                return
            try:
                self.cache.write_piece(piece_index, data)
            except OSError as exc:
                self.set_error("Falha ao gravar cache local: %s" % exc)
                return
            self.completed_pieces.add(piece_index)
            self.cache_bytes += len(data)
            self.piece_blocks.pop(piece_index, None)
            self._condition.notify_all()
            # O cliente é somente downloader: não anuncia HAVE sem responder
            # requests de upload do protocolo BitTorrent.
        self.notify_scheduler()

    def set_error(self, message):
        with self._lock:
            if not self.error:
                self.error = message
            self._condition.notify_all()

    def wait_for_metadata(self, timeout=35.0):
        self.start()
        deadline = time.monotonic() + timeout
        while not self.closed.is_set() and not self.metadata_ready.is_set():
            if self.error:
                return False
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False
            self.metadata_ready.wait(min(0.5, remaining))
        return self.metadata_ready.is_set()

    def _cleanup_stream_demands_locked(self, now=None):
        now = time.monotonic() if now is None else float(now)
        stale = [
            token for token, demand in self._stream_demands.items()
            if now - float(demand.get("updated_at", 0.0)) > STREAM_DEMAND_STALE_SECONDS
        ]
        for token in stale:
            self._stream_demands.pop(token, None)

    def begin_stream_request(self, file_position, length, explicit_range=False):
        """Registra uma leitura HTTP ativa e devolve um token interno.

        Ranges explícitos do Kodi (índice/seek) recebem prioridade sobre a
        leitura sequencial já aberta. O token é removido quando a conexão HTTP
        termina, portanto não fixa um seek antigo no scheduler.
        """
        if not self.metadata_ready.is_set() or not self.selected_file:
            raise TorrentError("metadata ainda não disponível")
        start = int(self.selected_file["offset"])
        end = start + int(self.selected_file["length"])
        position = min(max(start, int(file_position)), max(start, end - 1))
        request_end = min(end, position + max(1, int(length or 1)))
        now = time.monotonic()
        with self._lock:
            self._cleanup_stream_demands_locked(now)
            self._stream_demand_sequence += 1
            token = "stream-%d" % self._stream_demand_sequence
            self._stream_demands[token] = {
                "position": position,
                "end": request_end,
                "explicit": bool(explicit_range),
                "sequence": self._stream_demand_sequence,
                "updated_at": now,
            }
            # O cursor de diagnóstico acompanha o Range explícito mais recente
            # ou a leitura sequencial quando não há seek pendente.
            if explicit_range or not any(
                item.get("explicit") and key != token
                for key, item in self._stream_demands.items()
            ):
                self.playback_offset = position
            self.last_used = now
        self.notify_scheduler()
        return token

    def update_stream_request(self, token, file_position, length=0):
        if not token or not self.metadata_ready.is_set() or not self.selected_file:
            return
        start = int(self.selected_file["offset"])
        end = start + int(self.selected_file["length"])
        position = min(max(start, int(file_position)), max(start, end - 1))
        now = time.monotonic()
        with self._lock:
            self._cleanup_stream_demands_locked(now)
            demand = self._stream_demands.get(token)
            if not demand:
                return
            demand["position"] = position
            demand["end"] = min(end, position + max(1, int(length or 1)))
            demand["updated_at"] = now
            explicit_pending = any(item.get("explicit") for item in self._stream_demands.values())
            if demand.get("explicit") or not explicit_pending:
                self.playback_offset = position
            self.last_used = now
        self.notify_scheduler()

    def end_stream_request(self, token):
        if not token:
            return
        with self._lock:
            self._stream_demands.pop(token, None)
            self._cleanup_stream_demands_locked()
        self.notify_scheduler()

    def _ordered_stream_demands(self):
        """Snapshot das leituras HTTP, mais recente/urgente primeiro."""
        with self._lock:
            self._cleanup_stream_demands_locked()
            rows = [dict(item, token=token) for token, item in self._stream_demands.items()]
        rows.sort(key=lambda item: (0 if item.get("explicit") else 1, -int(item.get("sequence", 0))))
        return rows

    def set_playback_position(self, file_position):
        if not self.metadata_ready.is_set() or not self.selected_file:
            return
        start = self.selected_file["offset"]
        end = start + self.selected_file["length"]
        with self._lock:
            # Um Range explícito já ativo é mais importante que uma atualização
            # genérica vinda da leitura sequencial.
            has_explicit = any(item.get("explicit") for item in self._stream_demands.values())
            if not has_explicit:
                self.playback_offset = min(max(start, file_position), max(start, end - 1))
            self.last_used = time.monotonic()
        self.notify_scheduler()

    def _wait_for_piece(self, piece_index, timeout=120.0):
        deadline = time.monotonic() + timeout
        with self._condition:
            while piece_index not in self.completed_pieces and not self.closed.is_set():
                if self.error:
                    return False
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return False
                self._condition.wait(min(0.5, remaining))
        return piece_index in self.completed_pieces

    def read_file_range(self, file_position, length, timeout_per_piece=45.0, stream_request=None):
        if not self.metadata_ready.is_set() or self.selected_file is None:
            raise TorrentError("metadata ainda não disponível")
        if file_position < 0 or length < 0 or file_position + length > self.selected_file["length"]:
            raise TorrentError("Range fora do arquivo")
        if length == 0:
            return b""

        absolute = self.selected_file["offset"] + file_position
        if stream_request:
            self.update_stream_request(stream_request, absolute, length)
        else:
            self.set_playback_position(absolute)
        result = bytearray()
        remaining = length
        current = absolute
        while remaining > 0 and not self.closed.is_set():
            piece_index = current // self.piece_length
            inside = current % self.piece_length
            required = min(remaining, self._piece_size(piece_index) - inside)
            if stream_request:
                self.update_stream_request(stream_request, current, required)
            if not self._wait_for_piece(piece_index, timeout_per_piece):
                raise TorrentError(f"Peca {piece_index} nao recebida a tempo (timeout de {timeout_per_piece}s)")
            piece = self.cache.read_piece(piece_index)
            if piece is None or len(piece) != self._piece_size(piece_index):
                with self._lock:
                    self.completed_pieces.discard(piece_index)
                self.notify_scheduler()
                raise TorrentError(f"Peca {piece_index} corrompida ou ausente no cache")
            result.extend(piece[inside:inside + required])
            current += required
            remaining -= required
            if stream_request:
                self.update_stream_request(stream_request, current, max(1, remaining))
            else:
                self.set_playback_position(current)
        if remaining:
            raise TorrentError("Sessão encerrada antes de concluir o Range solicitado")
        return bytes(result)

    def _buffered_bytes_from_position(self):
        if not self.metadata_ready.is_set() or not self.selected_file:
            return 0
        file_start = self.selected_file["offset"]
        file_end = file_start + self.selected_file["length"]
        start = min(max(self.playback_offset, file_start), file_end)
        position = start
        while position < file_end:
            piece_index = position // self.piece_length
            if piece_index not in self.completed_pieces:
                break
            position = min(file_end, (piece_index + 1) * self.piece_length)
        return max(0, position - start)

    def _combined_speed(self):
        now = time.monotonic()
        samples = [(stamp, amount) for stamp, amount in self._status_speed_samples if now - stamp <= 12.0]
        if not samples:
            return 0.0
        return sum(amount for _, amount in samples) / max(1.0, now - samples[0][0])

    def status(self):
        self.start()
        with self._lock:
            connected = [peer for peer in self._peers.values() if peer.connected]
            active = [peer for peer in connected if peer.pending_count]
            startup = self._startup_buffer_state()
            self._cleanup_stream_demands_locked()
            demands = [dict(item) for item in self._stream_demands.values()]
            demands.sort(key=lambda item: (0 if item.get("explicit") else 1, -int(item.get("sequence", 0))))
            priority = demands[0] if demands else None
            if self.error:
                state = "erro"
            elif not self.metadata_ready.is_set():
                state = "buscando metadata"
            elif startup["ready"]:
                state = "pronto"
            else:
                state = "bufferizando"
            return {
                "state": state,
                "error": self.error,
                # Mantém o contrato existente: bytes_buffered representa a
                # janela inicial contínua. Os campos startup_* completam o
                # diagnóstico do índice final de MP4 sem quebrar clientes.
                "bytes_buffered": startup["head_bytes"],
                "buffer_target": startup["head_target"],
                "startup_ready": startup["ready"],
                "startup_tail_required": startup["tail_required"],
                "startup_tail_bytes": startup["tail_bytes"],
                "startup_tail_target": startup["tail_target"],
                "peers": len(connected),
                "active_peers": len(active),
                "speed_bps": int(self._combined_speed()),
                "file_name": self.selected_file["name"] if self.selected_file else self.display_name,
                "file_size": self.selected_file["length"] if self.selected_file else 0,
                "selected_file_index": self.selected_file["index"] if self.selected_file else None,
                "primary_video_count": len(self.list_primary_video_files()) if self.metadata_ready.is_set() else 0,
                "metadata_ready": self.metadata_ready.is_set(),
                "metadata_source": self.metadata_source or ("BEP 10" if self.metadata_ready.is_set() else ""),
                "metadata_resolution": self.metadata_resolution_state,
                "discovery": self.discovery_status,
                "discovery_round": self.discovery_round,
                "tracker_peers": self.tracker_peer_count,
                "dht_peers": self.dht_peer_count,
                "lpd_peers": self.lpd_peer_count,
                "pex_peers": self.pex_peer_count,
                "queued_peers": len(self._candidate_peers),
                # Telemetria leve para perícia de Range/seek sem expor dados
                # de peers: mostra somente a demanda HTTP que o scheduler está
                # priorizando no momento.
                "stream_requests": len(demands),
                "priority_range_start": int(priority.get("position", 0)) if priority else None,
                "priority_range_end": int(priority.get("end", 0)) if priority else None,
                "priority_range_explicit": bool(priority.get("explicit")) if priority else False,
            }

    def close(self, remove_cache=True):
        if self.closed.is_set():
            return
        self.closed.set()
        self._wake_scheduler.set()
        self._wake_discovery.set()
        with self._condition:
            self._condition.notify_all()
        with self._lock:
            peers_to_close = list(self._peers.values())
        for peer in peers_to_close:
            peer.close("sessão finalizada")
        self._stop_peer_listener()
        for thread in (self._listener_thread, self._lpd_thread, self._discovery_thread, self._scheduler_thread):
            if thread and thread.is_alive() and thread is not threading.current_thread():
                thread.join(timeout=1.5)
        if remove_cache:
            self.cache.clear()

class TorrentManager:
    def __init__(self, cache_root, settings=None, logger=None):
        self.cache_root = cache_root
        self.settings = settings or {}
        self.logger = logger
        self._lock = threading.RLock()
        self._sessions = {}
        os.makedirs(cache_root, exist_ok=True)

    def get_session(self, magnet_uri):
        descriptor = parse_magnet(magnet_uri)
        key = descriptor["info_hash"].hex()
        with self._lock:
            session = self._sessions.get(key)
            if session is None or session.closed.is_set():
                session = TorrentSession(
                    magnet_uri,
                    self.cache_root,
                    max_peers=self.settings.get("max_peers", 30),
                    buffer_size_mb=self.settings.get("buffer_size_mb", 30),
                    cache_limit_mb=self.settings.get("cache_limit_mb", 512),
                    peer_port=self.settings.get("peer_port", 6881),
                    enable_trackers=self.settings.get("enable_trackers", True),
                    enable_dht=self.settings.get("enable_dht", True),
                    enable_lpd=self.settings.get("enable_lpd", True),
                    local_peer_port=self.settings.get("local_peer_port", 0),
                    logger=self.logger,
                )
                self._sessions[key] = session
            session.last_used = time.monotonic()
        session.start()
        return session

    def get_session_by_info_hash(self, info_hash):
        if not isinstance(info_hash, (bytes, bytearray)):
            return None
        with self._lock:
            return self._sessions.get(bytes(info_hash).hex())

    def stop_session(self, magnet_uri):
        descriptor = parse_magnet(magnet_uri)
        key = descriptor["info_hash"].hex()
        with self._lock:
            session = self._sessions.pop(key, None)
        if session is not None:
            session.close(remove_cache=True)

    def stop_sessions_except(self, magnet_uri):
        """Libera sessões antigas quando outro magnet passa a ser usado.

        Há um único player ativo no Kodi. A sessão do magnet solicitado é
        preservada; as demais são removidas do mapa sob lock e fechadas fora
        dele para não concorrer com scheduler e callbacks de peers.
        """
        descriptor = parse_magnet(magnet_uri)
        keep_key = descriptor["info_hash"].hex()
        with self._lock:
            stale = [(key, session) for key, session in self._sessions.items()
                     if key != keep_key]
            for key, _session in stale:
                self._sessions.pop(key, None)
        for _key, session in stale:
            session.close(remove_cache=True)

    def cleanup_idle(self, idle_seconds=15 * 60):
        now = time.monotonic()
        with self._lock:
            stale = [(key, session) for key, session in self._sessions.items()
                     if now - session.last_used > idle_seconds]
            for key, _session in stale:
                self._sessions.pop(key, None)
        for _key, session in stale:
            session.close(remove_cache=True)

    def close_all(self):
        with self._lock:
            sessions = list(self._sessions.values())
            self._sessions.clear()
        for session in sessions:
            session.close(remove_cache=True)

class PiecesDataWrapper(dict):
    def __init__(self, engine):
        self.engine = engine
    def __len__(self):
        if self.engine.current_session:
            return len(self.engine.current_session.completed_pieces)
        return 0

class TorrentEngine:
    """Fachada do motor BitTorrent com catálogo rápido via API Wasmer.

    A API é utilizada exclusivamente para descobrir a estrutura do conteúdo.
    A metadata BitTorrent completa (incluindo hashes SHA-1 das peças) continua
    sendo recebida e validada via BEP 10 antes de qualquer byte ser enviado ao
    player. Isso evita metadados externos antigos e também evita stream falso.
    """
    def __init__(self):
        self.info_hash = None
        self.files = []
        self.current_session = None
        self.pieces_data = PiecesDataWrapper(self)
        self._catalog_lock = threading.RLock()
        self._catalogs = {}
        self._requested_files = {}
        settings = {}
        try:
            import xbmcvfs
            import xbmcaddon
            addon = xbmcaddon.Addon()
            addon_profile = addon.getAddonInfo("profile")
            if not xbmcvfs.exists(addon_profile):
                xbmcvfs.mkdirs(addon_profile)
            self.cache_dir = xbmcvfs.translatePath(os.path.join(addon_profile, "torrent_cache"))
            try:
                max_peers = int(addon.getSetting("max_peers") or 30)
            except Exception:
                max_peers = 30
            try:
                buffer_size_mb = int(addon.getSetting("buffer_size") or 30)
            except Exception:
                buffer_size_mb = 30
            try:
                peer_port = int(addon.getSetting("peer_port") or 6881)
            except Exception:
                peer_port = 6881
            try:
                local_peer_port = int(addon.getSetting("local_peer_port") or 0)
            except Exception:
                local_peer_port = 0
            settings = {
                "max_peers": max(1, min(max_peers, 30)),
                "buffer_size_mb": max(4, min(buffer_size_mb, 100)),
                "peer_port": max(0, min(peer_port, 65535)),
                "local_peer_port": max(0, min(local_peer_port, 65535)),
            }
        except Exception:
            import tempfile
            self.cache_dir = os.path.join(tempfile.gettempdir(), "puretorrent_cache")
        self.manager = TorrentManager(self.cache_dir, settings=settings, logger=self._log_callback)

    def _log_callback(self, text, level="info"):
        try:
            import xbmc
            level_map = {"debug": xbmc.LOGDEBUG, "warning": xbmc.LOGWARNING, "error": xbmc.LOGERROR}
            xbmc.log(text, level_map.get(level, xbmc.LOGINFO))
        except Exception:
            print(text)

    def log(self, text, level="info"):
        self._log_callback("[TorrentEngine] %s" % text, level)

    @property
    def piece_length(self):
        if self.current_session and self.current_session.metadata_ready.is_set():
            return self.current_session.piece_length
        return 0

    @property
    def total_pieces(self):
        if self.current_session and self.current_session.metadata_ready.is_set():
            return len(self.current_session.piece_hashes)
        return 0

    @property
    def peers(self):
        session = self.current_session
        if session:
            with session._lock:
                return list(session._peers.keys())
        return []

    @staticmethod
    def _catalog_path(value):
        value = _decode_text(value, "").replace(chr(92), "/").strip("/ ")
        parts = [_safe_filename(part) for part in value.split("/") if part and part not in (".", "..")]
        return "/".join(parts) or "arquivo"

    def _open_session(self, magnet_uri):
        self.manager.stop_sessions_except(magnet_uri)
        session = self.manager.get_session(magnet_uri)
        self.current_session = session
        self.info_hash = session.info_hash
        return session

    def _catalog_key(self, session):
        return session.info_hash_hex

    def _merge_api_trackers(self, session, trackers):
        if not isinstance(trackers, list):
            return
        with session._lock:
            known = set(session.trackers)
            for tracker in trackers:
                tracker = _decode_text(tracker, "").strip()
                if tracker and tracker not in known:
                    known.add(tracker)
                    session.trackers.append(tracker)

    def _catalog_record(self, session):
        """Retorna o estado do catálogo e inicia no máximo um worker Wasmer."""
        key = self._catalog_key(session)
        now = time.monotonic()
        worker_needed = False
        with self._catalog_lock:
            record = self._catalogs.get(key)
            if record is None:
                record = {
                    "state": "fetching",
                    "files": [],
                    "error": "",
                    "source": "wasmer",
                    "started": now,
                    "attempts": 1,
                    "retry_after": 0.0,
                }
                self._catalogs[key] = record
                worker_needed = True
            elif record.get("state") == "failed":
                can_retry = (
                    int(record.get("attempts", 1)) < 3
                    and now >= float(record.get("retry_after", 0.0))
                )
                if can_retry:
                    record.update({
                        "state": "fetching",
                        "error": "",
                        "started": now,
                        "attempts": int(record.get("attempts", 1)) + 1,
                    })
                    worker_needed = True
            # ready/fetching retornam imediatamente. Nenhuma requisição HTTP fica
            # presa na thread que atende /list ou /status.
        if worker_needed:
            worker = threading.Thread(
                target=self._fetch_catalog_worker,
                args=(session, key),
                name="PureTorrentWasmer",
                daemon=True,
            )
            worker.start()
        return record

    def _fetch_catalog_worker(self, session, key):
        """Consulta a Wasmer fora do handler HTTP e atualiza um único registro."""
        with self._catalog_lock:
            record = self._catalogs.get(key)
            if record is None or record.get("state") != "fetching":
                return
            started = float(record.get("started", time.monotonic()))
        try:
            query = urllib.parse.urlencode({"magnet": session.magnet_uri})
            request = urllib.request.Request(
                METADATA_API_URL + "?" + query,
                headers={"User-Agent": "PureTorrent/1.0 Kodi"},
            )
            with urllib.request.urlopen(request, timeout=METADATA_API_TIMEOUT_SECONDS) as response:
                raw = response.read(4 * 1024 * 1024 + 1)
            if len(raw) > 4 * 1024 * 1024:
                raise TorrentError("Resposta da API Wasmer excede o limite permitido")
            payload = json.loads(raw.decode("utf-8"))
            if not isinstance(payload, dict) or payload.get("success") is not True:
                raise TorrentError(_decode_text(payload.get("error") if isinstance(payload, dict) else "", "API Wasmer não retornou sucesso"))
            data = payload.get("data")
            if not isinstance(data, dict) or not data.get("metadata_available"):
                raise TorrentError("A API Wasmer não disponibilizou metadata para este magnet")
            returned_hash = _decode_text(data.get("info_hash"), "").lower()
            if returned_hash and returned_hash != key:
                raise TorrentError("A API Wasmer retornou metadata de outro info-hash")
            raw_files = data.get("files")
            if not isinstance(raw_files, list) or not raw_files:
                raise TorrentError("A API Wasmer não retornou arquivos")

            files = []
            next_offset = 0
            for index, entry in enumerate(raw_files):
                if not isinstance(entry, dict):
                    continue
                length = _int(entry.get("length"), -1)
                if length < 0:
                    continue
                offset = _int(entry.get("offset"), next_offset)
                if offset < 0:
                    offset = next_offset
                name = self._catalog_path(entry.get("name"))
                files.append({
                    "index": index,
                    "name": name,
                    "relative_path": name,
                    "basename": name.rsplit("/", 1)[-1],
                    "length": length,
                    "offset": offset,
                })
                next_offset = max(next_offset, offset + length)
            if not files:
                raise TorrentError("A API Wasmer retornou arquivos inválidos")

            # A API agiliza a seleção e adiciona trackers antes da próxima
            # rodada; hashes de peças continuam vindo exclusivamente do BEP 10.
            if not session.closed.is_set():
                self._merge_api_trackers(session, data.get("trackers"))
                try:
                    session.refresh_discovery()
                except Exception:
                    pass

            with self._catalog_lock:
                current = self._catalogs.get(key)
                if current is not record:
                    return
                record.update({
                    "state": "ready",
                    "files": files,
                    "error": "",
                    "total_size": _int(data.get("total_size"), next_offset),
                    "piece_length": _int(data.get("piece_length"), 0),
                    "elapsed": time.monotonic() - started,
                    "retry_after": 0.0,
                })
            self.log("Catálogo Wasmer pronto: %d arquivo(s) em %.2fs." % (len(files), record["elapsed"]), "info")
        except Exception as exc:
            with self._catalog_lock:
                current = self._catalogs.get(key)
                if current is not record:
                    return
                attempts = int(record.get("attempts", 1))
                record.update({
                    "state": "failed",
                    "error": "API Wasmer indisponível: %s" % exc,
                    "elapsed": time.monotonic() - started,
                    "retry_after": time.monotonic() + max(2.0, min(10.0, 2.0 * attempts)),
                })
            self.log(record["error"] + "; mantendo descoberta BitTorrent como contingência.", "warning")

    def _catalog_for(self, session):
        return self._catalog_record(session)

    @staticmethod
    def _is_video(file_info):
        return is_video_name(file_info.get("name", "")) and _int(file_info.get("length"), 0) > 0

    def _visible_files(self, session, catalog):
        if session.metadata_ready.is_set():
            return [dict(item) for item in session.files]
        if catalog.get("state") == "ready":
            return [dict(item) for item in catalog.get("files", [])]
        return []

    def _requested_file(self, session, catalog):
        requested = self._requested_files.get(self._catalog_key(session))
        files = self._visible_files(session, catalog)
        selected = next((item for item in files if requested is not None and item.get("index") == requested), None)
        if selected is not None:
            return selected
        videos = [item for item in files if self._is_video(item)]
        return videos[0] if videos else (files[0] if files else None)

    def _resolve_real_file_index(self, session, catalog, requested_index):
        """Mantém a escolha Wasmer mesmo se a metadata raw vier reordenada."""
        try:
            requested_index = int(requested_index)
        except (TypeError, ValueError):
            raise TorrentError("Índice de arquivo inválido")
        catalog_item = next((item for item in catalog.get("files", []) if int(item.get("index", -1)) == requested_index), None)
        direct = next((item for item in session.files if int(item.get("index", -1)) == requested_index), None)
        if catalog_item is not None:
            wanted_name = str(catalog_item.get("basename", "")).casefold()
            wanted_length = _int(catalog_item.get("length"), -1)
            if direct is not None and str(direct.get("basename", "")).casefold() == wanted_name and _int(direct.get("length"), -2) == wanted_length:
                return int(direct["index"])
            match = next((item for item in session.files if str(item.get("basename", "")).casefold() == wanted_name and _int(item.get("length"), -2) == wanted_length), None)
            if match is not None:
                return int(match["index"])
        if direct is not None:
            return int(direct["index"])
        raise TorrentError("Arquivo escolhido não foi encontrado na metadata BitTorrent")

    def _snapshot(self, session, catalog):
        files = self._visible_files(session, catalog)
        return {
            "files": files,
            "piece_length": session.piece_length if session.metadata_ready.is_set() else 0,
            "total_pieces": len(session.piece_hashes) if session.metadata_ready.is_set() else 0,
            "metadata_ready": session.metadata_ready.is_set(),
            "catalog_ready": catalog.get("state") == "ready",
            "source": "bittorrent" if session.metadata_ready.is_set() else catalog.get("source", "pending"),
            "catalog_error": catalog.get("error", ""),
        }

    def load_magnet(self, magnet_uri, monitor=None, wait_metadata=True, metadata_timeout=180.0):
        session = self._open_session(magnet_uri)
        catalog = self._catalog_for(session)
        session.request_http_metadata_once()
        if not wait_metadata:
            snapshot = self._snapshot(session, catalog)
            self.files = snapshot["files"]
            return snapshot
        deadline = time.monotonic() + max(5.0, float(metadata_timeout))
        last_log = 0.0
        while not session.metadata_ready.is_set():
            if monitor and hasattr(monitor, "isAborted") and monitor.isAborted():
                raise TorrentError("Operação cancelada pelo usuário")
            if session.closed.is_set():
                raise TorrentError("Sessão encerrada antes de preparar o conteúdo")
            if session.error:
                raise TorrentError(session.error)
            now = time.monotonic()
            if now >= deadline:
                with session._lock:
                    connected = sum(1 for peer in session._peers.values() if peer.connected)
                if connected:
                    raise TorrentError("Peers conectados não forneceram a metadata BitTorrent necessária para o stream")
                raise TorrentError("Nenhum peer BitTorrent ativo forneceu a metadata de integridade do conteúdo")
            if now - last_log >= 5.0:
                self.log("Aguardando metadata BitTorrent de integridade; catálogo=%s peers=%d" % (
                    catalog.get("state"), sum(1 for peer in list(session._peers.values()) if peer.connected)
                ))
                last_log = now
            session.metadata_ready.wait(min(0.5, max(0.05, deadline - now)))
        requested = self._requested_files.get(self._catalog_key(session))
        if requested is not None:
            resolved = self._resolve_real_file_index(session, catalog, requested)
            session.select_video_file(resolved)
        self.files = session.files
        return self._snapshot(session, catalog)

    def get_status(self, magnet_uri, file_index=None):
        session = self._open_session(magnet_uri)
        catalog = self._catalog_for(session)
        # /status é chamado enquanto a UI aguarda o buffer. Ele precisa iniciar
        # a metadata canônica, não apenas listar peers dos trackers.
        session.request_http_metadata_once()
        if file_index is not None:
            try:
                file_index = int(file_index)
            except (TypeError, ValueError):
                raise TorrentError("Índice de arquivo inválido")
            if catalog.get("state") == "ready" and not any(int(item.get("index", -1)) == file_index for item in catalog.get("files", [])) and not session.metadata_ready.is_set():
                raise TorrentError("Arquivo selecionado não existe no catálogo")
            self._requested_files[self._catalog_key(session)] = file_index
        if session.metadata_ready.is_set():
            requested = self._requested_files.get(self._catalog_key(session))
            if requested is not None:
                resolved = self._resolve_real_file_index(session, catalog, requested)
                session.select_video_file(resolved)
            data = session.status()
            data["catalog_ready"] = catalog.get("state") == "ready"
            data["catalog_source"] = catalog.get("source", "")
            data["catalog_error"] = catalog.get("error", "")
            return data
        selected = self._requested_file(session, catalog)
        with session._lock:
            peers = sum(1 for peer in session._peers.values() if peer.connected)
        return {
            "state": "preparando torrent" if catalog.get("state") == "ready" else "catalogando",
            "error": "",
            "catalog_error": catalog.get("error", ""),
            "catalog_ready": catalog.get("state") == "ready",
            "catalog_source": catalog.get("source", ""),
            "metadata_ready": False,
            "metadata_source": "",
            "metadata_resolution": getattr(session, "metadata_resolution_state", "preparando metadata"),
            "bytes_buffered": 0,
            "buffer_target": session.buffer_size_bytes,
            "peers": peers,
            "active_peers": 0,
            "speed_bps": 0,
            "file_name": selected.get("name") if selected else session.display_name,
            "file_size": selected.get("length", 0) if selected else 0,
            "selected_file_index": selected.get("index") if selected else None,
            "primary_video_count": len([item for item in self._visible_files(session, catalog) if self._is_video(item)]),
            "discovery": session.discovery_status,
            "discovery_round": session.discovery_round,
            "tracker_peers": session.tracker_peer_count,
            "dht_peers": session.dht_peer_count,
            "lpd_peers": session.lpd_peer_count,
            "pex_peers": session.pex_peer_count,
            "queued_peers": len(session._candidate_peers),
        }

    def select_file(self, magnet_uri, file_index):
        session = self._open_session(magnet_uri)
        key = self._catalog_key(session)
        self._requested_files[key] = int(file_index)
        if not session.metadata_ready.is_set():
            raise TorrentError("Metadata BitTorrent ainda não está pronta")
        catalog = self._catalog_for(session)
        resolved = self._resolve_real_file_index(session, catalog, file_index)
        return session.select_video_file(resolved)

    def get_stream_file(self, magnet_uri):
        """Retorna o arquivo canônico selecionado para o servidor HTTP.

        A interface pode mostrar o catálogo rápido da Wasmer, cuja numeração e
        ordenação podem diferir do metadado BitTorrent. Já a leitura de peças
        precisa obrigatoriamente do ``offset`` validado pelo metadado canônico.
        Esta rota interna evita que um objeto público, sem offset, chegue ao
        loop de streaming.
        """
        session = self._open_session(magnet_uri)
        if not session.metadata_ready.is_set():
            raise TorrentError("Metadata BitTorrent ainda não está pronta")
        with session._lock:
            selected = session.selected_file
            if not selected:
                raise TorrentError("Nenhum arquivo foi selecionado para o stream")
            return dict(selected)

    def stop_session(self, magnet_uri):
        try:
            key = parse_magnet(magnet_uri)["info_hash"].hex()
        except Exception:
            key = None
        self.manager.stop_session(magnet_uri)
        with self._catalog_lock:
            if key:
                self._requested_files.pop(key, None)
                self._catalogs.pop(key, None)
        if self.current_session is not None and key and self.current_session.info_hash_hex == key:
            self.current_session = None
            self.files = []
            self.info_hash = None

    def begin_stream_request(self, magnet_uri, file_index, file_position, length, explicit_range=False):
        session = self._open_session(magnet_uri)
        if not session.metadata_ready.is_set():
            raise TorrentError("Metadata BitTorrent ainda não está pronta")
        # file_position é relativo ao arquivo HTTP selecionado.
        selected = session.selected_file
        if not selected:
            raise TorrentError("Nenhum arquivo foi selecionado para o stream")
        return session.begin_stream_request(
            int(selected["offset"]) + int(file_position),
            int(length),
            explicit_range=bool(explicit_range),
        )

    def end_stream_request(self, magnet_uri, stream_request):
        try:
            session = self._open_session(magnet_uri)
            session.end_stream_request(stream_request)
        except Exception:
            # A conexão HTTP já está sendo finalizada; nunca mantenha um token
            # pendente por causa de erro de limpeza.
            pass

    def get_file_bytes(self, offset, length, monitor=None, stream_request=None):
        session = self.current_session
        if session is None or not session.metadata_ready.is_set():
            raise TorrentError("Stream solicitado antes da metadata BitTorrent estar pronta")
        if length <= 0:
            return b""
        target = next((item for item in session.files if item["offset"] <= offset < item["offset"] + item["length"]), None)
        if target is None:
            raise TorrentError("Offset de stream fora do arquivo")
        file_position = offset - target["offset"]
        if session.selected_file is None or session.selected_file.get("index") != target.get("index"):
            session.select_video_file(target["index"])
        return session.read_file_range(file_position, length, timeout_per_piece=75.0, stream_request=stream_request)

    def cleanup_idle(self, idle_seconds=15 * 60):
        self.manager.cleanup_idle(idle_seconds)
        if self.current_session is not None and self.current_session.closed.is_set():
            self.current_session = None
            self.files = []
            self.info_hash = None

    def close_all(self):
        self.manager.close_all()
        with self._catalog_lock:
            self._catalogs.clear()
            self._requested_files.clear()
        self.current_session = None
        self.files = []
        self.info_hash = None
