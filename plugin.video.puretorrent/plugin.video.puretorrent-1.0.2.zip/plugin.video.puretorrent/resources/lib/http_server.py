# -*- coding: utf-8 -*-
"""Servidor HTTP local do PureTorrent.

Expõe catálogo, status, stream e encerramento de sessão somente no loopback.
As respostas são deliberadamente honestas: nenhum byte artificial é enviado ao
player quando a rede BitTorrent não fornece uma peça válida.
"""

import json
import os
import re
import socket
import threading
import time
import urllib.parse

from resources.lib.torrent_engine import TorrentEngine, TorrentError
from resources.lib.media_types import is_video_name, media_mime_type

_active_server_socket = None


class RangeNotSatisfiable(Exception):
    pass


def _open_stream_socket(preferred_port):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        server_socket.bind(("127.0.0.1", int(preferred_port)))
        return server_socket, int(preferred_port)
    except OSError as preferred_error:
        try:
            server_socket.bind(("127.0.0.1", 0))
            active_port = int(server_socket.getsockname()[1])
            print("[PureTorrent] Porta %s indisponível (%s); usando %d." % (preferred_port, preferred_error, active_port))
            return server_socket, active_port
        except OSError as fallback_error:
            try:
                server_socket.close()
            except OSError:
                pass
            print("[PureTorrent] Falha ao abrir servidor local: %s" % fallback_error)
            return None, None


def _send_response(conn, status, headers=None, body=b""):
    headers = list(headers or [])
    if isinstance(body, str):
        body = body.encode("utf-8")
    reason = {
        200: "OK",
        206: "Partial Content",
        400: "Bad Request",
        404: "Not Found",
        416: "Range Not Satisfiable",
        503: "Service Unavailable",
    }.get(int(status), "Error")
    has_length = any(str(header).lower().startswith("content-length:") for header in headers)
    if not has_length:
        headers.append("Content-Length: %d" % len(body))
    headers.extend(["Connection: close", "Cache-Control: no-cache"])
    raw = "HTTP/1.1 %d %s\r\n%s\r\n\r\n" % (int(status), reason, "\r\n".join(headers))
    conn.sendall(raw.encode("ascii") + body)


def _send_json(conn, status, payload, extra_headers=None):
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    headers = [
        "Server: PureTorrent",
        "Content-Type: application/json; charset=utf-8",
        "Content-Length: %d" % len(body),
    ]
    if extra_headers:
        headers.extend(extra_headers)
    _send_response(conn, status, headers, body)


def send_http_error(conn, code, message, extra_headers=None):
    _send_json(conn, code, {"error": str(message)}, extra_headers)


def _parse_request(conn):
    conn.settimeout(12.0)
    request_data = b""
    marker = b"\r\n\r\n"
    while marker not in request_data and len(request_data) < 65536:
        chunk = conn.recv(4096)
        if not chunk:
            break
        request_data += chunk
    if not request_data or marker not in request_data:
        raise ValueError("Requisição HTTP incompleta")
    header_bytes = request_data.split(marker, 1)[0]
    lines = header_bytes.decode("iso-8859-1", "replace").split("\r\n")
    first = lines[0].split()
    if len(first) != 3 or first[0] not in ("GET", "HEAD"):
        raise ValueError("Método HTTP não suportado")
    method, target, _version = first
    target_parts = urllib.parse.urlsplit(target)
    params = dict(urllib.parse.parse_qsl(target_parts.query, keep_blank_values=True))
    headers = {}
    for line in lines[1:]:
        if ":" in line:
            key, value = line.split(":", 1)
            headers[key.strip().lower()] = value.strip()
    return method, target_parts.path or "/", params, headers


def _parse_range_header(value, file_size):
    if file_size <= 0:
        raise RangeNotSatisfiable("Arquivo vazio")
    if not value:
        return 0, file_size - 1, False
    value = value.strip()
    match = re.match(r"^bytes\s*=\s*(.+)$", value, re.IGNORECASE)
    if not match:
        raise RangeNotSatisfiable("Cabeçalho Range inválido")
    spec = match.group(1).strip()
    if "," in spec or "-" not in spec:
        raise RangeNotSatisfiable("Range múltiplo não suportado")
    start_text, end_text = [part.strip() for part in spec.split("-", 1)]
    if not start_text:
        if not end_text.isdigit() or int(end_text) <= 0:
            raise RangeNotSatisfiable("Range sufixado inválido")
        suffix = min(int(end_text), file_size)
        return file_size - suffix, file_size - 1, True
    if not start_text.isdigit():
        raise RangeNotSatisfiable("Início do Range inválido")
    start = int(start_text)
    if start >= file_size:
        raise RangeNotSatisfiable("Range fora do arquivo")
    if end_text:
        if not end_text.isdigit():
            raise RangeNotSatisfiable("Fim do Range inválido")
        end = min(int(end_text), file_size - 1)
        if end < start:
            raise RangeNotSatisfiable("Range invertido")
    else:
        end = file_size - 1
    return start, end, True


def _mime_type(file_name):
    """MIME centralizado para que MKV/AVI e demais containers não caiam em genérico."""
    return media_mime_type(file_name)


def _find_file(files, file_index):
    if file_index is not None:
        try:
            expected = int(file_index)
        except (TypeError, ValueError):
            raise TorrentError("Índice de arquivo inválido")
        selected = next((item for item in files if int(item.get("index", -1)) == expected), None)
        if selected is None:
            raise TorrentError("Arquivo selecionado não existe neste torrent")
        return selected
    videos = [item for item in files if is_video_name(item.get("name", ""))]
    if videos:
        return max(videos, key=lambda item: int(item.get("length", 0)))
    return max(files, key=lambda item: int(item.get("length", 0))) if files else None


def start_stream_server(preferred_port, service_monitor, instance_token=None):
    global _active_server_socket
    server_socket, active_port = _open_stream_socket(preferred_port)
    if not server_socket:
        return
    try:
        server_socket.listen(10)
        server_socket.settimeout(1.0)
        _active_server_socket = server_socket
    except Exception as exc:
        try:
            server_socket.close()
        except OSError:
            pass
        print("[PureTorrent] Não foi possível iniciar listener HTTP: %s" % exc)
        return

    if hasattr(service_monitor, "on_stream_server_bound"):
        try:
            service_monitor.on_stream_server_bound(active_port, instance_token)
        except Exception as exc:
            print("[PureTorrent] Falha ao publicar endpoint HTTP: %s" % exc)

    engine = TorrentEngine()
    last_cleanup = time.monotonic()
    print("[PureTorrent] Servidor HTTP local ativo em 127.0.0.1:%d" % active_port)
    try:
        while service_monitor.running:
            try:
                client_conn, _client_addr = server_socket.accept()
            except socket.timeout:
                if time.monotonic() - last_cleanup >= 60.0:
                    engine.cleanup_idle(15 * 60)
                    last_cleanup = time.monotonic()
                continue
            except OSError:
                if not service_monitor.running:
                    break
                continue
            worker = threading.Thread(
                target=handle_client_request,
                args=(client_conn, engine, service_monitor, instance_token),
                name="PureTorrentHTTP",
                daemon=True,
            )
            worker.start()
    finally:
        try:
            server_socket.close()
        except OSError:
            pass
        if _active_server_socket is server_socket:
            _active_server_socket = None
        engine.close_all()
        if hasattr(service_monitor, "on_stream_server_stopped"):
            try:
                service_monitor.on_stream_server_stopped(active_port, instance_token)
            except Exception:
                pass


def stop_stream_server():
    global _active_server_socket
    server_socket = _active_server_socket
    _active_server_socket = None
    if server_socket is None:
        return
    try:
        server_socket.shutdown(socket.SHUT_RDWR)
    except OSError:
        pass
    try:
        server_socket.close()
    except OSError:
        pass


def handle_client_request(conn, engine, monitor, instance_token=None):
    response_started = False
    stream_ticket = None
    stream_magnet = None
    stream_range = None
    try:
        method, path, query, request_headers = _parse_request(conn)
        # O timeout curto é necessário apenas para montar o cabeçalho HTTP.
        # Durante o stream o Kodi pode aguardar uma peça válida por mais tempo;
        # manter 12s no socket derruba a resposta local antes do motor concluir.
        conn.settimeout(None)
        if path.rstrip("/") == "/health":
            if not instance_token or query.get("token") != instance_token:
                send_http_error(conn, 404, "Servidor PureTorrent não encontrado")
                return
            _send_json(conn, 200, {"service": "puretorrent", "instance": instance_token}, ["X-PureTorrent-Instance: %s" % instance_token])
            return

        magnet = query.get("magnet")
        if not magnet:
            send_http_error(conn, 400, "Parâmetro magnet ausente")
            return

        normalized_path = path.rstrip("/") or "/"
        if normalized_path == "/list":
            info = engine.load_magnet(magnet, monitor, wait_metadata=False)
            files = info.get("files", [])
            state = "ready" if files else "pending"
            _send_json(conn, 200, {
                "state": state,
                "files": files,
                "metadata_ready": bool(info.get("metadata_ready")),
                "catalog_ready": bool(info.get("catalog_ready")),
                "source": info.get("source", "pending"),
                "catalog_error": info.get("catalog_error", ""),
            })
            return

        if normalized_path == "/status":
            status = engine.get_status(magnet, query.get("file_idx"))
            _send_json(conn, 200, status)
            return

        if normalized_path == "/stop":
            engine.stop_session(magnet)
            _send_json(conn, 200, {"status": "stopped"})
            return

        if normalized_path != "/stream":
            send_http_error(conn, 404, "Rota não encontrada")
            return

        info = engine.load_magnet(magnet, monitor, wait_metadata=True, metadata_timeout=180.0)
        selected = _find_file(info.get("files", []), query.get("file_idx"))
        if selected is None:
            raise TorrentError("Nenhum arquivo reproduzível encontrado")
        # A resposta raw pode ter ordem diferente do catálogo Wasmer. O motor
        # resolve pelo nome+tamanho quando necessário e devolve o arquivo real.
        engine.select_file(magnet, query.get("file_idx", selected.get("index")))
        selected = engine.get_stream_file(magnet)
        file_size = int(selected.get("length", 0))
        if file_size <= 0:
            raise TorrentError("Arquivo selecionado tem tamanho inválido")
        try:
            range_start, range_end, partial = _parse_range_header(request_headers.get("range"), file_size)
        except RangeNotSatisfiable as exc:
            send_http_error(conn, 416, str(exc), ["Content-Range: bytes */%d" % file_size])
            return

        content_length = range_end - range_start + 1
        headers = [
            "Server: PureTorrent",
            "Content-Type: %s" % _mime_type(selected.get("name", "")),
            "Content-Length: %d" % content_length,
            "Accept-Ranges: bytes",
        ]
        status = 206 if partial else 200
        if partial:
            headers.append("Content-Range: bytes %d-%d/%d" % (range_start, range_end, file_size))

        if method == "HEAD":
            _send_response(conn, status, headers, b"")
            return

        # Cada conexão mantém sua própria demanda. Um Range explícito do Kodi
        # passa à frente do GET sequencial que já possa estar aberto.
        stream_magnet = magnet
        stream_range = (range_start, range_end)
        stream_ticket = engine.begin_stream_request(
            magnet,
            query.get("file_idx", selected.get("index")),
            range_start,
            content_length,
            explicit_range=partial,
        )
        if partial and range_start > 0:
            print("[PureTorrent] Range prioritário solicitado: %d-%d/%d" % (range_start, range_end, file_size))

        # Não anuncie um corpo de vídeo até possuir o primeiro bloco real.
        # Isto evita "source read hit eof" quando o Kodi abre um Range distante
        # e a peça ainda está entrando pelo BitTorrent.
        chunk_size = 256 * 1024
        first_amount = min(chunk_size, content_length)
        first_data = engine.get_file_bytes(
            int(selected["offset"]) + range_start,
            first_amount,
            monitor,
            stream_request=stream_ticket,
        )
        if not first_data:
            raise TorrentError("Motor não retornou bytes válidos para o primeiro bloco")

        _send_response(conn, status, headers, b"")
        response_started = True
        conn.sendall(first_data)
        remaining = content_length - len(first_data)
        position = range_start + len(first_data)
        while remaining > 0 and monitor.running:
            amount = min(chunk_size, remaining)
            data = engine.get_file_bytes(
                int(selected["offset"]) + position,
                amount,
                monitor,
                stream_request=stream_ticket,
            )
            if not data:
                raise TorrentError("Motor não retornou bytes válidos")
            conn.sendall(data)
            remaining -= len(data)
            position += len(data)
    except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
        pass
    except Exception as exc:
        if not response_started:
            try:
                send_http_error(conn, 503, "Falha no stream: %s" % exc)
            except Exception:
                pass
        detail = ""
        if stream_range:
            detail = " [range %d-%d]" % stream_range
        print("[PureTorrent] Erro na requisição HTTP%s: %s" % (detail, exc))
    finally:
        if stream_ticket and stream_magnet:
            try:
                engine.end_stream_request(stream_magnet, stream_ticket)
            except Exception:
                pass
        try:
            conn.close()
        except OSError:
            pass
